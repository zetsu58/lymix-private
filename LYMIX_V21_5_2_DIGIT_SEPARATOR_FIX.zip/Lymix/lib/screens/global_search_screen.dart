import 'dart:async';
import 'package:flutter/material.dart';
import '../core/api_client.dart';
import '../theme/lymix_theme.dart';
import '../widgets/lymix_states.dart';
import 'room_screen.dart';

class GlobalSearchScreen extends StatefulWidget {
  const GlobalSearchScreen({super.key});
  @override State<GlobalSearchScreen> createState()=>_GlobalSearchScreenState();
}

class _GlobalSearchScreenState extends State<GlobalSearchScreen>{
  final controller=TextEditingController();
  Timer? debounce;
  bool loading=false;
  String? error;
  List<Map<String,dynamic>> users=[];
  List<Map<String,dynamic>> rooms=[];
  final recent=<String>[];

  @override void dispose(){debounce?.cancel();controller.dispose();super.dispose();}

  void _changed(String value){
    debounce?.cancel();
    debounce=Timer(const Duration(milliseconds:280),()=>_search(value));
  }

  Future<void> _search(String value) async{
    final q=value.trim();
    if(q.isEmpty){setState((){users=[];rooms=[];loading=false;error=null;});return;}
    setState((){loading=true;error=null;});
    try{
      final raw=await const ApiClient().getJson('/api/discovery/search?q=${Uri.encodeQueryComponent(q)}&limit=20');
      final map=Map<String,dynamic>.from(raw as Map);
      if(!mounted)return;
      setState((){
        users=(map['users'] as List? ?? const[]).map((e)=>Map<String,dynamic>.from(e as Map)).toList();
        rooms=(map['rooms'] as List? ?? const[]).map((e)=>Map<String,dynamic>.from(e as Map)).toList();
        loading=false;
      });
    }catch(e){if(mounted)setState((){loading=false;error=e.toString();});}
  }

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Ara')),
    body:ListView(
      padding:const EdgeInsets.fromLTRB(16,8,16,28),
      children:[
        TextField(
          controller:controller,
          autofocus:true,
          onChanged:_changed,
          textInputAction:TextInputAction.search,
          decoration:InputDecoration(
            prefixIcon:const Icon(Icons.search_rounded),
            hintText:'Kullanıcı, oda, ID veya kategori ara',
            suffixIcon:controller.text.isEmpty?null:IconButton(onPressed:(){controller.clear();_changed('');setState((){});},icon:const Icon(Icons.close_rounded)),
          ),
        ),
        const SizedBox(height:14),
        if(controller.text.trim().isEmpty)...[
          const Text('Son aramalar',style:TextStyle(fontSize:13,fontWeight:FontWeight.w900)),
          const SizedBox(height:8),
          Wrap(spacing:7,runSpacing:7,children:recent.map((q)=>ActionChip(label:Text(q),avatar:const Icon(Icons.history_rounded,size:15),onPressed:(){controller.text=q;_search(q);})).toList()),
          const SizedBox(height:20),
          const Text('Popüler aramalar',style:TextStyle(fontSize:13,fontWeight:FontWeight.w900)),
          const SizedBox(height:8),
          Wrap(spacing:7,runSpacing:7,children:['Sohbet','Müzik','Oyun','Yeni','VIP'].map((q)=>ActionChip(label:Text(q),avatar:const Icon(Icons.trending_up_rounded,size:15),onPressed:(){controller.text=q;_search(q);})).toList()),
        ] else if(loading)
          const LymixLoadingCard(label:'En uygun sonuçlar aranıyor...')
        else if(error!=null)
          LymixStateCard(icon:Icons.search_off_rounded,title:'Arama yapılamadı',message:error!,actionLabel:'Tekrar dene',onAction:()=>_search(controller.text))
        else if(users.isEmpty&&rooms.isEmpty)
          const LymixStateCard(icon:Icons.manage_search_rounded,title:'Sonuç bulunamadı',message:'Farklı bir kelime, kullanıcı ID’si veya daha kısa bir arama deneyebilirsin.')
        else ...[
          if(rooms.isNotEmpty)...[
            const Text('Odalar',style:TextStyle(fontSize:13,fontWeight:FontWeight.w900)),
            const SizedBox(height:7),
            ...rooms.map((r)=>_room(r)),
            const SizedBox(height:15),
          ],
          if(users.isNotEmpty)...[
            const Text('Kullanıcılar',style:TextStyle(fontSize:13,fontWeight:FontWeight.w900)),
            const SizedBox(height:7),
            ...users.map(_user),
          ],
        ],
      ],
    ),
  );

  Widget _room(Map<String,dynamic> r)=>Container(
    margin:const EdgeInsets.only(bottom:8),
    decoration:BoxDecoration(color:LymixColors.surface,borderRadius:BorderRadius.circular(17),border:Border.all(color:Colors.white.withValues(alpha: .05))),
    child:ListTile(
      onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>LymixRoomScreen(roomId:r['roomId'].toString(),roomTitle:r['title'].toString()))),
      leading:Container(width:42,height:42,decoration:BoxDecoration(color:Color(0x14FFD643),borderRadius:BorderRadius.circular(13)),child:const Icon(Icons.mic_none_rounded,color:LymixColors.gold)),
      title:Text(r['title'].toString(),style:const TextStyle(fontWeight:FontWeight.w800,fontSize:11.5)),
      subtitle:Text('${r['listeners']??0} dinleyici • kalite ${(r['quality'] as num?)?.toStringAsFixed(0)??'0'}',style:const TextStyle(color:Colors.white38,fontSize:9)),
      trailing:const Icon(Icons.chevron_right_rounded,color:Colors.white30),
    ),
  );

  Widget _user(Map<String,dynamic> u)=>Container(
    margin:const EdgeInsets.only(bottom:8),
    decoration:BoxDecoration(color:LymixColors.surface,borderRadius:BorderRadius.circular(17),border:Border.all(color:Colors.white.withValues(alpha: .05))),
    child:ListTile(
      leading:CircleAvatar(backgroundColor:const Color(0xFF251A31),child:Text(u['name'].toString().isEmpty?'?':u['name'].toString().substring(0,1).toUpperCase())),
      title:Text(u['name'].toString(),style:const TextStyle(fontWeight:FontWeight.w800,fontSize:11.5)),
      subtitle:Text('ID ${u['userId']} • VIP ${u['vip']??0}',style:const TextStyle(color:Colors.white38,fontSize:9)),
      trailing:OutlinedButton(onPressed:(){},child:const Text('Profil')),
    ),
  );
}
