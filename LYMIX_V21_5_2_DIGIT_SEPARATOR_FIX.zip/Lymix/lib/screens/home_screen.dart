import 'package:flutter/material.dart';
import 'room_screen.dart';
import 'game_center_screen.dart';
import 'feature_center_screen.dart';
import 'feed_screen.dart';
import 'vip_center_screen.dart';
import '../services/app_permission_service.dart';
import 'permission_center_screen.dart';
import 'coin_store_screen.dart';
import 'agency_family_screen.dart';
import 'profile_identity_screen.dart';
import 'app_settings_screen.dart';
import 'notification_center_screen.dart';
import 'privacy_center_screen.dart';
import 'global_search_screen.dart';
import '../theme/lymix_theme.dart';
import '../widgets/user_identity_name.dart';
import '../widgets/lymix_states.dart';

class LymixHomeScreen extends StatefulWidget {
  const LymixHomeScreen({super.key});

  @override
  State<LymixHomeScreen> createState() => _LymixHomeScreenState();
}

class _LymixHomeScreenState extends State<LymixHomeScreen> {
  int tab = 0;
  final colors = const [LymixColors.gold, LymixColors.amber, LymixColors.pink, LymixColors.purple];

  final rooms = const <Map<String, dynamic>>[];

  @override
  Widget build(BuildContext context) {
    final pages = [_home(), _discover(), _party(), _notifications(), _profile()];
    return Scaffold(
      backgroundColor: const Color(0xFF090611),
      body: SafeArea(child: pages[tab]),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF0E0A15),
        indicatorColor: const Color(0x22FFD643),
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Ana Sayfa'),
          NavigationDestination(icon: Icon(Icons.explore_outlined), selectedIcon: Icon(Icons.explore), label: 'Keşfet'),
          NavigationDestination(icon: Icon(Icons.mic_none), selectedIcon: Icon(Icons.mic), label: 'Parti'),
          NavigationDestination(icon: Icon(Icons.notifications_none), selectedIcon: Icon(Icons.notifications), label: 'Bildirim'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profil'),
        ],
      ),
    );
  }

  Widget _header() => Padding(
    padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
    child: Row(children: [
      Image.asset('assets/branding/lymix_logo_horizontal.png', width: 118, height: 34, fit: BoxFit.contain),
      const Spacer(),
      _iconButton(Icons.search, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const GlobalSearchScreen()))),
      const SizedBox(width: 8),
      _iconButton(Icons.chat_bubble_outline, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AgencyFamilyScreen()))),
      const SizedBox(width: 8),
      _iconButton(Icons.account_balance_wallet_outlined, _showWallet),
    ]),
  );

  Widget _iconButton(IconData icon, VoidCallback onTap) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(14),
    child: Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(color: Colors.white.withValues(alpha: .07), borderRadius: BorderRadius.circular(14)),
      child: Icon(icon, color: Colors.white),
    ),
  );

  Widget _home() => SingleChildScrollView(
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      _header(),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: _hero(),
      ),
      const SizedBox(height: 14),
      _flowBar(),
      const SizedBox(height: 20),
      _sectionTitle('Sana Özel Odalar', 'Tümünü Gör'),
      SizedBox(height: 182, child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        scrollDirection: Axis.horizontal,
        itemCount: rooms.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (_, i) => _roomCard(rooms[i], wide: true),
      )),
      const SizedBox(height: 22),
      _sectionTitle('Anlar', 'Daha Fazla'),
      _moments(),
      const SizedBox(height: 22),
      _sectionTitle('Akıllı Eşleşmeler', 'Yenile'),
      _matches(),
      const SizedBox(height: 30),
    ]),
  );

  Widget _flowBar() => SizedBox(
    height: 58,
    child: ListView(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      scrollDirection: Axis.horizontal,
      children: [
        _flowChip('🔥', 'Akış', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const FeedScreen()))),
        _flowChip('🎉', 'Etkinlik', () => _showInfo('Etkinlik', 'Günlük görevler, sezonlar ve oda etkinlikleri.')),
        _flowChip('🎮', 'Oyunlar', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const GameCenterScreen()))),
        _flowChip('👑', 'VIP', _showVip),
        _flowChip('🏆', 'Rozet', () => _showInfo('Rozetler', 'Oyun başarıları ve sezon derecelerinden kazanılan rozetler.')),
      ],
    ),
  );

  Widget _flowChip(String emoji, String text, VoidCallback onTap) => Padding(
    padding: const EdgeInsets.only(right: 8),
    child: ActionChip(
      onPressed: onTap,
      avatar: Text(emoji),
      label: Text(text),
      backgroundColor: const Color(0xFF191321),
      side: BorderSide(color: Colors.white.withValues(alpha: .06)),
      labelStyle: const TextStyle(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.w600),
    ),
  );

  Widget _hero() => Container(
    height: 170,
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(26),
      gradient: const LinearGradient(colors: [Color(0xFF24152B), Color(0xFF16101E), Color(0xFF231B0B)], begin: Alignment.topLeft, end: Alignment.bottomRight),
      border: Border.all(color: const Color(0x33FFD643)),
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Bugün kiminle\nsohbet edeceksin?', style: TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.w800)),
      const Spacer(),
      Row(children: [
        _gradientButton('Hızlı Eşleş', Icons.auto_awesome, () => setState(() => tab = 1)),
        const SizedBox(width: 10),
        OutlinedButton.icon(
          onPressed: () => setState(() => tab = 2),
          icon: const Icon(Icons.mic, size: 17),
          label: const Text('Parti Odaları'),
          style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: BorderSide(color: Colors.white.withValues(alpha: .20)), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
        )
      ])
    ]),
  );

  Widget _gradientButton(String text, IconData icon, VoidCallback onTap) => DecoratedBox(
    decoration: BoxDecoration(gradient: LymixColors.brandGradient, borderRadius: BorderRadius.circular(14), boxShadow: const [BoxShadow(color: Color(0x228A2BE2), blurRadius: 16, offset: Offset(0,8))]),
    child: ElevatedButton.icon(
      onPressed: onTap, icon: Icon(icon, size: 17), label: Text(text),
      style: ElevatedButton.styleFrom(backgroundColor: Colors.transparent, shadowColor: Colors.transparent, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
    ),
  );

  Widget _sectionTitle(String title, String action) => Padding(
    padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
    child: Row(children: [
      Text(title, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
      const Spacer(),
      Text(action, style: const TextStyle(color: LymixColors.gold, fontSize: 12, fontWeight: FontWeight.w700)),
    ]),
  );

  Widget _roomCard(Map<String, dynamic> r, {bool wide = false}) => GestureDetector(
    onTap: () async {
      final granted = await AppPermissionService.requestMicrophoneForRoom();
      if (!context.mounted) return;
      if (!granted) {
        await showDialog(context: context, builder: (_) => AlertDialog(
          title: const Text('Mikrofon izni gerekli'),
          content: const Text('Sesli odaya katılmak için mikrofon erişimine izin vermelisin. İstersen telefonu dinleyici modunda kullanmaya devam edebilirsin.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('İptal')),
            TextButton(onPressed: () { Navigator.pop(context); Navigator.push(context, MaterialPageRoute(builder: (_) => const PermissionCenterScreen())); }, child: const Text('İzin Merkezi')),
          ],
        ));
        return;
      }
      if (context.mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => LymixRoomScreen(roomId: r['id'], roomTitle: r['title'])));
    },
    child: Container(
      width: wide ? 245 : double.infinity,
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: const Color(0xFF15101F), borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withValues(alpha: .06)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const CircleAvatar(radius: 22, backgroundColor: Color(0xFF2A1840), child: Icon(Icons.graphic_eq_rounded, color: LymixColors.gold)),
          const SizedBox(width: 10),
          Expanded(child: Text(r['title'], maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
          Container(padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4), decoration: BoxDecoration(color: const Color(0x33FF2D55), borderRadius: BorderRadius.circular(8)), child: Text(r['tag'], style: const TextStyle(color: Color(0xFFFF6B86), fontSize: 9))),
        ]),
        const Spacer(),
        Text('@${r['host']}', style: const TextStyle(color: Colors.white54, fontSize: 12)),
        const SizedBox(height: 7),
        Row(children: [const Icon(Icons.headset, color: Colors.white54, size: 14), const SizedBox(width: 4), Text('${r['users']} dinleyici', style: const TextStyle(color: Colors.white70, fontSize: 11)), const Spacer(), const Icon(Icons.chevron_right, color: Colors.white38, size: 18)])
      ]),
    ),
  );

  Widget _moments() => SizedBox(
    height: 118,
    child: ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      scrollDirection: Axis.horizontal, itemCount: 6,
      itemBuilder: (_, i) => Container(
        width: 96, margin: const EdgeInsets.only(right: 10),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), color: const Color(0xFF181120)),
        child: Align(alignment: Alignment.bottomCenter, child: Container(width: double.infinity, padding: const EdgeInsets.all(7), decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Colors.black87])), child: Text('An ${i+1}', style: const TextStyle(color: Colors.white, fontSize: 11)))),
      ),
    ),
  );

  Widget _matches() => Container(
    margin: const EdgeInsets.symmetric(horizontal: 20),
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(color: const Color(0xFF15101F), borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.white10)),
    child: const Row(children: [
      Icon(Icons.person_search_rounded, color: LymixColors.gold),
      SizedBox(width: 12),
      Expanded(child: Text('Gerçek kullanıcılar geldikçe ilgi alanlarına göre eşleşmeler burada görünecek.', style: TextStyle(color: Colors.white60, height: 1.35))),
    ]),
  );

  Widget _discover() => _simplePage(
    title: 'Keşfet',
    subtitle: 'İlgi alanlarına göre insanları bul',
    child: Column(children: [
      _searchBox('İsim, kullanıcı adı veya ilgi alanı ara'),
      const SizedBox(height: 14),
      Wrap(spacing: 8, runSpacing: 8, children: ['Müzik','Oyun','Sohbet','Spor','Film','Gece Kuşları'].map((x) => Chip(label: Text(x), backgroundColor: const Color(0xFF191321), labelStyle: const TextStyle(color: Colors.white70))).toList()),
      const SizedBox(height: 18),
      const LymixStateCard(icon: Icons.people_outline_rounded, title: 'Henüz kullanıcı yok', message: 'Gerçek kullanıcılar kayıt oldukça keşfet sonuçları burada görünecek.'),
    ])
  );

  Widget _searchBox(String hint) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 14), decoration: BoxDecoration(color: const Color(0xFF15101F), borderRadius: BorderRadius.circular(15)),
    child: const TextField(style: TextStyle(color: Colors.white), decoration: InputDecoration(icon: Icon(Icons.search, color: Colors.white54), hintText: 'İsim, kullanıcı adı veya ilgi alanı ara', hintStyle: TextStyle(color: Colors.white38), border: InputBorder.none))
  );

  Widget _personTile(int i) => Container(
    margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(color: const Color(0xFF15101F), borderRadius: BorderRadius.circular(17)),
    child: Row(children: [
      const CircleAvatar(radius: 25, backgroundColor: Color(0xFF2A1840), child: Icon(Icons.person_rounded, color: Colors.white54)),
      const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Text(['Zeynep','Arda','Melis','Bora','Sude'][i], style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)), const SizedBox(width: 6), const Icon(Icons.verified, color: Color(0xFF4DA6FF), size: 15)]),
        const SizedBox(height: 3), Text(['Müzik • İstanbul','Oyun • Ankara','Film • İzmir','Spor • Bursa','Sohbet • Antalya'][i], style: const TextStyle(color: Colors.white54, fontSize: 11)),
      ])),
      _smallAction('Mesaj', Icons.chat_bubble_outline, () {}),
    ]),
  );

  Widget _party() => _simplePage(
    title: 'Parti Odaları',
    subtitle: 'Sesli sohbet, PK ve mini oyunlar',
    child: Column(children: [
      _featureStrip('🎙️', 'Sesli Parti', 'Binlerce konu odası arasından seç', () {}),
      _featureStrip('⚔️', 'PK Savaşı', 'Takımını kur, puan topla, liderlik tablosuna çık', () {}),
      _featureStrip('🎲', 'Mini Oyunlar', 'Ludo ve oda içi oyunlarla sohbeti hareketlendir', () {}),
      const SizedBox(height: 8),
      ...rooms.map((r) => Padding(padding: const EdgeInsets.only(bottom: 10), child: SizedBox(height: 125, child: _roomCard(r)))),
    ])
  );

  Widget _featureStrip(String emoji, String title, String sub, VoidCallback onTap) => InkWell(
    onTap: onTap, borderRadius: BorderRadius.circular(18),
    child: Container(
      margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF171021), Color(0xFF110D18)]), borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.white.withValues(alpha: .05))),
      child: Row(children: [Text(emoji, style: const TextStyle(fontSize: 28)), const SizedBox(width: 13), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)), const SizedBox(height: 3), Text(sub, style: const TextStyle(color: Colors.white54, fontSize: 11))])), const Icon(Icons.chevron_right, color: Colors.white38)])
    )
  );

  Widget _notifications() => _simplePage(
    title: 'Bildirimler',
    subtitle: 'Sosyal, oda ve sistem hareketlerini tek yerde yönet',
    child: Column(children: [
      Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFF1E1427), Color(0xFF100C16)]),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0x33FFD643)),
        ),
        child: Row(children: [
          Container(width: 48, height: 48, decoration: BoxDecoration(color: const Color(0x18FFD643), borderRadius: BorderRadius.circular(15)), child: const Icon(Icons.notifications_active_rounded, color: LymixColors.gold)),
          const SizedBox(width: 12),
          const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Bildirim Merkezi', style: TextStyle(fontWeight: FontWeight.w900)),
            SizedBox(height: 3),
            Text('Kategorilere ayır, okundu olarak işaretle veya istemediklerini kaldır.', style: TextStyle(color: Color(0x73FFFFFF), fontSize: 9.5, height: 1.35)),
          ])),
          IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NotificationCenterScreen())), icon: const Icon(Icons.arrow_forward_rounded)),
        ]),
      ),
      const SizedBox(height: 12),
      const LymixStateCard(icon: Icons.notifications_none_rounded, title: 'Henüz bildirim yok', message: 'Gerçek sosyal, oda ve sistem hareketleri burada görünecek.'),
      const SizedBox(height: 10),
      LymixBrandButton(label: 'Tüm Bildirimleri Aç', icon: Icons.notifications_none_rounded, onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NotificationCenterScreen()))),
    ]),
  );

  Widget _notice(IconData icon, String title, String time) => ListTile(
    contentPadding: const EdgeInsets.symmetric(vertical: 4),
    leading: Container(padding: const EdgeInsets.all(11), decoration: BoxDecoration(color: const Color(0x22FF2D55), borderRadius: BorderRadius.circular(13)), child: Icon(icon, color: LymixColors.gold)),
    title: Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
    subtitle: Text(time, style: const TextStyle(color: Colors.white38, fontSize: 11)),
  );

  Widget _profile() => _simplePage(
    title: 'Profil', subtitle: 'Kişiselleştir ve topluluğunu yönet',
    child: Column(children: [
      Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(gradient: const LinearGradient(colors:[Color(0xFF1B1224),Color(0xFF100D16)]), borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0x33FFD643))), child: Row(children: [
        const CircleAvatar(radius: 38, backgroundColor: Color(0xFF2A1840), child: Icon(Icons.person_rounded, size: 34, color: Colors.white70)),
        const SizedBox(width: 14), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const UserIdentityName(userId:'101',name:'Oda Sahibi',style:TextStyle(color:Colors.white,fontSize:19,fontWeight:FontWeight.bold)),
          const SizedBox(height: 4), const Text('Lymix ID: 101', style: TextStyle(color: Colors.white54, fontSize: 11)),
          const SizedBox(height: 8), Row(children: [const Icon(Icons.workspace_premium, color: Colors.amber, size: 16), const SizedBox(width: 4), const Text('VIP 2 • Lv.26', style: TextStyle(color: Colors.amber, fontSize: 12, fontWeight: FontWeight.bold))]),
          const SizedBox(height: 5), const Text('27 yaş • Atış 420K • Alınan 860K', style: TextStyle(color: Colors.white54, fontSize: 10))
        ])), _smallAction('Düzenle', Icons.edit_outlined, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfileIdentityScreen())))
      ])),
      const SizedBox(height: 14),
      _profileRow(Icons.auto_awesome_rounded, 'Profil Kimliği', 'Kullanıcı adı fontu, kişisel simge ve görünüm', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfileIdentityScreen()))),
      _profileRow(Icons.verified_user_outlined, 'Güvenlik ve Gizlilik', 'Engelleme, raporlama, görünürlük ve iletişim izinleri', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PrivacyCenterScreen()))),
      _profileRow(Icons.workspace_premium_outlined, 'VIP 1–10 • Lymix Crown', 'Yükleme eşiği, çerçeveler ve avantajlar', _showVip),
      _profileRow(Icons.home_work_outlined, 'Kendi Odam', 'Kalıcı kişisel oda • room_101', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LymixRoomScreen(roomId: 'room_101', roomTitle: 'Benim Odam')))),
      _profileRow(Icons.backpack_outlined, 'Sırt Çantası', 'Çerçeve • yüzük • giriş efekti • rozet', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const FeatureCenterScreen()))),
      _profileRow(Icons.favorite_outline, 'İlişki & Yüzük', 'Başlangıç tarihi • gün sayacı • karşılıklı atış', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const FeatureCenterScreen()))),
      _profileRow(Icons.currency_exchange, 'Kota & Elmas Dönüşümü', 'Atışa göre kota çarpanı • elmas → coin', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const FeatureCenterScreen()))),
      _profileRow(Icons.groups_3_outlined, 'Ajans Paneli', 'Yayıncı kota takibi • ajans odası kotası', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const FeatureCenterScreen()))),
      _profileRow(Icons.forum_outlined, 'Ajans Ailesi Mesajları', 'Sınırsız aile üyesi • en fazla 6 ajans admini', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AgencyFamilyScreen()))),
      _profileRow(Icons.sports_esports, 'Oyun Merkezi', '12 oyun • başarı rozeti sistemi', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const GameCenterScreen()))),
      _profileRow(Icons.account_balance_wallet_outlined, 'Cüzdan', '0 Coin • 0 Elmas', _showWallet),
      _profileRow(Icons.settings_outlined, 'Ayarlar', 'Bildirimler, dil, görünüm ve hesap', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AppSettingsScreen()))),
    ])
  );

  Widget _profileRow(IconData icon, String title, String sub, VoidCallback onTap) => ListTile(
    onTap: onTap, contentPadding: const EdgeInsets.symmetric(vertical: 4),
    leading: Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: Colors.white.withValues(alpha: .06), borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: Colors.white70)),
    title: Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)), subtitle: Text(sub, style: const TextStyle(color: Colors.white38, fontSize: 11)),
    trailing: const Icon(Icons.chevron_right, color: Colors.white30),
  );

  Widget _simplePage({required String title, required String subtitle, required Widget child}) => SingleChildScrollView(
    padding: const EdgeInsets.fromLTRB(20, 18, 20, 30),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w800)),
      const SizedBox(height: 4), Text(subtitle, style: const TextStyle(color: Colors.white54, fontSize: 12)),
      const SizedBox(height: 20), child,
    ])
  );

  Widget _smallAction(String text, IconData icon, VoidCallback onTap) => TextButton.icon(
    onPressed: onTap, icon: Icon(icon, size: 14), label: Text(text, style: const TextStyle(fontSize: 11)),
    style: TextButton.styleFrom(foregroundColor: LymixColors.gold, padding: const EdgeInsets.symmetric(horizontal: 8)),
  );

  void _showInfo(String title, String text) => showDialog(
    context: context,
    builder: (_) => AlertDialog(
      backgroundColor: const Color(0xFF1A1027),
      title: Text(title),
      content: Text(text),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Kapat'))],
    ),
  );

  void _showWallet() => showModalBottomSheet(
    context: context, backgroundColor: const Color(0xFF15101F), shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(25))),
    builder: (_) => Padding(padding: const EdgeInsets.all(22), child: Column(mainAxisSize: MainAxisSize.min, children: [
      const Text('Lymix Cüzdan', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 18), Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
        _balance('🪙', '5.000', 'Coin'), _balance('💎', '0', 'Elmas')
      ]), const SizedBox(height: 18),
      _gradientButton('Coin Satın Al', Icons.add_card, () { Navigator.pop(context); Navigator.push(context, MaterialPageRoute(builder: (_) => const CoinStoreScreen())); }),
      const SizedBox(height: 8), const Text('Satın alımlar uygulama mağazası üzerinden güvenli şekilde işlenir.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white38, fontSize: 10)),
    ]))
  );

  Widget _balance(String icon, String value, String label) => Column(children: [Text(icon, style: const TextStyle(fontSize: 28)), const SizedBox(height: 4), Text(value, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)), Text(label, style: const TextStyle(color: Colors.white54, fontSize: 11))]);

  void _showSafety() => showModalBottomSheet(
    context: context, backgroundColor: const Color(0xFF15101F),
    builder: (_) => SafeArea(child: Padding(padding: const EdgeInsets.all(22), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Güvenlik Merkezi', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12), const Text('Rahatsız edici kullanıcıları engelleyebilir, içerikleri raporlayabilir ve profil görünürlüğünü yönetebilirsin.', style: TextStyle(color: Colors.white60)),
      const SizedBox(height: 15), _profileRow(Icons.block, 'Engellenenler', 'Engellediğin hesaplar', () {}), _profileRow(Icons.flag_outlined, 'Raporlarım', 'Gönderdiğin raporların durumu', () {}), _profileRow(Icons.visibility_off_outlined, 'Gizlilik', 'Profil ve mesaj izinleri', () {}),
    ])))
  );


  void _showVip() => Navigator.push(context, MaterialPageRoute(builder: (_) => const VipCenterScreen()));

}
