import 'dart:ui';
import 'package:flutter/material.dart';
import 'lymix_pro_theme.dart';
import 'screens/global_search_screen.dart';
import 'screens/room_screen.dart';
import 'screens/game_center_screen.dart';
import 'screens/vip_center_screen.dart';
import 'screens/app_settings_screen.dart';
import 'screens/coin_store_screen.dart';
import 'screens/notification_center_screen.dart';
import 'screens/gift_catalog_screen.dart';
import 'screens/admin_economy_center_screen.dart';
import 'screens/owner_ops_center_screen.dart';

class LymixProShowcase extends StatefulWidget {
  const LymixProShowcase({super.key});
  @override
  State<LymixProShowcase> createState() => _LymixProShowcaseState();
}

class _LymixProShowcaseState extends State<LymixProShowcase>
    with SingleTickerProviderStateMixin {
  int index = 0;
  late final AnimationController _ambient;

  final List<Widget> pages = const <Widget>[
    DiscoverPage(),
    SocialPage(),
    GameCenterPage(),
    InboxPage(),
    ProfilePage(),
  ];

  @override
  void initState() {
    super.initState();
    _ambient = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _ambient.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: Stack(
        children: [
          AnimatedBuilder(
            animation: _ambient,
            builder: (_, __) {
              final t = _ambient.value;
              return Positioned.fill(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: RadialGradient(
                      center: Alignment(-0.75 + (t * 0.5), -0.9 + (t * 0.25)),
                      radius: 1.25,
                      colors: [
                        LymixPro.purple.withOpacity(0.14 + t * 0.05),
                        LymixPro.deepPurple.withOpacity(0.10),
                        LymixPro.bg,
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
          SafeArea(child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 280),
            switchInCurve: Curves.easeOutCubic,
            switchOutCurve: Curves.easeInCubic,
            child: KeyedSubtree(key: ValueKey(index), child: pages[index]),
          )),
        ],
      ),
      bottomNavigationBar: _GlassNav(
        index: index,
        onChanged: (v) => setState(() => index = v),
      ),
    );
  }
}

class _GlassNav extends StatelessWidget {
  final int index;
  final ValueChanged<int> onChanged;
  const _GlassNav({required this.index, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final items = const <({IconData icon, IconData selectedIcon, String label})>[
      (icon: Icons.home_outlined, selectedIcon: Icons.home_rounded, label: 'Ana Sayfa'),
      (icon: Icons.hub_outlined, selectedIcon: Icons.hub_rounded, label: 'Plaza'),
      (icon: Icons.sports_esports_outlined, selectedIcon: Icons.sports_esports_rounded, label: 'Oyun'),
      (icon: Icons.forum_outlined, selectedIcon: Icons.forum_rounded, label: 'Mesajlar'),
      (icon: Icons.person_outline_rounded, selectedIcon: Icons.person_rounded, label: 'Profil'),
    ];

    return SafeArea(
      top: false,
      minimum: const EdgeInsets.fromLTRB(10, 0, 10, 8),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(30),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
          child: Container(
            height: 76,
            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 7),
            decoration: BoxDecoration(
              color: const Color(0xE8130F1B),
              borderRadius: BorderRadius.circular(30),
              border: Border.all(color: Colors.white.withOpacity(.075)),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(.42),
                  blurRadius: 26,
                  offset: const Offset(0, 10),
                ),
                BoxShadow(
                  color: LymixPro.purple.withOpacity(.08),
                  blurRadius: 30,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: Row(
              children: List.generate(items.length, (i) {
                final selected = i == index;
                final item = items[i];
                return Expanded(
                  child: Semantics(
                    button: true,
                    selected: selected,
                    label: item.label,
                    child: InkWell(
                      borderRadius: BorderRadius.circular(23),
                      onTap: () => onChanged(i),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 260),
                        curve: Curves.easeOutBack,
                        margin: const EdgeInsets.symmetric(horizontal: 2),
                        decoration: BoxDecoration(
                          color: selected ? Colors.white.withOpacity(.045) : Colors.transparent,
                          borderRadius: BorderRadius.circular(23),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            TweenAnimationBuilder<double>(
                              tween: Tween(begin: 1, end: selected ? 1.08 : 1),
                              duration: const Duration(milliseconds: 240),
                              curve: Curves.easeOutBack,
                              builder: (_, scale, child) => Transform.scale(scale: scale, child: child),
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 240),
                                width: 38,
                                height: 38,
                                decoration: BoxDecoration(
                                  gradient: selected ? LymixPro.brandGradient : null,
                                  color: selected ? null : Colors.white.withOpacity(.035),
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: selected
                                        ? LymixPro.yellow.withOpacity(.55)
                                        : Colors.white.withOpacity(.055),
                                  ),
                                  boxShadow: selected
                                      ? [
                                          BoxShadow(
                                            color: LymixPro.yellow.withOpacity(.18),
                                            blurRadius: 14,
                                            spreadRadius: 1,
                                          ),
                                          BoxShadow(
                                            color: LymixPro.purple.withOpacity(.28),
                                            blurRadius: 20,
                                            spreadRadius: 2,
                                          ),
                                        ]
                                      : null,
                                ),
                                child: Icon(
                                  selected ? item.selectedIcon : item.icon,
                                  color: selected ? LymixPro.bg : Colors.white70,
                                  size: selected ? 21 : 20,
                                ),
                              ),
                            ),
                            const SizedBox(height: 3),
                            AnimatedDefaultTextStyle(
                              duration: const Duration(milliseconds: 220),
                              style: TextStyle(
                                fontSize: selected ? 10.5 : 9.5,
                                fontWeight: selected ? FontWeight.w900 : FontWeight.w650,
                                letterSpacing: selected ? .05 : 0,
                                color: selected ? LymixPro.yellow : Colors.white54,
                              ),
                              child: Text(item.label, maxLines: 1, overflow: TextOverflow.fade, softWrap: false),
                            ),
                            AnimatedContainer(
                              duration: const Duration(milliseconds: 220),
                              curve: Curves.easeOut,
                              margin: const EdgeInsets.only(top: 2),
                              width: selected ? 17 : 0,
                              height: 2.2,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(99),
                                gradient: selected ? LymixPro.brandGradient : null,
                                boxShadow: selected
                                    ? [BoxShadow(color: LymixPro.yellow.withOpacity(.45), blurRadius: 7)]
                                    : null,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              }),
            ),
          ),
        ),
      ),
    );
  }
}

class Head extends StatelessWidget {
  final String title;
  const Head(this.title, {super.key});

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(20, 18, 20, 12),
    child: Row(children: [
      ShaderMask(
        shaderCallback: (r) => LymixPro.brandGradient.createShader(r),
        child: const Text('LYMIX', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900, color: Colors.white, letterSpacing: 1.8)),
      ),
      const Spacer(),
      Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
      const SizedBox(width: 12),
      _GlassIconButton(icon: Icons.search_rounded, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const GlobalSearchScreen()))),
    ]),
  );
}

class _GlassIconButton extends StatefulWidget {
  final IconData icon;
  final VoidCallback onTap;
  final Color? color;
  const _GlassIconButton({required this.icon, required this.onTap, this.color});
  @override
  State<_GlassIconButton> createState() => _GlassIconButtonState();
}

class _GlassIconButtonState extends State<_GlassIconButton> {
  bool down = false;
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTapDown: (_) => setState(() => down = true),
    onTapCancel: () => setState(() => down = false),
    onTapUp: (_) => setState(() => down = false),
    onTap: widget.onTap,
    child: AnimatedScale(
      scale: down ? 0.90 : 1,
      duration: const Duration(milliseconds: 110),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
          child: Container(
            width: 48, height: 48,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.06),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: Colors.white.withOpacity(0.08)),
            ),
            child: Icon(widget.icon, color: widget.color ?? Colors.white),
          ),
        ),
      ),
    ),
  );
}

class DiscoverPage extends StatelessWidget {
  const DiscoverPage({super.key});

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.only(bottom: 118),
    children: [
      const Head('Parti'),
      _HeroBanner(onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LymixRoomScreen(roomId: 'featured', roomTitle: 'LYMIX Parti')))),
      const _Tabs(),
      _Room(name: 'Gece Sohbeti', sub: 'Müzik • Muhabbet', people: '53', icon: Icons.mic_rounded, roomId: 'night'),
      _Room(name: 'Yeni İnsanlar, Yeni Sesler', sub: 'LYMIX Topluluğu', people: '46', icon: Icons.auto_awesome, roomId: 'new-voices'),
      _Room(name: 'VIP Lounge', sub: 'Premium oda • VIP 6+', people: '28', icon: Icons.workspace_premium_rounded, roomId: 'vip-lounge', premium: true),
    ],
  );
}

class _HeroBanner extends StatefulWidget {
  final VoidCallback onTap;
  const _HeroBanner({required this.onTap});
  @override
  State<_HeroBanner> createState() => _HeroBannerState();
}

class _HeroBannerState extends State<_HeroBanner> with SingleTickerProviderStateMixin {
  late final AnimationController c;
  @override
  void initState() { super.initState(); c = AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat(reverse: true); }
  @override
  void dispose() { c.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: c,
    builder: (_, __) => GestureDetector(
      onTap: widget.onTap,
      child: Container(
        margin: const EdgeInsets.fromLTRB(16, 8, 16, 14),
        height: 178,
        decoration: BoxDecoration(
          gradient: LymixPro.premiumGradient,
          borderRadius: BorderRadius.circular(30),
          border: Border.all(color: Colors.white.withOpacity(0.12)),
          boxShadow: [
            BoxShadow(color: LymixPro.purple.withOpacity(0.18 + c.value * 0.18), blurRadius: 32 + c.value * 10, spreadRadius: 1),
          ],
        ),
        child: Stack(children: [
          Positioned(right: -15, top: -18, child: Transform.rotate(angle: c.value * .12, child: Icon(Icons.graphic_eq_rounded, size: 150, color: Colors.white.withOpacity(0.09)))),
          Positioned(right: 20, top: 22, child: _LivePill()),
          const Padding(
            padding: EdgeInsets.all(24),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.end, children: [
              Text('SESİNİ GÖSTER', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, letterSpacing: .3)),
              SizedBox(height: 5),
              Text('Sohbet • Topluluk • Eğlence', style: TextStyle(color: Colors.white70, fontSize: 15)),
              SizedBox(height: 14),
              Row(children: [Icon(Icons.groups_rounded, size: 18), SizedBox(width: 6), Text('1.248 kişi çevrimiçi', style: TextStyle(fontWeight: FontWeight.w700)), SizedBox(width: 16), Icon(Icons.bolt_rounded, size: 18), SizedBox(width: 4), Text('Anında katıl')]),
            ]),
          ),
        ]),
      ),
    ),
  );
}

class _LivePill extends StatefulWidget { const _LivePill(); @override State<_LivePill> createState()=>_LivePillState(); }
class _LivePillState extends State<_LivePill> with SingleTickerProviderStateMixin {
  late final AnimationController c;
  @override void initState(){super.initState();c=AnimationController(vsync:this,duration:const Duration(milliseconds:850))..repeat(reverse:true);}
  @override void dispose(){c.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>AnimatedBuilder(animation:c,builder:(_,__)=>Container(
    padding:const EdgeInsets.symmetric(horizontal:10,vertical:7),
    decoration:BoxDecoration(color:Colors.black.withOpacity(.24),borderRadius:BorderRadius.circular(20),border:Border.all(color:Colors.white24)),
    child:Row(mainAxisSize:MainAxisSize.min,children:[Container(width:8,height:8,decoration:BoxDecoration(shape:BoxShape.circle,color:Colors.redAccent,boxShadow:[BoxShadow(color:Colors.redAccent.withOpacity(.4+c.value*.5),blurRadius:4+c.value*8)])),const SizedBox(width:6),const Text('CANLI',style:TextStyle(fontSize:11,fontWeight:FontWeight.w900))]),
  ));
}

class _Tabs extends StatelessWidget { const _Tabs();
  @override Widget build(BuildContext context)=>Padding(
    padding:const EdgeInsets.symmetric(horizontal:16,vertical:6),
    child:Wrap(spacing:8,runSpacing:8,children:const[
      _GlassChip('⭐ Önerilen', selected:true), _GlassChip('🇹🇷 Türkiye'), _GlassChip('🌍 Global'), _GlassChip('🎵 Müzik'),
    ]),
  );
}

class _GlassChip extends StatelessWidget {
  final String label; final bool selected;
  const _GlassChip(this.label,{this.selected=false});
  @override Widget build(BuildContext context)=>Container(
    padding:const EdgeInsets.symmetric(horizontal:14,vertical:10),
    decoration:BoxDecoration(
      gradient:selected?LymixPro.brandGradient:null,
      color:selected?null:Colors.white.withOpacity(.045),
      borderRadius:BorderRadius.circular(15),
      border:Border.all(color:selected?Colors.transparent:Colors.white.withOpacity(.10)),
    ),
    child:Text(label,style:TextStyle(fontWeight:FontWeight.w800,color:selected?LymixPro.bg:Colors.white)),
  );
}

class _Room extends StatefulWidget {
  final String name, sub, people, roomId; final IconData icon; final bool premium;
  const _Room({required this.name,required this.sub,required this.people,required this.icon,required this.roomId,this.premium=false});
  @override State<_Room> createState()=>_RoomState();
}
class _RoomState extends State<_Room>{
  bool down=false;
  @override Widget build(BuildContext context)=>GestureDetector(
    onTapDown:(_)=>setState(()=>down=true), onTapCancel:()=>setState(()=>down=false), onTapUp:(_)=>setState(()=>down=false),
    onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>LymixRoomScreen(roomId:widget.roomId,roomTitle:widget.name))),
    child:AnimatedScale(scale: down ? .96 : 1,duration:const Duration(milliseconds:120),child:Container(
      margin:const EdgeInsets.fromLTRB(16,8,16,8), padding:const EdgeInsets.all(14),
      decoration:BoxDecoration(
        color:LymixPro.panel.withOpacity(.88), borderRadius:BorderRadius.circular(25),
        border:Border.all(color:widget.premium?LymixPro.yellow.withOpacity(.32):Colors.white.withOpacity(.07)),
        boxShadow:[BoxShadow(color:(widget.premium?LymixPro.yellow:LymixPro.purple).withOpacity(.07),blurRadius:20)],
      ),
      child:Row(children:[
        Container(width:76,height:76,decoration:BoxDecoration(gradient:widget.premium?LymixPro.premiumGradient:LymixPro.brandGradient,borderRadius:BorderRadius.circular(21)),child:Icon(widget.icon,size:34,color:LymixPro.bg)),
        const SizedBox(width:14),
        Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Row(children:[Flexible(child:Text(widget.name,style:const TextStyle(fontSize:17,fontWeight:FontWeight.w900))),if(widget.premium)...[const SizedBox(width:7),const Icon(Icons.verified_rounded,size:17,color:LymixPro.yellow)]]),
          const SizedBox(height:6),Text(widget.sub,style:const TextStyle(color:LymixPro.muted)),
          const SizedBox(height:9),const Row(children:[CircleAvatar(radius:10,backgroundColor:LymixPro.purple),SizedBox(width:4),CircleAvatar(radius:10,backgroundColor:LymixPro.yellow),SizedBox(width:4),CircleAvatar(radius:10,backgroundColor:Colors.blueGrey),SizedBox(width:8),Text('Aktif konuşma',style:TextStyle(fontSize:11,color:Colors.white54))]),
        ])),
        Column(children:[Text('▮▮ ${widget.people}',style:const TextStyle(color:LymixPro.yellow,fontWeight:FontWeight.w900)),const SizedBox(height:13),const Icon(Icons.chevron_right_rounded,color:Colors.white54)]),
      ]),
    )),
  );
}

class SocialPage extends StatelessWidget {
  const SocialPage({super.key});
  @override Widget build(BuildContext context)=>ListView(
    padding:const EdgeInsets.only(bottom:118),
    children:[const Head('Plaza'),...List.generate(4,(i)=>_SocialCard(index:i))],
  );
}

class _SocialCard extends StatefulWidget { final int index; const _SocialCard({required this.index}); @override State<_SocialCard> createState()=>_SocialCardState(); }
class _SocialCardState extends State<_SocialCard>{ bool liked=false; bool following=false;
  @override Widget build(BuildContext context)=>Container(
    margin:const EdgeInsets.fromLTRB(16,8,16,10),padding:const EdgeInsets.all(18),
    decoration:BoxDecoration(color:LymixPro.panel.withOpacity(.88),borderRadius:BorderRadius.circular(26),border:Border.all(color:Colors.white.withOpacity(.07))),
    child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(children:[const CircleAvatar(backgroundColor:LymixPro.purple,child:Icon(Icons.person)),const SizedBox(width:10),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('LYMIX Creator ${widget.index+1}',style:const TextStyle(fontWeight:FontWeight.w900)),const Text('VIP 4 • Lv.38',style:TextStyle(fontSize:11,color:LymixPro.muted))])),
        _GlassIconButton(icon:following?Icons.check_rounded:Icons.person_add_alt_1_rounded,color:following?Colors.greenAccent:null,onTap:()=>setState(()=>following=!following))]),
      const SizedBox(height:14),const Text('Senin gibi bir sesi bekliyoruz. Koltuğunu kap, sohbete katıl! 🎙️',style:TextStyle(height:1.35)),const SizedBox(height:14),
      _GradientButton(label:'Parti Odasına Katıl',icon:Icons.graphic_eq_rounded,onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>LymixRoomScreen(roomId:'plaza-${widget.index+1}',roomTitle:'Creator ${widget.index+1} Parti Odası')))),
      const SizedBox(height:12),Row(mainAxisAlignment:MainAxisAlignment.end,children:[
        _MiniAction(icon:liked?Icons.favorite:Icons.favorite_border,color:liked?Colors.pinkAccent:null,onTap:()=>setState(()=>liked=!liked)),
        _MiniAction(icon:Icons.chat_bubble_outline,onTap:()=>ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Yorum alanı açıldı.')))),
        _MiniAction(icon:Icons.more_horiz,onTap:()=>showModalBottomSheet(context:context,builder:(_)=>const SafeArea(child:ListTile(leading:Icon(Icons.flag_outlined),title:Text('İçeriği bildir'))))),
      ])
    ]),
  );
}

class _GradientButton extends StatefulWidget { final String label; final IconData icon; final VoidCallback onTap; const _GradientButton({required this.label,required this.icon,required this.onTap}); @override State<_GradientButton> createState()=>_GradientButtonState(); }
class _GradientButtonState extends State<_GradientButton>{bool down=false;@override Widget build(BuildContext context)=>GestureDetector(onTapDown:(_)=>setState(()=>down=true),onTapCancel:()=>setState(()=>down=false),onTapUp:(_)=>setState(()=>down=false),onTap:widget.onTap,child:AnimatedScale(scale: down ? .97 : 1,duration:const Duration(milliseconds:100),child:Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(gradient:LymixPro.premiumGradient,borderRadius:BorderRadius.circular(19),boxShadow:[BoxShadow(color:LymixPro.purple.withOpacity(.22),blurRadius:22)]),child:Row(children:[Icon(widget.icon),const SizedBox(width:10),Text(widget.label,style:const TextStyle(fontWeight:FontWeight.w900)),const Spacer(),const Icon(Icons.arrow_forward_rounded,size:20)]))));}

class _MiniAction extends StatelessWidget{final IconData icon;final VoidCallback onTap;final Color? color;const _MiniAction({required this.icon,required this.onTap,this.color});@override Widget build(BuildContext context)=>IconButton(onPressed:onTap,icon:Icon(icon,color:color),style:IconButton.styleFrom(backgroundColor:Colors.white.withOpacity(.035)));}

class GameCenterPage extends StatelessWidget {
  const GameCenterPage({super.key});
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.only(bottom:118),children:[
    const Head('Oyun Merkezi'),
    GestureDetector(onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const GameCenterScreen())),child:Container(margin:const EdgeInsets.all(16),padding:const EdgeInsets.all(20),decoration:BoxDecoration(gradient:LymixPro.premiumGradient,borderRadius:BorderRadius.circular(28),boxShadow:[BoxShadow(color:LymixPro.purple.withOpacity(.18),blurRadius:28)]),child:const Row(children:[Icon(Icons.bolt,size:36),SizedBox(width:12),Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Seviye 22',style:TextStyle(fontSize:22,fontWeight:FontWeight.w900)),Text('1.280 XP • %74 tamamlandı',style:TextStyle(fontSize:11,color:Colors.white70))]),Spacer(),Icon(Icons.emoji_events,size:40)]))),
    Padding(padding:const EdgeInsets.all(16),child:GridView.count(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:3,mainAxisSpacing:14,crossAxisSpacing:14,children:[Icons.rocket_launch,Icons.pets,Icons.phishing,Icons.sports_soccer,Icons.casino,Icons.sports_esports].asMap().entries.map((e)=>_GameTile(icon:e.value,index:e.key)).toList()))
  ]);
}
class _GameTile extends StatefulWidget {final IconData icon;final int index;const _GameTile({required this.icon,required this.index});@override State<_GameTile> createState()=>_GameTileState();}
class _GameTileState extends State<_GameTile> with SingleTickerProviderStateMixin{late final AnimationController c;@override void initState(){super.initState();c=AnimationController(vsync:this,duration:Duration(milliseconds:1200+widget.index*120))..repeat(reverse:true);}@override void dispose(){c.dispose();super.dispose();}@override Widget build(BuildContext context)=>AnimatedBuilder(animation:c,builder:(_,__)=>GestureDetector(onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const GameCenterScreen())),child:Container(decoration:BoxDecoration(color:LymixPro.panel.withOpacity(.9),borderRadius:BorderRadius.circular(22),border:Border.all(color:Colors.white.withOpacity(.07)),boxShadow:[BoxShadow(color:LymixPro.purple.withOpacity(.04+c.value*.09),blurRadius:14+c.value*8)]),child:Transform.scale(scale:.95+c.value*.04,child:Icon(widget.icon,size:44,color:Color.lerp(LymixPro.yellow,Colors.white,c.value*.22))))));}

class InboxPage extends StatelessWidget {
  const InboxPage({super.key});

  @override
  Widget build(BuildContext context) => ListView(
        padding: const EdgeInsets.only(bottom: 118),
        children: [
          const Head('Mesaj'),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _Quick(
                  Icons.person_add,
                  'Uygula',
                  () => ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Arkadaşlık istekleri açıldı.')),
                  ),
                ),
                _Quick(
                  Icons.campaign,
                  'Aktivite',
                  () => ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Aktivite merkezi açıldı.')),
                  ),
                ),
                _Quick(
                  Icons.notifications,
                  'Bildirim',
                  () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const NotificationCenterScreen()),
                  ),
                ),
                _Quick(
                  Icons.visibility,
                  'Ziyaretçiler',
                  () => ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Profil ziyaretçileri açıldı.')),
                  ),
                ),
              ],
            ),
          ),
          ...List.generate(7, (i) {
            return Container(
              margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(i == 0 ? .045 : .018),
                borderRadius: BorderRadius.circular(18),
              ),
              child: ListTile(
                onTap: () => ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('LYMIX Kullanıcı ${i + 1} sohbeti açılıyor...')),
                ),
                leading: CircleAvatar(
                  backgroundColor: i.isEven ? LymixPro.purple : LymixPro.yellow,
                  child: const Icon(Icons.person, color: LymixPro.bg),
                ),
                title: Text(
                  'LYMIX Kullanıcı ${i + 1}',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: const Text('Yeni mesaj ve oda daveti'),
                trailing: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(i == 0 ? '13 sn' : 'Dün'),
                    if (i == 0) const SizedBox(height: 5),
                    if (i == 0)
                      Container(
                        width: 8,
                        height: 8,
                        decoration: const BoxDecoration(
                          color: LymixPro.yellow,
                          shape: BoxShape.circle,
                        ),
                      ),
                  ],
                ),
              ),
            );
          }),
        ],
      );
}
class _Quick extends StatelessWidget {final IconData i;final String t;final VoidCallback onTap;const _Quick(this.i,this.t,this.onTap);@override Widget build(BuildContext context)=>InkWell(borderRadius:BorderRadius.circular(22),onTap:onTap,child:Padding(padding:const EdgeInsets.all(6),child:Column(children:[CircleAvatar(radius:29,backgroundColor:LymixPro.panel2,child:Icon(i,color:LymixPro.yellow)),const SizedBox(height:7),Text(t,style:const TextStyle(fontSize:12,fontWeight:FontWeight.w700))])));}

class ProfilePage extends StatelessWidget { const ProfilePage({super.key});
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.only(bottom:118),children:[
    const Head('Profil'),const SizedBox(height:10),
    Center(child:Stack(alignment:Alignment.center,children:[Container(width:124,height:124,decoration:BoxDecoration(shape:BoxShape.circle,gradient:LymixPro.brandGradient,boxShadow:[BoxShadow(color:LymixPro.purple.withOpacity(.30),blurRadius:30)])),const CircleAvatar(radius:54,backgroundColor:LymixPro.deepPurple,child:Icon(Icons.person,size:58,color:Colors.white))])),
    const SizedBox(height:13),const Center(child:Row(mainAxisSize:MainAxisSize.min,children:[Text('LYMIX CREATOR',style:TextStyle(fontSize:23,fontWeight:FontWeight.w900)),SizedBox(width:6),Icon(Icons.verified_rounded,color:LymixPro.yellow,size:19)])),
    const Center(child:Text('ID: 31059515  •  VIP 4  •  Lv.38',style:TextStyle(color:LymixPro.muted))),const SizedBox(height:20),
    const Padding(padding:EdgeInsets.symmetric(horizontal:24),child:Row(mainAxisAlignment:MainAxisAlignment.spaceAround,children:[_Stat('4','Arkadaşlar'),_Stat('5','Takip'),_Stat('6','Fan')])),
    GestureDetector(onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const VipCenterScreen())),child:Container(margin:const EdgeInsets.all(18),padding:const EdgeInsets.all(18),decoration:BoxDecoration(gradient:LymixPro.premiumGradient,borderRadius:BorderRadius.circular(24),boxShadow:[BoxShadow(color:LymixPro.purple.withOpacity(.20),blurRadius:24)]),child:const Column(children:[Row(children:[Icon(Icons.workspace_premium,size:36),SizedBox(width:14),Expanded(child:Text('VIP Merkezi',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold))),Text('VIP 4',style:TextStyle(fontWeight:FontWeight.w900)),SizedBox(width:6),Icon(Icons.chevron_right)]),SizedBox(height:13),LinearProgressIndicator(value:.62,minHeight:6,borderRadius:BorderRadius.all(Radius.circular(9)),backgroundColor:Colors.black26,color:Colors.white),SizedBox(height:7),Row(children:[Text('62% tamamlandı',style:TextStyle(fontSize:11,color:Colors.white70)),Spacer(),Text('VIP 5 →',style:TextStyle(fontSize:11,fontWeight:FontWeight.w800))])]))),
    Padding(padding:const EdgeInsets.all(18),child:GridView.count(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:4,mainAxisSpacing:16,crossAxisSpacing:12,children:[
      _ProfileAction(Icons.workspace_premium,'VIP',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const VipCenterScreen()))),
      _ProfileAction(Icons.card_giftcard_rounded,'Hediyeler',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const GiftCatalogScreen()))),
      _ProfileAction(Icons.favorite,'Favori',()=>ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Favoriler açıldı.')))),
      _ProfileAction(Icons.shopping_bag,'Mağaza',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const CoinStoreScreen()))),
      _ProfileAction(Icons.admin_panel_settings_rounded,'Admin',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const AdminEconomyCenterScreen()))),
      _ProfileAction(Icons.sports_esports,'Oyun',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const GameCenterScreen()))),
      _ProfileAction(Icons.monitor_heart_rounded,'Owner Ops',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const OwnerOpsCenterScreen()))),
      _ProfileAction(Icons.settings,'Ayarlar',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const AppSettingsScreen()))),
    ]))
  ]);}
class _ProfileAction extends StatelessWidget{final IconData icon;final String label;final VoidCallback onTap;const _ProfileAction(this.icon,this.label,this.onTap);@override Widget build(BuildContext context)=>InkWell(onTap:onTap,borderRadius:BorderRadius.circular(19),child:Container(decoration:BoxDecoration(color:Colors.white.withOpacity(.035),borderRadius:BorderRadius.circular(19),border:Border.all(color:Colors.white.withOpacity(.06))),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(icon,color:LymixPro.yellow,size:31),const SizedBox(height:6),Text(label,style:const TextStyle(fontSize:11,fontWeight:FontWeight.w700))])));}
class _Stat extends StatelessWidget {final String n,t;const _Stat(this.n,this.t);@override Widget build(BuildContext c)=>Column(children:[Text(n,style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold)),Text(t,style:const TextStyle(color:LymixPro.muted))]);}
