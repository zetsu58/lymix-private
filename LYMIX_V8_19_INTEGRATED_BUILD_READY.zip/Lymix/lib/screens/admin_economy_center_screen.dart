import 'package:flutter/material.dart';
import '../models/gift_model.dart';
import '../services/coin_wallet_service.dart';

class AdminEconomyCenterScreen extends StatefulWidget {
  const AdminEconomyCenterScreen({super.key});
  @override State<AdminEconomyCenterScreen> createState()=>_AdminEconomyCenterScreenState();
}

class _AdminEconomyCenterScreenState extends State<AdminEconomyCenterScreen> {
  bool giftsEnabled=true, luckyEnabled=true, roomEffects=true, antiAbuse=true;
  double eventMultiplier=1;
  final disabled=<String>{};
  @override Widget build(BuildContext context)=>Scaffold(
    backgroundColor:const Color(0xFF0B0811),
    appBar:AppBar(title:const Text('Admin • Ekonomi & Hediyeler')),
    body:ListView(padding:const EdgeInsets.fromLTRB(16,14,16,28),children:[
      _hero(), const SizedBox(height:14),
      Wrap(spacing:10,runSpacing:10,children:[_metric('Hediye','18'),_metric('Coin Akışı','3.65M'),_metric('Aktif Oda','42'),_metric('Risk','Düşük')]),
      const SizedBox(height:16),
      _switch('Hediye gönderimi',giftsEnabled,(v)=>setState(()=>giftsEnabled=v)),
      _switch('Lucky / şanslı hediye',luckyEnabled,(v)=>setState(()=>luckyEnabled=v)),
      _switch('Oda çapı animasyonlar',roomEffects,(v)=>setState(()=>roomEffects=v)),
      _switch('Anti-abuse / hız limiti',antiAbuse,(v)=>setState(()=>antiAbuse=v)),
      const SizedBox(height:14),
      const Text('Etkinlik fiyat çarpanı',style:TextStyle(fontWeight:FontWeight.w900)),
      Slider(value:eventMultiplier,min:.5,max:2,divisions:6,label:'x${eventMultiplier.toStringAsFixed(1)}',onChanged:(v)=>setState(()=>eventMultiplier=v)),
      Text('x${eventMultiplier.toStringAsFixed(1)} • Sunucu tarafında uygulanacak',style:const TextStyle(color:Colors.white54,fontSize:11)),
      const Divider(height:30),
      Row(children:[const Expanded(child:Text('Hediye kataloğu',style:TextStyle(fontSize:18,fontWeight:FontWeight.w900))),OutlinedButton.icon(onPressed:()=>CoinWalletService.instance.creditDemo(100000),icon:const Icon(Icons.add),label:const Text('Demo +100K'))]),
      const SizedBox(height:8),
      ...lymixGiftCatalog.map((g)=>Card(child:ListTile(
        leading:Container(width:44,height:44,alignment:Alignment.center,decoration:BoxDecoration(shape:BoxShape.circle,color:giftTierColor(g.tier).withOpacity(.12)),child:Text(g.symbol,style:const TextStyle(fontSize:24))),
        title:Text(g.name),subtitle:Text('${g.coins} Coin • ${g.category}${g.roomWide?' • Oda çapı':''}'),
        trailing:Switch(value:!disabled.contains(g.id),onChanged:(v)=>setState((){v?disabled.remove(g.id):disabled.add(g.id);})),
      ))),
      const SizedBox(height:10),
      const Text('Not: Production sürümünde fiyat, bakiye, gönderim ve admin değişiklikleri sadece backend imzalı işlemlerle uygulanmalı; istemci tek başına para basmamalı.',style:TextStyle(color:Colors.white38,fontSize:10)),
    ]),
  );
  Widget _hero()=>Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(borderRadius:BorderRadius.circular(24),gradient:const LinearGradient(colors:[Color(0xFF2B1250),Color(0xFF6D2BFF),Color(0xFFFFC400)])),child:const Row(children:[Icon(Icons.admin_panel_settings_rounded,size:40),SizedBox(width:13),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('LYMIX ECONOMY CONTROL',style:TextStyle(fontWeight:FontWeight.w900,fontSize:17)),SizedBox(height:3),Text('Coin • atış • hediye • event • güvenlik',style:TextStyle(color:Colors.white70,fontSize:11))]))]));
  Widget _metric(String a,String b)=>Container(width:150,padding:const EdgeInsets.all(13),decoration:BoxDecoration(color:Colors.white.withOpacity(.045),borderRadius:BorderRadius.circular(18),border:Border.all(color:Colors.white.withOpacity(.06))),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(a,style:const TextStyle(color:Colors.white45,fontSize:10)),const SizedBox(height:5),Text(b,style:const TextStyle(color:Color(0xFFFFD200),fontWeight:FontWeight.w900,fontSize:18))]));
  Widget _switch(String t,bool v,ValueChanged<bool> f)=>SwitchListTile(value:v,onChanged:f,title:Text(t),activeColor:const Color(0xFFFFD200));
}
