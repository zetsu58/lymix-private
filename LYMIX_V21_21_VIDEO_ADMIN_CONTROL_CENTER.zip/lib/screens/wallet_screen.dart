import 'package:flutter/material.dart';
import '../core/api_client.dart';
import '../design/lymix_design_system.dart';
import '../models/wallet_models.dart';
import '../services/wallet_service.dart';

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});
  @override
  State<WalletScreen> createState()=>_WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  final _service = WalletService(const ApiClient());
  WalletBalance _balance = const WalletBalance(coins:0,diamonds:0);
  List<CoinPackage> _packages = const [];
  bool _loading = true;
  String _channel = 'google_play';

  @override
  void initState(){super.initState();_load();}

  Future<void> _load() async {
    try {
      final b = await _service.balance();
      final p = await _service.packages();
      if(!mounted)return;
      setState((){_balance=b;_packages=p;_loading=false;});
    } catch(_) {
      if(mounted)setState(()=>_loading=false);
    }
  }

  @override
  Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(
      title:const Text('Cüzdanım'),
      actions:[
        IconButton(onPressed:(){},icon:const Icon(Icons.support_agent_rounded)),
        IconButton(onPressed:(){},icon:const Icon(Icons.receipt_long_rounded)),
      ],
    ),
    body:_loading
      ? const Center(child:CircularProgressIndicator(color:LymixPalette.gold))
      : ListView(
          padding:const EdgeInsets.fromLTRB(16,8,16,28),
          children:[
            const _Tabs(),
            const SizedBox(height:18),
            const Text('Bakiye',style:TextStyle(color:LymixPalette.text3,fontSize:10)),
            const SizedBox(height:5),
            Row(children:[
              const Icon(Icons.monetization_on_rounded,color:LymixPalette.gold,size:38),
              const SizedBox(width:8),
              Text('${_balance.coins}',style:const TextStyle(fontSize:34,fontWeight:FontWeight.w900)),
            ]),
            const SizedBox(height:20),
            _channelBar('Kredi / Banka Kartı','credit_card',Icons.credit_card_rounded),
            const SizedBox(height:10),
            _channelBar('Google Play','google_play',Icons.shop_2_rounded),
            const SizedBox(height:10),
            _channelBar('TRC20 / USDT','trc20',Icons.currency_bitcoin_rounded),
            const SizedBox(height:10),
            _channelBar('ERC20 / BSC','erc20_bsc',Icons.token_rounded),
            const SizedBox(height:16),
            _grid(),
            const SizedBox(height:18),
            Container(
              padding:const EdgeInsets.all(12),
              decoration:BoxDecoration(
                color:Colors.white.withValues(alpha:.035),
                borderRadius:BorderRadius.circular(16),
                border:Border.all(color:Colors.white.withValues(alpha:.055)),
              ),
              child:const Text(
                'Google Play / App Store üzerinden satılan coin paketleri mağaza ürünleriyle eşleştirilir. Kart ve kripto kanalları yalnızca ilgili mağaza kuralları ve ülke uygunluğu sağlandığında etkinleştirilmelidir.',
                style:TextStyle(color:LymixPalette.text3,fontSize:9,height:1.45),
              ),
            ),
          ],
        ),
  );

  Widget _channelBar(String label,String id,IconData icon)=>InkWell(
    onTap:()=>setState(()=>_channel=id),
    borderRadius:BorderRadius.circular(16),
    child:Container(
      padding:const EdgeInsets.symmetric(horizontal:14,vertical:15),
      decoration:BoxDecoration(
        color:_channel==id?LymixPalette.purple.withValues(alpha:.11):Colors.white.withValues(alpha:.035),
        borderRadius:BorderRadius.circular(16),
        border:Border.all(color:_channel==id?LymixPalette.purple.withValues(alpha:.28):Colors.white.withValues(alpha:.055)),
      ),
      child:Row(children:[
        Container(width:42,height:42,decoration:BoxDecoration(color:Colors.white.withValues(alpha:.05),borderRadius:BorderRadius.circular(12)),child:Icon(icon,color:LymixPalette.gold)),
        const SizedBox(width:10),
        Expanded(child:Text(label,style:const TextStyle(fontSize:12,fontWeight:FontWeight.w900))),
        Icon(_channel==id?Icons.keyboard_arrow_up_rounded:Icons.keyboard_arrow_down_rounded,color:LymixPalette.text3),
      ]),
    ),
  );

  Widget _grid() {
    final items=_packages.where((p)=>p.channel==_channel&&p.enabled).toList();
    if(items.isEmpty){
      return Container(
        padding:const EdgeInsets.all(20),
        decoration:BoxDecoration(color:Colors.white.withValues(alpha:.025),borderRadius:BorderRadius.circular(16)),
        child:const Text('Bu ödeme kanalı için henüz aktif paket yok.',textAlign:TextAlign.center,style:TextStyle(color:LymixPalette.text3,fontSize:10)),
      );
    }
    return GridView.builder(
      shrinkWrap:true,
      physics:const NeverScrollableScrollPhysics(),
      itemCount:items.length,
      gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:3,crossAxisSpacing:8,mainAxisSpacing:8,childAspectRatio:.83),
      itemBuilder:(_,i){
        final p=items[i];
        return InkWell(
          onTap:()=>_service.startPurchase(p.id),
          borderRadius:BorderRadius.circular(15),
          child:Container(
            padding:const EdgeInsets.all(10),
            decoration:BoxDecoration(
              color:Colors.white.withValues(alpha:.045),
              borderRadius:BorderRadius.circular(15),
              border:Border.all(color:Colors.white.withValues(alpha:.05)),
            ),
            child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
              Row(mainAxisAlignment:MainAxisAlignment.center,children:[
                const Icon(Icons.monetization_on_rounded,color:LymixPalette.gold,size:18),
                const SizedBox(width:4),
                Flexible(child:Text('${p.coins}',style:const TextStyle(fontWeight:FontWeight.w900,fontSize:13))),
              ]),
              const SizedBox(height:7),
              Text('VIPexp ${p.vipExp}',style:const TextStyle(color:LymixPalette.text3,fontSize:8.5)),
              const SizedBox(height:8),
              Text(p.displayPrice,style:const TextStyle(fontWeight:FontWeight.w900,fontSize:10.5)),
            ]),
          ),
        );
      },
    );
  }
}

class _Tabs extends StatelessWidget {
  const _Tabs();
  @override
  Widget build(BuildContext context)=>const Row(children:[
    Text('Coins',style:TextStyle(fontSize:12,fontWeight:FontWeight.w900)),
    SizedBox(width:24),
    Text('Diamonds',style:TextStyle(fontSize:12,color:LymixPalette.text3)),
  ]);
}
