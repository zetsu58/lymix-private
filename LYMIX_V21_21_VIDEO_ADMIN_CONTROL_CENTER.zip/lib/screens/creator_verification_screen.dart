import 'package:flutter/material.dart';
import '../core/api_client.dart';
import '../design/lymix_design_system.dart';
import '../services/creator_verification_service.dart';
import '../services/face_liveness_service.dart';
import '../services/session_service.dart';

class CreatorVerificationScreen extends StatefulWidget {
  const CreatorVerificationScreen({super.key});

  @override
  State<CreatorVerificationScreen> createState() => _CreatorVerificationScreenState();
}

class _CreatorVerificationScreenState extends State<CreatorVerificationScreen> {
  final legalName = TextEditingController();
  final phone = TextEditingController();
  final code = TextEditingController();
  final agency = TextEditingController();
  final service = CreatorVerificationService(ApiClient(tokenProvider: SessionService.token));
  final FaceLivenessService liveness = const RegulaFaceLivenessService();

  String country = 'TR';
  String gender = 'unspecified';
  String? livenessSessionId;
  FaceLivenessStatus livenessStatus = FaceLivenessStatus.notStarted;
  bool codeRequested = false;
  bool phoneVerified = false;
  bool busy = false;
  String? status;
  String? error;

  @override
  void initState() {
    super.initState();
    _loadStatus();
  }

  Future<void> _loadStatus() async {
    try {
      final row = await service.status();
      if (!mounted) return;
      setState(() {
        status = row['status']?.toString();
        phoneVerified = row['phoneVerified'] == true;
        if (row['phone'] != null) phone.text = '${row['phone']}';
      });
    } catch (_) {}
  }

  @override
  void dispose() {
    legalName.dispose();
    phone.dispose();
    code.dispose();
    agency.dispose();
    super.dispose();
  }

  Future<void> _requestCode() async {
    if (phone.text.trim().length < 8) {
      setState(() => error = 'Geçerli bir telefon numarası gir.');
      return;
    }
    setState(() { busy = true; error = null; });
    try {
      await service.requestPhoneCode(phone.text);
      if (mounted) setState(() => codeRequested = true);
    } on ApiException catch (e) {
      if (mounted) setState(() => error = e.message);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _confirmCode() async {
    setState(() { busy = true; error = null; });
    try {
      await service.confirmPhoneCode(phone.text, code.text);
      if (mounted) setState(() => phoneVerified = true);
    } on ApiException catch (e) {
      if (mounted) setState(() => error = e.message);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _startLiveness() async {
    if (!phoneVerified) {
      setState(() => error = 'Canlı yüz doğrulamasından önce telefon numaranı doğrula.');
      return;
    }
    setState(() { busy = true; error = null; livenessStatus = FaceLivenessStatus.pending; });
    final result = await liveness.start();
    if (!mounted) return;
    setState(() {
      busy = false;
      livenessStatus = result.status;
      livenessSessionId = result.sessionId;
      if (result.status != FaceLivenessStatus.passed) error = result.message ?? 'Canlı yüz doğrulaması tamamlanamadı.';
    });
  }

  Future<void> _submit() async {
    if (!phoneVerified) {
      setState(() => error = 'Önce telefon numaranı doğrula.');
      return;
    }
    if (legalName.text.trim().length < 3) {
      setState(() => error = 'Ad soyad gerekli.');
      return;
    }
    if (livenessStatus != FaceLivenessStatus.passed || livenessSessionId == null) {
      setState(() => error = 'Canlı yüz doğrulamasını başarıyla tamamla.');
      return;
    }
    setState(() { busy = true; error = null; });
    try {
      throw const ApiException('Canlı yüz doğrulama sağlayıcısının sunucu doğrulaması henüz etkin değil. Regula production lisansı gerekli.');
      if (!mounted) return;
      setState(() => status = '${row['status'] ?? 'PENDING'}');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Yayıncı başvurun incelemeye gönderildi.')),
      );
    } on ApiException catch (e) {
      if (mounted) setState(() => error = e.message);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final submitted = ['PENDING','APPROVED','REJECTED','NEEDS_REVERIFY'].contains(status);
    return Scaffold(
      appBar: AppBar(title: const Text('Yayıncı Doğrulama')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 14, 18, 32),
        children: [
          LymixGlassSurface(
            elevated: true,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const LymixPremiumBadge('CREATOR VERIFY', icon: Icons.verified_user_rounded),
              const SizedBox(height: 12),
              const Text('Profesyonel yayıncı hesabı', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
              const SizedBox(height: 6),
              Text(
                submitted
                  ? 'Başvuru durumu: ${status ?? '—'}'
                  : 'Telefonunu doğrula, canlı yüz taramasını tamamla ve başvurunu gönder. Bu doğrulama yalnızca yayıncı/ajans başvurusunda istenir.',
                style: const TextStyle(color: LymixPalette.text2, height: 1.4),
              ),
            ]),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: legalName,
            decoration: const InputDecoration(labelText: 'Ad Soyad', prefixIcon: Icon(Icons.badge_outlined)),
          ),
          const SizedBox(height: 10),
          Row(children: [
            SizedBox(
              width: 94,
              child: DropdownButtonFormField<String>(
                initialValue: country,
                decoration: const InputDecoration(labelText: 'Ülke'),
                items: const [
                  DropdownMenuItem(value:'TR',child:Text('TR')),
                  DropdownMenuItem(value:'AZ',child:Text('AZ')),
                  DropdownMenuItem(value:'DE',child:Text('DE')),
                  DropdownMenuItem(value:'GB',child:Text('GB')),
                ],
                onChanged: (v) => setState(() => country = v ?? 'TR'),
              ),
            ),
            const SizedBox(width: 9),
            Expanded(
              child: TextField(
                controller: phone,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(labelText: 'Telefon (+90...)', prefixIcon: Icon(Icons.phone_outlined)),
              ),
            ),
          ]),
          const SizedBox(height: 9),
          if (!phoneVerified) ...[
            SizedBox(
              height: 48,
              child: FilledButton.icon(
                onPressed: busy ? null : _requestCode,
                icon: const Icon(Icons.sms_outlined),
                label: Text(codeRequested ? 'Kodu Tekrar Gönder' : 'Doğrulama Kodu Gönder'),
              ),
            ),
            if (codeRequested) ...[
              const SizedBox(height: 9),
              Row(children: [
                Expanded(child: TextField(
                  controller: code,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: '6 haneli kod'),
                )),
                const SizedBox(width: 8),
                FilledButton(onPressed: busy ? null : _confirmCode, child: const Text('Onayla')),
              ]),
            ],
          ] else
            const ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Icon(Icons.verified_rounded, color: LymixPalette.success),
              title: Text('Telefon doğrulandı'),
              subtitle: Text('Numara başvuruna güvenli biçimde bağlandı.'),
            ),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            initialValue: gender,
            decoration: const InputDecoration(labelText: 'Cinsiyet (profil bilgisi)'),
            items: const [
              DropdownMenuItem(value:'unspecified',child:Text('Belirtmek istemiyorum')),
              DropdownMenuItem(value:'female',child:Text('Kadın')),
              DropdownMenuItem(value:'male',child:Text('Erkek')),
              DropdownMenuItem(value:'other',child:Text('Diğer')),
            ],
            onChanged: (v) => setState(() => gender = v ?? 'unspecified'),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: agency,
            decoration: const InputDecoration(
              labelText: 'Ajans ID / Kodu (opsiyonel)',
              prefixIcon: Icon(Icons.hub_outlined),
            ),
          ),
          const SizedBox(height: 14),
          LymixPressable(
            onTap: busy ? null : _startLiveness,
            child: LymixGlassSurface(
              child: Row(children: [
                Container(
                  width: 48, height: 48,
                  decoration: BoxDecoration(
                    color: (livenessStatus == FaceLivenessStatus.passed ? LymixPalette.success : LymixPalette.purple).withValues(alpha:.12),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Icon(
                    livenessStatus == FaceLivenessStatus.passed ? Icons.verified_face_rounded : Icons.face_retouching_natural_rounded,
                    color: livenessStatus == FaceLivenessStatus.passed ? LymixPalette.success : LymixPalette.purple,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start,children:[
                  Text(livenessStatus == FaceLivenessStatus.passed ? 'Canlı yüz doğrulaması tamamlandı' : 'Canlı yüz taramasını başlat', style: const TextStyle(fontWeight: FontWeight.w900)),
                  const SizedBox(height:4),
                  const Text('Kamera karşısında yönlendirmeleri takip et. Sağ/sol baş hareketi, yüz pozisyonu ve canlılık kontrolleri lisanslı anti-spoof SDK tarafından doğrulanır.', style: TextStyle(color:LymixPalette.text3,fontSize:9.5,height:1.35)),
                ])),
                const Icon(Icons.chevron_right_rounded,color:LymixPalette.text3),
              ]),
            ),
          ),
          const SizedBox(height: 8),
          const Text('Not: Güvenlik nedeniyle normal video kaydı canlı yüz doğrulaması sayılmaz. Canlılık sonucu Regula Face SDK tarafından doğrulanır.', style: TextStyle(color:LymixPalette.text3,fontSize:9,height:1.35)),
          if (error != null) ...[
            const SizedBox(height: 10),
            Text(error!, style: const TextStyle(color:LymixPalette.danger,fontWeight:FontWeight.w700)),
          ],
          const SizedBox(height: 18),
          SizedBox(
            height: 54,
            child: FilledButton.icon(
              onPressed: busy || status == 'PENDING' || status == 'APPROVED' ? null : _submit,
              icon: const Icon(Icons.send_rounded),
              label: Text(status == 'APPROVED' ? 'Yayıncı Onaylandı' : status == 'PENDING' ? 'İncelemede' : 'Başvuruyu Gönder'),
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'Gizlilik: Telefon, cihaz kurulum kimliği ve doğrulama videosu yalnızca güvenlik/başvuru amacıyla işlenmelidir. Production ortamında saklama süresi, silme talebi ve erişim kayıtları uygulanmalıdır.',
            style: TextStyle(color:LymixPalette.text3,fontSize:9,height:1.4),
          ),
        ],
      ),
    );
  }
}
