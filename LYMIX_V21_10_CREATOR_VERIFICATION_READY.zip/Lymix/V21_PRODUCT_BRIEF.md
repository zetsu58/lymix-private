# LYMIX V21 Product Brief

## Product direction
Lymix V21 is the transition from a visual demo to a real social voice product. Fake rooms, fake users and fake social counters must not be used to create the impression of activity. Empty states should look intentional and premium.

## Xena parity lessons applied to Lymix
- Voice-room discovery and free room creation are first-class flows.
- Games, VIP identity, gifting and social activity must connect to the same user graph instead of living as isolated demo screens.
- Room interactions should be fast: join, seat, mic, profile peek, follow, message, gift, report and leave all need clear feedback.
- Premium status should be visible through identity, frames, room entry and gift presentation without making the interface visually noisy.
- Social retention comes from rooms + messages + moments + games + rewards, not from fake population.

## V21 rules
- Real room data only. If no rooms exist, show a premium empty state and Create Room CTA.
- Real user data only. System accounts such as Lymix Official are explicitly marked as system accounts.
- Language selection must update the app immediately and persist across restarts.
- Turkish and English are the primary complete product packs. German, Italian, Russian, Hindi and Azerbaijani have core navigation support and fall back to English for untranslated secondary strings until their full copy review is complete.
- Every interactive icon must have a destination, state change, sheet or explicit disabled/upcoming state.
- Private/locked/hidden room details must never leak into messaging presence or discovery.
- Motion should be purposeful: short press feedback, smooth page transitions, subtle presence rings and tiered gift effects.
- Build infrastructure remains pinned to the hardened Flutter/Android toolchain.
