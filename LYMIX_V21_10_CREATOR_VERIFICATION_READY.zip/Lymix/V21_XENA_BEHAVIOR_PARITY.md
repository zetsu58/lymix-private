# LYMIX V21.6 — Xena behavior-parity audit

This document describes product behaviors inferred from publicly visible APK resources.
No proprietary Xena source code, branding, artwork, or assets are copied.

## Xena APK structural signals observed
- Hundreds of room/chat/live/gift resources.
- Multiple seat layouts and seat states: empty, locked, mute, invite, apply.
- PK resources for selected times, red/blue score, win/fail/draw, rank and team battle.
- Gift recipient selection, all-user mode, gift wall, combo/lucky/group gifts.
- Profile actions for follow/following/chat/share and live/party presence.
- VIP center, dynamic avatar, privileges, expiry/level-change flows.
- Agency search/join/host-center resources.
- Voice/chat recording, send/receive bubbles, loading and error states.
- Game-room specific microphone, free-seat and game-state resources.

## Lymix parity rules implemented
1. User profile has follow/message/open-room/safety actions.
2. Direct messages have real empty state and open-room privacy gating.
3. Room seat mini-card routes to profile/message/gift/report.
4. Search user result routes to a profile.
5. Favorites and inventory are real destinations, not FeatureHub placeholders.
6. Safety sheet routes to blocked users, reports and privacy.
7. Feed buttons all respond; no empty callback remains in audited surfaces.
8. VIP history has a real state screen.
9. Gift targets: single / occupied seats / room; sender excluded.
10. PK: 5/10/20/30/60 min, countdown, scoring, seat-switch lock.
11. Permanent room model preserved; agency status upgrades same room.
12. Existing Agora/Gradle/Android build hardening remains unchanged.

## Never copy
- Xena logo/name/brand
- proprietary images/PAG animations
- decompiled implementation code
- private API credentials/endpoints
