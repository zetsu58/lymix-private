# LYMIX V21.5 FINAL PRODUCT RULES

## Permanent room model
- Every real user owns exactly one permanent room.
- Room ID remains stable across sessions.
- User edits/enters their room; normal UI never creates unlimited rooms.
- If user becomes an agency account, the same permanent room becomes the agency room.
- Agency status must not destroy room history, ID, moderation history or PK history.

## Real social state
- No fake rooms, fake listeners, fake gifts, fake followers, fake events or fake balances.
- Empty state is a first-class premium screen with a useful next action.
- Locked/private rooms are not exposed through message presence/join shortcuts.

## Gifts
- Single / all occupied seats / everyone in room.
- Current user is always excluded.
- Group gift cost = gift price x quantity x unique eligible recipients.
- Each recipient generates its own settlement record.
- Quota, host credit and agency commission are recipient-specific.
- Insufficient balance and zero-recipient state must block send before transaction.

## PK
- 5/10/20/30/60 minutes.
- 3-second countdown, live scores, reset/final state.
- During PK, direct seat switching is blocked; user must stand first.
- Backend-ready for rematch, history, streak and seasonal leaderboard.

## Economy
- Coins, quota points, recyclable coins, earned credits and agency credits are separate ledgers.
- Production settlement is server-authoritative.
- No client balance minting.
- KYC/region/payment-provider rules required for real payout.
- Gift/settlement requests must be idempotent and auditable.

## UX quality
- Unified design tokens and motion timings.
- Press feedback + haptics for critical actions.
- Loading/content/empty/error/offline/restricted states on network surfaces.
- Minimum practical touch target ~48dp.
- No dead button: unavailable features are hidden or explicitly marked.

## Release gate
1. Dependency resolution succeeds.
2. Analyzer has zero real errors.
3. Tests compile/pass.
4. Android AAR metadata passes.
5. Manifest merge passes.
6. Debug APK is non-empty.
7. Main navigation, login, My Room, PK, gift, messages, profile smoke-test.
