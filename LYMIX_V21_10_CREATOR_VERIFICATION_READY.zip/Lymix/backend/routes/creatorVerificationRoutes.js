const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

module.exports = function createCreatorVerificationRoutes({ verification, audit }) {
  const r = express.Router();
  const uploadDir = path.join(__dirname,'..','uploads','creator-verification');
  fs.mkdirSync(uploadDir,{recursive:true});
  const upload = multer({
    storage:multer.diskStorage({
      destination:(_req,_file,cb)=>cb(null,uploadDir),
      filename:(req,file,cb)=>{
        const ext=path.extname(file.originalname||'').toLowerCase();
        cb(null,`${String(req.auth?.sub||'user')}_${Date.now()}_${crypto.randomUUID()}${ext||'.mp4'}`);
      },
    }),
    limits:{fileSize:30*1024*1024},
    fileFilter:(_req,file,cb)=>cb(null,String(file.mimetype||'').startsWith('video/')),
  });

  r.get('/me',(req,res)=>{
    const row=verification.get(req.auth.sub);
    if(!row)return res.json({status:'NOT_STARTED',phoneVerified:false});
    res.json({
      status:row.status,
      phone:row.phoneMasked,
      phoneVerified:true,
      agencyId:row.agencyId,
      countryCode:row.countryCode,
      updatedAt:row.updatedAt,
      reviewNote:row.reviewNote,
    });
  });

  r.post('/phone/request',(req,res)=>{
    try{
      const row=verification.requestPhoneCode(req.auth.sub,req.body?.phone);
      res.json({ok:true,phone:row.phone,debugCode:row.debugCode});
    }catch(e){res.status(400).json({error:'invalid_phone',message:'Telefon numarası geçersiz.'});}
  });

  r.post('/phone/confirm',(req,res)=>{
    const ok=verification.confirmPhoneCode(req.auth.sub,req.body?.phone,req.body?.code);
    if(!ok)return res.status(400).json({error:'invalid_code',message:'Kod geçersiz veya süresi dolmuş.'});
    res.json({ok:true});
  });

  r.post('/submit',upload.single('verificationVideo'),(req,res)=>{
    try{
      if(!req.file)return res.status(400).json({error:'video_required',message:'Görüntülü doğrulama videosu gerekli.'});
      const row=verification.submit(req.auth.sub,{
        ...req.body,
        verificationVideoPath:req.file.path,
      });
      audit?.record?.({
        actorAdminId:req.auth.sub,action:'creator_verification_submit',
        targetType:'creator_verification',targetId:req.auth.sub,
        reason:'Creator submitted verification',metadata:{applicationId:row.id},
      });
      res.status(201).json({id:row.id,status:row.status});
    }catch(e){
      if(req.file?.path)fs.unlink(req.file.path,()=>{});
      res.status(400).json({error:e.message||'submit_failed'});
    }
  });

  return r;
};
