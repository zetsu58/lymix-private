# LYMIX V21.8 — Premium visual chrome audit

## Competitor APK behavior patterns observed
Resource names reveal separate presentation layers for:
- home/live banners
- room operation banners
- global gift top tips
- lucky/naming gift top tips
- VIP upgrade megaphone
- agency broadcast tips
- follow guides
- PK start tips
- welcome-package dialogs
- mini-card action popups
- gift-combo continuation strips

These are behavior references only. No competitor artwork/assets/code are included.

## Lymix implementation
- Auto-advancing product banner carousel (5s)
- Premium page indicators and touch feedback
- Rotating Lymix Official ticker
- Generic top-tip component for gift/VIP/PK/agency/system events
- Reusable feature popup sheet
- PK top-tip integrated into room
- Unified icon tile, border, motion and haptic language
- No fake user, fake jackpot, fake gift or fake social proof content

## Production binding
Static product notices can ship locally.
User/activity-specific banners, top-tips and popups must be driven by signed backend events.
