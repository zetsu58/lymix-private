# LYMIX V21.7 Clean-room architecture integration

This release reimplements product architecture observed from public APK behavior without copying proprietary source, assets, branding, credentials, or private endpoints.

## Core layers added
- RoomRuntimeController: room connection, participants and seat state.
- SocialPresenceRepository: public/open-room presence with private-room privacy gate.
- GameProviderAdapter: provider-neutral launch contract.
- GameProviderService: backend-authoritative catalog and launch-session client.
- GameSessionController: idle/invite/ready/matching/loading/playing/finished/failed game state.
- Game bridge events: game_ready, game_result, game_closed; malformed client events ignored.
- PermanentRoomService: one stable room per user; agency status upgrades same room.
- RoomPkController: timed PK and seat-switch rule.
- Gift settlement architecture: recipient-specific quota/credits/agency settlement.

## Game-room behavior
- Game catalog comes from Lymix backend; no fake game list.
- Launch uses authenticated SessionService user, never hard-coded demo user IDs.
- roomId is preserved into provider launch session.
- Provider secrets remain server-side.
- RTC remains Agora; game provider is an independent adapter.
- Game overlay sends structured bridge events into GameSessionController.
- Result/coin events must be verified server-side before affecting wallet or quota.

## Social/room cleanup
- Removed fake room event carousel.
- Removed fake VIP/level labels from empty/demo seat state.
- Room contribution/visitor/microphone counts derive from current state.
- Lucky/event controls no longer generate fake prizes/events.

## Provider-ready targets
Sud/ByteSun/H5/native providers can implement the same GameProviderAdapter contract. The app does not depend on a competitor credential or proprietary implementation.
