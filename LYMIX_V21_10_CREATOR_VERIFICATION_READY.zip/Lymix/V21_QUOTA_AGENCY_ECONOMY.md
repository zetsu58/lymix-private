# LYMIX V21 — Quota / Host Earnings / Agency Bank

## Currency separation
- **Coins**: purchased/spendable entertainment currency. Not fiat.
- **Gift Value**: gross coin value consumed by a gift transaction.
- **Quota Points**: weighted activity progress generated from received gifts.
- **Recyclable Coins**: configurable fraction returned to the receiver ecosystem; may be transferable to a verified agency bank only under server rules.
- **Earned Credits**: broadcaster settlement units. Not directly spendable Coins.
- **Agency Credits**: agency commission settlement units.
- **Agency Coin Bank**: server ledger for permitted agency transfers and settlement operations.
- **Fiat Payout**: external payout after KYC/region/provider/chargeback checks.

## Default policy
The percentages in code are placeholders for product testing and are NOT competitor rates.
Every tier has:
- quotaWeightBps
- recyclableCoinBps
- hostEarningBps
- agencyCommissionBps

All production percentages must come from signed backend configuration.

## Gift settlement flow
1. User spends Coins.
2. Backend creates immutable gift transaction.
3. Gift animation may play optimistically.
4. Backend computes quota + host + agency + recyclable values.
5. Settlement enters `pending`.
6. Chargeback/risk lock window -> `locked`.
7. Valid settlement -> `settled`.
8. Fraud/refund -> `reversed`.
9. Agency-bank transfer and host payout use separate signed requests.

## Safety requirements
- Idempotency key on every gift transaction.
- No client-side balance minting.
- Server time for quota windows.
- KYC for cash-out roles.
- Minimum payout threshold.
- Country-level payout eligibility.
- Chargeback reserve / lock period.
- Anti-self-gifting and circular gifting checks.
- Device/account/risk scoring.
- Audit log for admin changes.
- Agency bank transfers require role + server approval.
