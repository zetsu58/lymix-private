import 'dart:async';
import 'package:flutter/material.dart';
import '../design/lymix_design_system.dart';

class LymixBannerItem {
  final IconData icon;
  final String eyebrow;
  final String title;
  final String subtitle;
  final String action;
  final VoidCallback onTap;

  const LymixBannerItem({
    required this.icon,
    required this.eyebrow,
    required this.title,
    required this.subtitle,
    required this.action,
    required this.onTap,
  });
}

class LymixPromoCarousel extends StatefulWidget {
  final List<LymixBannerItem> items;
  const LymixPromoCarousel({super.key, required this.items});

  @override
  State<LymixPromoCarousel> createState() => _LymixPromoCarouselState();
}

class _LymixPromoCarouselState extends State<LymixPromoCarousel> {
  final controller = PageController(viewportFraction: .92);
  Timer? timer;
  int index = 0;

  @override
  void initState() {
    super.initState();
    if (widget.items.length > 1) {
      timer = Timer.periodic(const Duration(seconds: 5), (_) {
        if (!mounted || !controller.hasClients) return;
        final next = (index + 1) % widget.items.length;
        controller.animateToPage(
          next,
          duration: const Duration(milliseconds: 430),
          curve: Curves.easeOutCubic,
        );
      });
    }
  }

  @override
  void dispose() {
    timer?.cancel();
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.items.isEmpty) return const SizedBox.shrink();
    return Column(
      children: [
        SizedBox(
          height: 174,
          child: PageView.builder(
            controller: controller,
            itemCount: widget.items.length,
            onPageChanged: (value) => setState(() => index = value),
            itemBuilder: (_, i) => _BannerCard(item: widget.items[i]),
          ),
        ),
        const SizedBox(height: 8),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(widget.items.length, (i) {
            final active = i == index;
            return AnimatedContainer(
              duration: const Duration(milliseconds: 220),
              width: active ? 20 : 6,
              height: 6,
              margin: const EdgeInsets.symmetric(horizontal: 3),
              decoration: BoxDecoration(
                color: active ? LymixPalette.gold : Colors.white24,
                borderRadius: BorderRadius.circular(99),
              ),
            );
          }),
        ),
      ],
    );
  }
}

class _BannerCard extends StatelessWidget {
  final LymixBannerItem item;
  const _BannerCard({required this.item});

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 5),
    child: LymixPressable(
      onTap: item.onTap,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF2A1736),
              Color(0xFF171020),
              Color(0xFF0B0911),
            ],
          ),
          border: Border.all(color: Colors.white.withValues(alpha: .09)),
          boxShadow: [
            BoxShadow(
              color: LymixPalette.purple.withValues(alpha: .12),
              blurRadius: 26,
              offset: const Offset(0, 12),
            ),
          ],
        ),
        child: Stack(
          children: [
            Positioned(
              right: -18,
              top: -16,
              child: Container(
                width: 142,
                height: 142,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      LymixPalette.purple.withValues(alpha: .30),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              right: 20,
              top: 22,
              child: Container(
                width: 58,
                height: 58,
                decoration: BoxDecoration(
                  gradient: LymixPalette.brand,
                  borderRadius: BorderRadius.circular(19),
                  boxShadow: [
                    BoxShadow(
                      color: LymixPalette.gold.withValues(alpha: .22),
                      blurRadius: 20,
                    ),
                  ],
                ),
                child: Icon(item.icon, color: const Color(0xFF151018), size: 29),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(22, 22, 104, 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    Container(
                      width: 7,
                      height: 7,
                      decoration: const BoxDecoration(
                        color: LymixPalette.gold,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      item.eyebrow.toUpperCase(),
                      style: const TextStyle(
                        color: LymixPalette.gold,
                        fontSize: 9,
                        letterSpacing: 1.1,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ]),
                  const Spacer(),
                  Text(
                    item.title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 23,
                      height: 1.05,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    item.subtitle,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: LymixPalette.text2,
                      fontSize: 10.5,
                      height: 1.35,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(children: [
                    Text(
                      item.action,
                      style: const TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w900,
                        color: LymixPalette.text,
                      ),
                    ),
                    const SizedBox(width: 4),
                    const Icon(Icons.arrow_forward_rounded, size: 14),
                  ]),
                ],
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

class LymixTickerItem {
  final IconData icon;
  final String text;
  const LymixTickerItem(this.icon, this.text);
}

class LymixSystemTicker extends StatefulWidget {
  final List<LymixTickerItem> items;
  final VoidCallback? onTap;
  const LymixSystemTicker({super.key, required this.items, this.onTap});

  @override
  State<LymixSystemTicker> createState() => _LymixSystemTickerState();
}

class _LymixSystemTickerState extends State<LymixSystemTicker> {
  Timer? timer;
  int index = 0;

  @override
  void initState() {
    super.initState();
    if (widget.items.length > 1) {
      timer = Timer.periodic(const Duration(seconds: 4), (_) {
        if (mounted) setState(() => index = (index + 1) % widget.items.length);
      });
    }
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.items.isEmpty) return const SizedBox.shrink();
    final item = widget.items[index];
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 2),
      child: LymixPressable(
        onTap: widget.onTap,
        child: Container(
          height: 42,
          padding: const EdgeInsets.symmetric(horizontal: 11),
          decoration: BoxDecoration(
            color: LymixPalette.surface.withValues(alpha: .92),
            borderRadius: BorderRadius.circular(15),
            border: Border.all(color: Colors.white.withValues(alpha: .065)),
          ),
          child: Row(children: [
            Container(
              width: 27,
              height: 27,
              decoration: BoxDecoration(
                color: LymixPalette.gold.withValues(alpha: .12),
                borderRadius: BorderRadius.circular(9),
              ),
              child: Icon(item.icon, size: 15, color: LymixPalette.gold),
            ),
            const SizedBox(width: 9),
            const Text(
              'LYMIX',
              style: TextStyle(
                fontSize: 9,
                letterSpacing: .8,
                fontWeight: FontWeight.w900,
                color: LymixPalette.gold,
              ),
            ),
            const SizedBox(width: 9),
            Container(width: 1, height: 16, color: Colors.white12),
            const SizedBox(width: 9),
            Expanded(
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 260),
                transitionBuilder: (child, animation) => SlideTransition(
                  position: Tween<Offset>(
                    begin: const Offset(0, .35),
                    end: Offset.zero,
                  ).animate(animation),
                  child: FadeTransition(opacity: animation, child: child),
                ),
                child: Text(
                  item.text,
                  key: ValueKey(item.text),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: LymixPalette.text2,
                    fontSize: 10.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ),
            const Icon(Icons.chevron_right_rounded, size: 17, color: LymixPalette.text3),
          ]),
        ),
      ),
    );
  }
}

enum LymixTopTipKind { gift, vip, pk, agency, system }

class LymixTopTip extends StatelessWidget {
  final LymixTopTipKind kind;
  final String title;
  final String body;
  final VoidCallback? onTap;

  const LymixTopTip({
    super.key,
    required this.kind,
    required this.title,
    required this.body,
    this.onTap,
  });

  ({IconData icon, Color color}) get visual => switch (kind) {
        LymixTopTipKind.gift => (icon: Icons.card_giftcard_rounded, color: LymixPalette.pink),
        LymixTopTipKind.vip => (icon: Icons.workspace_premium_rounded, color: LymixPalette.gold),
        LymixTopTipKind.pk => (icon: Icons.flash_on_rounded, color: LymixPalette.danger),
        LymixTopTipKind.agency => (icon: Icons.hub_rounded, color: LymixPalette.cyan),
        LymixTopTipKind.system => (icon: Icons.campaign_rounded, color: LymixPalette.violet),
      };

  @override
  Widget build(BuildContext context) {
    final v = visual;
    return LymixPressable(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.fromLTRB(12, 8, 12, 0),
        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 9),
        decoration: BoxDecoration(
          color: const Color(0xF21A1323),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: v.color.withValues(alpha: .24)),
          boxShadow: const [
            BoxShadow(color: Color(0x55000000), blurRadius: 18, offset: Offset(0, 7)),
          ],
        ),
        child: Row(children: [
          Container(
            width: 35,
            height: 35,
            decoration: BoxDecoration(
              color: v.color.withValues(alpha: .12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(v.icon, color: v.color, size: 19),
          ),
          const SizedBox(width: 10),
          Expanded(child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900)),
              const SizedBox(height: 2),
              Text(
                body,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: LymixPalette.text3, fontSize: 9.5),
              ),
            ],
          )),
          if (onTap != null)
            const Icon(Icons.chevron_right_rounded, color: LymixPalette.text3, size: 18),
        ]),
      ),
    );
  }
}

class LymixFeaturePopup extends StatelessWidget {
  final IconData icon;
  final String eyebrow;
  final String title;
  final String body;
  final String action;
  final VoidCallback onAction;

  const LymixFeaturePopup({
    super.key,
    required this.icon,
    required this.eyebrow,
    required this.title,
    required this.body,
    required this.action,
    required this.onAction,
  });

  @override
  Widget build(BuildContext context) => SafeArea(
    child: Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 18),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(
          width: 42,
          height: 4,
          decoration: BoxDecoration(
            color: Colors.white24,
            borderRadius: BorderRadius.circular(99),
          ),
        ),
        const SizedBox(height: 18),
        Container(
          width: 72,
          height: 72,
          decoration: BoxDecoration(
            gradient: LymixPalette.brand,
            borderRadius: BorderRadius.circular(23),
            boxShadow: [
              BoxShadow(
                color: LymixPalette.gold.withValues(alpha: .20),
                blurRadius: 28,
              ),
            ],
          ),
          child: Icon(icon, size: 34, color: const Color(0xFF151018)),
        ),
        const SizedBox(height: 14),
        Text(
          eyebrow.toUpperCase(),
          style: const TextStyle(
            color: LymixPalette.gold,
            fontSize: 9,
            letterSpacing: 1.2,
            fontWeight: FontWeight.w900,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          title,
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
        ),
        const SizedBox(height: 8),
        Text(
          body,
          textAlign: TextAlign.center,
          style: const TextStyle(
            color: LymixPalette.text2,
            height: 1.45,
            fontSize: 11,
          ),
        ),
        const SizedBox(height: 18),
        SizedBox(
          width: double.infinity,
          child: FilledButton.icon(
            onPressed: onAction,
            icon: const Icon(Icons.arrow_forward_rounded),
            label: Text(action),
          ),
        ),
      ]),
    ),
  );
}
