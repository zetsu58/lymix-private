import 'package:flutter/material.dart';

class FeedScreen extends StatefulWidget {
  const FeedScreen({super.key});
  @override State<FeedScreen> createState() => _FeedScreenState();
}

class _FeedScreenState extends State<FeedScreen> {
  final controller = TextEditingController();
  final posts = <Map<String, dynamic>>[];

  @override void dispose(){controller.dispose();super.dispose();}

  @override Widget build(BuildContext context)=>Scaffold(
    backgroundColor:const Color(0xFF090611),
    appBar:AppBar(backgroundColor:const Color(0xFF110B19),title:const Text('Lymix Akış')),
    body:ListView(padding:const EdgeInsets.all(14),children:[
      Container(padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:Color(0xFF15101F),borderRadius:BorderRadius.circular(18)),child:Column(children:[
        Row(children:[const CircleAvatar(radius:20,backgroundColor:Color(0xFF2A1840),child:Icon(Icons.person_rounded,color:Colors.white70)),const SizedBox(width:10),Expanded(child:TextField(controller:controller,maxLines:3,minLines:1,decoration:const InputDecoration(hintText: 'Bir şey paylaş...', border: InputBorder.none)))]),
        Row(children:[TextButton.icon(onPressed:()=>_composerInfo('Medya','Fotoğraf/video yükleme backend medya servisine bağlandığında burada dosya seçici açılacak.'),icon:const Icon(Icons.image_outlined),label:const Text('Medya')),TextButton.icon(onPressed:()=>_composerInfo('Etkinlik','Kalıcı odan için gerçek etkinlik oluşturma akışı burada açılacak.'),icon:const Icon(Icons.event_outlined),label:const Text('Etkinlik')),const Spacer(),FilledButton(onPressed:_post,child:const Text('Paylaş'))])
      ])),
      const SizedBox(height:14),
      ...posts.map((p)=>Container(margin:const EdgeInsets.only(bottom:12),padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:Color(0xFF15101F),borderRadius:BorderRadius.circular(18)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Row(children:[const CircleAvatar(radius:18,backgroundColor:Color(0xFF2A1840),child:Icon(Icons.person_rounded,size:18,color:Colors.white70)),const SizedBox(width:9),Text(p['user'],style:const TextStyle(fontWeight:FontWeight.bold)),const Spacer(),const Text('şimdi',style:TextStyle(color:Colors.white38,fontSize:10))]),
        const SizedBox(height:10),Text(p['text'],style:const TextStyle(color:Colors.white70)),const SizedBox(height:12),
        Row(children:[IconButton(onPressed:()=>setState(()=>p['likes']=(p['likes'] as int)+1),icon:const Icon(Icons.favorite_border,size:20)),Text('${p['likes']}',style:const TextStyle(fontSize:11,color:Colors.white54)),IconButton(onPressed:()=>_comments(p),icon:const Icon(Icons.chat_bubble_outline,size:19)),Text('${p['comments']}',style:const TextStyle(fontSize:11,color:Colors.white54)),const Spacer(),IconButton(onPressed:()=>_share(p),icon:const Icon(Icons.share_outlined,size:19))])
      ])))
    ])
  );

  void _post(){final text=controller.text.trim();if(text.isEmpty)return;setState((){posts.insert(0,{'user':'Siz','text':text,'likes':0,'comments':0});controller.clear();});}

  void _composerInfo(String title,String body)=>showModalBottomSheet(
    context:context,
    builder:(ctx)=>SafeArea(child:Padding(
      padding:const EdgeInsets.all(20),
      child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text(title,style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900)),
        const SizedBox(height:7),
        Text(body,style:const TextStyle(color:Colors.white60)),
        const SizedBox(height:14),
        FilledButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Tamam')),
      ]),
    )),
  );

  void _comments(Map<String,dynamic> post)=>showModalBottomSheet(
    context:context,
    isScrollControlled:true,
    builder:(ctx)=>SafeArea(child:Padding(
      padding:EdgeInsets.only(left:18,right:18,top:18,bottom:MediaQuery.of(ctx).viewInsets.bottom+18),
      child:Column(mainAxisSize:MainAxisSize.min,children:[
        const Text('Yorumlar',style:TextStyle(fontSize:18,fontWeight:FontWeight.w900)),
        const SizedBox(height:12),
        const Text('Henüz yorum yok.',style:TextStyle(color:Colors.white54)),
        const SizedBox(height:12),
        TextField(
          decoration:const InputDecoration(hintText:'Yorum yaz...'),
          onSubmitted:(v){if(v.trim().isEmpty)return;setState(()=>post['comments']=(post['comments'] as int)+1);Navigator.pop(ctx);},
        ),
      ]),
    )),
  );

  void _share(Map<String,dynamic> post){
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content:Text('Paylaşım bağlantısı hazırlandığında sistem paylaşım menüsü açılacak.')),
    );
  }
}

