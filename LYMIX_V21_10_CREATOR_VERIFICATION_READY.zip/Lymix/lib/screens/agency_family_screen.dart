import 'package:flutter/material.dart';

class AgencyFamilyScreen extends StatefulWidget {
  const AgencyFamilyScreen({super.key});

  @override
  State<AgencyFamilyScreen> createState() => _AgencyFamilyScreenState();
}

class _AgencyFamilyScreenState extends State<AgencyFamilyScreen> {
  final chat = TextEditingController();
  final List<Map<String, String>> messages = [
    {'u': 'Sistem', 'm': 'Ajans mesajları, üyelik onaylandığında burada görünür.'},
  ];
  final List<Map<String, String>> members = [];
  final List<Map<String, String>> pending = [];

  static const int maxAgencyAdmins = 6; // Ajans sahibi hariç atanabilir admin limiti.
  int get adminCount => members.where((m) => m['role'] == 'Admin').length;
  bool get isAgencyOwner => false; // Backend role/claim gelene kadar yönetim kapalı.

  @override
  void dispose() {
    chat.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF090611),
      appBar: AppBar(
        backgroundColor: const Color(0xFF110C1C),
        foregroundColor: Colors.white,
        title: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Ajans Ailesi', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
          Text('Ajans üyeliği doğrulandığında kod ve roller burada görünür', style: TextStyle(fontSize: 10, color: Colors.white54)),
        ]),
        actions: [
          IconButton(tooltip: 'Üyeler', onPressed: _membersSheet, icon: const Icon(Icons.groups_3_outlined)),
          if (isAgencyOwner) IconButton(tooltip: 'Katılma Yönetimi', onPressed: _approvalSheet, icon: const Icon(Icons.admin_panel_settings_outlined)),
        ],
      ),
      body: Column(children: [
        _agencyBanner(),
        Expanded(child: ListView.builder(
          padding: const EdgeInsets.fromLTRB(14, 10, 14, 12),
          itemCount: messages.length,
          itemBuilder: (_, i) {
            final m = messages[i];
            final system = m['u'] == 'Sistem';
            return Align(
              alignment: system ? Alignment.center : (m['u'] == 'Siz' ? Alignment.centerRight : Alignment.centerLeft),
              child: Container(
                constraints: const BoxConstraints(maxWidth: 320),
                margin: const EdgeInsets.only(bottom: 9),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                decoration: BoxDecoration(
                  color: system ? Colors.white.withValues(alpha: .05) : (m['u'] == 'Siz' ? const Color(0x33FFD54A) : const Color(0xFF17101F)),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: system ? Colors.white10 : Colors.white.withValues(alpha: .05)),
                ),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  if (!system) Text(m['u']!, style: const TextStyle(color: Colors.amber, fontSize: 10, fontWeight: FontWeight.w800)),
                  Text(m['m']!, style: TextStyle(color: system ? Colors.white60 : Colors.white, fontSize: 13)),
                ]),
              ),
            );
          },
        )),
        _composer(),
      ]),
    );
  }

  Widget _agencyBanner() => Container(
    width: double.infinity,
    margin: const EdgeInsets.fromLTRB(14, 12, 14, 0),
    padding: const EdgeInsets.all(13),
    decoration: BoxDecoration(
      gradient: const LinearGradient(colors: [Color(0xFF251A0B), Color(0xFF15101F)]),
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: Colors.amber.withValues(alpha: .20)),
    ),
    child: Row(children: [
      const CircleAvatar(backgroundColor: Color(0x33FFD54A), child: Icon(Icons.family_restroom, color: Colors.amber)),
      const SizedBox(width: 11),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Ajans bilgileri bekleniyor', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
        Text('${members.length} aile üyesi • $adminCount/$maxAgencyAdmins admin • Gerçek üyelik backend tarafından doğrulanır', style: const TextStyle(color: Colors.white54, fontSize: 10)),
      ])),
      if (isAgencyOwner) TextButton(onPressed: _approvalSheet, child: Text('İstekler ${pending.length}')),
    ]),
  );

  Widget _composer() => SafeArea(top: false, child: Padding(
    padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
    child: Row(children: [
      Expanded(child: TextField(
        controller: chat,
        maxLength: 500,
        style: const TextStyle(color: Colors.white),
        decoration: InputDecoration(
          counterText: '', hintText: 'Ajans ailene mesaj yaz...', hintStyle: const TextStyle(color: Colors.white38),
          filled: true, fillColor: const Color(0xFF17101F),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
        ),
      )),
      const SizedBox(width: 8),
      IconButton.filled(onPressed: _send, style: IconButton.styleFrom(backgroundColor: Colors.amber, foregroundColor: Colors.black), icon: const Icon(Icons.send_rounded)),
    ]),
  ));

  void _send() {
    final value = chat.text.trim();
    if (value.isEmpty) return;
    setState(() {
      messages.add({'u': 'Siz', 'm': value});
      chat.clear();
    });
  }

  void _membersSheet() => showModalBottomSheet(
    context: context,
    backgroundColor: const Color(0xFF15101F),
    showDragHandle: true,
    builder: (_) => SafeArea(child: Padding(
      padding: const EdgeInsets.all(18),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Ajans Ailesi Üyeleri (${members.length})', style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800)),
        const SizedBox(height: 10),
        ...members.map((m) => ListTile(
          contentPadding: EdgeInsets.zero,
          leading: CircleAvatar(child: Text(m['name']![0])),
          title: Text(m['name']!, style: const TextStyle(color: Colors.white)),
          subtitle: Text('ID ${m['id']} • ${m['role']}', style: const TextStyle(color: Colors.white54, fontSize: 11)),
          trailing: m['role'] == 'Sahip' ? const Icon(Icons.workspace_premium, color: Colors.amber) : null,
        )),
        Text('Aile üyesi alımında sayı sınırı yoktur. Ajans sahibi en fazla $maxAgencyAdmins kişiye Admin yetkisi verebilir.', style: const TextStyle(color: Colors.white38, fontSize: 10)),
      ]),
    )),
  );

  void _approvalSheet() => showModalBottomSheet(
    context: context,
    backgroundColor: const Color(0xFF15101F),
    isScrollControlled: true,
    showDragHandle: true,
    builder: (ctx) => StatefulBuilder(builder: (ctx, setLocal) => SafeArea(child: Padding(
      padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Ajansa / Aileye Katılma Yönetimi', style: TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w900)),
        const SizedBox(height: 5),
        const Text('Başvuruları yalnızca ajans sahibi onaylayabilir. Onaylanan kullanıcı otomatik olarak ajansın özel mesaj odasına eklenir.', style: TextStyle(color: Colors.white54, fontSize: 11)),
        const SizedBox(height: 14),
        if (pending.isEmpty) const Padding(padding: EdgeInsets.all(18), child: Center(child: Text('Bekleyen başvuru yok.', style: TextStyle(color: Colors.white54)))),
        ...pending.map((p) => Container(
          margin: const EdgeInsets.only(bottom: 9), padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: Colors.white.withValues(alpha: .04), borderRadius: BorderRadius.circular(14)),
          child: Row(children: [
            CircleAvatar(child: Text(p['name']![0])), const SizedBox(width: 10),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(p['name']!, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
              Text('ID ${p['id']} • ${p['note']}', style: const TextStyle(color: Colors.white54, fontSize: 10)),
            ])),
            IconButton(tooltip: 'Reddet', onPressed: () { setState(() => pending.remove(p)); setLocal(() {}); }, icon: const Icon(Icons.close, color: Colors.redAccent)),
            IconButton(tooltip: 'Onayla', onPressed: () {
              setState(() {
                pending.remove(p);
                members.add({'id': p['id']!, 'name': p['name']!, 'role': 'Üye'});
                messages.add({'u': 'Sistem', 'm': '✅ ${p['name']} ajans ailesine katıldı.'});
              });
              setLocal(() {});
            }, icon: const Icon(Icons.check_circle, color: Colors.greenAccent)),
          ]),
        )),
        Text('Aile üyeliği sınırsızdır. Admin yetkisi ayrı yönetilir ve en fazla $maxAgencyAdmins kişiye verilebilir.', style: const TextStyle(color: Colors.amber, fontSize: 11)),
      ]),
    ))),
  );
}
