import 'package:flutter/material.dart';
import '../design/lymix_design_system.dart';

class InventoryScreen extends StatelessWidget {
  const InventoryScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Çantam')),
    body: ListView(
      padding: const EdgeInsets.all(16),
      children: const [
        _InventoryCategory(Icons.account_circle_outlined, 'Avatar Çerçeveleri', 'Sahip olduğun çerçeveler'),
        _InventoryCategory(Icons.auto_awesome_rounded, 'Giriş Efektleri', 'Odaya giriş animasyonları'),
        _InventoryCategory(Icons.chat_bubble_outline_rounded, 'Mesaj Balonları', 'VIP ve etkinlik görünümleri'),
        _InventoryCategory(Icons.badge_outlined, 'Rozetler', 'Kazanılmış kimlik ve başarı rozetleri'),
        _InventoryCategory(Icons.diamond_outlined, 'Özel Varlıklar', 'Etkinlik ve sezon öğeleri'),
      ],
    ),
  );
}

class _InventoryCategory extends StatelessWidget {
  final IconData icon; final String title; final String subtitle;
  const _InventoryCategory(this.icon, this.title, this.subtitle);
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: LymixGlassSurface(
      child: ListTile(
        contentPadding: EdgeInsets.zero,
        leading: Icon(icon, color: LymixPalette.gold),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
        subtitle: Text(subtitle, style: const TextStyle(color: LymixPalette.text3, fontSize: 10)),
        trailing: const Text('0', style: TextStyle(color: LymixPalette.text3)),
      ),
    ),
  );
}
