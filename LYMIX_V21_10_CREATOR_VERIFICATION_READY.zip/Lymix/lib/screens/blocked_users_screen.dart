import 'package:flutter/material.dart';
import '../design/lymix_design_system.dart';

class BlockedUsersScreen extends StatelessWidget {
  const BlockedUsersScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Engellenenler')),
    body: const Center(
      child: Padding(
        padding: EdgeInsets.all(28),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.block_rounded, size: 50, color: LymixPalette.text3),
          SizedBox(height: 12),
          Text('Engellenen hesap yok', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
          SizedBox(height: 5),
          Text('Engellediğin gerçek hesaplar burada yönetilecek.', textAlign: TextAlign.center, style: TextStyle(color: LymixPalette.text3)),
        ]),
      ),
    ),
  );
}
