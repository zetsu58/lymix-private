import 'package:flutter/material.dart';
import '../services/localization_service.dart';
import '../services/permanent_room_service.dart';
import '../design/lymix_design_system.dart';
import 'room_screen.dart';

/// Kept with the old class name to avoid breaking existing routes.
/// Product behavior is now "My Permanent Room", never "create unlimited rooms".
class RoomCreateScreen extends StatefulWidget {
  const RoomCreateScreen({super.key});

  @override
  State<RoomCreateScreen> createState() => _RoomCreateScreenState();
}

class _RoomCreateScreenState extends State<RoomCreateScreen> {
  final title = TextEditingController();
  final topic = TextEditingController();
  PermanentRoomProfile? room;
  bool loading = true;
  bool saving = false;
  bool locked = false;
  bool discoverable = true;
  int seats = 12;
  String? error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final r = await PermanentRoomService.ensureForCurrentUser();
      if (!mounted) return;
      room = r;
      title.text = r.title;
      topic.text = r.topic;
      locked = r.isPrivate;
      discoverable = r.discoverable;
      seats = r.seats;
    } catch (e) {
      error = '$e';
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  void dispose() {
    title.dispose();
    topic.dispose();
    super.dispose();
  }

  Future<void> _saveAndEnter() async {
    final current = room;
    if (current == null || saving) return;
    final name = title.text.trim();
    if (name.length < 3) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(context.lx('roomNameError'))),
      );
      return;
    }

    setState(() => saving = true);
    final updated = current.copyWith(
      title: name,
      topic: topic.text.trim(),
      isPrivate: locked,
      discoverable: locked ? false : discoverable,
      seats: seats,
    );
    await PermanentRoomService.save(updated);
    if (!mounted) return;
    room = updated;
    setState(() => saving = false);

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => LymixRoomScreen(
          roomId: updated.roomId,
          roomTitle: updated.title,
          currentUserIsOwner: true,
          isPrivateRoom: updated.isPrivate,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    if (error != null || room == null) {
      return Scaffold(
        appBar: AppBar(title: Text(context.lx('myRoom'))),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.cloud_off_rounded, size: 48, color: LymixPalette.text3),
              const SizedBox(height: 12),
              const Text('Oda bilgisi yüklenemedi.', style: TextStyle(fontWeight: FontWeight.w900)),
              const SizedBox(height: 6),
              Text(error ?? '', textAlign: TextAlign.center, style: const TextStyle(color: LymixPalette.text3)),
              const SizedBox(height: 16),
              FilledButton(onPressed: () {
                setState(() { loading = true; error = null; });
                _load();
              }, child: const Text('Tekrar Dene')),
            ]),
          ),
        ),
      );
    }

    final r = room!;
    return Scaffold(
      appBar: AppBar(title: Text(r.isAgencyRoom ? context.lx('agencyRoom') : context.lx('myRoom'))),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 32),
        children: [
          LymixGlassSurface(
            elevated: true,
            child: Row(children: [
              Container(
                width: 56,
                height: 56,
                decoration: const BoxDecoration(
                  gradient: LymixPalette.brand,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  r.isAgencyRoom ? Icons.hub_rounded : Icons.graphic_eq_rounded,
                  color: Colors.black,
                ),
              ),
              const SizedBox(width: 13),
              Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    r.isAgencyRoom ? (r.agencyName ?? context.lx('agencyRoom')) : context.lx('permanentRoom'),
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'ID: ${r.roomId} • ${r.isAgencyRoom ? context.lx('agencyRoomSub') : context.lx('permanentRoomSub')}',
                    style: const TextStyle(color: LymixPalette.text2, fontSize: 10),
                  ),
                ],
              )),
            ]),
          ),
          const SizedBox(height: 18),
          TextField(
            controller: title,
            maxLength: 42,
            decoration: InputDecoration(labelText: context.lx('roomName')),
          ),
          TextField(
            controller: topic,
            maxLength: 120,
            minLines: 2,
            maxLines: 3,
            decoration: InputDecoration(labelText: context.lx('roomTopic')),
          ),
          DropdownButtonFormField<int>(
            initialValue: seats,
            decoration: InputDecoration(labelText: context.lx('micSeats')),
            items: [8, 12, 16].map((v) => DropdownMenuItem(
              value: v,
              child: Text('$v ${context.lx('seats')}'),
            )).toList(),
            onChanged: (v) => setState(() => seats = v ?? 12),
          ),
          const SizedBox(height: 6),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: locked,
            onChanged: (v) => setState(() {
              locked = v;
              if (v) discoverable = false;
            }),
            title: Text(context.lx('privateRoom')),
            subtitle: Text(context.lx('privateRoomSub')),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: discoverable && !locked,
            onChanged: locked ? null : (v) => setState(() => discoverable = v),
            title: Text(context.lx('showDiscover')),
            subtitle: Text(context.lx('showDiscoverSub')),
          ),
          const SizedBox(height: 18),
          SizedBox(
            height: 54,
            child: FilledButton.icon(
              onPressed: saving ? null : _saveAndEnter,
              icon: saving
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.login_rounded),
              label: Text(context.lx('enterMyRoom')),
            ),
          ),
        ],
      ),
    );
  }
}
