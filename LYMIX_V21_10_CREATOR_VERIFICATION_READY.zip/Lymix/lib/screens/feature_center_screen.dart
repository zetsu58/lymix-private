import 'package:flutter/material.dart';
import 'agency_family_screen.dart';
import 'creator_earnings_screen.dart';
import 'creator_verification_screen.dart';
import 'feed_screen.dart';
import 'game_center_screen.dart';
import 'inventory_screen.dart';
import 'notification_center_screen.dart';
import 'relationship_center_screen.dart';
import 'room_create_screen.dart';
import 'vip_center_screen.dart';

class FeatureCenterScreen extends StatelessWidget {
  const FeatureCenterScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Lymix Özellik Merkezi')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
          ListTile(
            leading: const Icon(Icons.verified_user_rounded, color: Color(0xFFFFD338)),
            title: const Text('Yayıncı Doğrulama'),
            subtitle: const Text('Telefon • canlı video • ajans başvurusu'),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CreatorVerificationScreen())),
          ),

            _route(context, Icons.dynamic_feed, 'Akış & Post', 'Gerçek topluluk paylaşımları ve etkinlikler', const FeedScreen()),
            _route(context, Icons.workspace_premium_rounded, 'VIP & Crown', 'VIP ayrıcalıkları, çerçeveler ve kimlik', const VipCenterScreen()),
            _route(context, Icons.backpack_rounded, 'Çantam', 'Sahip olunan gerçek profil varlıkları', const InventoryScreen()),
            _route(context, Icons.favorite_outline_rounded, 'İlişki Merkezi', 'Karşılıklı onaylanan ilişki ve ortak ilerleme', const RelationshipCenterScreen()),
            _route(context, Icons.currency_exchange_rounded, 'Kota & Kazanç', 'Yayıncı kota ve settlement görünümü', const CreatorEarningsScreen()),
            _route(context, Icons.groups_3_rounded, 'Ajans & Aile', 'Ajans üyeleri, roller ve özel iletişim', const AgencyFamilyScreen()),
            _route(context, Icons.home_work_outlined, 'Kendi Odam', 'Hesabına bağlı tek kalıcı oda', const RoomCreateScreen()),
            _route(context, Icons.sports_esports_rounded, 'Oyun Merkezi', 'Lisanslı sağlayıcıdan gelen gerçek oyun kataloğu', const GameCenterScreen()),
            _route(context, Icons.campaign_outlined, 'Sistem Bildirimleri', 'Lymix Official ve sistem bildirimleri', const NotificationCenterScreen()),
          ],
        ),
      );

  Widget _route(BuildContext context, IconData icon, String title, String subtitle, Widget target) => Card(
        margin: const EdgeInsets.only(bottom: 10),
        child: ListTile(
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => target)),
          leading: CircleAvatar(child: Icon(icon)),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
          subtitle: Text(subtitle, style: const TextStyle(fontSize: 11)),
          trailing: const Icon(Icons.chevron_right_rounded),
        ),
      );
}
