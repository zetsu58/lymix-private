import 'package:flutter/material.dart';
import '../design/lymix_design_system.dart';
import '../game_overlay_widget.dart';
import '../services/game_provider_service.dart';
import '../services/game_session_controller.dart';
import '../services/session_service.dart';

class GameCenterScreen extends StatefulWidget {
  final String roomId;
  const GameCenterScreen({super.key, this.roomId = 'global'});

  @override
  State<GameCenterScreen> createState() => _GameCenterScreenState();
}

class _GameCenterScreenState extends State<GameCenterScreen> {
  final provider = GameProviderService();
  late final GameSessionController session = GameSessionController(provider: provider);
  List<GameCatalogEntry> games = const [];
  bool loading = true;
  String? error;

  @override
  void initState() {
    super.initState();
    session.addListener(_refresh);
    _load();
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  Future<void> _load() async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final result = await provider.getCatalog();
      if (!mounted) return;
      setState(() => games = result);
    } catch (e) {
      if (!mounted) return;
      setState(() => error = '$e');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  void dispose() {
    session.removeListener(_refresh);
    session.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('Oyun Merkezi'),
          actions: [
            if (session.active)
              const Padding(
                padding: EdgeInsets.only(right: 16),
                child: Center(child: LymixPremiumBadge('OYUN AKTİF', icon: Icons.sports_esports_rounded)),
              ),
          ],
        ),
        body: _body(),
      );

  Widget _body() {
    if (loading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.cloud_off_rounded, size: 52, color: LymixPalette.text3),
            const SizedBox(height: 12),
            const Text('Oyun kataloğu yüklenemedi', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            Text(error!, textAlign: TextAlign.center, style: const TextStyle(color: LymixPalette.text3)),
            const SizedBox(height: 14),
            FilledButton.icon(onPressed: _load, icon: const Icon(Icons.refresh_rounded), label: const Text('Tekrar Dene')),
          ]),
        ),
      );
    }
    if (games.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(28),
          child: LymixGlassSurface(
            elevated: true,
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.sports_esports_rounded, size: 56, color: LymixPalette.gold),
              SizedBox(height: 12),
              Text('Oyun sağlayıcısı bekleniyor', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
              SizedBox(height: 7),
              Text(
                'Lisanslı oyun sağlayıcısının kataloğu backend’e bağlandığında gerçek oyunlar burada otomatik görünecek. Lymix demo oyun veya sahte skor göstermez.',
                textAlign: TextAlign.center,
                style: TextStyle(color: LymixPalette.text2, height: 1.45),
              ),
            ]),
          ),
        ),
      );
    }
    return GridView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: games.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        childAspectRatio: .86,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
      ),
      itemBuilder: (_, i) => _tile(games[i]),
    );
  }

  Widget _tile(GameCatalogEntry game) => LymixPressable(
        onTap: () => _open(game),
        child: LymixGlassSurface(
          padding: const EdgeInsets.all(12),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Container(
              width: 58,
              height: 58,
              decoration: BoxDecoration(
                gradient: LymixPalette.brand,
                borderRadius: BorderRadius.circular(18),
              ),
              child: game.iconUrl == null
                  ? const Icon(Icons.sports_esports_rounded, color: Colors.black, size: 30)
                  : ClipRRect(
                      borderRadius: BorderRadius.circular(18),
                      child: Image.network(game.iconUrl!, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.sports_esports_rounded, color: Colors.black)),
                    ),
            ),
            const SizedBox(height: 9),
            Text(game.name, maxLines: 2, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 11)),
            const SizedBox(height: 3),
            Text(game.category, style: const TextStyle(color: LymixPalette.text3, fontSize: 9)),
          ]),
        ),
      );

  Future<void> _open(GameCatalogEntry game) async {
    final user = await SessionService.user();
    if (!mounted) return;
    if (user == null || user.id.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Oyun için aktif oturum gerekli.')));
      return;
    }
    try {
      final url = await session.launch(
        gameId: game.id,
        roomId: widget.roomId,
        userId: user.id,
        displayName: user.displayName.isEmpty ? user.login : user.displayName,
      );
      if (!mounted) return;
      showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        builder: (sheetContext) => LymixLiveGameOverlay(
          gameUrl: url,
          onBridgeEvent: session.handleBridgeEvent,
          onClose: () {
            session.close();
            Navigator.pop(sheetContext);
          },
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    }
  }
}
