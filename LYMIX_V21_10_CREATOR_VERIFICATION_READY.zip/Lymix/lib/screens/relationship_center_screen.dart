import 'package:flutter/material.dart';
import '../design/lymix_design_system.dart';

class RelationshipCenterScreen extends StatelessWidget {
  const RelationshipCenterScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('İlişki Merkezi')),
        body: const Center(
          child: Padding(
            padding: EdgeInsets.all(28),
            child: LymixGlassSurface(
              elevated: true,
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.favorite_outline_rounded, size: 52, color: LymixPalette.pink),
                SizedBox(height: 12),
                Text('Henüz ilişki bağlantın yok', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                SizedBox(height: 7),
                Text(
                  'Karşılıklı onaylanan ilişki, başlangıç tarihi, ortak hediye/katkı ilerlemesi ve yüzük envanteri burada gösterilecek. Lymix demo eşleşme üretmez.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: LymixPalette.text2, height: 1.45),
                ),
              ]),
            ),
          ),
        ),
      );
}
