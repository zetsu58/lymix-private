import 'package:flutter/material.dart';
import '../services/localization_service.dart';
import '../theme/lymix_theme.dart';
import 'language_screen.dart';
import 'privacy_center_screen.dart';
import 'moderation_safety_screen.dart';
import 'account_data_screen.dart';
import 'message_requests_screen.dart';
import 'notification_preferences_screen.dart';
import 'comfort_settings_screen.dart';
import 'audio_quality_screen.dart';
import 'device_sessions_screen.dart';

class AppSettingsScreen extends StatefulWidget {
  const AppSettingsScreen({super.key});
  @override
  State<AppSettingsScreen> createState() => _AppSettingsScreenState();
}

class _AppSettingsScreenState extends State<AppSettingsScreen> {
  final localeController = LymixLocaleController.instance;
  bool entranceEffects = true;
  bool roomEffects = true;
  bool autoPlay = false;
  bool reduceMotion = false;
  bool dataSaver = false;

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(context.lx('settings'))),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
          children: [
            _group(context.lx('application'), [
              _tile(Icons.language_rounded, context.lx('language'), lymixLanguageNames[localeController.locale.languageCode] ?? 'Türkçe', () => Navigator.push(context, MaterialPageRoute(builder: (_) => LanguageScreen(controller: localeController)))),
              _tile(Icons.notifications_active_outlined, context.lx('notificationPreferences'), context.lx('notificationSub'), () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NotificationPreferencesScreen()))),
              _tile(Icons.mark_chat_unread_outlined, context.lx('messageRequests'), context.lx('messageRequestsSub'), () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MessageRequestsScreen()))),
            ]),
            const SizedBox(height: 14),
            _group(context.lx('visualExperience'), [
              _switch(Icons.auto_awesome_rounded, context.lx('entranceEffects'), context.lx('entranceEffectsSub'), entranceEffects, (v) => setState(() => entranceEffects = v)),
              _switch(Icons.blur_on_rounded, context.lx('roomEffects'), context.lx('roomEffectsSub'), roomEffects, (v) => setState(() => roomEffects = v)),
              _switch(Icons.play_circle_outline_rounded, context.lx('autoplay'), context.lx('autoplaySub'), autoPlay, (v) => setState(() => autoPlay = v)),
              _switch(Icons.motion_photos_off_outlined, context.lx('reduceMotion'), context.lx('reduceMotionSub'), reduceMotion, (v) => setState(() => reduceMotion = v)),
              _tile(Icons.visibility_outlined, context.lx('visualComfort'), context.lx('visualComfortSub'), () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ComfortSettingsScreen()))),
              _tile(Icons.graphic_eq_rounded, context.lx('audioQuality'), context.lx('audioQualitySub'), () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AudioQualityScreen()))),
              _switch(Icons.data_saver_on_rounded, context.lx('dataSaver'), context.lx('dataSaverSub'), dataSaver, (v) => setState(() => dataSaver = v)),
            ]),
            const SizedBox(height: 14),
            _group(context.lx('securityAccount'), [
              _tile(Icons.shield_outlined, context.lx('privacy'), context.lx('privacySub'), () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PrivacyCenterScreen()))),
              _tile(Icons.health_and_safety_outlined, context.lx('moderationSafety'), context.lx('moderationSafetySub'), () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ModerationSafetyScreen()))),
              _tile(Icons.devices_outlined, context.lx('devices'), context.lx('devicesSub'), () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DeviceSessionsScreen()))),
              _tile(Icons.lock_outline_rounded, context.lx('accountData'), context.lx('accountDataSub'), () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AccountDataScreen()))),
            ]),
            const SizedBox(height: 18),
            const Text('Lymix • V21', textAlign: TextAlign.center, style: TextStyle(color: Colors.white30, fontSize: 10)),
          ],
        ),
      );

  Widget _group(String title, List<Widget> children) => Container(
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
        decoration: BoxDecoration(color: LymixColors.surface, borderRadius: BorderRadius.circular(22), border: Border.all(color: Colors.white.withValues(alpha: .05))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Padding(padding: const EdgeInsets.fromLTRB(5, 2, 5, 7), child: Text(title, style: const TextStyle(color: Colors.white54, fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: .7))),
          ...children,
        ]),
      );

  Widget _tile(IconData icon, String title, String sub, VoidCallback onTap) => ListTile(
        onTap: onTap,
        leading: _icon(icon),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
        subtitle: Text(sub, style: const TextStyle(color: Colors.white38, fontSize: 9.5)),
        trailing: const Icon(Icons.chevron_right_rounded, color: Colors.white30),
      );

  Widget _switch(IconData icon, String title, String sub, bool value, ValueChanged<bool> onChanged) => SwitchListTile.adaptive(
        value: value,
        onChanged: onChanged,
        activeColor: LymixColors.gold,
        secondary: _icon(icon),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
        subtitle: Text(sub, style: const TextStyle(color: Colors.white38, fontSize: 9.5)),
      );

  Widget _icon(IconData icon) => Container(
        width: 39,
        height: 39,
        decoration: BoxDecoration(color: Colors.white.withValues(alpha: .045), borderRadius: BorderRadius.circular(12)),
        child: Icon(icon, color: LymixColors.gold, size: 19),
      );
}
