import 'package:flutter/material.dart';
import '../design/lymix_design_system.dart';
import 'room_screen.dart';

class DirectMessageScreen extends StatefulWidget {
  final String userId;
  final String displayName;
  final String? openRoomId;
  final String? openRoomTitle;
  final bool privateRoom;

  const DirectMessageScreen({
    super.key,
    required this.userId,
    required this.displayName,
    this.openRoomId,
    this.openRoomTitle,
    this.privateRoom = false,
  });

  @override
  State<DirectMessageScreen> createState() => _DirectMessageScreenState();
}

class _DirectMessageScreenState extends State<DirectMessageScreen> {
  final input = TextEditingController();
  final messages = <Map<String, dynamic>>[];

  bool get canJoin =>
      !widget.privateRoom && (widget.openRoomId?.isNotEmpty ?? false);

  @override
  void dispose() {
    input.dispose();
    super.dispose();
  }

  void _send() {
    final text = input.text.trim();
    if (text.isEmpty) return;
    setState(() {
      messages.add({'text': text, 'me': true, 'seen': false});
      input.clear();
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(widget.displayName),
              Text(
                canJoin
                    ? '${widget.openRoomTitle ?? 'Açık oda'} • odada'
                    : widget.privateRoom
                        ? 'Özel oda bilgisi gizli'
                        : 'Özel mesaj',
                style: const TextStyle(fontSize: 9, color: LymixPalette.text3),
              ),
            ],
          ),
          actions: [
            if (canJoin)
              IconButton(
                tooltip: 'Odaya Git',
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => LymixRoomScreen(
                      roomId: widget.openRoomId!,
                      roomTitle: widget.openRoomTitle ?? 'Sesli Oda',
                    ),
                  ),
                ),
                icon: const Icon(Icons.graphic_eq_rounded, color: LymixPalette.gold),
              ),
          ],
        ),
        body: Column(children: [
          Expanded(
            child: messages.isEmpty
                ? const Center(
                    child: Padding(
                      padding: EdgeInsets.all(28),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Icon(Icons.forum_outlined, size: 48, color: LymixPalette.text3),
                        SizedBox(height: 12),
                        Text('Sohbeti başlat', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                        SizedBox(height: 5),
                        Text(
                          'Mesajlar gerçek kullanıcı etkileşimiyle burada oluşur. Demo konuşma gösterilmez.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: LymixPalette.text3),
                        ),
                      ]),
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.all(14),
                    itemCount: messages.length,
                    itemBuilder: (_, i) {
                      final m = messages[i];
                      return Align(
                        alignment: m['me'] == true ? Alignment.centerRight : Alignment.centerLeft,
                        child: Container(
                          constraints: const BoxConstraints(maxWidth: 290),
                          margin: const EdgeInsets.only(bottom: 8),
                          padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 10),
                          decoration: BoxDecoration(
                            color: m['me'] == true ? LymixPalette.purple : LymixPalette.surface2,
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Text('${m['text']}'),
                        ),
                      );
                    },
                  ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
              child: Row(children: [
                IconButton(
                  tooltip: 'Hediye',
                  onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Hediye, oda içinden gerçek alıcı ve bakiye ile gönderilir.')),
                  ),
                  icon: const Icon(Icons.card_giftcard_rounded, color: LymixPalette.gold),
                ),
                Expanded(
                  child: TextField(
                    controller: input,
                    minLines: 1,
                    maxLines: 4,
                    textInputAction: TextInputAction.send,
                    onSubmitted: (_) => _send(),
                    decoration: const InputDecoration(hintText: 'Mesaj yaz...'),
                  ),
                ),
                IconButton(onPressed: _send, icon: const Icon(Icons.send_rounded)),
              ]),
            ),
          ),
        ]),
      );
}
