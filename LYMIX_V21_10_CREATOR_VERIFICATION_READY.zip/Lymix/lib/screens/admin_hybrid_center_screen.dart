import 'package:flutter/material.dart';
import '../design/lymix_design_system.dart';
import '../services/admin_access_service.dart';
import '../services/session_service.dart';
import 'admin_economy_center_screen.dart';
import 'admin_web_panel_screen.dart';
import 'agency_family_screen.dart';
import 'blocked_users_screen.dart';
import 'my_reports_screen.dart';
import 'notification_center_screen.dart';
import 'privacy_center_screen.dart';

class AdminHybridCenterScreen extends StatefulWidget {
  const AdminHybridCenterScreen({super.key});

  @override
  State<AdminHybridCenterScreen> createState() => _AdminHybridCenterScreenState();
}

class _AdminHybridCenterScreenState extends State<AdminHybridCenterScreen> {
  SessionUser? user;
  Set<AdminCapability> capabilities = const {};
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final u = await SessionService.user();
    if (!mounted) return;
    setState(() {
      user = u;
      capabilities = u == null
          ? const {}
          : AdminAccessService.capabilitiesFor(u);
      loading = false;
    });
  }

  bool has(AdminCapability c) => capabilities.contains(c);

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    if (user == null || capabilities.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('Yönetim')),
        body: const Center(
          child: Padding(
            padding: EdgeInsets.all(24),
            child: Text(
              'Bu hesabın yönetim yetkisi yok.',
              style: TextStyle(color: LymixPalette.text2),
            ),
          ),
        ),
      );
    }

    final isSuper = AdminAccessService.isSuperAdminRole(user!.role);

    return Scaffold(
      appBar: AppBar(
        title: Text(isSuper ? 'LYMIX Yönetim Merkezi' : 'Ajans Yönetimi'),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 34),
        children: [
          _hero(isSuper),
          const SizedBox(height: 14),
          if (has(AdminCapability.roomModeration))
            _section('Canlı Operasyon', [
              _AdminAction(
                Icons.mic_rounded,
                'Oda Moderasyonu',
                'Admin listesi • susturma • atma • oda kuralları',
                () => _info(
                  'Oda Moderasyonu',
                  'Oda sahibinin ve moderatörlerin hızlı araçları mevcut oda '
                  'ekranında çalışır. Global müdahaleler backend audit kaydıyla '
                  'uygulanmalıdır.',
                ),
              ),
              _AdminAction(
                Icons.campaign_rounded,
                'Duyurular',
                'Sistem ve oda duyurularını yönet',
                () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const NotificationCenterScreen(),
                  ),
                ),
              ),
            ]),
          if (has(AdminCapability.agencyManagement))
            _section('Ajans & Yayıncı', [
              _AdminAction(
                Icons.hub_rounded,
                'Ajans Merkezi',
                'Üyeler • başvurular • host yönetimi',
                () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const AgencyFamilyScreen(),
                  ),
                ),
              ),
            ]),
          if (has(AdminCapability.reports))
            _section('Güvenlik', [
              _AdminAction(
                Icons.flag_rounded,
                'Raporlar',
                'Şikayet ve moderasyon durumu',
                () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const MyReportsScreen()),
                ),
              ),
              _AdminAction(
                Icons.block_rounded,
                'Engellenenler',
                'Engel kayıtları ve güvenlik kontrolleri',
                () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const BlockedUsersScreen()),
                ),
              ),
              _AdminAction(
                Icons.privacy_tip_rounded,
                'Gizlilik Merkezi',
                'Profil, oda ve mesaj izinleri',
                () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const PrivacyCenterScreen(),
                  ),
                ),
              ),
            ]),
          if (has(AdminCapability.economy))
            _section('Ekonomi', [
              _AdminAction(
                Icons.toll_rounded,
                'Ekonomi & Hediyeler',
                'Coin • hediye • kota • ajans bankası',
                () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const AdminEconomyCenterScreen(),
                  ),
                ),
              ),
            ]),
          if (has(AdminCapability.auditLog) || has(AdminCapability.userLookup))
            _section('Global Operasyon', [
              _AdminAction(
                Icons.manage_search_rounded,
                'Kullanıcı & Audit',
                'Kullanıcı arama • rol • ceza • değişiklik geçmişi',
                () => _info(
                  'Kullanıcı & Audit',
                  'Production sürümünde global kullanıcı/rol/ceza/audit işlemleri '
                  'web panel + backend üzerinden yürütülecek.',
                ),
              ),
              if (has(AdminCapability.webConsole))
                _AdminAction(
                  Icons.language_rounded,
                  'Web Yönetim Paneli',
                  'Gelişmiş kullanıcı, ajans, ekonomi ve audit işlemleri',
                  () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const AdminWebPanelScreen(),
                    ),
                  ),
                ),
            ]),
          const SizedBox(height: 14),
          const Text(
            'Uygulama içi admin hızlı operasyon arayüzüdür. Global kullanıcı, '
            'coin, settlement, rol ve kalıcı ban değişiklikleri backend tarafından '
            'yetkilendirilip audit log’a yazılmalıdır.',
            style: TextStyle(
              fontSize: 9.5,
              color: LymixPalette.text3,
              height: 1.45,
            ),
          ),
        ],
      ),
    );
  }

  Widget _hero(bool isSuper) => Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF241331), Color(0xFF5C34A8), Color(0xFFFFC72E)],
          ),
          borderRadius: BorderRadius.circular(25),
        ),
        child: Row(
          children: [
            const Icon(Icons.admin_panel_settings_rounded, size: 44),
            const SizedBox(width: 13),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    isSuper ? 'HEAD ADMIN' : 'AGENCY CONTROL',
                    style: const TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    user!.displayName.isEmpty
                        ? user!.login
                        : user!.displayName,
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  Text(
                    'Rol: ${user!.role}',
                    style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );

  Widget _section(String title, List<_AdminAction> items) => Padding(
        padding: const EdgeInsets.only(bottom: 18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 8),
            ...items.map(
              (item) => Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: LymixPressable(
                  onTap: item.onTap,
                  child: LymixGlassSurface(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 12,
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 42,
                          height: 42,
                          decoration: BoxDecoration(
                            color: LymixPalette.gold.withValues(alpha: .10),
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: Icon(
                            item.icon,
                            color: LymixPalette.gold,
                            size: 21,
                          ),
                        ),
                        const SizedBox(width: 11),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                item.title,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              const SizedBox(height: 3),
                              Text(
                                item.subtitle,
                                style: const TextStyle(
                                  color: LymixPalette.text3,
                                  fontSize: 9.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const Icon(
                          Icons.chevron_right_rounded,
                          color: LymixPalette.text3,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      );

  void _info(String title, String body) => showModalBottomSheet(
        context: context,
        backgroundColor: LymixPalette.bgRaised,
        builder: (ctx) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.admin_panel_settings_rounded,
                  size: 42,
                  color: LymixPalette.gold,
                ),
                const SizedBox(height: 10),
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 7),
                Text(
                  body,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: LymixPalette.text2,
                    height: 1.45,
                  ),
                ),
                const SizedBox(height: 14),
                FilledButton(
                  onPressed: () => Navigator.pop(ctx),
                  child: const Text('Tamam'),
                ),
              ],
            ),
          ),
        ),
      );
}

class _AdminAction {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _AdminAction(
    this.icon,
    this.title,
    this.subtitle,
    this.onTap,
  );
}
