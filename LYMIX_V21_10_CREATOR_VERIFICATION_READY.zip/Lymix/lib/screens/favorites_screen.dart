import 'package:flutter/material.dart';
import '../design/lymix_design_system.dart';

class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Favoriler')),
    body: const Center(
      child: Padding(
        padding: EdgeInsets.all(28),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.favorite_border_rounded, size: 52, color: LymixPalette.text3),
          SizedBox(height: 12),
          Text('Henüz favorin yok', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
          SizedBox(height: 6),
          Text('Favoriye eklediğin gerçek odalar, kullanıcılar ve içerikler burada görünecek.', textAlign: TextAlign.center, style: TextStyle(color: LymixPalette.text3)),
        ]),
      ),
    ),
  );
}
