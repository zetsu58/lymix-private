import 'package:flutter/material.dart';
import '../design/lymix_design_system.dart';
import '../economy/quota_economy.dart';

class CreatorEarningsScreen extends StatelessWidget {
  const CreatorEarningsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    const policy = QuotaEconomyPolicy.defaults;
    return Scaffold(
      appBar: AppBar(title: const Text('Kota & Kazanç')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const LymixGlassSurface(
            elevated: true,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              LymixPremiumBadge('YAYINCI', icon: Icons.query_stats_rounded),
              SizedBox(height: 12),
              Text('0', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
              Text('Günlük kota puanı', style: TextStyle(color: LymixPalette.text3)),
              SizedBox(height: 10),
              LinearProgressIndicator(value: 0),
            ]),
          ),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: _Metric('Bekleyen Kazanç', '0', Icons.schedule_rounded)),
            SizedBox(width: 10),
            Expanded(child: _Metric('Settled', '0', Icons.verified_rounded)),
          ]),
          const SizedBox(height: 12),
          LymixGlassSurface(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Kota hedefleri', style: TextStyle(fontWeight: FontWeight.w900)),
              const SizedBox(height: 7),
              Text('Günlük ${policy.dailyQuotaTarget} • Aylık ${policy.monthlyQuotaTarget}', style: const TextStyle(color: LymixPalette.text2)),
              const SizedBox(height: 5),
              const Text('Gerçek ilerleme ve payout uygunluğu backend settlement kayıtlarından gelecektir.', style: TextStyle(color: LymixPalette.text3, fontSize: 10)),
            ]),
          ),
        ],
      ),
    );
  }
}

class _Metric extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  const _Metric(this.label, this.value, this.icon);
  @override
  Widget build(BuildContext context) => LymixGlassSurface(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(icon, color: LymixPalette.gold),
          const SizedBox(height: 8),
          Text(value, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
          Text(label, style: const TextStyle(fontSize: 9, color: LymixPalette.text3)),
        ]),
      );
}
