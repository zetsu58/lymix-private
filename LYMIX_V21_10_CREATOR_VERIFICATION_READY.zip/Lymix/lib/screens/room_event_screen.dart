import 'package:flutter/material.dart';
import '../design/lymix_design_system.dart';

class RoomEventScreen extends StatelessWidget {
  final String roomId;
  final String roomTitle;
  const RoomEventScreen({
    super.key,
    required this.roomId,
    required this.roomTitle,
  });

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Oda Etkinlikleri')),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: LymixGlassSurface(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.event_available_rounded, size: 50, color: LymixPalette.gold),
                  const SizedBox(height: 14),
                  const Text(
                    'Henüz etkinlik yok',
                    style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 7),
                  const Text(
                    'Gerçek bir etkinlik planlandığında tarih, katılımcılar ve hatırlatıcı burada görünecek. Lymix sahte katılımcı veya etkinlik göstermez.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: LymixPalette.text2, height: 1.45),
                  ),
                  const SizedBox(height: 16),
                  OutlinedButton.icon(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back_rounded),
                    label: const Text('Odaya Dön'),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
}
