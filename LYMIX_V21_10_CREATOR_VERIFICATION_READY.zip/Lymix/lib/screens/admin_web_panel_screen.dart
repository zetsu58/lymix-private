import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../design/lymix_design_system.dart';
import '../core/app_config.dart';
import '../services/session_service.dart';
import '../services/admin_access_service.dart';

class AdminWebPanelScreen extends StatefulWidget {
  const AdminWebPanelScreen({super.key});

  @override
  State<AdminWebPanelScreen> createState() => _AdminWebPanelScreenState();
}

class _AdminWebPanelScreenState extends State<AdminWebPanelScreen> {
  static const _configuredPanelUrl = String.fromEnvironment(
    'LYMIX_ADMIN_PANEL_URL',
    defaultValue: '',
  );

  static String get panelUrl => _configuredPanelUrl.isNotEmpty
      ? _configuredPanelUrl
      : '${AppConfig.apiBase}/admin/';

  WebViewController? controller;
  bool checking = true;
  bool allowed = false;
  String? error;

  @override
  void initState() {
    super.initState();
    _prepare();
  }

  Future<void> _prepare() async {
    final canOpen = await AdminAccessService.can(AdminCapability.webConsole);
    if (!mounted) return;

    if (!canOpen) {
      setState(() {
        checking = false;
        error = 'Bu hesap web yönetim konsoluna yetkili değil.';
      });
      return;
    }

    if (!panelUrl.startsWith('https://')) {
      setState(() {
        checking = false;
        allowed = true;
        error = 'Admin panel yalnızca HTTPS üzerinden açılabilir.';
      });
      return;
    }

    final accessToken = await SessionService.token();
    final c = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageFinished: (_) async {
            if (accessToken == null || accessToken.isEmpty) return;
            final encoded = jsonEncode(accessToken);
            await controller?.runJavaScript(
              'window.LymixAdminBridge && '
              'window.LymixAdminBridge.acceptToken($encoded);',
            );
          },
          onNavigationRequest: (request) {
            final target = Uri.tryParse(request.url);
            final base = Uri.tryParse(panelUrl);
            if (target == null || base == null) {
              return NavigationDecision.prevent;
            }
            if (target.scheme != 'https' || target.host != base.host) {
              return NavigationDecision.prevent;
            }
            return NavigationDecision.navigate;
          },
        ),
      );

    controller = c;
    await c.loadRequest(Uri.parse(panelUrl));

    setState(() {
      controller = c;
      checking = false;
      allowed = true;
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('LYMIX Web Yönetim'),
          actions: [
            if (controller != null)
              IconButton(
                tooltip: 'Yenile',
                onPressed: () => controller!.reload(),
                icon: const Icon(Icons.refresh_rounded),
              ),
          ],
        ),
        body: checking
            ? const Center(child: CircularProgressIndicator())
            : controller == null
                ? _state()
                : WebViewWidget(controller: controller!),
      );

  Widget _state() => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: LymixGlassSurface(
            elevated: true,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.admin_panel_settings_rounded,
                  size: 54,
                  color: LymixPalette.gold,
                ),
                const SizedBox(height: 13),
                const Text(
                  'Web Yönetim Konsolu',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 8),
                Text(
                  error ?? 'Panel kullanılamıyor.',
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: LymixPalette.text2,
                    height: 1.45,
                  ),
                ),
                const SizedBox(height: 12),
                const Text(
                  'Gerçek yetkilendirme backend üzerinde JWT + role + capability '
                  'kontrolüyle yapılmalıdır.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: LymixPalette.text3,
                    fontSize: 10,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
}
