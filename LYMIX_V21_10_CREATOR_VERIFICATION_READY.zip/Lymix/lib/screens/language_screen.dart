import 'package:flutter/material.dart';
import '../services/localization_service.dart';
import '../theme/lymix_theme.dart';

class LanguageScreen extends StatelessWidget {
  final LymixLocaleController? controller;
  const LanguageScreen({super.key, this.controller});

  @override
  Widget build(BuildContext context) {
    final c = controller ?? LymixLocaleController.instance;
    return AnimatedBuilder(
      animation: c,
      builder: (context, _) => Scaffold(
        appBar: AppBar(title: Text(context.lx('language'))),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          children: [
            Container(
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [Color(0xFF20142B), Color(0xFF110D18)]),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0x33FFD643)),
              ),
              child: Row(children: [
                const Icon(Icons.translate_rounded, color: LymixColors.gold),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(context.lx('chooseLanguage'), style: const TextStyle(fontWeight: FontWeight.w800)),
                    const SizedBox(height: 3),
                    Text(context.lx('chooseLanguageSub'), style: const TextStyle(color: Colors.white60, fontSize: 11, height: 1.35)),
                  ]),
                ),
              ]),
            ),
            const SizedBox(height: 14),
            ...LymixLocaleController.supported.map((locale) {
              final selected = c.locale.languageCode == locale.languageCode;
              return Container(
                margin: const EdgeInsets.only(bottom: 8),
                decoration: BoxDecoration(
                  color: selected ? const Color(0xFF1E1526) : const Color(0xFF120E1A),
                  borderRadius: BorderRadius.circular(17),
                  border: Border.all(color: selected ? const Color(0x66FFD643) : Colors.white.withValues(alpha: .05)),
                ),
                child: ListTile(
                  onTap: () => c.setLocale(locale),
                  leading: Icon(Icons.language_rounded, color: selected ? LymixColors.gold : Colors.white38),
                  title: Text(
                    lymixLanguageNames[locale.languageCode] ?? locale.languageCode,
                    style: TextStyle(fontWeight: selected ? FontWeight.w800 : FontWeight.w600),
                  ),
                  trailing: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 180),
                    child: selected
                        ? const Icon(Icons.check_circle_rounded, key: ValueKey('selected'), color: LymixColors.gold)
                        : const Icon(Icons.circle_outlined, key: ValueKey('idle'), color: Colors.white24),
                  ),
                ),
              );
            }),
          ],
        ),
      ),
    );
  }
}
