import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../services/identity_asset_service.dart';
import '../services/session_service.dart';
import '../theme/lymix_theme.dart';

class ProfileIdentityScreen extends StatefulWidget {
  const ProfileIdentityScreen({super.key});
  @override State<ProfileIdentityScreen> createState() => _ProfileIdentityScreenState();
}

class _ProfileIdentityScreenState extends State<ProfileIdentityScreen> {
  String selectedPreset = 'Lymix Sans';
  String? runtimeFamily;
  Uint8List? iconBytes;
  Uint8List? fontBytes;
  String? fontFilename;
  String? iconFilename;
  bool saving=false;
  bool applyInRooms = true;
  bool applyInProfile = true;

  static const presetFonts = ['Lymix Sans', 'Modern', 'Yuvarlak', 'Editoryal', 'Mono'];

  Future<void> _pickFont() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['ttf', 'otf'],
      withData: true,
    );
    if (result == null || result.files.isEmpty) return;
    final file = result.files.single;
    final bytes = file.bytes;
    if (bytes == null) return _toast('Dosya okunamadı.');
    final error = IdentityAssetService.validateFont(file.name, bytes);
    if (error != null) return _toast(error);
    try {
      final family = await IdentityAssetService.loadRuntimeFont(
        bytes: bytes,
        stableFamilyName: 'user_font_preview_${DateTime.now().millisecondsSinceEpoch}',
      );
      if (!mounted) return;
      setState(() { runtimeFamily = family; fontBytes = bytes; fontFilename = file.name; });
      _toast('Yazı tipi önizlemeye uygulandı.');
    } catch (_) {
      _toast('Bu yazı tipi cihazda yüklenemedi. Başka bir TTF/OTF dosyası dene.');
    }
  }

  Future<void> _pickIcon() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['png', 'jpg', 'jpeg', 'webp'],
      withData: true,
    );
    if (result == null || result.files.isEmpty) return;
    final file = result.files.single;
    final bytes = file.bytes;
    if (bytes == null) return _toast('Dosya okunamadı.');
    final error = IdentityAssetService.validateIcon(file.name, bytes);
    if (error != null) return _toast(error);
    setState(() { iconBytes = bytes; iconFilename = file.name; });
  }

  void _toast(String text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));

  Future<void> _saveIdentity() async {
    if (saving) return;
    setState(() => saving = true);
    try {
      final user = await SessionService.user();
      if (user == null || user.id.isEmpty) {
        throw StateError('Profil kimliği için aktif oturum gerekli.');
      }
      if (fontBytes != null && fontFilename != null) {
        await IdentityAssetService.uploadFont(userId: user.id, filename: fontFilename!, bytes: fontBytes!);
      }
      if (iconBytes != null && iconFilename != null) {
        await IdentityAssetService.uploadIcon(userId: user.id, filename: iconFilename!, bytes: iconBytes!);
      }
      if (!mounted) return;
      _toast('Profil kimliği kaydedildi. iOS ve Android cihazlarda güvenli sürüm kullanılacak.');
    } catch (e) {
      if (!mounted) return;
      _toast('Kaydetme tamamlanamadı: ${e.toString().replaceFirst('StateError: ', '')}');
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }


  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Profil Kimliği')),
    body: ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
      children: [
        _preview(),
        const SizedBox(height: 18),
        _sectionTitle('Kullanıcı adı görünümü', 'Hazır stillerden seç veya kendi TTF/OTF dosyanı yükle.'),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8, runSpacing: 8,
          children: presetFonts.map((f) => ChoiceChip(
            selected: selectedPreset == f,
            onSelected: (_) => setState(() { selectedPreset = f; runtimeFamily = null; }),
            label: Text(f),
            selectedColor: LymixColors.gold.withValues(alpha: .16),
            side: BorderSide(color: selectedPreset == f ? const Color(0x88FFD643) : Colors.white10),
          )).toList(),
        ),
        const SizedBox(height: 12),
        OutlinedButton.icon(
          onPressed: _pickFont,
          icon: const Icon(Icons.text_fields_rounded),
          label: const Text('Kendi yazı tipimi yükle'),
        ),
        const SizedBox(height: 20),
        _sectionTitle('Kişisel simge', 'Profil yanında kullanılacak simge tüm cihazlarda aynı görünmesi için görsel olarak saklanır.'),
        const SizedBox(height: 10),
        Row(children: [
          Container(
            width: 70, height: 70,
            decoration: BoxDecoration(color: Colors.white.withValues(alpha: .04), borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.white10)),
            clipBehavior: Clip.antiAlias,
            child: iconBytes == null
                ? const Icon(Icons.auto_awesome_rounded, color: LymixColors.gold, size: 30)
                : Image.memory(iconBytes!, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.broken_image_outlined)),
          ),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            OutlinedButton.icon(onPressed: _pickIcon, icon: const Icon(Icons.upload_rounded), label: const Text('Simge yükle')),
            const SizedBox(height: 6),
            const Text('PNG/JPG/WebP • en fazla 3 MB • sunucuda kare formatına normalize edilir.', style: TextStyle(color: Colors.white38, fontSize: 9)),
          ])),
        ]),
        const SizedBox(height: 20),
        _sectionTitle('Nerede görünsün?', 'Kimliğini farklı alanlarda ayrı ayrı kullanabilirsin.'),
        SwitchListTile.adaptive(
          value: applyInProfile, onChanged: (v) => setState(() => applyInProfile = v),
          title: const Text('Profil ve mini kart'), subtitle: const Text('Profil, arama ve takipçi listeleri'),
          contentPadding: EdgeInsets.zero, activeThumbColor: LymixColors.gold,
        ),
        SwitchListTile.adaptive(
          value: applyInRooms, onChanged: (v) => setState(() => applyInRooms = v),
          title: const Text('Oda ve sohbet'), subtitle: const Text('Koltuk adı, sohbet etiketi ve oda listeleri'),
          contentPadding: EdgeInsets.zero, activeThumbColor: LymixColors.gold,
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.all(13),
          decoration: BoxDecoration(color: const Color(0xFF10131B), borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0x2248C9FF))),
          child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(Icons.devices_rounded, color: Color(0xFF73D5FF), size: 18),
            SizedBox(width: 9),
            Expanded(child: Text(
              'Uyumluluk koruması: özel yazı tipi açılamazsa Lymix Sans kullanılır. Simge dosyası sunucuda normalize edilerek tek CDN sürümü üzerinden iOS ve Android’e dağıtılır.',
              style: TextStyle(color: Colors.white60, fontSize: 10, height: 1.4),
            )),
          ]),
        ),
        const SizedBox(height: 18),
        LymixBrandButton(label: saving ? 'Kaydediliyor...' : 'Kimliği Kaydet', icon: saving ? Icons.sync_rounded : Icons.check_rounded, onPressed: saving ? null : _saveIdentity),
      ],
    ),
  );

  Widget _sectionTitle(String title, String sub) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(title, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w900)),
    const SizedBox(height: 3),
    Text(sub, style: const TextStyle(color: Color(0x73FFFFFF), fontSize: 10, height: 1.35)),
  ]);

  Widget _preview() => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      gradient: const LinearGradient(colors: [Color(0xFF1C1226), Color(0xFF0F0C15)]),
      borderRadius: BorderRadius.circular(24),
      border: Border.all(color: const Color(0x33FFD643)),
    ),
    child: Row(children: [
      const CircleAvatar(radius: 31, backgroundColor: Color(0xFF2A1840), child: Icon(Icons.person_rounded, size: 30, color: Colors.white70)),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Flexible(child: Text('Profil Önizleme', overflow: TextOverflow.ellipsis, style: TextStyle(
            color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800, fontFamily: runtimeFamily,
          ))),
          const SizedBox(width: 6),
          if (iconBytes != null) ClipRRect(borderRadius: BorderRadius.circular(5), child: Image.memory(iconBytes!, width: 20, height: 20, fit: BoxFit.cover)),
          if (iconBytes == null) const Icon(Icons.auto_awesome_rounded, color: LymixColors.gold, size: 18),
        ]),
        const SizedBox(height: 4),
        const Text('Gerçek kullanıcı seviyesi ve rozetleri burada görünür', style: TextStyle(color: Color(0x73FFFFFF), fontSize: 10)),
      ])),
      Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5), decoration: BoxDecoration(gradient: LymixColors.brandGradient, borderRadius: BorderRadius.circular(10)), child: const Text('ÖNİZLEME', style: TextStyle(color: Color(0xFF160E18), fontSize: 8, fontWeight: FontWeight.w900))),
    ]),
  );
}
