import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'app_config.dart';

class ApiException implements Exception {
  final String message;
  final int? statusCode;
  final String? code;
  const ApiException(this.message, {this.statusCode, this.code});
  @override String toString() => message;
}

class ApiClient {
  final Future<String?> Function()? tokenProvider;
  const ApiClient({this.tokenProvider});

  Uri _uri(String path) => Uri.parse('${AppConfig.apiBase}${path.startsWith('/') ? path : '/$path'}');

  Future<Map<String, String>> _headers() async {
    final token = await tokenProvider?.call();
    return {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      if (token != null && token.isNotEmpty) 'Authorization': 'Bearer $token',
    };
  }

  Future<dynamic> getJson(String path, {Duration timeout = const Duration(seconds: 10)}) async {
    try {
      final r = await http.get(_uri(path), headers: await _headers()).timeout(timeout);
      return _decode(r);
    } on TimeoutException {
      throw const ApiException('Sunucu yanıt vermedi. Bağlantını kontrol edip tekrar dene.', code: 'timeout');
    } on ApiException {
      rethrow;
    } catch (_) {
      throw const ApiException('Ağa bağlanılamadı. İnternet bağlantını kontrol et.', code: 'network');
    }
  }

  Future<dynamic> postJson(String path, Object? body, {Duration timeout = const Duration(seconds: 12)}) async {
    try {
      final r = await http.post(_uri(path), headers: await _headers(), body: jsonEncode(body)).timeout(timeout);
      return _decode(r);
    } on TimeoutException {
      throw const ApiException('İşlem zaman aşımına uğradı. Tekrar dene.', code: 'timeout');
    } on ApiException {
      rethrow;
    } catch (_) {
      throw const ApiException('İşlem sırasında bağlantı kesildi.', code: 'network');
    }
  }


  Future<dynamic> postMultipart(
    String path, {
    required Map<String, String> fields,
    String? fileField,
    String? filePath,
    Duration timeout = const Duration(seconds: 45),
  }) async {
    try {
      final token = await tokenProvider?.call();
      final req = http.MultipartRequest('POST', _uri(path));
      req.headers['Accept'] = 'application/json';
      if (token != null && token.isNotEmpty) {
        req.headers['Authorization'] = 'Bearer $token';
      }
      req.fields.addAll(fields);
      if (fileField != null && filePath != null && filePath.isNotEmpty) {
        req.files.add(await http.MultipartFile.fromPath(fileField, filePath));
      }
      final streamed = await req.send().timeout(timeout);
      final response = await http.Response.fromStream(streamed);
      return _decode(response);
    } on TimeoutException {
      throw const ApiException('Dosya yükleme zaman aşımına uğradı.', code: 'timeout');
    } on ApiException {
      rethrow;
    } catch (_) {
      throw const ApiException('Dosya yüklenemedi. Bağlantını kontrol et.', code: 'network');
    }
  }

  dynamic _decode(http.Response r) {
    dynamic body;
    try { body = r.body.isEmpty ? null : jsonDecode(r.body); } catch (_) { body = r.body; }
    if (r.statusCode >= 200 && r.statusCode < 300) return body;
    final msg = body is Map ? (body['message'] ?? body['error'] ?? 'İşlem tamamlanamadı.') : 'İşlem tamamlanamadı.';
    final code = body is Map ? body['error']?.toString() : null;
    throw ApiException(msg.toString(), statusCode: r.statusCode, code: code);
  }
}
