import 'quota_economy.dart';

abstract class SettlementRepository {
  Future<void> recordGiftSettlement({
    required String giftTransactionId,
    required String senderUserId,
    required String receiverUserId,
    required String? agencyId,
    required GiftSettlementPreview preview,
  });

  Future<int> fetchDailyQuota(String userId);
  Future<int> fetchMonthlyQuota(String userId);
  Future<int> fetchAgencyBankBalance(String agencyId);

  /// Only the backend may execute a transfer. Client requests are advisory.
  Future<String> requestAgencyBankTransfer({
    required String agencyId,
    required String hostUserId,
    required int recyclableCoins,
  });

  /// Fiat payout must be KYC/region/payment-provider compliant and server signed.
  Future<String> requestHostPayout({
    required String userId,
    required int earnedCredits,
  });
}
