import 'package:flutter/material.dart';
import 'design/lymix_design_system.dart';

class LymixPro {
  static const bg = Color(0xFF0A0810);
  static const panel = Color(0xFF17131F);
  static const panel2 = Color(0xFF21172E);
  static const yellow = Color(0xFFFFD200);
  static const purple = Color(0xFF7B3FF2);
  static const deepPurple = Color(0xFF2C0F4D);
  static const text = Color(0xFFF7F4FF);
  static const muted = Color(0xFFAAA2B5);

  static const brandGradient = LinearGradient(
    colors: [yellow, Color(0xFFFFA800), purple],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const premiumGradient = LinearGradient(
    colors: [Color(0xFF32134E), Color(0xFF7B3FF2), Color(0xFFFFD200)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static ThemeData theme() {
    final scheme = ColorScheme.fromSeed(
      seedColor: LymixPalette.purple,
      brightness: Brightness.dark,
      surface: LymixPalette.surface,
    ).copyWith(
      primary: LymixPalette.gold,
      secondary: LymixPalette.purple,
      tertiary: LymixPalette.pink,
      error: LymixPalette.danger,
    );

    return ThemeData(
      brightness: Brightness.dark,
      useMaterial3: true,
      scaffoldBackgroundColor: LymixPalette.bg,
      colorScheme: scheme,
      splashFactory: InkSparkle.splashFactory,
      visualDensity: VisualDensity.standard,
      appBarTheme: const AppBarTheme(
        elevation: 0,
        centerTitle: false,
        backgroundColor: LymixPalette.bg,
        surfaceTintColor: Colors.transparent,
        foregroundColor: LymixPalette.text,
        titleTextStyle: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: LymixPalette.text),
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        color: LymixPalette.surface,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(LymixRadius.lg)),
      ),
      navigationBarTheme: NavigationBarThemeData(
        height: 72,
        elevation: 0,
        backgroundColor: LymixPalette.bgRaised.withValues(alpha: .98),
        indicatorColor: LymixPalette.gold.withValues(alpha: .12),
        labelTextStyle: const WidgetStatePropertyAll(
          TextStyle(fontSize: 10, fontWeight: FontWeight.w800),
        ),
      ),
      bottomSheetTheme: const BottomSheetThemeData(
        backgroundColor: LymixPalette.bgRaised,
        modalBackgroundColor: LymixPalette.bgRaised,
        surfaceTintColor: Colors.transparent,
        showDragHandle: true,
        dragHandleColor: Color(0x44FFFFFF),
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: LymixPalette.surface,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(LymixRadius.xl)),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          minimumSize: const Size(48, 48),
          backgroundColor: LymixPalette.gold,
          foregroundColor: const Color(0xFF151018),
          textStyle: const TextStyle(fontWeight: FontWeight.w900),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(LymixRadius.md)),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          minimumSize: const Size(48, 48),
          foregroundColor: LymixPalette.text,
          side: const BorderSide(color: Color(0x22FFFFFF)),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(LymixRadius.md)),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white.withValues(alpha: .045),
        contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(LymixRadius.md),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(LymixRadius.md),
          borderSide: BorderSide(color: LymixPalette.gold.withValues(alpha: .48)),
        ),
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: LymixPalette.surface3,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(LymixRadius.md)),
      ),
    );
  }
}
