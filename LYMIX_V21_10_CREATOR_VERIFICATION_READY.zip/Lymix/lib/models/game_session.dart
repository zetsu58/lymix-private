enum GameSessionPhase {
  idle,
  inviting,
  ready,
  matching,
  loading,
  playing,
  finished,
  failed,
}

class GamePlayer {
  final String userId;
  final String displayName;
  final bool spectator;
  final bool ready;

  const GamePlayer({
    required this.userId,
    required this.displayName,
    this.spectator = false,
    this.ready = false,
  });

  GamePlayer copyWith({bool? spectator, bool? ready}) => GamePlayer(
        userId: userId,
        displayName: displayName,
        spectator: spectator ?? this.spectator,
        ready: ready ?? this.ready,
      );
}

class GameSessionState {
  final String roomId;
  final String gameId;
  final GameSessionPhase phase;
  final List<GamePlayer> players;
  final String? launchUrl;
  final String? sessionId;
  final String? error;
  final Map<String, dynamic> result;

  const GameSessionState({
    required this.roomId,
    required this.gameId,
    this.phase = GameSessionPhase.idle,
    this.players = const [],
    this.launchUrl,
    this.sessionId,
    this.error,
    this.result = const {},
  });

  GameSessionState copyWith({
    GameSessionPhase? phase,
    List<GamePlayer>? players,
    String? launchUrl,
    String? sessionId,
    String? error,
    Map<String, dynamic>? result,
    bool clearError = false,
  }) =>
      GameSessionState(
        roomId: roomId,
        gameId: gameId,
        phase: phase ?? this.phase,
        players: players ?? this.players,
        launchUrl: launchUrl ?? this.launchUrl,
        sessionId: sessionId ?? this.sessionId,
        error: clearError ? null : error ?? this.error,
        result: result ?? this.result,
      );
}
