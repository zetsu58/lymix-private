class GiftRecipient {
  final String userId;
  final String displayName;
  final String? avatarUrl;
  final bool isSeated;

  const GiftRecipient({
    required this.userId,
    required this.displayName,
    this.avatarUrl,
    this.isSeated = false,
  });
}
