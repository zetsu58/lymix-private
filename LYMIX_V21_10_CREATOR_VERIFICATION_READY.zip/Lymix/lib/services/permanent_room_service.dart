import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'session_service.dart';

class PermanentRoomProfile {
  final String ownerUserId;
  final String roomId;
  final String title;
  final String topic;
  final bool isPrivate;
  final bool discoverable;
  final int seats;
  final String? agencyId;
  final String? agencyName;

  const PermanentRoomProfile({
    required this.ownerUserId,
    required this.roomId,
    required this.title,
    required this.topic,
    required this.isPrivate,
    required this.discoverable,
    required this.seats,
    this.agencyId,
    this.agencyName,
  });

  bool get isAgencyRoom => agencyId != null && agencyId!.isNotEmpty;

  PermanentRoomProfile copyWith({
    String? title,
    String? topic,
    bool? isPrivate,
    bool? discoverable,
    int? seats,
    String? agencyId,
    String? agencyName,
    bool clearAgency = false,
  }) =>
      PermanentRoomProfile(
        ownerUserId: ownerUserId,
        roomId: roomId,
        title: title ?? this.title,
        topic: topic ?? this.topic,
        isPrivate: isPrivate ?? this.isPrivate,
        discoverable: discoverable ?? this.discoverable,
        seats: seats ?? this.seats,
        agencyId: clearAgency ? null : agencyId ?? this.agencyId,
        agencyName: clearAgency ? null : agencyName ?? this.agencyName,
      );

  Map<String, dynamic> toJson() => {
        'ownerUserId': ownerUserId,
        'roomId': roomId,
        'title': title,
        'topic': topic,
        'isPrivate': isPrivate,
        'discoverable': discoverable,
        'seats': seats,
        'agencyId': agencyId,
        'agencyName': agencyName,
      };

  factory PermanentRoomProfile.fromJson(Map<String, dynamic> json) =>
      PermanentRoomProfile(
        ownerUserId: '${json['ownerUserId'] ?? ''}',
        roomId: '${json['roomId'] ?? ''}',
        title: '${json['title'] ?? ''}',
        topic: '${json['topic'] ?? ''}',
        isPrivate: json['isPrivate'] == true,
        discoverable: json['discoverable'] != false,
        seats: (json['seats'] as num?)?.toInt() ?? 12,
        agencyId: json['agencyId']?.toString(),
        agencyName: json['agencyName']?.toString(),
      );
}

class PermanentRoomService {
  static String _key(String userId) => 'lymix.permanentRoom.$userId';

  /// Local persistence is only a fallback for the current demo/backend stage.
  /// Production backend must be source of truth and keep roomId stable forever.
  static Future<PermanentRoomProfile> ensureForCurrentUser() async {
    final user = await SessionService.user();
    if (user == null || user.id.isEmpty) {
      throw StateError('Oturum kullanıcısı bulunamadı.');
    }

    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key(user.id));
    if (raw != null && raw.isNotEmpty) {
      try {
        return PermanentRoomProfile.fromJson(
          Map<String, dynamic>.from(jsonDecode(raw) as Map),
        );
      } catch (_) {}
    }

    final stable = _stableRoomId(user.id);
    final created = PermanentRoomProfile(
      ownerUserId: user.id,
      roomId: stable,
      title: '${user.displayName.isEmpty ? user.login : user.displayName} Odası',
      topic: '',
      isPrivate: false,
      discoverable: true,
      seats: 12,
      agencyId: _isAgencyRole(user.role) ? 'agency:${user.id}' : null,
      agencyName: _isAgencyRole(user.role)
          ? '${user.displayName.isEmpty ? user.login : user.displayName} Ajansı'
          : null,
    );
    await save(created);
    return created;
  }

  static Future<void> save(PermanentRoomProfile profile) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key(profile.ownerUserId), jsonEncode(profile.toJson()));
  }

  static bool _isAgencyRole(String role) {
    final r = role.toLowerCase();
    return r.contains('agency') || r.contains('ajans');
  }

  static String _stableRoomId(String userId) {
    var hash = 2166136261;
    for (final code in userId.codeUnits) {
      hash ^= code;
      hash = (hash * 16777619) & 0x7fffffff;
    }
    return 'LMX-${hash.toString().padLeft(8, '0')}';
  }
}
