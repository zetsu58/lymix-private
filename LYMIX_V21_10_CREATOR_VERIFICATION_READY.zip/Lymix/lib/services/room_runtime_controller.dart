import 'package:flutter/foundation.dart';
import '../models/room_model.dart';

enum RoomConnectionPhase { connecting, connected, reconnecting, disconnected, failed }

class RoomParticipant {
  final String userId;
  final String displayName;
  final bool host;
  final bool moderator;
  final bool speaking;
  final int? seatIndex;

  const RoomParticipant({
    required this.userId,
    required this.displayName,
    this.host = false,
    this.moderator = false,
    this.speaking = false,
    this.seatIndex,
  });
}

class RoomRuntimeController extends ChangeNotifier {
  final String roomId;
  RoomConnectionPhase connection = RoomConnectionPhase.connecting;
  final List<RoomParticipant> participants = [];
  final List<RoomSeat> seats;

  RoomRuntimeController({required this.roomId, int seatCount = 12})
      : seats = List.generate(seatCount, (index) => RoomSeat(index: index));

  int get participantCount => participants.length;
  int get occupiedSeatCount => seats.where((s) => s.status == SeatStatus.occupied).length;

  void setConnection(RoomConnectionPhase value) {
    if (connection == value) return;
    connection = value;
    notifyListeners();
  }

  void replaceParticipants(Iterable<RoomParticipant> value) {
    participants
      ..clear()
      ..addAll(value);
    notifyListeners();
  }

  void clearSeat(int index) {
    if (index < 0 || index >= seats.length) return;
    final seat = seats[index];
    seat.status = SeatStatus.empty;
    seat.userId = null;
    seat.userName = null;
    seat.avatarUrl = null;
    seat.isMuted = false;
    seat.isSpeaking = false;
    notifyListeners();
  }
}
