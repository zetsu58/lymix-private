import 'session_service.dart';

enum AdminCapability {
  roomModeration,
  agencyManagement,
  userLookup,
  reports,
  announcements,
  economy,
  settlement,
  auditLog,
  webConsole,
}

class AdminAccessService {
  static const _superRoles = {
    'admin',
    'superadmin',
    'super_admin',
    'headadmin',
    'head_admin',
    'owner',
  };

  static const _agencyRoles = {
    'agency',
    'agency_owner',
    'agency_admin',
    'agent',
  };

  static bool isSuperAdminRole(String role) =>
      _superRoles.contains(role.trim().toLowerCase());

  static bool isAgencyRole(String role) =>
      _agencyRoles.contains(role.trim().toLowerCase());

  static Set<AdminCapability> capabilitiesFor(SessionUser user) {
    if (isSuperAdminRole(user.role)) {
      return AdminCapability.values.toSet();
    }
    if (isAgencyRole(user.role)) {
      return {
        AdminCapability.roomModeration,
        AdminCapability.agencyManagement,
        AdminCapability.announcements,
        AdminCapability.reports,
      };
    }
    return const {};
  }

  static Future<bool> can(AdminCapability capability) async {
    final user = await SessionService.user();
    if (user == null) return false;
    return capabilitiesFor(user).contains(capability);
  }
}
