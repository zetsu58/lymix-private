import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LymixLocaleController extends ChangeNotifier {
  LymixLocaleController._();
  static final LymixLocaleController instance = LymixLocaleController._();

  static const _storageKey = 'lymix.locale';
  static const supported = <Locale>[
    Locale('tr'),
    Locale('en'),
    Locale('de'),
    Locale('it'),
    Locale('ru'),
    Locale('hi'),
    Locale('az'),
  ];

  Locale _locale = const Locale('tr');
  Locale get locale => _locale;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final code = prefs.getString(_storageKey);
    if (code == null) return;
    final match = supported.where((l) => l.languageCode == code);
    if (match.isNotEmpty) _locale = match.first;
  }

  Future<void> setLocale(Locale value) async {
    if (!supported.any((l) => l.languageCode == value.languageCode)) return;
    if (_locale.languageCode == value.languageCode) return;
    _locale = value;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_storageKey, value.languageCode);
  }
}

class LymixLocaleScope extends InheritedNotifier<LymixLocaleController> {
  const LymixLocaleScope({
    super.key,
    required LymixLocaleController controller,
    required super.child,
  }) : super(notifier: controller);

  static LymixLocaleController of(BuildContext context) =>
      context.dependOnInheritedWidgetOfExactType<LymixLocaleScope>()!.notifier!;
}

const lymixLanguageNames = <String, String>{
  'tr': 'Türkçe',
  'en': 'English',
  'de': 'Deutsch',
  'it': 'Italiano',
  'ru': 'Русский',
  'hi': 'हिन्दी',
  'az': 'Azərbaycan türkcəsi',
};

class LymixStrings {
  static const Map<String, Map<String, String>> _v = {
    'tr': {
      'home': 'Ana Sayfa', 'discover': 'Keşfet', 'plaza': 'Plaza', 'games': 'Oyun', 'gameCenter': 'Oyun Merkezi', 'messages': 'Mesajlar', 'profile': 'Profil',
      'settings': 'Ayarlar', 'language': 'Dil', 'app': 'Lymix', 'official': 'Lymix Official', 'openOfficial': 'Resmi mesajı aç',
      'welcomeTitle': 'Hoş geldin!', 'welcomeBody': 'Kurallar, seviye/VIP, hediyeler ve güvenlik bilgileri resmi mesaj kutuna gönderildi. Hesabın gerçek sosyal verilerde sıfırdan başlar; Lymix Official sistem takibi sayaçlara dahil edilmez.',
      'application': 'Uygulama', 'visualExperience': 'Görsel deneyim', 'securityAccount': 'Güvenlik ve hesap', 'notificationPreferences': 'Bildirim Tercihleri',
      'notificationSub': 'Mesaj, oda, hediye, VIP ve sessiz saat ayarları', 'messageRequests': 'Mesaj İstekleri', 'messageRequestsSub': 'Yeni kişilerden gelen güvenli mesaj istekleri',
      'entranceEffects': 'Giriş efektleri', 'entranceEffectsSub': 'VIP ve özel giriş animasyonları', 'roomEffects': 'Oda efektleri', 'roomEffectsSub': 'Hediye, coin rain ve oda efektleri',
      'autoplay': 'Otomatik oynatma', 'autoplaySub': 'Hareketli içerikleri otomatik oynat', 'reduceMotion': 'Hareketi azalt', 'reduceMotionSub': 'Yoğun animasyonları ve büyük efektleri azalt',
      'visualComfort': 'Görsel Rahatlık', 'visualComfortSub': 'Sakin mod, parıltı azaltma ve tek elle kullanım', 'audioQuality': 'Ses Kalitesi', 'audioQualitySub': 'Gürültü, yankı, otomatik ses seviyesi ve ses çıkışı',
      'dataSaver': 'Veri tasarrufu', 'dataSaverSub': 'Hücresel bağlantıda daha küçük görseller ve daha az ön yükleme', 'privacy': 'Gizlilik', 'privacySub': 'Profil, mesaj ve görünürlük izinleri',
      'moderationSafety': 'Moderasyon ve Güvenlik', 'moderationSafetySub': 'Mesaj filtresi, ses moderasyonu ve şikayet politikası', 'devices': 'Cihazlar', 'devicesSub': 'Giriş yapılan cihazları ve oturumları yönet',
      'accountData': 'Hesap ve Veriler', 'accountDataSub': 'Şifre, doğrulama, veri indirme ve hesap silme', 'chooseLanguage': 'Uygulama dilini seç',
      'chooseLanguageSub': 'Seçimin anında uygulanır ve bu cihazda hatırlanır.', 'newRoom': 'Odam', 'startCommunity': 'Kendi kalıcı odanı yönet', 'myRoom':'Odam', 'enterMyRoom':'Odama Gir', 'permanentRoom':'Kalıcı Odam', 'permanentRoomSub':'Bu oda hesabına kalıcı olarak bağlıdır', 'agencyRoom':'Ajans Odası', 'agencyRoomSub':'Ajans statüsü bu kalıcı oda üzerinde çalışır',
      'realUsersOnly': 'Oda boş başlayacak. Katılımcılar yalnızca gerçek kullanıcılar olacak.', 'roomName': 'Oda adı', 'roomNameHint': 'Örn. Gece Muhabbeti', 'roomTopic': 'Konu / açıklama',
      'roomTopicHint': 'İnsanlar odaya girmeden önce ne konuşulduğunu bilsin.', 'micSeats': 'Mikrofon koltuğu', 'seats': 'koltuk', 'privateRoom': 'Özel / kilitli oda',
      'privateRoomSub': 'Kilitli odalar dışarıdan görünmez ve “yanına git” özelliğinde paylaşılmaz.', 'showDiscover': 'Keşfette göster', 'showDiscoverSub': 'Açık odanın keşfet listesinde görünmesine izin ver.',
      'createRoom': 'Odama Gir', 'roomNameError': 'Oda adı en az 3 karakter olmalı.', 'vipLevel': 'VIP & Seviye', 'myGifts': 'Hediyelerim', 'favorites': 'Favoriler', 'wallet': 'Cüzdan',
      'bag': 'Çantam', 'identityBadge': 'Kimlik & Rozet', 'notifications': 'Bildirimler', 'adminEconomy': 'Admin Ekonomi', 'ownerOps': 'Owner Ops',
    },
    'en': {
      'home': 'Home', 'discover': 'Discover', 'plaza': 'Plaza', 'games': 'Games', 'gameCenter': 'Game Center', 'messages': 'Messages', 'profile': 'Profile',
      'settings': 'Settings', 'language': 'Language', 'app': 'Lymix', 'official': 'Lymix Official', 'openOfficial': 'Open official message',
      'welcomeTitle': 'Welcome!', 'welcomeBody': 'Rules, levels/VIP, gifts and safety information were sent to your official inbox. Your real social stats start from zero; the Lymix Official system follow is excluded from counters.',
      'application': 'Application', 'visualExperience': 'Visual experience', 'securityAccount': 'Security & account', 'notificationPreferences': 'Notification Preferences',
      'notificationSub': 'Messages, rooms, gifts, VIP and quiet hours', 'messageRequests': 'Message Requests', 'messageRequestsSub': 'Safe requests from new people',
      'entranceEffects': 'Entrance effects', 'entranceEffectsSub': 'VIP and special entrance animations', 'roomEffects': 'Room effects', 'roomEffectsSub': 'Gifts, coin rain and room effects',
      'autoplay': 'Autoplay', 'autoplaySub': 'Automatically play animated content', 'reduceMotion': 'Reduce motion', 'reduceMotionSub': 'Reduce intense animations and large effects',
      'visualComfort': 'Visual Comfort', 'visualComfortSub': 'Calm mode, reduced glow and one-handed use', 'audioQuality': 'Audio Quality', 'audioQualitySub': 'Noise, echo, auto gain and audio output',
      'dataSaver': 'Data saver', 'dataSaverSub': 'Smaller images and less preloading on cellular', 'privacy': 'Privacy', 'privacySub': 'Profile, messaging and visibility permissions',
      'moderationSafety': 'Moderation & Safety', 'moderationSafetySub': 'Message filters, voice moderation and reporting policy', 'devices': 'Devices', 'devicesSub': 'Manage signed-in devices and sessions',
      'accountData': 'Account & Data', 'accountDataSub': 'Password, verification, data download and account deletion', 'chooseLanguage': 'Choose app language',
      'chooseLanguageSub': 'Your choice applies instantly and is remembered on this device.', 'newRoom': 'My Room', 'startCommunity': 'Manage your permanent room', 'myRoom':'My Room', 'enterMyRoom':'Enter My Room', 'permanentRoom':'Permanent Room', 'permanentRoomSub':'This room is permanently linked to your account', 'agencyRoom':'Agency Room', 'agencyRoomSub':'Agency status runs on this permanent room',
      'realUsersOnly': 'The room starts empty. Participants will only be real users.', 'roomName': 'Room name', 'roomNameHint': 'e.g. Late Night Chat', 'roomTopic': 'Topic / description',
      'roomTopicHint': 'Let people know what the room is about before they join.', 'micSeats': 'Mic seats', 'seats': 'seats', 'privateRoom': 'Private / locked room',
      'privateRoomSub': 'Locked rooms stay hidden and are never exposed through “join them”.', 'showDiscover': 'Show in Discover', 'showDiscoverSub': 'Allow this public room to appear in discovery.',
      'createRoom': 'Enter My Room', 'roomNameError': 'Room name must be at least 3 characters.', 'vipLevel': 'VIP & Level', 'myGifts': 'My Gifts', 'favorites': 'Favorites', 'wallet': 'Wallet',
      'bag': 'Inventory', 'identityBadge': 'Identity & Badges', 'notifications': 'Notifications', 'adminEconomy': 'Admin Economy', 'ownerOps': 'Owner Ops',
    },
    'de': {'myRoom':'Mein Raum','enterMyRoom':'Meinen Raum öffnen','agencyRoom':'Agenturraum','home':'Start','discover':'Entdecken','plaza':'Plaza','games':'Spiele','gameCenter':'Spielzentrum','messages':'Nachrichten','profile':'Profil','settings':'Einstellungen','language':'Sprache','newRoom':'Neuer Raum','createRoom':'Raum erstellen','chooseLanguage':'App-Sprache wählen','chooseLanguageSub':'Die Auswahl wird sofort angewendet und auf diesem Gerät gespeichert.'},
    'it': {'myRoom':'La mia stanza','enterMyRoom':'Entra nella stanza','agencyRoom':'Stanza agenzia','home':'Home','discover':'Scopri','plaza':'Plaza','games':'Giochi','gameCenter':'Centro giochi','messages':'Messaggi','profile':'Profilo','settings':'Impostazioni','language':'Lingua','newRoom':'Nuova stanza','createRoom':'Crea stanza','chooseLanguage':'Scegli la lingua','chooseLanguageSub':'La scelta viene applicata subito e salvata su questo dispositivo.'},
    'ru': {'myRoom':'Моя комната','enterMyRoom':'Войти в комнату','agencyRoom':'Комната агентства','home':'Главная','discover':'Обзор','plaza':'Плаза','games':'Игры','gameCenter':'Игровой центр','messages':'Сообщения','profile':'Профиль','settings':'Настройки','language':'Язык','newRoom':'Новая комната','createRoom':'Создать комнату','chooseLanguage':'Выберите язык','chooseLanguageSub':'Выбор применяется сразу и сохраняется на устройстве.'},
    'hi': {'myRoom':'मेरा रूम','enterMyRoom':'मेरे रूम में जाएँ','agencyRoom':'एजेंसी रूम','home':'होम','discover':'खोजें','plaza':'प्लाज़ा','games':'गेम','gameCenter':'गेम सेंटर','messages':'संदेश','profile':'प्रोफ़ाइल','settings':'सेटिंग्स','language':'भाषा','newRoom':'नया रूम','createRoom':'रूम बनाएँ','chooseLanguage':'ऐप भाषा चुनें','chooseLanguageSub':'चयन तुरंत लागू होता है और इस डिवाइस पर सेव रहता है।'},
    'az': {'myRoom':'Otağım','enterMyRoom':'Otağıma gir','agencyRoom':'Agentlik otağı','home':'Ana səhifə','discover':'Kəşf et','plaza':'Plaza','games':'Oyunlar','gameCenter':'Oyun Mərkəzi','messages':'Mesajlar','profile':'Profil','settings':'Ayarlar','language':'Dil','newRoom':'Yeni otaq','createRoom':'Otaq yarat','chooseLanguage':'Tətbiq dilini seç','chooseLanguageSub':'Seçim dərhal tətbiq olunur və bu cihazda yadda saxlanılır.'},
  };

  static String t(Locale locale, String key) {
    return _v[locale.languageCode]?[key] ?? _v['en']?[key] ?? _v['tr']?[key] ?? key;
  }
}

extension LymixLocalizationContext on BuildContext {
  Locale get lymixLocale => LymixLocaleScope.of(this).locale;
  String lx(String key) => LymixStrings.t(lymixLocale, key);
}
