import 'dart:async';
import 'package:flutter/foundation.dart';

enum RoomPkPhase { idle, countdown, active, finished }

class RoomPkController extends ChangeNotifier {
  static const supportedMinutes = <int>[5, 10, 20, 30, 60];

  RoomPkPhase phase = RoomPkPhase.idle;
  int selectedMinutes = 5;
  Duration remaining = Duration.zero;
  int leftScore = 0;
  int rightScore = 0;
  int countdown = 0;
  Timer? _timer;

  bool get isLocked => phase == RoomPkPhase.countdown || phase == RoomPkPhase.active;
  bool get isActive => phase == RoomPkPhase.active;
  double get progress {
    final total = Duration(minutes: selectedMinutes).inSeconds;
    if (total <= 0) return 0;
    return (remaining.inSeconds / total).clamp(0, 1);
  }

  void selectMinutes(int minutes) {
    if (isLocked || !supportedMinutes.contains(minutes)) return;
    selectedMinutes = minutes;
    notifyListeners();
  }

  void start() {
    if (isLocked) return;
    _timer?.cancel();
    leftScore = 0;
    rightScore = 0;
    countdown = 3;
    phase = RoomPkPhase.countdown;
    remaining = Duration(minutes: selectedMinutes);
    notifyListeners();

    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (phase == RoomPkPhase.countdown) {
        countdown -= 1;
        if (countdown <= 0) phase = RoomPkPhase.active;
        notifyListeners();
        return;
      }
      if (phase != RoomPkPhase.active) return;
      final next = remaining - const Duration(seconds: 1);
      remaining = next.isNegative ? Duration.zero : next;
      if (remaining == Duration.zero) finish();
      notifyListeners();
    });
  }

  void addLeft(int points) {
    if (!isActive || points <= 0) return;
    leftScore += points;
    notifyListeners();
  }

  void addRight(int points) {
    if (!isActive || points <= 0) return;
    rightScore += points;
    notifyListeners();
  }

  void reset() {
    _timer?.cancel();
    phase = RoomPkPhase.idle;
    remaining = Duration.zero;
    leftScore = 0;
    rightScore = 0;
    countdown = 0;
    notifyListeners();
  }

  void finish() {
    _timer?.cancel();
    if (phase == RoomPkPhase.idle) return;
    phase = RoomPkPhase.finished;
    remaining = Duration.zero;
    notifyListeners();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
}
