import 'dart:io';
import '../core/api_client.dart';
import 'session_service.dart';
import 'device_identity_service.dart';

class CreatorVerificationService {
  final ApiClient api;
  const CreatorVerificationService(this.api);

  Future<Map<String,dynamic>> status() async {
    final data = await api.getJson('/api/creator-verification/me');
    return Map<String,dynamic>.from(data as Map);
  }

  Future<void> requestPhoneCode(String phoneE164) async {
    await api.postJson('/api/creator-verification/phone/request', {
      'phone': phoneE164.trim(),
    });
  }

  Future<void> confirmPhoneCode(String phoneE164, String code) async {
    await api.postJson('/api/creator-verification/phone/confirm', {
      'phone': phoneE164.trim(),
      'code': code.trim(),
    });
  }

  Future<Map<String,dynamic>> submit({
    required String legalName,
    required String phoneE164,
    required String countryCode,
    required String gender,
    required String videoPath,
    String? agencyId,
  }) async {
    final user = await SessionService.user();
    final installationId = await DeviceIdentityService.getOrCreate();

    final data = await api.postMultipart(
      '/api/creator-verification/submit',
      fields: {
        'legalName': legalName.trim(),
        'phone': phoneE164.trim(),
        'countryCode': countryCode.trim().toUpperCase(),
        'gender': gender,
        'agencyId': agencyId?.trim() ?? '',
        'installationId': installationId,
        'platform': Platform.operatingSystem,
        'osVersion': Platform.operatingSystemVersion,
        'appUserId': user?.id ?? '',
      },
      fileField: 'verificationVideo',
      filePath: videoPath,
    );
    return Map<String,dynamic>.from(data as Map);
  }
}
