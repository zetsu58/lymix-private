import 'dart:convert';
import 'package:flutter/foundation.dart';
import '../models/game_session.dart';
import 'game_provider_service.dart';

class GameSessionController extends ChangeNotifier {
  final GameProviderService provider;
  GameSessionState? state;

  GameSessionController({GameProviderService? provider})
      : provider = provider ?? GameProviderService();

  bool get active => switch (state?.phase) {
        GameSessionPhase.inviting ||
        GameSessionPhase.ready ||
        GameSessionPhase.matching ||
        GameSessionPhase.loading ||
        GameSessionPhase.playing => true,
        _ => false,
      };

  Future<String> launch({
    required String gameId,
    required String roomId,
    required String userId,
    required String displayName,
  }) async {
    state = GameSessionState(
      roomId: roomId,
      gameId: gameId,
      phase: GameSessionPhase.loading,
      players: [GamePlayer(userId: userId, displayName: displayName, ready: true)],
    );
    notifyListeners();

    try {
      final launch = await provider.getLaunchSession(
        gameId: gameId,
        roomId: roomId,
        userId: userId,
      );
      state = state!.copyWith(
        phase: GameSessionPhase.playing,
        launchUrl: launch.launchUrl,
        sessionId: launch.sessionId,
        clearError: true,
      );
      notifyListeners();
      return launch.launchUrl;
    } catch (e) {
      state = state!.copyWith(phase: GameSessionPhase.failed, error: '$e');
      notifyListeners();
      rethrow;
    }
  }

  void handleBridgeEvent(String raw) {
    final current = state;
    if (current == null) return;
    try {
      final event = Map<String, dynamic>.from(jsonDecode(raw) as Map);
      final type = '${event['type'] ?? ''}';
      switch (type) {
        case 'game_ready':
          state = current.copyWith(phase: GameSessionPhase.playing);
          break;
        case 'game_result':
          state = current.copyWith(
            phase: GameSessionPhase.finished,
            result: Map<String, dynamic>.from(event['result'] as Map? ?? const {}),
          );
          break;
        case 'game_closed':
          state = current.copyWith(phase: GameSessionPhase.finished);
          break;
        default:
          return;
      }
      notifyListeners();
    } catch (_) {
      // Invalid/untrusted bridge messages are deliberately ignored.
    }
  }

  void close() {
    final current = state;
    if (current == null) return;
    state = current.copyWith(phase: GameSessionPhase.finished);
    notifyListeners();
  }
}
