class SocialPresence {
  final String userId;
  final bool online;
  final String? publicRoomId;
  final String? publicRoomTitle;
  final bool privateRoom;

  const SocialPresence({
    required this.userId,
    required this.online,
    this.publicRoomId,
    this.publicRoomTitle,
    this.privateRoom = false,
  });

  bool get canExposeRoom => online && !privateRoom && (publicRoomId?.isNotEmpty ?? false);
}

abstract class SocialPresenceRepository {
  Future<SocialPresence> presenceOf(String userId);
  Stream<SocialPresence> watchPresence(String userId);
}
