class GameLaunchRequest {
  final String gameId;
  final String roomId;
  final String userId;
  const GameLaunchRequest({required this.gameId, required this.roomId, required this.userId});
}

class GameLaunchSession {
  final String launchUrl;
  final String? sessionId;
  final String provider;
  final DateTime? expiresAt;
  const GameLaunchSession({
    required this.launchUrl,
    required this.provider,
    this.sessionId,
    this.expiresAt,
  });
}

abstract class GameProviderAdapter {
  Future<GameLaunchSession> launch(GameLaunchRequest request);
}
