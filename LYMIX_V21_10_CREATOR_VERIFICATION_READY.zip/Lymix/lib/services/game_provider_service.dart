import 'dart:convert';
import 'package:http/http.dart' as http;
import 'game_provider_adapter.dart';


class GameCatalogEntry {
  final String id;
  final String name;
  final String category;
  final String? iconUrl;
  final String provider;

  const GameCatalogEntry({
    required this.id,
    required this.name,
    required this.category,
    required this.provider,
    this.iconUrl,
  });

  factory GameCatalogEntry.fromJson(Map<String, dynamic> json) => GameCatalogEntry(
        id: '${json['id'] ?? json['gameId'] ?? ''}',
        name: '${json['name'] ?? 'Oyun'}',
        category: '${json['category'] ?? 'Casual'}',
        iconUrl: json['iconUrl']?.toString(),
        provider: '${json['provider'] ?? 'provider'}',
      );
}

class GameProviderService implements GameProviderAdapter {
  static const String apiBaseUrl = String.fromEnvironment('LYMIX_API_BASE_URL', defaultValue: 'http://10.0.2.2:3000');

  Future<List<GameCatalogEntry>> getCatalog() async {
    final uri = Uri.parse('$apiBaseUrl/api/games');
    final response = await http.get(uri).timeout(const Duration(seconds: 8));
    final decoded = jsonDecode(response.body);
    if (response.statusCode != 200) {
      throw Exception('Oyun kataloğu yüklenemedi');
    }
    final raw = decoded is Map ? decoded['games'] : decoded;
    if (raw is! List) return const [];
    return raw
        .whereType<Map>()
        .map((e) => GameCatalogEntry.fromJson(Map<String, dynamic>.from(e)))
        .where((e) => e.id.isNotEmpty)
        .toList(growable: false);
  }

  @override
  Future<GameLaunchSession> launch(GameLaunchRequest request) async => getLaunchSession(
        gameId: request.gameId,
        roomId: request.roomId,
        userId: request.userId,
      );

  Future<GameLaunchSession> getLaunchSession({
    required String gameId,
    required String roomId,
    required String userId,
  }) async {
    final uri = Uri.parse('$apiBaseUrl/api/games/$gameId/launch').replace(
      queryParameters: {'roomId': roomId, 'userId': userId},
    );
    final response = await http.get(uri).timeout(const Duration(seconds: 8));
    final decoded = jsonDecode(response.body);
    if (decoded is! Map) {
      throw Exception('Oyun sağlayıcısından geçersiz yanıt alındı');
    }
    final data = Map<String, dynamic>.from(decoded);
    final launchUrl = data['launchUrl']?.toString();
    if (response.statusCode != 200 || launchUrl == null || launchUrl.isEmpty) {
      throw Exception(data['error'] ?? 'Oyun sağlayıcısı başlatılamadı');
    }
    DateTime? expiresAt;
    final expires = data['expiresAt']?.toString();
    if (expires != null) expiresAt = DateTime.tryParse(expires);
    return GameLaunchSession(
      launchUrl: launchUrl,
      sessionId: data['sessionId']?.toString(),
      provider: data['provider']?.toString() ?? 'lymix-backend',
      expiresAt: expiresAt,
    );
  }

  Future<String> getLaunchUrl({
    required String gameId,
    required String roomId,
    required String userId,
  }) async => (await getLaunchSession(gameId: gameId, roomId: roomId, userId: userId)).launchUrl;
}
