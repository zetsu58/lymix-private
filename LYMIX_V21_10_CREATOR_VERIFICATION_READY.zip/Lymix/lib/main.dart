import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'lymix_pro_theme.dart';
import 'features/launch/lymix_launch_screen.dart';
import 'screens/auth_gate.dart';
import 'services/localization_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await LymixLocaleController.instance.load();
  runApp(const LymixApp());
}

class LymixApp extends StatelessWidget {
  const LymixApp({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = LymixLocaleController.instance;
    return LymixLocaleScope(
      controller: controller,
      child: AnimatedBuilder(
        animation: controller,
        builder: (context, _) => MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'LYMIX',
          theme: LymixPro.theme(),
          locale: controller.locale,
          supportedLocales: LymixLocaleController.supported,
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          home: const LymixLaunchScreen(next: AuthGate()),
        ),
      ),
    );
  }
}
