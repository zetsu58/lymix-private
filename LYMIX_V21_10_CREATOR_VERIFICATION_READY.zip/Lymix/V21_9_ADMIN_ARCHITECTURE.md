# LYMIX V21.9 — Hybrid Admin Architecture

## Xena APK behavior signals observed
- Audio-room admin list and max-admin-count
- Set/remove admin RPC models
- Kick records and revoke operations
- Ban/unban chat resources
- Room announcement edit/publish
- Agency search/broadcast/host center
- Anchor dashboard with income overview, tasks, levels and shortcuts
- Coin bill/recharge history surfaces
- Audit status models
- Large WebView + JS bridge infrastructure

No Xena admin credentials, proprietary code or assets are used.

## Lymix design
### In-app fast admin
- Room moderation
- Agency/host management
- Reports/security
- Announcements
- Economy/gift/quota overview
- Agency bank shortcuts

### Web admin
Recommended for:
- global user search
- role/permission changes
- permanent bans
- agency approval/compliance
- gift catalog/pricing
- quota/payout policy
- settlement and chargeback
- audit logs
- support cases
- dashboards and exports

Configured with:
`--dart-define=LYMIX_ADMIN_PANEL_URL=https://admin.example.com`

WebView is restricted to the configured HTTPS host.

## Security rules
- Client role is UI gating only, never final authorization.
- Backend validates JWT + role + capability on every privileged endpoint.
- Global economy/role/ban/settlement changes are server authoritative.
- Every privileged mutation gets immutable audit log.
- Sensitive actions should require re-auth/MFA in production.


## V21.9.1 deployable web console
- `/admin/` now serves a real static control-center UI from the same backend.
- Dashboard, users, rooms, agencies, economy, moderation, system campaigns and audit tabs are implemented.
- Admin web can login with the same auth API.
- When opened inside Lymix, the current access token is injected into `sessionStorage`; it is never appended to the URL.
- If `LYMIX_ADMIN_PANEL_URL` is omitted, mobile defaults to `${LYMIX_API_BASE}/admin/`.
- Backend demo users/demo room were removed so admin metrics do not fake production activity.
