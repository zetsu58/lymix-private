# LYMIX Admin Web Deployment

Bu klasör bağımsız statik admin arayüzüdür.

## En kolay kurulum
Backend `server.js`, bu klasörü `/admin/` altında otomatik servis eder.
Backend internette çalışıyorsa:
`https://BACKEND-ALAN-ADINIZ/admin/`

Mobil uygulama ayrıca `LYMIX_ADMIN_PANEL_URL` verilmezse otomatik olarak:
`AppConfig.apiBase + /admin/`
adresini açar.

## Güvenlik
- Production'da `LYMIX_REQUIRE_AUTH=true`.
- Owner/admin hesabı backend environment değişkenleriyle bootstrap edilmelidir.
- JWT final yetkilendirme kaynağıdır.
- UI'da görünen rol tek başına yetki değildir.
- Admin API her mutation için RBAC/capability ve audit kontrolü yapmalıdır.
- HTTPS zorunludur.
- Gerçek production'da CSP, CORS ve allowed origins daraltılmalıdır.
- Yüksek riskli finance/role/ban işlemlerinde MFA/re-auth eklenmelidir.

## Ayrı host etmek istersen
Bu klasörü Cloudflare Pages / Netlify / Vercel Static'e yükleyebilirsin.
Bu durumda API CORS origin'i admin domainine izin vermeli ve uygulama build'ine:
`--dart-define=LYMIX_ADMIN_PANEL_URL=https://admin.SENIN-DOMAININ`
eklenmelidir.
