
(() => {
  const state = {
    token: sessionStorage.getItem('lymix_admin_access') || '',
    refreshToken: sessionStorage.getItem('lymix_admin_refresh') || '',
    user: null,
    page: 'overview',
    stats: null,
  };

  const pages = [
    ['overview','⌂','Genel Bakış'],
    ['users','◎','Kullanıcılar'],
    ['rooms','◉','Odalar'],
    ['agencies','◇','Ajanslar'],
    ['creators','✓','Yayıncı Onayları'],
    ['economy','◈','Ekonomi'],
    ['moderation','⚑','Moderasyon'],
    ['campaigns','✦','Kampanyalar'],
    ['audit','≡','Audit Log'],
  ];

  const $ = (q) => document.querySelector(q);
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const num = (n) => new Intl.NumberFormat('tr-TR').format(Number(n || 0));

  window.LymixAdminBridge = {
    acceptToken(token) {
      if (!token) return;
      state.token = token;
      sessionStorage.setItem('lymix_admin_access', token);
      hideLogin();
      boot();
    }
  };

  function toast(text) {
    const el = document.createElement('div');
    el.className = 'toast'; el.textContent = text;
    $('#toastHost').appendChild(el);
    setTimeout(() => el.remove(), 2800);
  }

  async function api(path, options = {}) {
    const headers = {'Content-Type':'application/json', ...(options.headers || {})};
    if (state.token) headers.Authorization = `Bearer ${state.token}`;
    headers['x-admin-id'] = state.user?.id || 'web-admin';
    const res = await fetch(path, {...options, headers});
    if (res.status === 401) { showLogin('Oturum sona erdi. Tekrar giriş yap.'); throw new Error('unauthorized'); }
    let data = null;
    try { data = await res.json(); } catch (_) {}
    if (!res.ok) throw new Error(data?.error || `HTTP ${res.status}`);
    return data;
  }

  function renderNav() {
    $('#nav').innerHTML = pages.map(([id,icon,label]) =>
      `<button class="nav-btn ${state.page===id?'active':''}" data-page="${id}">
        <span class="nav-ico">${icon}</span><span class="nav-label">${label}</span>
      </button>`).join('');
    document.querySelectorAll('.nav-btn').forEach(b => b.onclick = () => {
      state.page = b.dataset.page; renderNav(); renderPage();
    });
  }

  function showLogin(message='') {
    $('#loginModal').classList.add('show');
    $('#loginError').textContent = message;
  }
  function hideLogin() { $('#loginModal').classList.remove('show'); }

  async function login(login, password) {
    const deviceId = localStorage.getItem('lymix_admin_device') ||
      `admin-web-${crypto.randomUUID ? crypto.randomUUID() : Date.now()}`;
    localStorage.setItem('lymix_admin_device', deviceId);
    const res = await fetch('/api/auth/login', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({login,password,deviceId,deviceName:'LYMIX Admin Web',platform:'web',appVersion:'21.9.1'})
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Giriş başarısız');
    state.token = data.accessToken || '';
    state.refreshToken = data.refreshToken || '';
    state.user = data.user || null;
    sessionStorage.setItem('lymix_admin_access', state.token);
    sessionStorage.setItem('lymix_admin_refresh', state.refreshToken);
    hideLogin();
    await boot();
  }

  $('#loginForm').addEventListener('submit', async e => {
    e.preventDefault();
    $('#loginError').textContent = '';
    try { await login($('#loginInput').value.trim(), $('#passwordInput').value); }
    catch (err) { $('#loginError').textContent = err.message; }
  });

  $('#refreshBtn').onclick = () => renderPage(true);

  async function boot() {
    if (!state.token) { showLogin(); return; }
    $('#connectionText').textContent = 'Backend bağlanıyor';
    try {
      state.stats = await api('/api/admin/stats');
      $('.status-dot').classList.add('ok');
      $('#connectionText').textContent = 'Backend bağlı';
      $('#adminName').textContent = state.user?.displayName || state.user?.name || 'Baş Admin';
      $('#adminRole').textContent = state.user?.role || 'Admin session';
      renderNav(); await renderPage();
    } catch (e) {
      $('.status-dot').classList.remove('ok');
      $('#connectionText').textContent = 'Bağlantı hatası';
      if (e.message !== 'unauthorized') toast(e.message);
    }
  }

  async function renderPage(force=false) {
    const titles = Object.fromEntries(pages.map(p => [p[0], p[2]]));
    $('#pageTitle').textContent = titles[state.page] || 'LYMIX';
    $('#content').innerHTML = `<div class="card empty">Yükleniyor…</div>`;
    try {
      if (state.page === 'overview') return renderOverview(force);
      if (state.page === 'users') return renderUsers();
      if (state.page === 'rooms') return renderRooms();
      if (state.page === 'agencies') return renderAgencies();
      if (state.page === 'creators') return renderCreators();
      if (state.page === 'economy') return renderEconomy();
      if (state.page === 'moderation') return renderModeration();
      if (state.page === 'campaigns') return renderCampaigns();
      if (state.page === 'audit') return renderAudit();
    } catch (e) {
      $('#content').innerHTML = `<div class="card"><b class="danger">İşlem başarısız</b><p class="muted">${esc(e.message)}</p></div>`;
    }
  }

  async function renderOverview(force) {
    if (force || !state.stats) state.stats = await api('/api/admin/stats');
    const s = state.stats;
    $('#content').innerHTML = `
      <div class="grid stats">
        ${stat('Toplam Kullanıcı',s.totalUsers,'Gerçek hesap kaydı')}
        ${stat('Aktif Oda',s.activeRooms,'Canlı oda durumu')}
        ${stat('Ajans',s.agencies,'Onaylı/yönetilen')}
        ${stat('Bekleyen Doğrulama',s.pendingVerifications,'İnceleme kuyruğu')}
      </div>
      <div class="grid two" style="margin-top:13px">
        <div class="card">
          <div class="section-head"><h3>Güvenlik Özeti</h3><span class="badge danger">LIVE OPS</span></div>
          <div class="grid three">
            ${mini('Hesap Ban',s.accountBans)}
            ${mini('Cihaz Ban',s.deviceBans)}
            ${mini('IP Ban',s.ipBans)}
          </div>
        </div>
        <div class="card">
          <div class="section-head"><h3>Feature Flags</h3><small>Remote config</small></div>
          ${Object.entries(s.featureFlags || {}).map(([k,v]) =>
            `<div class="policy"><b>${esc(k)}</b><small class="${v?'ok':'danger'}">${v?'AKTİF':'KAPALI'}</small></div>`).join('')}
        </div>
      </div>`;
  }
  function stat(label,value,sub){return `<div class="card"><div class="stat-label">${label}</div><div class="stat-value">${num(value)}</div><div class="stat-sub">${sub}</div></div>`}
  function mini(label,value){return `<div class="policy"><b>${label}</b><small>${num(value)}</small></div>`}

  async function renderUsers() {
    const users = await api('/api/admin/users');
    $('#content').innerHTML = `
      <div class="card">
        <div class="toolbar"><input id="userSearch" placeholder="ID, isim veya özel ID ara"><button class="ghost" id="userSearchBtn">Ara</button></div>
        <div id="userTable">${userTable(users)}</div>
      </div>`;
    $('#userSearchBtn').onclick = async () => {
      const q = encodeURIComponent($('#userSearch').value.trim());
      $('#userTable').innerHTML = userTable(await api('/api/admin/users?q='+q));
      bindUserActions();
    };
    bindUserActions();
  }
  function userTable(users) {
    if (!users.length) return `<div class="empty">Kullanıcı bulunamadı.</div>`;
    return `<table><thead><tr><th>KULLANICI</th><th>COIN</th><th>ROLLER</th><th>DURUM</th><th>AKSİYON</th></tr></thead><tbody>
      ${users.map(u => `<tr>
        <td><b>${esc(u.name || u.displayName || 'Kullanıcı')}</b><br><span class="muted">${esc(u.id)}</span></td>
        <td>${num(u.coins)}</td>
        <td>${(u.admin?.roles||['user']).map(r=>`<span class="badge">${esc(r)}</span>`).join(' ')}</td>
        <td>${u.ban?'<span class="badge danger">BAN</span>':'<span class="badge ok">AKTİF</span>'}</td>
        <td><div class="action-row"><button class="ghost user-view" data-id="${esc(u.id)}">İncele</button>
        ${u.ban?`<button class="ghost user-unban" data-id="${esc(u.id)}">Ban Kaldır</button>`:`<button class="danger-btn user-ban" data-id="${esc(u.id)}">Ban</button>`}</div></td>
      </tr>`).join('')}
    </tbody></table>`;
  }
  function bindUserActions() {
    document.querySelectorAll('.user-view').forEach(b => b.onclick = async () => {
      const d = await api('/api/admin/users/'+encodeURIComponent(b.dataset.id));
      alert(JSON.stringify(d,null,2));
    });
    document.querySelectorAll('.user-ban').forEach(b => b.onclick = async () => {
      const reason = prompt('Ban gerekçesi'); if (!reason) return;
      await api(`/api/admin/users/${encodeURIComponent(b.dataset.id)}/ban`,{method:'POST',body:JSON.stringify({reason})});
      toast('Kullanıcı banlandı'); renderUsers();
    });
    document.querySelectorAll('.user-unban').forEach(b => b.onclick = async () => {
      await api(`/api/admin/users/${encodeURIComponent(b.dataset.id)}/ban`,{method:'DELETE',body:JSON.stringify({reason:'Admin web'})});
      toast('Ban kaldırıldı'); renderUsers();
    });
  }

  async function renderRooms() {
    const rooms = await fetch('/api/rooms').then(r=>r.json());
    $('#content').innerHTML = `<div class="card"><div class="section-head"><h3>Canlı Odalar</h3><span class="badge gold">${rooms.length} oda</span></div>
      ${rooms.length?`<table><thead><tr><th>ODA</th><th>OWNER</th><th>KOLTUK</th><th>DİNLEYİCİ</th><th>DURUM</th></tr></thead><tbody>
      ${rooms.map(r=>`<tr><td><b>${esc(r.title)}</b><br><span class="muted">${esc(r.id)}</span></td><td>${esc(r.ownerId)}</td><td>${num(r.occupiedSeats)}</td><td>${num(r.listeners)}</td><td>${r.locked?'<span class="badge">KİLİTLİ</span>':'<span class="badge ok">AÇIK</span>'}</td></tr>`).join('')}
      </tbody></table>`:`<div class="empty">Şu anda açık oda yok.</div>`}</div>`;
  }

  async function renderAgencies() {
    $('#content').innerHTML = `<div class="grid two">
      <div class="card"><div class="section-head"><h3>Yeni Ajans</h3><span class="badge">RBAC</span></div>
        <label>Ajans Adı<input id="agencyName" placeholder="Ajans adı"></label>
        <label>Owner User ID<input id="agencyOwner" placeholder="Kullanıcı ID"></label>
        <button class="primary" id="createAgency">Ajans Oluştur</button>
      </div>
      <div class="card"><h3>Ajans Politikası</h3><p class="muted">Ajans sahibi, broadcaster ve oda bağları backend audit log ile yönetilir. Mobil istemci final yetki kaynağı değildir.</p></div>
    </div>`;
    $('#createAgency').onclick = async () => {
      const name=$('#agencyName').value.trim(), ownerUserId=$('#agencyOwner').value.trim();
      if(!name)return toast('Ajans adı gerekli');
      await api('/api/admin/agencies',{method:'POST',body:JSON.stringify({name,ownerUserId,reason:'Admin web'})});
      toast('Ajans oluşturuldu');
    };
  }


  async function renderCreators() {
    const rows = await api('/api/admin/creator-verifications');
    $('#content').innerHTML = `<div class="card">
      <div class="section-head"><h3>Yayıncı Doğrulama Kuyruğu</h3><span class="badge gold">${rows.length} başvuru</span></div>
      ${rows.length?`<table><thead><tr><th>ADAY</th><th>TELEFON</th><th>CİHAZ</th><th>AJANS</th><th>DURUM</th><th>AKSİYON</th></tr></thead><tbody>
      ${rows.map(x=>`<tr>
        <td><b>${esc(x.legalName)}</b><br><span class="muted">${esc(x.userId)} • ${esc(x.countryCode)} • ${esc(x.gender)}</span></td>
        <td>${esc(x.phone)}</td>
        <td>${esc(x.platform)}<br><span class="muted">${esc(x.osVersion||'')}</span></td>
        <td>${esc(x.agencyId||'—')}</td>
        <td><span class="badge ${x.status==='APPROVED'?'ok':x.status==='REJECTED'?'danger':'gold'}">${esc(x.status)}</span></td>
        <td><div class="action-row">
          <button class="primary creator-review" data-id="${esc(x.userId)}" data-status="APPROVED">Onayla</button>
          <button class="ghost creator-review" data-id="${esc(x.userId)}" data-status="NEEDS_REVERIFY">Tekrar Doğrula</button>
          <button class="danger-btn creator-review" data-id="${esc(x.userId)}" data-status="REJECTED">Reddet</button>
        </div></td>
      </tr>`).join('')}</tbody></table>`:`<div class="empty">Bekleyen yayıncı başvurusu yok.</div>`}
      <p class="muted" style="margin-top:14px">Cinsiyet yalnızca profil bilgisi olabilir; yayıncı onay kararında tek başına belirleyici kriter olarak kullanılmamalıdır. Onay kimlik/telefon/canlılık/uygunluk incelemesine dayanır.</p>
    </div>`;
    document.querySelectorAll('.creator-review').forEach(b=>b.onclick=async()=>{
      const note=prompt('İnceleme notu')||'';
      await api(`/api/admin/creator-verifications/${encodeURIComponent(b.dataset.id)}/review`,{
        method:'POST',body:JSON.stringify({status:b.dataset.status,note})
      });
      toast('Başvuru güncellendi'); renderCreators();
    });
  }

  async function renderEconomy() {
    const cfg = await api('/api/admin/config');
    const e = cfg.economy || {};
    $('#content').innerHTML = `<div class="grid two">
      <div class="card">
        <div class="section-head"><h3>Ekonomi Politikası</h3><span class="badge gold">SERVER AUTHORITATIVE</span></div>
        <div class="policy-grid">
          ${policy('Diamond → Coin',e.diamondToCoinRate)}
          ${policy('Alıcı Hediye Payı',Math.round((e.receiverGiftPercent||0)*100)+'%')}
          ${policy('Min Cashout Diamond',num(e.minCashoutDiamonds))}
          ${policy('Settlement','Audit + KYC')}
        </div>
      </div>
      <div class="card">
        <h3>Güvenlik</h3>
        <p class="muted">Coin, kota, earned credit ve ajans settlement ayrı ledger olmalıdır. Gerçek payout backend KYC, ülke uygunluğu ve chargeback kontrollerinden sonra yapılır.</p>
      </div>
    </div>`;
  }
  function policy(a,b){return `<div class="policy"><b>${a}</b><small>${esc(b)}</small></div>`}

  async function renderModeration() {
    const bans = await api('/api/admin/security/bans');
    $('#content').innerHTML = `<div class="grid stats">
      ${stat('Hesap Ban',bans.accounts?.length||0,'Kalıcı/geçici')}
      ${stat('Cihaz Ban',bans.devices?.length||0,'Fingerprint')}
      ${stat('IP Ban',bans.ips?.length||0,'Hash kayıt')}
      ${stat('Toplam', (bans.accounts?.length||0)+(bans.devices?.length||0)+(bans.ips?.length||0),'Aktif güvenlik kaydı')}
    </div>
    <div class="card" style="margin-top:13px"><h3>Moderasyon İlkesi</h3><p class="muted">Rapor → inceleme → aksiyon → itiraz → audit zinciri. Yüksek riskli işlemlerde tekrar doğrulama/MFA önerilir.</p></div>`;
  }

  async function renderCampaigns() {
    $('#content').innerHTML = `<div class="grid two">
      <div class="card"><div class="section-head"><h3>Sistem Mesajı</h3><span class="badge gold">LIVE</span></div>
        <label>Başlık<input id="campTitle" value="Lymix"></label>
        <label>Mesaj<textarea id="campMessage" rows="5" placeholder="Duyuru metni"></textarea></label>
        <label>Oda ID (opsiyonel)<input id="campRoom" placeholder="Boşsa global"></label>
        <button class="primary" id="sendCampaign">Gönder</button>
      </div>
      <div class="card"><h3>Banner / Ticker / Popup</h3><p class="muted">V21.8 premium chrome katmanı remote config ile beslenmeye hazır. Production’da kampanyalar hedef kitle, dil, tarih ve VIP/ajans segmentiyle versioned config üzerinden yönetilmelidir.</p></div>
    </div>`;
    $('#sendCampaign').onclick = async () => {
      const title=$('#campTitle').value.trim(),message=$('#campMessage').value.trim(),roomId=$('#campRoom').value.trim();
      if(!message)return toast('Mesaj boş olamaz');
      await api('/api/admin/system-message',{method:'POST',body:JSON.stringify({title,message,roomId:roomId||null,reason:'Admin web campaign'})});
      toast('Sistem mesajı gönderildi');
    };
  }

  async function renderAudit() {
    const rows = await api('/api/admin/audit?limit=150');
    $('#content').innerHTML = `<div class="card"><div class="section-head"><h3>Değişiklik Geçmişi</h3><span class="badge">${rows.length} kayıt</span></div>
      ${rows.length?`<table><thead><tr><th>ZAMAN</th><th>ADMIN</th><th>AKSİYON</th><th>HEDEF</th><th>GEREKÇE</th></tr></thead><tbody>
      ${rows.map(x=>`<tr><td>${esc(x.at)}</td><td>${esc(x.actorAdminId)}</td><td><span class="badge">${esc(x.action)}</span></td><td>${esc(x.targetType)} / ${esc(x.targetId)}</td><td>${esc(x.reason||'—')}</td></tr>`).join('')}
      </tbody></table>`:`<div class="empty">Henüz audit kaydı yok.</div>`}</div>`;
  }

  if (state.token) { hideLogin(); boot(); } else showLogin();
})();
