# LYMIX V21 Deep Research Brief

## Product target
Lymix must feel like a real social product even with zero users. No fake room, fake visitor, fake sender, fake gift history or fake balance is allowed in production UI.

## Research-derived pillars
1. Voice room + social graph + gifts + games + PK must behave as one system, not isolated screens.
2. Lymix Official acts as onboarding/product guide, not spam: first-run help, rules, room suggestions, icebreakers, safety and milestone prompts.
3. PK is a stateful room mode: 5/10/20/30/60 min, 3-second countdown, live score, final state, reset, rematch-ready architecture.
4. During active PK, direct seat switching is disabled. User must leave the current seat first.
5. Empty states must provide a next action: create room, discover, invite, complete profile.
6. Premium status must be visible across entry effect, seat frame, nameplate, profile, room badge and gift presentation.
7. Motion language: press ~105 ms, fast UI ~160 ms, page ~220 ms, sheet ~260 ms. No random durations.
8. Accessibility: 48dp critical touch targets, clear contrast, reduced-motion support, semantic labels for icon-only actions.
9. Performance: localize rebuilds, avoid expensive opacity/clipping in continuous animations, lazy-build lists and keep animation children stable.
10. Reliability: loading/content/empty/error/offline/restricted states must exist for user-facing network screens.
11. Architecture direction: View/ViewModel/Repository/Service boundaries for social, room, wallet, gifts, PK and messaging.
12. Release quality: real crash/ANR monitoring should be connected before production rollout.

## Competitor-derived opportunities
- Smart room icebreakers/topics (SUGO-style product concept, Lymix-specific implementation)
- Voice room + real-time PK/game loops (TopTop-like product integration, not copied UI)
- Strong room discovery and premium identity layers
- Moments/social feed only when real backend content exists
- Room share/deep-link, follow graph, profile peek and join-friend-room behavior
- Season PK leaderboard, rematch, streak and room history
- Gift tiers with light/heavy animation budgets
- User safety, reporting, blocking and privacy gating built into every social surface

## Non-goals
- Copying competitor branding, logos, proprietary assets or source code
- Fake social proof
- Random animation overload
- Debug/admin shortcuts visible to normal production users
