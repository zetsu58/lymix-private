import 'package:flutter/material.dart';
import '../models/gift_model.dart';
import '../models/gift_recipient.dart';
import '../services/coin_wallet_service.dart';
import '../economy/quota_economy.dart';
import '../design/lymix_design_system.dart';
import '../design/lymix_icon_system.dart';
import 'lymix_visual_production.dart';

enum GiftTargetMode { single, seated, room }

typedef GiftSendCallback = Future<void> Function(
  LymixGiftItem gift,
  int quantity,
  List<GiftRecipient> recipients,
);

class GiftSendSheet extends StatefulWidget {
  final String currentUserId;
  final List<GiftRecipient> roomRecipients;
  final String? initialReceiverUserId;
  final GiftSendCallback onSend;

  const GiftSendSheet({
    super.key,
    required this.currentUserId,
    required this.roomRecipients,
    required this.onSend,
    this.initialReceiverUserId,
  });

  @override
  State<GiftSendSheet> createState() => _GiftSendSheetState();
}

class _GiftSendSheetState extends State<GiftSendSheet> {
  String category = 'Mini';
  int selected = 0;
  int qty = 1;
  bool sending = false;
  GiftTargetMode targetMode = GiftTargetMode.single;
  String? selectedReceiverId;
  final cats = const ['Mini', 'Sosyal', 'Premium', 'Epik', 'Efsane'];

  List<LymixGiftItem> get list =>
      lymixGiftCatalog.where((g) => g.category == category).toList();

  List<GiftRecipient> get eligibleRecipients {
    final seen = <String>{};
    return widget.roomRecipients.where((r) {
      if (r.userId == widget.currentUserId) return false;
      if (r.userId.trim().isEmpty) return false;
      return seen.add(r.userId);
    }).toList();
  }

  List<GiftRecipient> get seatedRecipients =>
      eligibleRecipients.where((r) => r.isSeated).toList();

  List<GiftRecipient> get selectedRecipients {
    switch (targetMode) {
      case GiftTargetMode.single:
        if (selectedReceiverId == null) return const [];
        return eligibleRecipients
            .where((r) => r.userId == selectedReceiverId)
            .toList();
      case GiftTargetMode.seated:
        return seatedRecipients;
      case GiftTargetMode.room:
        return eligibleRecipients;
    }
  }

  @override
  void initState() {
    super.initState();
    CoinWalletService.instance.init();
    selectedReceiverId = widget.initialReceiverUserId;
    if (selectedReceiverId == widget.currentUserId) selectedReceiverId = null;
    if (selectedReceiverId == null && eligibleRecipients.isNotEmpty) {
      selectedReceiverId = eligibleRecipients.first.userId;
    }
  }

  @override
  Widget build(BuildContext context) {
    final items = list;
    if (selected >= items.length) selected = 0;
    final gift = items[selected];
    final recipients = selectedRecipients;
    final recipientCount = recipients.length;
    final perRecipient = gift.coins * qty;
    final totalCost = perRecipient * recipientCount;

    return SafeArea(
      child: Container(
        constraints: BoxConstraints(
          maxHeight: MediaQuery.sizeOf(context).height * .91,
        ),
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
        decoration: const BoxDecoration(
          color: Color(0xFF0D0814),
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 42,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.white24,
                borderRadius: BorderRadius.circular(9),
              ),
            ),
            const SizedBox(height: 12),
            Row(children: [
              const LymixIcon(
                LymixGlyph.gift,
                size: 20,
                style: LymixIconStyle.premium,
                active: true,
              ),
              const SizedBox(width: 9),
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Hediye', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                  SizedBox(height: 2),
                  Text('Alıcı seç • hediyeyi seç • gönder',
                    style: TextStyle(color: LymixPalette.text3, fontSize: 8.8)),
                ],
              ),
              const Spacer(),
              AnimatedBuilder(
                animation: CoinWalletService.instance,
                builder: (_, __) => Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                  decoration: BoxDecoration(
                    color: const Color(0x22FFD200),
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Text(
                    '🪙 ${CoinWalletService.instance.balance}',
                    style: const TextStyle(
                      color: Color(0xFFFFD200),
                      fontWeight: FontWeight.w900,
                      fontSize: 12,
                    ),
                  ),
                ),
              ),
            ]),
            const SizedBox(height: 12),
            _recipientModeBar(),
            const SizedBox(height: 10),
            AnimatedSwitcher(
              duration: LymixMotion.fast,
              child: targetMode == GiftTargetMode.single
                  ? _singleRecipientPicker()
                  : _groupRecipientSummary(),
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 38,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: cats
                    .map((c) => Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: ChoiceChip(
                            label: Text(c),
                            selected: category == c,
                            onSelected: (_) => setState(() {
                              category = c;
                              selected = 0;
                            }),
                            selectedColor: const Color(0xFFFFD200),
                            labelStyle: TextStyle(
                              color: category == c
                                  ? Colors.black
                                  : Colors.white70,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ))
                    .toList(),
              ),
            ),
            const SizedBox(height: 12),
            Flexible(
              child: GridView.builder(
                shrinkWrap: true,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 4,
                  crossAxisSpacing: 8,
                  mainAxisSpacing: 8,
                  childAspectRatio: .78,
                ),
                itemCount: items.length,
                itemBuilder: (_, i) {
                  final g = items[i];
                  final active = i == selected;
                  final color = giftTierColor(g.tier);
                  return LymixPressable(
                    onTap: () => setState(() => selected = i),
                    child: AnimatedContainer(
                      duration: LymixMotion.fast,
                      padding: const EdgeInsets.all(7),
                      decoration: BoxDecoration(
                        color: active
                            ? color.withValues(alpha: .11)
                            : Colors.white.withValues(alpha: .025),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: active
                              ? color
                              : Colors.white.withValues(alpha: .05),
                          width: active ? 1.5 : 1,
                        ),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(g.symbol,
                              style: TextStyle(fontSize: active ? 32 : 28)),
                          const SizedBox(height: 4),
                          Text(
                            g.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 9,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          Text(
                            '${g.coins}',
                            style: TextStyle(
                              fontSize: 9,
                              color: color,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 9),
            Container(
              height: 1,
              color: Colors.white.withValues(alpha:.05),
            ),
            const SizedBox(height: 9),
            Row(children: [
              for (final q in [1, 5, 10, 99])
                Padding(
                  padding: const EdgeInsets.only(right: 7),
                  child: ChoiceChip(
                    label: Text('x$q'),
                    selected: qty == q,
                    onSelected: (_) => setState(() => qty = q),
                    selectedColor: const Color(0xFF783FF2),
                  ),
                ),
              const Spacer(),
              Text(
                recipientCount == 0
                    ? 'Alıcı seç'
                    : '$recipientCount kişi • $totalCost Coin',
                style: TextStyle(
                  color: recipientCount == 0
                      ? LymixPalette.danger
                      : const Color(0xFFFFD200),
                  fontWeight: FontWeight.w900,
                ),
              ),
            ]),
            const SizedBox(height: 8),
            if (recipientCount > 0)
              Builder(builder: (_) {
                final settlement = const QuotaEconomyEngine().preview(
                  gift: gift,
                  quantity: qty,
                  receiverHasAgency: false,
                );
                return Container(
                  width: double.infinity,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 11, vertical: 9),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: .035),
                    borderRadius: BorderRadius.circular(14),
                    border:
                        Border.all(color: Colors.white.withValues(alpha: .05)),
                  ),
                  child: Text(
                    'Kişi başı kota +${settlement.quotaPoints} • geri coin +${settlement.recyclableCoins} • kazanç kredisi +${settlement.hostEarnedCredits}',
                    style:
                        const TextStyle(fontSize: 9, color: Colors.white54),
                  ),
                );
              }),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFFFFD200),
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(18),
                  ),
                ),
                onPressed: sending || recipientCount == 0
                    ? null
                    : () async {
                        final ok =
                            await CoinWalletService.instance.spend(totalCost);
                        if (!mounted) return;
                        if (!ok) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text(
                                'Yetersiz Coin. Coin mağazasından bakiye yükleyebilirsin.',
                              ),
                            ),
                          );
                          return;
                        }
                        setState(() => sending = true);
                        try {
                          await widget.onSend(gift, qty, recipients);
                          if (mounted) Navigator.pop(context);
                        } finally {
                          if (mounted) setState(() => sending = false);
                        }
                      },
                icon: Icon(sending
                    ? Icons.hourglass_top_rounded
                    : Icons.auto_awesome_rounded),
                label: Text(
                  sending
                      ? 'Gönderiliyor...'
                      : recipientCount == 0
                          ? 'Alıcı seç'
                          : 'Gönder • $recipientCount kişi • $totalCost Coin',
                  style: const TextStyle(fontWeight: FontWeight.w900),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _recipientModeBar() => Row(
        children: [
          Expanded(child: _modeButton(GiftTargetMode.single, 'Tek Kişi', Icons.person_rounded)),
          const SizedBox(width: 6),
          Expanded(child: _modeButton(GiftTargetMode.seated, 'Koltuklar', Icons.event_seat_rounded)),
          const SizedBox(width: 6),
          Expanded(child: _modeButton(GiftTargetMode.room, 'Herkes', Icons.groups_rounded)),
        ],
      );

  Widget _modeButton(GiftTargetMode mode, String label, IconData icon) {
    final active = targetMode == mode;
    return LymixPressable(
      onTap: () => setState(() => targetMode = mode),
      child: AnimatedContainer(
        duration: LymixMotion.fast,
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
        decoration: BoxDecoration(
          gradient: active ? LymixPalette.brand : null,
          color: active ? null : Colors.white.withValues(alpha: .035),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
              color: active ? Colors.transparent : Colors.white10),
        ),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, size: 15, color: active ? Colors.black : Colors.white70),
          const SizedBox(width: 5),
          Flexible(
            child: Text(
              label,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w900,
                color: active ? Colors.black : Colors.white70,
              ),
            ),
          ),
        ]),
      ),
    );
  }

  Widget _singleRecipientPicker() {
    final recipients = eligibleRecipients;
    if (recipients.isEmpty) {
      return const SizedBox(
        height: 68,
        child: Center(
          child: Text(
            'Odada hediye gönderebileceğin başka bir kullanıcı yok.',
            style: TextStyle(color: Colors.white54, fontSize: 10),
          ),
        ),
      );
    }
    return SizedBox(
      key: const ValueKey('single-recipient'),
      height: 72,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: recipients.length,
        separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemBuilder: (_, i) {
          final r = recipients[i];
          final active = r.userId == selectedReceiverId;
          return LymixPressable(
            onTap: () => setState(() => selectedReceiverId = r.userId),
            child: SizedBox(
              width: 58,
              child: Column(children: [
                AnimatedContainer(
                  duration: LymixMotion.fast,
                  padding: const EdgeInsets.all(2),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: active ? LymixPalette.brand : null,
                    border: active ? null : Border.all(color: Colors.white12),
                  ),
                  child: CircleAvatar(
                    radius: 21,
                    backgroundColor: LymixPalette.surface3,
                    backgroundImage: r.avatarUrl != null && r.avatarUrl!.isNotEmpty
                        ? NetworkImage(r.avatarUrl!)
                        : null,
                    child: r.avatarUrl == null || r.avatarUrl!.isEmpty
                        ? Text(
                            r.displayName.isEmpty
                                ? '?'
                                : r.displayName.characters.first.toUpperCase(),
                            style: const TextStyle(fontWeight: FontWeight.w900),
                          )
                        : null,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  r.displayName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 8,
                    fontWeight: active ? FontWeight.w900 : FontWeight.w600,
                    color: active ? LymixPalette.gold : Colors.white60,
                  ),
                ),
              ]),
            ),
          );
        },
      ),
    );
  }

  Widget _groupRecipientSummary() {
    final recipients = selectedRecipients;
    final label = targetMode == GiftTargetMode.seated
        ? 'Dolu koltuklardaki kullanıcılar'
        : 'Odadaki tüm kullanıcılar';
    return Container(
      key: ValueKey(targetMode),
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: .035),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withValues(alpha: .06)),
      ),
      child: Row(children: [
        Icon(
          targetMode == GiftTargetMode.seated
              ? Icons.event_seat_rounded
              : Icons.groups_rounded,
          color: LymixPalette.gold,
        ),
        const SizedBox(width: 9),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label,
                  style: const TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                  )),
              Text(
                recipients.isEmpty
                    ? 'Uygun alıcı yok'
                    : '${recipients.length} gerçek kullanıcı • Kendin dahil değilsin',
                style: const TextStyle(fontSize: 9, color: Colors.white54),
              ),
            ],
          ),
        ),
      ]),
    );
  }
}
