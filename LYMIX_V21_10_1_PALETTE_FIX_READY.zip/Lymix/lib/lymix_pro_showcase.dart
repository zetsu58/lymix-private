import 'dart:ui';
import 'package:flutter/material.dart';
import 'lymix_pro_theme.dart';
import 'screens/global_search_screen.dart';
import 'screens/room_screen.dart';
import 'screens/room_create_screen.dart';
import 'screens/game_center_screen.dart';
import 'screens/vip_center_screen.dart';
import 'screens/app_settings_screen.dart';
import 'screens/coin_store_screen.dart';
import 'screens/notification_center_screen.dart';
import 'screens/message_requests_screen.dart';
import 'screens/gift_catalog_screen.dart';
import 'screens/admin_economy_center_screen.dart';
import 'screens/owner_ops_center_screen.dart';
import 'screens/official_chat_screen.dart';
import 'screens/feature_hub_screen.dart';
import 'screens/super_admin_profile_screen.dart';
import 'services/official_bot_service.dart';
import 'services/localization_service.dart';
import 'screens/user_profile_screen.dart';
import 'screens/direct_message_screen.dart';
import 'screens/favorites_screen.dart';
import 'screens/inventory_screen.dart';
import 'widgets/lymix_live_chrome.dart';
import 'screens/admin_hybrid_center_screen.dart';
import 'design/lymix_design_system.dart';

class LymixProShowcase extends StatefulWidget {
  const LymixProShowcase({super.key});
  @override
  State<LymixProShowcase> createState() => _LymixProShowcaseState();
}

class _LymixProShowcaseState extends State<LymixProShowcase>
    with SingleTickerProviderStateMixin {
  int index = 0;
  late final AnimationController _ambient;

  final List<Widget> pages = const <Widget>[
    DiscoverPage(),
    SocialPage(),
    GameCenterPage(),
    InboxPage(),
    ProfilePage(),
  ];

  @override
  void initState() {
    super.initState();
    _ambient = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat(reverse: true);
    WidgetsBinding.instance.addPostFrameCallback((_) => _showOfficialWelcomeIfNeeded());
  }

  Future<void> _showOfficialWelcomeIfNeeded() async {
    if (!await OfficialBotService.shouldShowWelcome() || !mounted) return;
    await OfficialBotService.markWelcomeDelivered();
    if (!mounted) return;
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF130F1B),
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Row(children: [
              CircleAvatar(backgroundColor: LymixPro.yellow, child: Icon(Icons.graphic_eq_rounded, color: LymixPro.bg)),
              SizedBox(width: 10),
              Expanded(child: Text('Lymix Official', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900))),
              Icon(Icons.verified_rounded, color: LymixPro.yellow),
            ]),
            const SizedBox(height: 12),
            Text(context.lx('welcomeBody'), style: const TextStyle(color: Colors.white70, height: 1.4)),
            const SizedBox(height: 16),
            SizedBox(width: double.infinity, child: FilledButton.icon(
              onPressed: () { Navigator.pop(sheetContext); Navigator.push(context, MaterialPageRoute(builder: (_) => const OfficialChatScreen())); },
              icon: const Icon(Icons.mark_chat_unread_rounded),
              label: Text(context.lx('openOfficial')),
            )),
          ]),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _ambient.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: Stack(
        children: [
          AnimatedBuilder(
            animation: _ambient,
            builder: (_, __) {
              final t = _ambient.value;
              return Positioned.fill(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: RadialGradient(
                      center: Alignment(-0.75 + (t * 0.5), -0.9 + (t * 0.25)),
                      radius: 1.25,
                      colors: [
                        LymixPro.purple.withValues(alpha: 0.14 + t * 0.05),
                        LymixPro.deepPurple.withValues(alpha: 0.10),
                        LymixPro.bg,
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
          SafeArea(child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 280),
            switchInCurve: Curves.easeOutCubic,
            switchOutCurve: Curves.easeInCubic,
            child: KeyedSubtree(key: ValueKey(index), child: pages[index]),
          )),
        ],
      ),
      bottomNavigationBar: _GlassNav(
        index: index,
        onChanged: (v) => setState(() => index = v),
      ),
    );
  }
}

class _GlassNav extends StatelessWidget {
  final int index;
  final ValueChanged<int> onChanged;
  const _GlassNav({required this.index, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final items = <({IconData icon, IconData selectedIcon, String label})>[
      (icon: Icons.home_outlined, selectedIcon: Icons.home_rounded, label: context.lx('home')),
      (icon: Icons.hub_outlined, selectedIcon: Icons.hub_rounded, label: context.lx('plaza')),
      (icon: Icons.sports_esports_outlined, selectedIcon: Icons.sports_esports_rounded, label: context.lx('games')),
      (icon: Icons.forum_outlined, selectedIcon: Icons.forum_rounded, label: context.lx('messages')),
      (icon: Icons.person_outline_rounded, selectedIcon: Icons.person_rounded, label: context.lx('profile')),
    ];

    return SafeArea(
      top: false,
      minimum: const EdgeInsets.fromLTRB(10, 0, 10, 8),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(30),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
          child: Container(
            height: 76,
            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 7),
            decoration: BoxDecoration(
              color: const Color(0xE8130F1B),
              borderRadius: BorderRadius.circular(30),
              border: Border.all(color: Colors.white.withValues(alpha: .075)),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: .42),
                  blurRadius: 26,
                  offset: const Offset(0, 10),
                ),
                BoxShadow(
                  color: LymixPro.purple.withValues(alpha: .08),
                  blurRadius: 30,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: Row(
              children: List.generate(items.length, (i) {
                final selected = i == index;
                final item = items[i];
                return Expanded(
                  child: Semantics(
                    button: true,
                    selected: selected,
                    label: item.label,
                    child: InkWell(
                      borderRadius: BorderRadius.circular(23),
                      onTap: () => onChanged(i),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 260),
                        curve: Curves.easeOutBack,
                        margin: const EdgeInsets.symmetric(horizontal: 2),
                        decoration: BoxDecoration(
                          color: selected ? Colors.white.withValues(alpha: .045) : Colors.transparent,
                          borderRadius: BorderRadius.circular(23),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            TweenAnimationBuilder<double>(
                              tween: Tween(begin: 1, end: selected ? 1.08 : 1),
                              duration: const Duration(milliseconds: 240),
                              curve: Curves.easeOutBack,
                              builder: (_, scale, child) => Transform.scale(scale: scale, child: child),
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 240),
                                width: 38,
                                height: 38,
                                decoration: BoxDecoration(
                                  gradient: selected ? LymixPro.brandGradient : null,
                                  color: selected ? null : Colors.white.withValues(alpha: .035),
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: selected
                                        ? LymixPro.yellow.withValues(alpha: .55)
                                        : Colors.white.withValues(alpha: .055),
                                  ),
                                  boxShadow: selected
                                      ? [
                                          BoxShadow(
                                            color: LymixPro.yellow.withValues(alpha: .18),
                                            blurRadius: 14,
                                            spreadRadius: 1,
                                          ),
                                          BoxShadow(
                                            color: LymixPro.purple.withValues(alpha: .28),
                                            blurRadius: 20,
                                            spreadRadius: 2,
                                          ),
                                        ]
                                      : null,
                                ),
                                child: Icon(
                                  selected ? item.selectedIcon : item.icon,
                                  color: selected ? LymixPro.bg : Colors.white70,
                                  size: selected ? 21 : 20,
                                ),
                              ),
                            ),
                            const SizedBox(height: 3),
                            AnimatedDefaultTextStyle(
                              duration: const Duration(milliseconds: 220),
                              style: TextStyle(
                                fontSize: selected ? 10.5 : 9.5,
                                fontWeight: selected ? FontWeight.w900 : FontWeight.w600,
                                letterSpacing: selected ? .05 : 0,
                                color: selected ? LymixPro.yellow : Colors.white54,
                              ),
                              child: Text(item.label, maxLines: 1, overflow: TextOverflow.fade, softWrap: false),
                            ),
                            AnimatedContainer(
                              duration: const Duration(milliseconds: 220),
                              curve: Curves.easeOut,
                              margin: const EdgeInsets.only(top: 2),
                              width: selected ? 17 : 0,
                              height: 2.2,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(99),
                                gradient: selected ? LymixPro.brandGradient : null,
                                boxShadow: selected
                                    ? [BoxShadow(color: LymixPro.yellow.withValues(alpha: .45), blurRadius: 7)]
                                    : null,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              }),
            ),
          ),
        ),
      ),
    );
  }
}

class Head extends StatelessWidget {
  final String title;
  const Head(this.title, {super.key});

  String _localized(BuildContext context) {
    const keys = <String, String>{
      'Keşfet': 'discover',
      'Plaza': 'plaza',
      'Oyun Merkezi': 'gameCenter',
      'Mesajlar': 'messages',
      'Profil': 'profile',
    };
    final key = keys[title];
    return key == null ? title : context.lx(key);
  }

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(20, 18, 20, 12),
    child: Row(children: [
      ShaderMask(
        shaderCallback: (r) => LymixPro.brandGradient.createShader(r),
        child: const Text('LYMIX', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900, color: Colors.white, letterSpacing: 1.8)),
      ),
      const Spacer(),
      Text(_localized(context), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
      const SizedBox(width: 12),
      _GlassIconButton(icon: Icons.search_rounded, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const GlobalSearchScreen()))),
    ]),
  );
}

class _GlassIconButton extends StatefulWidget {
  final IconData icon;
  final VoidCallback onTap;
  final Color? color;
  const _GlassIconButton({required this.icon, required this.onTap, this.color});
  @override
  State<_GlassIconButton> createState() => _GlassIconButtonState();
}

class _GlassIconButtonState extends State<_GlassIconButton> {
  bool down = false;
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTapDown: (_) => setState(() => down = true),
    onTapCancel: () => setState(() => down = false),
    onTapUp: (_) => setState(() => down = false),
    onTap: widget.onTap,
    child: AnimatedScale(
      scale: down ? 0.90 : 1,
      duration: const Duration(milliseconds: 110),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
          child: Container(
            width: 48, height: 48,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.06),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: Colors.white.withValues(alpha: 0.08)),
            ),
            child: Icon(widget.icon, color: widget.color ?? Colors.white),
          ),
        ),
      ),
    ),
  );
}


class DiscoverPage extends StatefulWidget {
  const DiscoverPage({super.key});

  @override
  State<DiscoverPage> createState() => _DiscoverPageState();
}

class _DiscoverPageState extends State<DiscoverPage> {
  bool popupShown = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!popupShown) {
      popupShown = true;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        // Lightweight once-per-widget product popup; Official welcome remains separately persisted.
        showModalBottomSheet<void>(
          context: context,
          backgroundColor: LymixPalette.bgRaised,
          showDragHandle: false,
          builder: (sheetContext) => LymixFeaturePopup(
            icon: Icons.graphic_eq_rounded,
            eyebrow: 'Kalıcı Odan',
            title: 'Odan her zaman seninle',
            body: 'Her Lymix kullanıcısının tek ve kalıcı bir odası vardır. Ajans statüsüne geçtiğinde aynı oda ajans odasına dönüşür; oda kimliğin ve geçmişin korunur.',
            action: 'Odama Git',
            onAction: () {
              Navigator.pop(sheetContext);
              Navigator.push(context, MaterialPageRoute(builder: (_) => const RoomCreateScreen()));
            },
          ),
        );
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final banners = <LymixBannerItem>[
      LymixBannerItem(
        icon: Icons.graphic_eq_rounded,
        eyebrow: 'Kalıcı Oda',
        title: 'Odan hazır.',
        subtitle: 'Yeni oda üretme yok. Kendi sabit odanı düzenle, aç ve topluluğunu büyüt.',
        action: 'Odama Git',
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RoomCreateScreen())),
      ),
      LymixBannerItem(
        icon: Icons.flash_on_rounded,
        eyebrow: 'Room PK',
        title: '5–60 dk PK.',
        subtitle: 'Canlı skor, geri sayım ve PK sırasında kontrollü koltuk davranışı.',
        action: 'PK odada başlatılır',
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RoomCreateScreen())),
      ),
      LymixBannerItem(
        icon: Icons.card_giftcard_rounded,
        eyebrow: 'Hediye',
        title: 'Tek kişi veya tüm oda.',
        subtitle: 'Kendin hariç tek kullanıcıya, dolu koltuklara veya odadaki herkese gönder.',
        action: 'Hediye kataloğu',
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const GiftCatalogScreen())),
      ),
      LymixBannerItem(
        icon: Icons.shield_rounded,
        eyebrow: 'Güvenlik',
        title: 'Özel oda gerçekten özel.',
        subtitle: 'Kilitli odalar mesajlarda ve yanına git akışlarında dışarıya sızdırılmaz.',
        action: 'Ayarları Gör',
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AppSettingsScreen())),
      ),
    ];

    return ListView(
      padding: const EdgeInsets.only(bottom: 118),
      children: [
        const Head('Keşfet'),
        LymixSystemTicker(
          items: const [
            LymixTickerItem(Icons.verified_rounded, 'Lymix Official güvenlik ve ürün bildirimleri burada görünür.'),
            LymixTickerItem(Icons.graphic_eq_rounded, 'Her kullanıcıya tek ve kalıcı oda kimliği atanır.'),
            LymixTickerItem(Icons.card_giftcard_rounded, 'Toplu hediyede ücret gerçek alıcı sayısına göre hesaplanır.'),
          ],
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const OfficialChatScreen())),
        ),
        const SizedBox(height: 10),
        LymixPromoCarousel(items: banners),
        const SizedBox(height: 6),
        const _Tabs(),
        Container(
          margin: const EdgeInsets.fromLTRB(16, 14, 16, 8),
          padding: const EdgeInsets.fromLTRB(22, 28, 22, 24),
          decoration: BoxDecoration(
            color: LymixPro.panel.withValues(alpha: .88),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: Colors.white.withValues(alpha: .08)),
          ),
          child: Column(children: [
            Container(
              width: 72,
              height: 72,
              decoration: const BoxDecoration(shape: BoxShape.circle, gradient: LymixPro.brandGradient),
              child: const Icon(Icons.mic_none_rounded, size: 34, color: LymixPro.bg),
            ),
            const SizedBox(height: 16),
            const Text('Henüz açık oda yok', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 7),
            const Text(
              'Lymix sahte kalabalık göstermiyor. Kendi kalıcı odana girebilir veya gerçek kullanıcıların açık odalarını burada keşfedebilirsin.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white60, height: 1.45),
            ),
            const SizedBox(height: 18),
            _GradientButton(
              label: 'Odama Git',
              icon: Icons.graphic_eq_rounded,
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RoomCreateScreen())),
            ),
          ]),
        ),
      ],
    );
  }
}

class _Tabs extends StatelessWidget { const _Tabs();
  @override Widget build(BuildContext context)=>Padding(
    padding:const EdgeInsets.symmetric(horizontal:16,vertical:6),
    child:Wrap(spacing:8,runSpacing:8,children:const[
      _GlassChip('⭐ Önerilen', selected:true), _GlassChip('🇹🇷 Türkiye'), _GlassChip('🌍 Global'), _GlassChip('🎵 Müzik'),
    ]),
  );
}

class _GlassChip extends StatelessWidget {
  final String label; final bool selected;
  const _GlassChip(this.label,{this.selected=false});
  @override Widget build(BuildContext context)=>Container(
    padding:const EdgeInsets.symmetric(horizontal:14,vertical:10),
    decoration:BoxDecoration(
      gradient:selected?LymixPro.brandGradient:null,
      color:selected?null:Colors.white.withValues(alpha: .045),
      borderRadius:BorderRadius.circular(15),
      border:Border.all(color:selected?Colors.transparent:Colors.white.withValues(alpha: .10)),
    ),
    child:Text(label,style:TextStyle(fontWeight:FontWeight.w800,color:selected?LymixPro.bg:Colors.white)),
  );
}

class SocialPage extends StatelessWidget {
  const SocialPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.only(bottom: 118),
    children: [
      const Head('Plaza'),
      Container(
        margin: const EdgeInsets.fromLTRB(16, 18, 16, 8),
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(color: LymixPro.panel.withValues(alpha: .88), borderRadius: BorderRadius.circular(28), border: Border.all(color: Colors.white10)),
        child: Column(children: [
          const Icon(Icons.explore_outlined, size: 52, color: LymixPro.yellow),
          const SizedBox(height: 14),
          const Text('Plaza gerçek etkileşimlerle dolacak', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900), textAlign: TextAlign.center),
          const SizedBox(height: 7),
          const Text('Takip ettiğin kullanıcıların açık odaları, gerçek topluluk paylaşımları ve etkinlikler burada görünecek.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white60, height: 1.45)),
          const SizedBox(height: 18),
          _GradientButton(label: 'Odama Git', icon: Icons.add_rounded, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RoomCreateScreen()))),
        ]),
      ),
    ],
  );
}

class _GradientButton extends StatefulWidget { final String label; final IconData icon; final VoidCallback onTap; const _GradientButton({required this.label,required this.icon,required this.onTap}); @override State<_GradientButton> createState()=>_GradientButtonState(); }
class _GradientButtonState extends State<_GradientButton>{bool down=false;@override Widget build(BuildContext context)=>GestureDetector(onTapDown:(_)=>setState(()=>down=true),onTapCancel:()=>setState(()=>down=false),onTapUp:(_)=>setState(()=>down=false),onTap:widget.onTap,child:AnimatedScale(scale: down ? .97 : 1,duration:const Duration(milliseconds:100),child:Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(gradient:LymixPro.premiumGradient,borderRadius:BorderRadius.circular(19),boxShadow:[BoxShadow(color:LymixPro.purple.withValues(alpha: .22),blurRadius:22)]),child:Row(children:[Icon(widget.icon),const SizedBox(width:10),Text(widget.label,style:const TextStyle(fontWeight:FontWeight.w900)),const Spacer(),const Icon(Icons.arrow_forward_rounded,size:20)]))));}

class _MiniAction extends StatelessWidget{final IconData icon;final VoidCallback onTap;final Color? color;const _MiniAction({required this.icon,required this.onTap,this.color});@override Widget build(BuildContext context)=>IconButton(onPressed:onTap,icon:Icon(icon,color:color),style:IconButton.styleFrom(backgroundColor:Colors.white.withValues(alpha: .035)));}

class GameCenterPage extends StatelessWidget {
  const GameCenterPage({super.key});
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.only(bottom:118),children:[
    const Head('Oyun Merkezi'),
    GestureDetector(onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const GameCenterScreen())),child:Container(margin:const EdgeInsets.all(16),padding:const EdgeInsets.all(20),decoration:BoxDecoration(gradient:LymixPro.premiumGradient,borderRadius:BorderRadius.circular(28),boxShadow:[BoxShadow(color:LymixPro.purple.withValues(alpha: .18),blurRadius:28)]),child:const Row(children:[Icon(Icons.bolt,size:36),SizedBox(width:12),Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Seviye 0',style:TextStyle(fontSize:22,fontWeight:FontWeight.w900)),Text('0 XP • Yolculuk yeni başlıyor',style:TextStyle(fontSize:11,color:Colors.white70))]),Spacer(),Icon(Icons.emoji_events,size:40)]))),
    Padding(padding:const EdgeInsets.all(16),child:GridView.count(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:3,mainAxisSpacing:14,crossAxisSpacing:14,children:[Icons.rocket_launch,Icons.pets,Icons.phishing,Icons.sports_soccer,Icons.casino,Icons.sports_esports].asMap().entries.map((e)=>_GameTile(icon:e.value,index:e.key)).toList()))
  ]);
}
class _GameTile extends StatefulWidget {final IconData icon;final int index;const _GameTile({required this.icon,required this.index});@override State<_GameTile> createState()=>_GameTileState();}
class _GameTileState extends State<_GameTile> with SingleTickerProviderStateMixin{late final AnimationController c;@override void initState(){super.initState();c=AnimationController(vsync:this,duration:Duration(milliseconds:1200+widget.index*120))..repeat(reverse:true);}@override void dispose(){c.dispose();super.dispose();}@override Widget build(BuildContext context)=>AnimatedBuilder(animation:c,builder:(_,__)=>GestureDetector(onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const GameCenterScreen())),child:Container(decoration:BoxDecoration(color:LymixPro.panel.withValues(alpha: .9),borderRadius:BorderRadius.circular(22),border:Border.all(color:Colors.white.withValues(alpha: .07)),boxShadow:[BoxShadow(color:LymixPro.purple.withValues(alpha: .04+c.value*.09),blurRadius:14+c.value*8)]),child:Transform.scale(scale:.95+c.value*.04,child:Icon(widget.icon,size:44,color:Color.lerp(LymixPro.yellow,Colors.white,c.value*.22))))));}

class InboxPage extends StatelessWidget {
  const InboxPage({super.key});

  @override
  Widget build(BuildContext context) {
    const official = (name: 'Lymix Official', roomId: '', roomTitle: '', inRoom: false, privateRoom: false, official: true);
    return ListView(
      padding: const EdgeInsets.only(bottom: 118),
      children: [
        const Head('Mesajlar'),
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
            _Quick(Icons.person_add_alt_1_rounded, 'İstekler', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MessageRequestsScreen()))),
            _Quick(Icons.notifications_rounded, 'Bildirim', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NotificationCenterScreen()))),
            _Quick(Icons.support_agent_rounded, 'Official', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const OfficialChatScreen()))),
          ]),
        ),
        const _MessageUserTile(user: official),
        Container(
          margin: const EdgeInsets.fromLTRB(16, 18, 16, 8),
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(color: Colors.white.withValues(alpha: .028), borderRadius: BorderRadius.circular(24), border: Border.all(color: Colors.white.withValues(alpha: .06))),
          child: const Column(children: [
            Icon(Icons.chat_bubble_outline_rounded, size: 42, color: Colors.white38),
            SizedBox(height: 12),
            Text('Henüz özel sohbetin yok', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
            SizedBox(height: 5),
            Text('Gerçek kullanıcılarla etkileşime geçtiğinde sohbetlerin burada görünecek. Sahte konuşmalar gösterilmiyor.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white54, height: 1.4)),
          ]),
        ),
      ],
    );
  }
}

class _MessageUserTile extends StatelessWidget {
  final ({String name, String roomId, String roomTitle, bool inRoom, bool privateRoom, bool official}) user;
  const _MessageUserTile({required this.user});

  @override
  Widget build(BuildContext context) {
    final canJoin = user.inRoom && !user.privateRoom && user.roomId.isNotEmpty;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(color: Colors.white.withValues(alpha: .026), borderRadius: BorderRadius.circular(20)),
      child: ListTile(
        onTap: () {
          if (user.official) {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const OfficialChatScreen()));
          } else {
            Navigator.push(context, MaterialPageRoute(builder: (_) => DirectMessageScreen(userId: user.name, displayName: user.name, openRoomId: canJoin ? user.roomId : null, openRoomTitle: canJoin ? user.roomTitle : null, privateRoom: user.privateRoom)));
          }
        },
        leading: _PresenceAvatar(name: user.name, showRing: canJoin, official: user.official, onJoin: canJoin ? () => Navigator.push(context, MaterialPageRoute(builder: (_) => LymixRoomScreen(roomId: user.roomId, roomTitle: user.roomTitle))) : null),
        title: Row(children: [
          Flexible(child: Text(user.name, style: const TextStyle(fontWeight: FontWeight.w800))),
          if (user.official) ...[const SizedBox(width: 4), const Icon(Icons.verified_rounded, size: 16, color: LymixPro.yellow)],
        ]),
        subtitle: Text(user.official
            ? 'Hoş geldin, kurallar ve Lymix rehberi'
            : canJoin
                ? '${user.roomTitle} odasında • profiline dokunup yanına git'
                : user.privateRoom
                    ? 'Mesaj gönderildi • oda bilgisi gizli'
                    : 'Özel mesaj'),
        trailing: canJoin ? const Icon(Icons.graphic_eq_rounded, color: LymixPro.yellow) : const Icon(Icons.chevron_right_rounded),
      ),
    );
  }
}

class _PresenceAvatar extends StatefulWidget {
  final String name;
  final bool showRing;
  final bool official;
  final VoidCallback? onJoin;
  const _PresenceAvatar({required this.name, required this.showRing, required this.official, this.onJoin});
  @override State<_PresenceAvatar> createState() => _PresenceAvatarState();
}

class _PresenceAvatarState extends State<_PresenceAvatar> with SingleTickerProviderStateMixin {
  late final AnimationController controller;
  @override void initState() { super.initState(); controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))..repeat(); }
  @override void dispose() { controller.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => GestureDetector(
    onTap: widget.onJoin,
    child: AnimatedBuilder(animation: controller, builder: (_, child) {
      final glow = widget.showRing ? .28 + controller.value * .45 : 0.0;
      return Container(
        width: 52, height: 52, padding: EdgeInsets.all(widget.showRing ? 2.5 : 0),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: widget.showRing ? SweepGradient(transform: GradientRotation(controller.value * 6.28), colors: const [LymixPro.yellow, LymixPro.purple, Color(0xFFFF4FA3), LymixPro.yellow]) : null,
          boxShadow: widget.showRing ? [BoxShadow(color: LymixPro.purple.withValues(alpha: glow), blurRadius: 16)] : null,
        ),
        child: CircleAvatar(
          backgroundColor: widget.official ? LymixPro.yellow : LymixPro.deepPurple,
          child: Icon(widget.official ? Icons.graphic_eq_rounded : Icons.person_rounded, color: widget.official ? LymixPro.bg : Colors.white),
        ),
      );
    }),
  );
}

class _Quick extends StatelessWidget {
  final IconData i; final String t; final VoidCallback onTap;
  const _Quick(this.i, this.t, this.onTap);
  @override Widget build(BuildContext context) => InkWell(
    borderRadius: BorderRadius.circular(22), onTap: onTap,
    child: Padding(padding: const EdgeInsets.all(6), child: Column(children: [
      CircleAvatar(radius: 29, backgroundColor: LymixPro.panel2, child: Icon(i, color: LymixPro.yellow)),
      const SizedBox(height: 7), Text(t, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
    ])),
  );
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.only(bottom: 118), children: [
    const Head('Profil'), const SizedBox(height: 10),
    Center(child: GestureDetector(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SuperAdminProfileScreen())),
      child: Stack(alignment: Alignment.center, children: [
        Container(width: 128, height: 128, decoration: BoxDecoration(shape: BoxShape.circle, gradient: LymixPro.brandGradient, boxShadow: [BoxShadow(color: LymixPro.purple.withValues(alpha: .32), blurRadius: 30)])),
        const CircleAvatar(radius: 55, backgroundColor: Color(0xFF160F20), backgroundImage: AssetImage('assets/branding/lymix_mark_1024.png')),
      ]),
    )),
    const SizedBox(height: 13),
    const Center(child: Row(mainAxisSize: MainAxisSize.min, children: [Text('LYMIX OWNER', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900)), SizedBox(width: 6), Icon(Icons.verified_rounded, color: LymixPro.yellow, size: 19)])),
    const Center(child: Text('SUPER ADMIN • Owner Lv.999', style: TextStyle(color: LymixPro.muted))),
    const SizedBox(height: 8),
    const Center(child: Text('Gerçek kullanıcılar: 0 takipçi • 0 takip • 0 hediye geçmişi ile başlar', style: TextStyle(color: Colors.white38, fontSize: 9.5))),
    const SizedBox(height: 18),
    const Padding(padding: EdgeInsets.symmetric(horizontal: 24), child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [_Stat('0', 'Arkadaşlar'), _Stat('0', 'Takip'), _Stat('0', 'Fan')])),
    GestureDetector(onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const VipCenterScreen())), child: Container(
      margin: const EdgeInsets.all(18), padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(gradient: LymixPro.premiumGradient, borderRadius: BorderRadius.circular(24), boxShadow: [BoxShadow(color: LymixPro.purple.withValues(alpha: .20), blurRadius: 24)]),
      child: const Row(children: [Icon(Icons.workspace_premium_rounded, size: 36), SizedBox(width: 14), Expanded(child: Text('VIP & Seviye Merkezi', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))), Icon(Icons.chevron_right_rounded)]),
    )),
    Padding(padding: const EdgeInsets.all(18), child: GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 4, mainAxisSpacing: 16, crossAxisSpacing: 12, children: [
      _ProfileAction(Icons.workspace_premium_rounded, context.lx('vipLevel'), () => Navigator.push(context, MaterialPageRoute(builder: (_) => const VipCenterScreen()))),
      _ProfileAction(Icons.card_giftcard_rounded, context.lx('myGifts'), () => Navigator.push(context, MaterialPageRoute(builder: (_) => const GiftCatalogScreen()))),
      _ProfileAction(Icons.favorite_rounded, context.lx('favorites'), () => Navigator.push(context, MaterialPageRoute(builder: (_) => const FavoritesScreen()))),
      _ProfileAction(Icons.account_balance_wallet_rounded, context.lx('wallet'), () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CoinStoreScreen()))),
      _ProfileAction(Icons.inventory_2_rounded, context.lx('bag'), () => Navigator.push(context, MaterialPageRoute(builder: (_) => const InventoryScreen()))),
      _ProfileAction(Icons.badge_rounded, context.lx('identityBadge'), () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SuperAdminProfileScreen()))),
      _ProfileAction(Icons.sports_esports_rounded, context.lx('gameCenter'), () => Navigator.push(context, MaterialPageRoute(builder: (_) => const GameCenterScreen()))),
      _ProfileAction(Icons.notifications_rounded, context.lx('notifications'), () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NotificationCenterScreen()))),
      _ProfileAction(Icons.admin_panel_settings_rounded, context.lx('adminEconomy'), () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminHybridCenterScreen()))),
      _ProfileAction(Icons.monitor_heart_rounded, context.lx('ownerOps'), () => Navigator.push(context, MaterialPageRoute(builder: (_) => const OwnerOpsCenterScreen()))),
      _ProfileAction(Icons.support_agent_rounded, 'Lymix Official', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const OfficialChatScreen()))),
      _ProfileAction(Icons.settings_rounded, context.lx('settings'), () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AppSettingsScreen()))),
    ])),
  ]);
}

class _ProfileAction extends StatelessWidget {
  final IconData icon; final String label; final VoidCallback onTap;
  const _ProfileAction(this.icon, this.label, this.onTap);
  @override Widget build(BuildContext context) => InkWell(
    onTap: onTap, borderRadius: BorderRadius.circular(19),
    child: Container(
      decoration: BoxDecoration(color: Colors.white.withValues(alpha: .035), borderRadius: BorderRadius.circular(19), border: Border.all(color: Colors.white.withValues(alpha: .06))),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, color: LymixPro.yellow, size: 29), const SizedBox(height: 6), Padding(padding: const EdgeInsets.symmetric(horizontal: 2), child: Text(label, textAlign: TextAlign.center, maxLines: 2, style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w700)))]),
    ),
  );
}

class _Stat extends StatelessWidget {
  final String n, t; const _Stat(this.n, this.t);
  @override Widget build(BuildContext c) => Column(children: [Text(n, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)), Text(t, style: const TextStyle(color: LymixPro.muted))]);
}
