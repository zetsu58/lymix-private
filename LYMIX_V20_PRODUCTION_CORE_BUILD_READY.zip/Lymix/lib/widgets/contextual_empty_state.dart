import 'package:flutter/material.dart';
import '../theme/lymix_theme.dart';

class ContextualEmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String message;
  final String? primaryLabel;
  final String? secondaryLabel;
  final VoidCallback? onPrimary;
  final VoidCallback? onSecondary;

  const ContextualEmptyState({
    super.key,
    required this.icon,
    required this.title,
    required this.message,
    this.primaryLabel,
    this.secondaryLabel,
    this.onPrimary,
    this.onSecondary,
  });

  @override Widget build(BuildContext context)=>Container(
    width:double.infinity,
    padding:const EdgeInsets.fromLTRB(22,24,22,20),
    decoration:BoxDecoration(
      gradient:const LinearGradient(colors:[Color(0xFF15111D),Color(0xFF0E0B13)]),
      borderRadius:BorderRadius.circular(24),
      border:Border.all(color:Colors.white.withValues(alpha: .05)),
    ),
    child:Column(children:[
      Container(
        width:58,height:58,
        decoration:BoxDecoration(
          shape:BoxShape.circle,
          color:const Color(0x12FFD643),
          border:Border.all(color:const Color(0x22FFD643)),
        ),
        child:Icon(icon,color:LymixColors.gold,size:26),
      ),
      const SizedBox(height:14),
      Text(title,textAlign:TextAlign.center,style:const TextStyle(fontSize:14,fontWeight:FontWeight.w900)),
      const SizedBox(height:6),
      Text(message,textAlign:TextAlign.center,style:const TextStyle(color:Color(0x70FFFFFF),fontSize:10.5,height:1.45)),
      if(primaryLabel!=null&&onPrimary!=null)...[
        const SizedBox(height:14),
        SizedBox(width:double.infinity,child:FilledButton(onPressed:onPrimary,child:Text(primaryLabel!))),
      ],
      if(secondaryLabel!=null&&onSecondary!=null)...[
        const SizedBox(height:4),
        TextButton(onPressed:onSecondary,child:Text(secondaryLabel!)),
      ],
    ]),
  );
}
