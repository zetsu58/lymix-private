import 'package:flutter/material.dart';
import '../services/moderation_service.dart';
import '../theme/lymix_theme.dart';

class ReportCenterScreen extends StatefulWidget {
  final String? targetUserId;
  final String? targetUserName;
  final String? roomId;
  final String? roomTitle;
  final String? evidenceText;

  const ReportCenterScreen({
    super.key,
    this.targetUserId,
    this.targetUserName,
    this.roomId,
    this.roomTitle,
    this.evidenceText,
  });

  @override State<ReportCenterScreen> createState()=>_ReportCenterScreenState();
}

class _ReportCenterScreenState extends State<ReportCenterScreen>{
  final details=TextEditingController();
  String category='harassment';
  bool saving=false;

  final categories=const <String,String>{
    'harassment':'Hakaret / taciz',
    'profanity':'Küfürlü içerik',
    'voice_profanity':'Mikrofonda küfür',
    'spam':'Spam / reklam',
    'fraud':'Dolandırıcılık',
    'sexual':'Uygunsuz cinsel içerik',
    'threat':'Tehdit / şiddet',
    'impersonation':'Taklit / sahte hesap',
    'other':'Diğer',
  };

  @override void dispose(){details.dispose();super.dispose();}

  Future<void> _submit() async {
    if(saving)return;
    if(details.text.trim().length<8){
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Lütfen olayı en az birkaç kelimeyle açıkla.')));
      return;
    }
    setState(()=>saving=true);
    try{
      await ModerationService().report(
        targetUserId:widget.targetUserId,
        roomId:widget.roomId,
        category:category,
        description:details.text.trim(),
        evidence:[
          if(widget.evidenceText!=null&&widget.evidenceText!.trim().isNotEmpty)
            {'type':'user_selected_text','value':widget.evidenceText!.trim().length > 500 ? widget.evidenceText!.trim().substring(0,500) : widget.evidenceText!.trim()},
        ],
      );
      if(!mounted)return;
      await showDialog(
        context:context,
        builder:(ctx)=>AlertDialog(
          title:const Text('Şikayet alındı'),
          content:const Text('Kaydın inceleme kuyruğuna eklendi. Aynı olay için tekrar tekrar şikayet göndermene gerek yok.'),
          actions:[FilledButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Tamam'))],
        ),
      );
      if(mounted)Navigator.pop(context,true);
    }catch(e){
      if(!mounted)return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Şikayet gönderilemedi: $e')));
    }finally{
      if(mounted)setState(()=>saving=false);
    }
  }

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Şikayet Et')),
    body:ListView(
      padding:const EdgeInsets.fromLTRB(16,8,16,30),
      children:[
        Container(
          padding:const EdgeInsets.all(15),
          decoration:BoxDecoration(
            gradient:const LinearGradient(colors:[Color(0xFF1F1428),Color(0xFF100C16)]),
            borderRadius:BorderRadius.circular(20),
            border:Border.all(color:const Color(0x33FFD643)),
          ),
          child:Row(children:[
            Container(width:44,height:44,decoration:BoxDecoration(color:const Color(0x18FFD643),borderRadius:BorderRadius.circular(14)),child:const Icon(Icons.flag_outlined,color:LymixColors.gold)),
            const SizedBox(width:11),
            Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
              Text(widget.targetUserName??widget.roomTitle??'İçerik şikayeti',style:const TextStyle(fontWeight:FontWeight.w900)),
              const SizedBox(height:3),
              Text(widget.targetUserId!=null?'Kullanıcı raporu':'Oda / içerik raporu',style:const TextStyle(color:Colors.white42,fontSize:9.5)),
            ])),
          ]),
        ),
        const SizedBox(height:16),
        const Text('Neden bildiriyorsun?',style:TextStyle(fontSize:14,fontWeight:FontWeight.w900)),
        const SizedBox(height:8),
        ...categories.entries.map((e)=>RadioListTile<String>(
          value:e.key,groupValue:category,onChanged:(v)=>setState(()=>category=v??category),
          activeThumbColor:LymixColors.gold,
          title:Text(e.value,style:const TextStyle(fontSize:11.5,fontWeight:FontWeight.w700)),
          contentPadding:EdgeInsets.zero,
          dense:true,
        )),
        const SizedBox(height:10),
        const Text('Ne oldu?',style:TextStyle(fontSize:14,fontWeight:FontWeight.w900)),
        const SizedBox(height:8),
        TextField(
          controller:details,
          minLines:4,maxLines:7,maxLength:1000,
          decoration:const InputDecoration(hintText:'Olayı, zamanı ve varsa tekrar eden davranışı kısaca anlat...'),
        ),
        if(widget.evidenceText!=null&&widget.evidenceText!.isNotEmpty)...[
          const SizedBox(height:10),
          Container(
            padding:const EdgeInsets.all(12),
            decoration:BoxDecoration(color:Colors.white.withValues(alpha: .035),borderRadius:BorderRadius.circular(15),border:Border.all(color:Colors.white.withValues(alpha: .05))),
            child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
              const Row(children:[Icon(Icons.attach_file_rounded,size:15,color:LymixColors.gold),SizedBox(width:5),Text('Eklenen kanıt',style:TextStyle(fontSize:9.5,fontWeight:FontWeight.w800))]),
              const SizedBox(height:5),
              Text(widget.evidenceText!,maxLines:4,overflow:TextOverflow.ellipsis,style:const TextStyle(color:Color(0x75FFFFFF),fontSize:9.5,height:1.35)),
            ]),
          ),
        ],
        const SizedBox(height:12),
        const Text('Şikayetler otomatik ceza vermek için tek başına kullanılmaz; sistem sinyalleri ve moderasyon kayıtlarıyla birlikte incelenir.',style:TextStyle(color:Colors.white38,fontSize:9.2,height:1.4)),
        const SizedBox(height:18),
        DecoratedBox(
          decoration:BoxDecoration(gradient:LymixColors.brandGradient,borderRadius:BorderRadius.circular(17)),
          child:ElevatedButton.icon(
            onPressed:saving?null:_submit,
            icon:Icon(saving?Icons.sync_rounded:Icons.flag_rounded),
            label:Text(saving?'Gönderiliyor...':'Şikayeti Gönder'),
            style:ElevatedButton.styleFrom(backgroundColor:Colors.transparent,shadowColor:Colors.transparent,foregroundColor:const Color(0xFF150E18),padding:const EdgeInsets.symmetric(vertical:13)),
          ),
        ),
      ],
    ),
  );
}
