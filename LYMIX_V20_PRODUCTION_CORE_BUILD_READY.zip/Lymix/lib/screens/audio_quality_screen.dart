import 'package:flutter/material.dart';
import '../services/audio_experience_service.dart';
import '../theme/lymix_theme.dart';

class AudioQualityScreen extends StatefulWidget {
  const AudioQualityScreen({super.key});
  @override State<AudioQualityScreen> createState()=>_AudioQualityScreenState();
}

class _AudioQualityScreenState extends State<AudioQualityScreen>{
  bool loading=true;
  bool noise=true, echo=true, gain=true, lowData=false;
  String route='auto';

  @override void initState(){super.initState();_load();}
  Future<void> _load() async{
    final s=await AudioExperienceService.load();
    if(!mounted)return;
    setState((){noise=s.noiseSuppression;echo=s.echoCancellation;gain=s.autoGain;lowData=s.lowDataMode;route=s.preferredRoute;loading=false;});
  }
  Future<void> _save() async{
    await AudioExperienceService.save(AudioExperienceSettings(
      noiseSuppression:noise, echoCancellation:echo, autoGain:gain, lowDataMode:lowData, preferredRoute:route,
    ));
    if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Ses tercihleri kaydedildi.')));
  }

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Ses Kalitesi')),
    body:loading
      ? const Center(child:CircularProgressIndicator(color:LymixColors.gold))
      : ListView(padding:const EdgeInsets.fromLTRB(16,10,16,28),children:[
          _card(),
          const SizedBox(height:12),
          _group('Konuşma iyileştirme',[
            _sw('Gürültü engelleme','Fan, klavye ve arka plan gürültüsünü azaltır.',noise,(v)=>setState(()=>noise=v)),
            _sw('Yankı engelleme','Hoparlörden mikrofona dönen sesi azaltır.',echo,(v)=>setState(()=>echo=v)),
            _sw('Otomatik ses seviyesi','Düşük/yüksek mikrofon seviyesini dengeler.',gain,(v)=>setState(()=>gain=v)),
          ]),
          const SizedBox(height:12),
          _group('Bağlantı ve çıkış',[
            _sw('Düşük veri modu','Zayıf bağlantıda daha düşük bant genişliği hedefler.',lowData,(v)=>setState(()=>lowData=v)),
            Padding(
              padding:const EdgeInsets.fromLTRB(4,4,4,8),
              child:DropdownButtonFormField<String>(
                value:route,
                decoration:const InputDecoration(labelText:'Tercih edilen ses çıkışı'),
                items:const[
                  DropdownMenuItem(value:'auto',child:Text('Otomatik')),
                  DropdownMenuItem(value:'speaker',child:Text('Hoparlör')),
                  DropdownMenuItem(value:'earpiece',child:Text('Ahize')),
                  DropdownMenuItem(value:'bluetooth',child:Text('Bluetooth / kulaklık')),
                ],
                onChanged:(v)=>setState(()=>route=v??'auto'),
              ),
            ),
          ]),
          const SizedBox(height:16),
          SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:_save,icon:const Icon(Icons.check_rounded),label:const Text('Kaydet'))),
          const SizedBox(height:10),
          const Text('RTC katmanı bu ayarları desteklenen Agora/WebRTC ses API’lerine uygular; cihaz desteklemiyorsa güvenli varsayılan kullanılır.',style:TextStyle(color:Colors.white34,fontSize:9.2,height:1.4)),
        ]),
  );

  Widget _card()=>Container(
    padding:const EdgeInsets.all(15),
    decoration:BoxDecoration(
      gradient:const LinearGradient(colors:[Color(0xFF20142B),Color(0xFF100C16)]),
      borderRadius:BorderRadius.circular(22),
      border:Border.all(color:const Color(0x33FFD643)),
    ),
    child:const Row(children:[
      Icon(Icons.graphic_eq_rounded,color:LymixColors.gold,size:27),
      SizedBox(width:11),
      Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('Temiz ve rahat konuşma',style:TextStyle(fontSize:14,fontWeight:FontWeight.w900)),
        SizedBox(height:4),
        Text('Ses ayarları mümkün olduğunca otomatik çalışır; istersen burada daha sakin veya daha düşük veri tüketen bir profil seçebilirsin.',style:TextStyle(color:Color(0x75FFFFFF),fontSize:9.5,height:1.4)),
      ])),
    ]),
  );

  Widget _group(String title,List<Widget> children)=>Container(
    padding:const EdgeInsets.fromLTRB(12,12,12,4),
    decoration:BoxDecoration(color:LymixColors.surface,borderRadius:BorderRadius.circular(20),border:Border.all(color:Colors.white.withValues(alpha: .05))),
    child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Padding(padding:const EdgeInsets.fromLTRB(5,2,5,4),child:Text(title,style:const TextStyle(color:Colors.white54,fontSize:9.5,fontWeight:FontWeight.w800))),
      ...children,
    ]),
  );

  Widget _sw(String title,String sub,bool value,ValueChanged<bool> onChanged)=>SwitchListTile.adaptive(
    value:value,onChanged:onChanged,activeThumbColor:LymixColors.gold,
    title:Text(title,style:const TextStyle(fontSize:11.5,fontWeight:FontWeight.w800)),
    subtitle:Text(sub,style:const TextStyle(color:Colors.white38,fontSize:9.2)),
  );
}
