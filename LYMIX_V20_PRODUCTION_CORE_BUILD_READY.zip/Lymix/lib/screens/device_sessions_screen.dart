import 'package:flutter/material.dart';
import '../core/api_client.dart';
import '../services/session_service.dart';
import '../theme/lymix_theme.dart';
import '../widgets/lymix_states.dart';

class DeviceSessionsScreen extends StatefulWidget {
  const DeviceSessionsScreen({super.key});
  @override State<DeviceSessionsScreen> createState()=>_DeviceSessionsScreenState();
}

class _DeviceSessionsScreenState extends State<DeviceSessionsScreen>{
  bool loading=true;
  String? error;
  List<Map<String,dynamic>> rows=[];

  @override void initState(){super.initState();_load();}
  Future<void> _load() async{
    setState((){loading=true;error=null;});
    try{
      final data=await ApiClient(tokenProvider:SessionService.token).getJson('/api/devices');
      final map=Map<String,dynamic>.from(data as Map);
      final list=(map['rows'] as List? ?? const[]).map((e)=>Map<String,dynamic>.from(e as Map)).toList();
      if(mounted)setState((){rows=list;loading=false;});
    }catch(e){if(mounted)setState((){error=e.toString();loading=false;});}
  }

  Future<void> _revoke(String id) async{
    try{
      await ApiClient(tokenProvider:SessionService.token).postJson('/api/devices/revoke-others',{'currentId':id});
      await _load();
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}
  }

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Cihazlar ve Oturumlar')),
    body:RefreshIndicator(
      color:LymixColors.gold,onRefresh:_load,
      child:ListView(
        physics:const AlwaysScrollableScrollPhysics(),
        padding:const EdgeInsets.fromLTRB(16,10,16,28),
        children:[
          if(loading) const LymixLoadingCard(label:'Cihazların yükleniyor...')
          else if(error!=null) LymixStateCard(icon:Icons.devices_other_rounded,title:'Cihazlar yüklenemedi',message:error!,actionLabel:'Tekrar dene',onAction:_load)
          else if(rows.isEmpty) const LymixStateCard(icon:Icons.devices_rounded,title:'Aktif cihaz bulunamadı',message:'Giriş yaptığın cihazlar burada listelenecek.')
          else ...rows.map((r)=>Container(
            margin:const EdgeInsets.only(bottom:9),
            padding:const EdgeInsets.all(13),
            decoration:BoxDecoration(color:LymixColors.surface,borderRadius:BorderRadius.circular(18),border:Border.all(color:Colors.white.withValues(alpha: .05))),
            child:Row(children:[
              Container(width:42,height:42,decoration:BoxDecoration(color:const Color(0x14FFD643),borderRadius:BorderRadius.circular(13)),child:Icon((r['platform']??'').toString().toLowerCase().contains('ios')?Icons.phone_iphone_rounded:Icons.android_rounded,color:LymixColors.gold)),
              const SizedBox(width:10),
              Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                Text((r['deviceName']??'Cihaz').toString(),style:const TextStyle(fontWeight:FontWeight.w800,fontSize:11.5)),
                Text('${r['platform']??''} • ${r['appVersion']??''}',style:const TextStyle(color:Colors.white38,fontSize:9)),
              ])),
              IconButton(tooltip:'Diğer oturumları kapat',onPressed:()=>_revoke((r['id']??'').toString()),icon:const Icon(Icons.logout_rounded,color:Colors.white54)),
            ]),
          )),
        ],
      ),
    ),
  );
}
