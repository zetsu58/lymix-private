import '../core/api_client.dart';
import '../models/wallet_models.dart';

class WalletService {
  final ApiClient api;
  const WalletService(this.api);

  Future<WalletBalance> balance() async {
    final data = await api.getJson('/api/wallet/me');
    final map = Map<String,dynamic>.from(data as Map);
    return WalletBalance(
      coins: (map['coins'] as num?)?.toInt() ?? 0,
      diamonds: (map['diamonds'] as num?)?.toInt() ?? 0,
    );
  }

  Future<List<CoinPackage>> packages() async {
    final data = await api.getJson('/api/wallet/packages');
    final list = (data as List?) ?? const [];
    return list.map((e){
      final m = Map<String,dynamic>.from(e as Map);
      return CoinPackage(
        id: '${m['id']}',
        coins: (m['coins'] as num?)?.toInt() ?? 0,
        vipExp: (m['vipExp'] as num?)?.toInt() ?? 0,
        displayPrice: '${m['displayPrice'] ?? ''}',
        currency: '${m['currency'] ?? ''}',
        channel: '${m['channel'] ?? 'store'}',
        enabled: m['enabled'] != false,
      );
    }).toList();
  }

  Future<void> startPurchase(String packageId) async {
    await api.postJson('/api/wallet/purchase-intent', {'packageId': packageId});
  }

  Future<void> adminGrant({
    required String targetUserId,
    required int coins,
    required String reason,
  }) async {
    await api.postJson('/api/admin/wallet/grant', {
      'targetUserId': targetUserId,
      'coins': coins,
      'reason': reason,
    });
  }
}
