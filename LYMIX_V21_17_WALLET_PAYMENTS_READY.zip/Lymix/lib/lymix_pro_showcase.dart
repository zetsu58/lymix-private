import 'dart:ui';
import 'package:flutter/material.dart';
import 'lymix_pro_theme.dart';
import 'screens/global_search_screen.dart';
import 'screens/room_screen.dart';
import 'screens/room_create_screen.dart';
import 'screens/game_center_screen.dart';
import 'screens/vip_center_screen.dart';
import 'screens/app_settings_screen.dart';
import 'screens/coin_store_screen.dart';
import 'screens/notification_center_screen.dart';
import 'screens/message_requests_screen.dart';
import 'screens/gift_catalog_screen.dart';
import 'screens/admin_economy_center_screen.dart';
import 'screens/owner_ops_center_screen.dart';
import 'screens/official_chat_screen.dart';
import 'screens/feature_hub_screen.dart';
import 'screens/super_admin_profile_screen.dart';
import 'services/official_bot_service.dart';
import 'services/localization_service.dart';
import 'screens/user_profile_screen.dart';
import 'screens/direct_message_screen.dart';
import 'screens/favorites_screen.dart';
import 'screens/inventory_screen.dart';
import 'widgets/lymix_live_chrome.dart';
import 'screens/admin_hybrid_center_screen.dart';
import 'design/lymix_design_system.dart';
import 'widgets/lymix_premium_shell.dart';
import 'design/lymix_icon_system.dart';
import 'screens/creator_verification_screen.dart';
import 'screens/agency_family_screen.dart';
import 'screens/feed_screen.dart';
import 'widgets/lymix_visual_production.dart';
import 'screens/wallet_screen.dart';
import 'screens/admin_coin_grant_screen.dart';

class LymixProShowcase extends StatefulWidget {
  const LymixProShowcase({super.key});
  @override
  State<LymixProShowcase> createState() => _LymixProShowcaseState();
}

class _LymixProShowcaseState extends State<LymixProShowcase>
    with SingleTickerProviderStateMixin {
  int index = 0;
  late final AnimationController _ambient;

  final List<Widget> pages = const <Widget>[
    DiscoverPage(),
    SocialPage(),
    GameCenterPage(),
    InboxPage(),
    ProfilePage(),
  ];

  @override
  void initState() {
    super.initState();
    _ambient = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat(reverse: true);
    WidgetsBinding.instance.addPostFrameCallback((_) => _showOfficialWelcomeIfNeeded());
  }

  Future<void> _showOfficialWelcomeIfNeeded() async {
    if (!await OfficialBotService.shouldShowWelcome() || !mounted) return;
    await OfficialBotService.markWelcomeDelivered();
    if (!mounted) return;
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF130F1B),
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Row(children: [
              CircleAvatar(backgroundColor: LymixPro.yellow, child: Icon(Icons.graphic_eq_rounded, color: LymixPro.bg)),
              SizedBox(width: 10),
              Expanded(child: Text('Lymix Official', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900))),
              Icon(Icons.verified_rounded, color: LymixPro.yellow),
            ]),
            const SizedBox(height: 12),
            Text(context.lx('welcomeBody'), style: const TextStyle(color: Colors.white70, height: 1.4)),
            const SizedBox(height: 16),
            SizedBox(width: double.infinity, child: FilledButton.icon(
              onPressed: () { Navigator.pop(sheetContext); Navigator.push(context, MaterialPageRoute(builder: (_) => const OfficialChatScreen())); },
              icon: const Icon(Icons.mark_chat_unread_rounded),
              label: Text(context.lx('openOfficial')),
            )),
          ]),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _ambient.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: Stack(
        children: [
          AnimatedBuilder(
            animation: _ambient,
            builder: (_, __) {
              final t = _ambient.value;
              return Positioned.fill(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: RadialGradient(
                      center: Alignment(-0.75 + (t * 0.5), -0.9 + (t * 0.25)),
                      radius: 1.25,
                      colors: [
                        LymixPro.purple.withValues(alpha: 0.14 + t * 0.05),
                        LymixPro.deepPurple.withValues(alpha: 0.10),
                        LymixPro.bg,
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
          SafeArea(child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 280),
            switchInCurve: Curves.easeOutCubic,
            switchOutCurve: Curves.easeInCubic,
            child: KeyedSubtree(key: ValueKey(index), child: pages[index]),
          )),
        ],
      ),
      bottomNavigationBar: _GlassNav(
        index: index,
        onChanged: (v) => setState(() => index = v),
      ),
    );
  }
}

class _GlassNav extends StatelessWidget {
  final int index;
  final ValueChanged<int> onChanged;
  const _GlassNav({required this.index, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final items = <({IconData icon, IconData selectedIcon, String label})>[
      (icon: Icons.home_outlined, selectedIcon: Icons.home_rounded, label: context.lx('home')),
      (icon: Icons.hub_outlined, selectedIcon: Icons.hub_rounded, label: 'Eşleş'),
      (icon: Icons.sports_esports_outlined, selectedIcon: Icons.sports_esports_rounded, label: context.lx('games')),
      (icon: Icons.forum_outlined, selectedIcon: Icons.forum_rounded, label: context.lx('messages')),
      (icon: Icons.person_outline_rounded, selectedIcon: Icons.person_rounded, label: context.lx('profile')),
    ];

    return SafeArea(
      top: false,
      minimum: const EdgeInsets.fromLTRB(8, 0, 8, 5),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(22),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
          child: Container(
            height: 70,
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 5),
            decoration: BoxDecoration(
              color: const Color(0xF20D0914),
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: Colors.white.withValues(alpha: .075)),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: .42),
                  blurRadius: 26,
                  offset: const Offset(0, 10),
                ),
                BoxShadow(
                  color: LymixPro.purple.withValues(alpha: .08),
                  blurRadius: 30,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: Row(
              children: List.generate(items.length, (i) {
                final selected = i == index;
                final item = items[i];
                return Expanded(
                  child: Semantics(
                    button: true,
                    selected: selected,
                    label: item.label,
                    child: InkWell(
                      borderRadius: BorderRadius.circular(23),
                      onTap: () => onChanged(i),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 260),
                        curve: Curves.easeOutBack,
                        margin: const EdgeInsets.symmetric(horizontal: 2),
                        decoration: BoxDecoration(
                          color: selected ? Colors.white.withValues(alpha: .045) : Colors.transparent,
                          borderRadius: BorderRadius.circular(23),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            TweenAnimationBuilder<double>(
                              tween: Tween(begin: 1, end: selected ? 1.08 : 1),
                              duration: const Duration(milliseconds: 240),
                              curve: Curves.easeOutBack,
                              builder: (_, scale, child) => Transform.scale(scale: scale, child: child),
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 240),
                                width: 34,
                                height: 34,
                                decoration: BoxDecoration(
                                  gradient: selected ? LymixPro.brandGradient : null,
                                  color: selected ? null : Colors.white.withValues(alpha: .035),
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: selected
                                        ? LymixPro.yellow.withValues(alpha: .55)
                                        : Colors.white.withValues(alpha: .055),
                                  ),
                                  boxShadow: selected
                                      ? [
                                          BoxShadow(
                                            color: LymixPro.yellow.withValues(alpha: .18),
                                            blurRadius: 14,
                                            spreadRadius: 1,
                                          ),
                                          BoxShadow(
                                            color: LymixPro.purple.withValues(alpha: .28),
                                            blurRadius: 20,
                                            spreadRadius: 2,
                                          ),
                                        ]
                                      : null,
                                ),
                                child: Icon(
                                  selected ? item.selectedIcon : item.icon,
                                  color: selected ? LymixPro.bg : Colors.white70,
                                  size: selected ? 21 : 20,
                                ),
                              ),
                            ),
                            const SizedBox(height: 3),
                            AnimatedDefaultTextStyle(
                              duration: const Duration(milliseconds: 220),
                              style: TextStyle(
                                fontSize: selected ? 10.5 : 9.5,
                                fontWeight: selected ? FontWeight.w900 : FontWeight.w600,
                                letterSpacing: selected ? .05 : 0,
                                color: selected ? LymixPro.yellow : Colors.white54,
                              ),
                              child: Text(item.label, maxLines: 1, overflow: TextOverflow.fade, softWrap: false),
                            ),
                            AnimatedContainer(
                              duration: const Duration(milliseconds: 220),
                              curve: Curves.easeOut,
                              margin: const EdgeInsets.only(top: 2),
                              width: selected ? 17 : 0,
                              height: 2.2,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(99),
                                gradient: selected ? LymixPro.brandGradient : null,
                                boxShadow: selected
                                    ? [BoxShadow(color: LymixPro.yellow.withValues(alpha: .45), blurRadius: 7)]
                                    : null,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              }),
            ),
          ),
        ),
      ),
    );
  }
}

class Head extends StatelessWidget {
  final String title;
  const Head(this.title, {super.key});

  String _localized(BuildContext context) {
    const keys = <String, String>{
      'Keşfet': 'discover',
      'Plaza': 'plaza',
      'Oyun Merkezi': 'gameCenter',
      'Mesajlar': 'messages',
      'Profil': 'profile',
    };
    final key = keys[title];
    return key == null ? title : context.lx(key);
  }

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(20, 18, 20, 12),
    child: Row(children: [
      ShaderMask(
        shaderCallback: (r) => LymixPro.brandGradient.createShader(r),
        child: const Text('LYMIX', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900, color: Colors.white, letterSpacing: 1.8)),
      ),
      const Spacer(),
      Text(_localized(context), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
      const SizedBox(width: 12),
      _GlassIconButton(icon: Icons.search_rounded, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const GlobalSearchScreen()))),
    ]),
  );
}

class _GlassIconButton extends StatefulWidget {
  final IconData icon;
  final VoidCallback onTap;
  final Color? color;
  const _GlassIconButton({required this.icon, required this.onTap, this.color});
  @override
  State<_GlassIconButton> createState() => _GlassIconButtonState();
}

class _GlassIconButtonState extends State<_GlassIconButton> {
  bool down = false;
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTapDown: (_) => setState(() => down = true),
    onTapCancel: () => setState(() => down = false),
    onTapUp: (_) => setState(() => down = false),
    onTap: widget.onTap,
    child: AnimatedScale(
      scale: down ? 0.90 : 1,
      duration: const Duration(milliseconds: 110),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
          child: Container(
            width: 48, height: 48,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.06),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: Colors.white.withValues(alpha: 0.08)),
            ),
            child: Icon(widget.icon, color: widget.color ?? Colors.white),
          ),
        ),
      ),
    ),
  );
}


class DiscoverPage extends StatefulWidget {
  const DiscoverPage({super.key});
  @override State<DiscoverPage> createState()=>_DiscoverPageState();
}

class _DiscoverPageState extends State<DiscoverPage> {
  int tab=0;
  @override Widget build(BuildContext context){
    final banners=<LymixBannerItem>[
      LymixBannerItem(icon:Icons.graphic_eq_rounded,eyebrow:'KALICI ODA',title:'Partin burada başlar',subtitle:'Tek kalıcı odanı düzenle, mikrofonları yönet, PK ve oyun başlat.',action:'Odama Git',onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const RoomCreateScreen()))),
      LymixBannerItem(icon:Icons.sports_esports_rounded,eyebrow:'OYUN + SES',title:'Oynarken konuş',subtitle:'Oda sesini kapatmadan lisanslı oyun sağlayıcısına geçecek mimari hazır.',action:'Oyun Merkezi',onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const GameCenterScreen()))),
      LymixBannerItem(icon:Icons.verified_user_rounded,eyebrow:'CREATOR',title:'Yayıncı hesabını doğrula',subtitle:'Telefon, canlı video ve ajans bağlantısıyla profesyonel creator akışı.',action:'Başvur',onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const CreatorVerificationScreen()))),
      LymixBannerItem(icon:Icons.workspace_premium_rounded,eyebrow:'VIP',title:'Kimliğini öne çıkar',subtitle:'Rozet, giriş efekti, profil çerçevesi ve oda görünümü tek VIP katmanında.',action:'VIP Merkezi',onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const VipCenterScreen()))),
    ];
    return ListView(padding:const EdgeInsets.only(bottom:118),children:[
      LymixTopBrandBar(title:'LYMIX',subtitle:'Voice • Party • Games • Match',onSearch:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const GlobalSearchScreen())),onNotifications:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const NotificationCenterScreen()))),
      LymixSystemTicker(items:const[
        LymixTickerItem(Icons.verified_rounded,'Lymix Official • güvenlik ve ürün bildirimleri'),
        LymixTickerItem(Icons.graphic_eq_rounded,'Kalıcı oda kimliği • ajans statüsünde aynı oda korunur'),
        LymixTickerItem(Icons.card_giftcard_rounded,'Toplu hediye maliyeti gerçek alıcı sayısına göre hesaplanır'),
      ],onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const OfficialChatScreen()))),
      const SizedBox(height:10),
      LymixPromoCarousel(items:banners),
      const SizedBox(height:12),
      LymixSectionTabs(tabs:const['Önerilen','Parti','Türkiye','Yeni'],active:tab,onChanged:(v)=>setState(()=>tab=v)),
      const SizedBox(height:14),
      Padding(padding:const EdgeInsets.symmetric(horizontal:14),child:GridView.count(
        shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:4,crossAxisSpacing:8,mainAxisSpacing:8,childAspectRatio:.78,children:[
          _DiscoverShortcut(icon:Icons.graphic_eq_rounded,label:'Odam',onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const RoomCreateScreen()))),
          _DiscoverShortcut(icon:Icons.favorite_rounded,label:'Eşleş',onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const GlobalSearchScreen()))),
          _DiscoverShortcut(icon:Icons.sports_esports_rounded,label:'Oyun',onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const GameCenterScreen()))),
          _DiscoverShortcut(icon:Icons.verified_user_rounded,label:'Creator',onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const CreatorVerificationScreen()))),
        ],
      )),
      const SizedBox(height:18),
      const Padding(padding:EdgeInsets.symmetric(horizontal:16),child:Row(children:[Text('Canlı Partiler',style:TextStyle(fontSize:17,fontWeight:FontWeight.w1000)),Spacer(),Text('GERÇEK ZAMANLI',style:TextStyle(color:LymixPalette.gold,fontSize:8,fontWeight:FontWeight.w900,letterSpacing:.8))])),
      Container(margin:const EdgeInsets.fromLTRB(14,10,14,0),padding:const EdgeInsets.all(22),decoration:BoxDecoration(color:LymixPalette.surface.withValues(alpha:.92),borderRadius:BorderRadius.circular(22),border:Border.all(color:Colors.white.withValues(alpha:.06))),child:Column(children:[
        const Icon(Icons.waves_rounded,size:46,color:LymixPalette.text3),const SizedBox(height:11),
        const Text('Şu anda açık oda yok',style:TextStyle(fontSize:17,fontWeight:FontWeight.w1000)),const SizedBox(height:5),
        const Text('Sahte oda ve katılımcı göstermiyoruz. İlk gerçek odalar backend’den geldiğinde burada kategori, ülke ve popülerlik sırasıyla listelenecek.',textAlign:TextAlign.center,style:TextStyle(color:LymixPalette.text3,fontSize:10,height:1.4)),const SizedBox(height:15),
        FilledButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const RoomCreateScreen())),icon:const Icon(Icons.mic_rounded),label:const Text('Odama Git')),
      ])),
    ]);
  }
}

class _DiscoverShortcut extends StatelessWidget{
  final IconData icon;final String label;final VoidCallback onTap;
  const _DiscoverShortcut({required this.icon,required this.label,required this.onTap});
  @override Widget build(BuildContext context)=>LymixPressable(onTap:onTap,child:Container(decoration:BoxDecoration(color:Colors.white.withValues(alpha:.035),borderRadius:BorderRadius.circular(18),border:Border.all(color:Colors.white.withValues(alpha:.055))),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Container(width:43,height:43,decoration:BoxDecoration(gradient:LymixPalette.brand,borderRadius:BorderRadius.circular(14)),child:Icon(icon,color:const Color(0xFF151018),size:22)),const SizedBox(height:7),Text(label,style:const TextStyle(fontSize:9.5,fontWeight:FontWeight.w900))])));
}

class _Tabs extends StatelessWidget { const _Tabs();
  @override Widget build(BuildContext context)=>Padding(
    padding:const EdgeInsets.symmetric(horizontal:16,vertical:6),
    child:Wrap(spacing:8,runSpacing:8,children:const[
      _GlassChip('⭐ Önerilen', selected:true), _GlassChip('🇹🇷 Türkiye'), _GlassChip('🌍 Global'), _GlassChip('🎵 Müzik'),
    ]),
  );
}

class _GlassChip extends StatelessWidget {
  final String label; final bool selected;
  const _GlassChip(this.label,{this.selected=false});
  @override Widget build(BuildContext context)=>Container(
    padding:const EdgeInsets.symmetric(horizontal:14,vertical:10),
    decoration:BoxDecoration(
      gradient:selected?LymixPro.brandGradient:null,
      color:selected?null:Colors.white.withValues(alpha: .045),
      borderRadius:BorderRadius.circular(15),
      border:Border.all(color:selected?Colors.transparent:Colors.white.withValues(alpha: .10)),
    ),
    child:Text(label,style:TextStyle(fontWeight:FontWeight.w800,color:selected?LymixPro.bg:Colors.white)),
  );
}

class SocialPage extends StatefulWidget {
  const SocialPage({super.key});
  @override State<SocialPage> createState()=>_SocialPageState();
}
class _SocialPageState extends State<SocialPage>{
  int mode=0;
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.only(bottom:118),children:[
    LymixTopBrandBar(title:'Eşleş & Moments',subtitle:'İlgi alanı • gerçek profil • sosyal akış',onSearch:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const GlobalSearchScreen()))),
    LymixSectionTabs(tabs:const['Eşleş','Moments','Takip'],active:mode,onChanged:(v)=>setState(()=>mode=v)),
    const SizedBox(height:14),
    if(mode==0)...[
      Container(margin:const EdgeInsets.symmetric(horizontal:14),padding:const EdgeInsets.all(18),decoration:BoxDecoration(gradient:const LinearGradient(colors:[Color(0xFF4A174B),Color(0xFF1B1026)]),borderRadius:BorderRadius.circular(24),border:Border.all(color:Colors.white.withValues(alpha:.07))),child:Column(children:[
        const Icon(Icons.favorite_rounded,size:44,color:LymixPalette.pink),const SizedBox(height:10),
        const Text('Akıllı eşleşme',style:TextStyle(fontSize:19,fontWeight:FontWeight.w1000)),const SizedBox(height:5),
        const Text('İlgi alanı, dil ve güvenlik tercihleri backend’e bağlandığında gerçek adaylar burada gösterilecek. Sahte profil üretilmez.',textAlign:TextAlign.center,style:TextStyle(color:Colors.white60,fontSize:10,height:1.4)),const SizedBox(height:14),
        FilledButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const GlobalSearchScreen())),icon:const Icon(Icons.travel_explore_rounded),label:const Text('İnsanları Keşfet')),
      ])),
      const SizedBox(height:14),
      Padding(padding:const EdgeInsets.symmetric(horizontal:14),child:Row(children:[Expanded(child:_MatchFilter(icon:Icons.language_rounded,title:'Dil',value:'Türkçe')),const SizedBox(width:8),Expanded(child:_MatchFilter(icon:Icons.interests_rounded,title:'İlgi',value:'Sohbet'))])),
    ] else if(mode==1)...[
      const Padding(padding:EdgeInsets.symmetric(horizontal:16),child:Text('Moments',style:TextStyle(fontSize:17,fontWeight:FontWeight.w1000))),
      Container(margin:const EdgeInsets.fromLTRB(14,10,14,0),padding:const EdgeInsets.all(20),decoration:BoxDecoration(color:Colors.white.withValues(alpha:.03),borderRadius:BorderRadius.circular(22),border:Border.all(color:Colors.white.withValues(alpha:.055))),child:Column(children:[const Icon(Icons.photo_library_outlined,size:43,color:LymixPalette.text3),const SizedBox(height:10),const Text('Henüz paylaşım yok',style:TextStyle(fontWeight:FontWeight.w900)),const SizedBox(height:4),const Text('Gerçek kullanıcı fotoğraf, kısa video ve oda anlarını paylaştığında burada görünecek.',textAlign:TextAlign.center,style:TextStyle(color:LymixPalette.text3,fontSize:10)),const SizedBox(height:12),OutlinedButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const FeedScreen())),icon:const Icon(Icons.add_circle_outline),label:const Text('Moment Oluştur'))])),
    ] else ...[
      Container(margin:const EdgeInsets.symmetric(horizontal:14),padding:const EdgeInsets.all(20),decoration:BoxDecoration(color:Colors.white.withValues(alpha:.03),borderRadius:BorderRadius.circular(22)),child:const Column(children:[Icon(Icons.people_outline_rounded,size:43,color:LymixPalette.text3),SizedBox(height:10),Text('Takip akışın boş',style:TextStyle(fontWeight:FontWeight.w900)),SizedBox(height:4),Text('Takip ettiğin gerçek kullanıcıların açık odaları ve paylaşımları burada görünür.',textAlign:TextAlign.center,style:TextStyle(color:LymixPalette.text3,fontSize:10))]))
    ],
  ]);
}
class _MatchFilter extends StatelessWidget{final IconData icon;final String title;final String value;const _MatchFilter({required this.icon,required this.title,required this.value});@override Widget build(BuildContext context)=>Container(padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:Colors.white.withValues(alpha:.035),borderRadius:BorderRadius.circular(17),border:Border.all(color:Colors.white.withValues(alpha:.055))),child:Row(children:[Icon(icon,color:LymixPalette.gold,size:18),const SizedBox(width:8),Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(color:LymixPalette.text3,fontSize:8)),Text(value,style:const TextStyle(fontSize:10,fontWeight:FontWeight.w900))])])) ;}

class InboxPage extends StatelessWidget {
  const InboxPage({super.key});

  @override
  Widget build(BuildContext context) {
    const official = (name: 'Lymix Official', roomId: '', roomTitle: '', inRoom: false, privateRoom: false, official: true);
    return ListView(
      padding: const EdgeInsets.only(bottom: 118),
      children: [
        const Head('Mesajlar'),
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
            _Quick(Icons.person_add_alt_1_rounded, 'İstekler', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MessageRequestsScreen()))),
            _Quick(Icons.notifications_rounded, 'Bildirim', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NotificationCenterScreen()))),
            _Quick(Icons.support_agent_rounded, 'Official', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const OfficialChatScreen()))),
          ]),
        ),
        const _MessageUserTile(user: official),
        Container(
          margin: const EdgeInsets.fromLTRB(16, 18, 16, 8),
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(color: Colors.white.withValues(alpha: .028), borderRadius: BorderRadius.circular(24), border: Border.all(color: Colors.white.withValues(alpha: .06))),
          child: const Column(children: [
            Icon(Icons.chat_bubble_outline_rounded, size: 42, color: Colors.white38),
            SizedBox(height: 12),
            Text('Henüz özel sohbetin yok', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
            SizedBox(height: 5),
            Text('Gerçek kullanıcılarla etkileşime geçtiğinde sohbetlerin burada görünecek. Sahte konuşmalar gösterilmiyor.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white54, height: 1.4)),
          ]),
        ),
      ],
    );
  }
}

class _MessageUserTile extends StatelessWidget {
  final ({String name, String roomId, String roomTitle, bool inRoom, bool privateRoom, bool official}) user;
  const _MessageUserTile({required this.user});

  @override
  Widget build(BuildContext context) {
    final canJoin = user.inRoom && !user.privateRoom && user.roomId.isNotEmpty;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(color: Colors.white.withValues(alpha: .026), borderRadius: BorderRadius.circular(20)),
      child: ListTile(
        onTap: () {
          if (user.official) {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const OfficialChatScreen()));
          } else {
            Navigator.push(context, MaterialPageRoute(builder: (_) => DirectMessageScreen(userId: user.name, displayName: user.name, openRoomId: canJoin ? user.roomId : null, openRoomTitle: canJoin ? user.roomTitle : null, privateRoom: user.privateRoom)));
          }
        },
        leading: _PresenceAvatar(name: user.name, showRing: canJoin, official: user.official, onJoin: canJoin ? () => Navigator.push(context, MaterialPageRoute(builder: (_) => LymixRoomScreen(roomId: user.roomId, roomTitle: user.roomTitle))) : null),
        title: Row(children: [
          Flexible(child: Text(user.name, style: const TextStyle(fontWeight: FontWeight.w800))),
          if (user.official) ...[const SizedBox(width: 4), const Icon(Icons.verified_rounded, size: 16, color: LymixPro.yellow)],
        ]),
        subtitle: Text(user.official
            ? 'Hoş geldin, kurallar ve Lymix rehberi'
            : canJoin
                ? '${user.roomTitle} odasında • profiline dokunup yanına git'
                : user.privateRoom
                    ? 'Mesaj gönderildi • oda bilgisi gizli'
                    : 'Özel mesaj'),
        trailing: canJoin ? const Icon(Icons.graphic_eq_rounded, color: LymixPro.yellow) : const Icon(Icons.chevron_right_rounded),
      ),
    );
  }
}

class _PresenceAvatar extends StatefulWidget {
  final String name;
  final bool showRing;
  final bool official;
  final VoidCallback? onJoin;
  const _PresenceAvatar({required this.name, required this.showRing, required this.official, this.onJoin});
  @override State<_PresenceAvatar> createState() => _PresenceAvatarState();
}

class _PresenceAvatarState extends State<_PresenceAvatar> with SingleTickerProviderStateMixin {
  late final AnimationController controller;
  @override void initState() { super.initState(); controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))..repeat(); }
  @override void dispose() { controller.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => GestureDetector(
    onTap: widget.onJoin,
    child: AnimatedBuilder(animation: controller, builder: (_, child) {
      final glow = widget.showRing ? .28 + controller.value * .45 : 0.0;
      return Container(
        width: 52, height: 52, padding: EdgeInsets.all(widget.showRing ? 2.5 : 0),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: widget.showRing ? SweepGradient(transform: GradientRotation(controller.value * 6.28), colors: const [LymixPro.yellow, LymixPro.purple, Color(0xFFFF4FA3), LymixPro.yellow]) : null,
          boxShadow: widget.showRing ? [BoxShadow(color: LymixPro.purple.withValues(alpha: glow), blurRadius: 16)] : null,
        ),
        child: CircleAvatar(
          backgroundColor: widget.official ? LymixPro.yellow : LymixPro.deepPurple,
          child: Icon(widget.official ? Icons.graphic_eq_rounded : Icons.person_rounded, color: widget.official ? LymixPro.bg : Colors.white),
        ),
      );
    }),
  );
}

class _Quick extends StatelessWidget {
  final IconData i; final String t; final VoidCallback onTap;
  const _Quick(this.i, this.t, this.onTap);
  @override Widget build(BuildContext context) => InkWell(
    borderRadius: BorderRadius.circular(22), onTap: onTap,
    child: Padding(padding: const EdgeInsets.all(6), child: Column(children: [
      CircleAvatar(radius: 29, backgroundColor: LymixPro.panel2, child: Icon(i, color: LymixPro.yellow)),
      const SizedBox(height: 7), Text(t, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
    ])),
  );
}


class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.only(bottom: 118),
    children: [
      const LymixTopBrandBar(
        title: 'Profil',
        subtitle: 'Hesap • kimlik • VIP • ajans',
      ),
      const LymixMediaBanner(
        eyebrow: 'PROFILE',
        title: 'Lymix Identity',
        subtitle: 'VIP • Creator • Agency • Level • Koleksiyon',
        icon: Icons.workspace_premium_rounded,
      ),
      Container(
        margin: const EdgeInsets.fromLTRB(14, 6, 14, 12),
        padding: const EdgeInsets.fromLTRB(15, 17, 15, 15),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF25142F), Color(0xFF130D1C), Color(0xFF0C0912)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: Colors.white.withValues(alpha:.07)),
          boxShadow: [
            BoxShadow(
              color: LymixPro.purple.withValues(alpha:.12),
              blurRadius: 24,
              offset: const Offset(0,10),
            )
          ],
        ),
        child: Column(children: [
          Row(children: [
            GestureDetector(
              onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const SuperAdminProfileScreen())),
              child: Stack(children: [
                Container(
                  width: 82, height: 82, padding: const EdgeInsets.all(3),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LymixPro.brandGradient,
                    boxShadow: [BoxShadow(
                      color:LymixPro.purple.withValues(alpha:.28),
                      blurRadius:18)],
                  ),
                  child: const CircleAvatar(
                    backgroundColor: Color(0xFF160F20),
                    backgroundImage: AssetImage('assets/branding/lymix_mark_1024.png'),
                  ),
                ),
                Positioned(
                  right:0,bottom:3,
                  child:Container(
                    width:24,height:24,
                    decoration:BoxDecoration(
                      color:LymixPalette.gold,
                      shape:BoxShape.circle,
                      border:Border.all(color:LymixPalette.bg,width:2),
                    ),
                    child:const Icon(Icons.verified_rounded,
                      color:Color(0xFF151018),size:14),
                  ),
                ),
              ]),
            ),
            const SizedBox(width: 13),
            const Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('LYMIX OWNER', style: TextStyle(
                  fontSize: 20, fontWeight: FontWeight.w1000)),
                SizedBox(height: 4),
                Text('Baş Admin • Lymix Official',
                  style: TextStyle(color:LymixPalette.text3,fontSize:10)),
                SizedBox(height: 9),
                Wrap(spacing:5,runSpacing:5,children:[
                  LymixPremiumBadge('OWNER',icon:Icons.workspace_premium_rounded),
                  LymixPremiumBadge('VERIFIED',icon:Icons.verified_user_rounded),
                ]),
              ],
            )),
            const Icon(Icons.chevron_right_rounded,color:LymixPalette.text3),
          ]),
          const SizedBox(height: 16),
          Container(height:1,color:Colors.white.withValues(alpha:.055)),
          const SizedBox(height: 13),
          const Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _Stat('0','Arkadaş'),
              _Stat('0','Takip'),
              _Stat('0','Fan'),
              _Stat('0','Hediye'),
            ],
          ),
        ]),
      ),
      LymixPressable(
        onTap: () => Navigator.push(context,
          MaterialPageRoute(builder: (_) => const VipCenterScreen())),
        child: Container(
          margin: const EdgeInsets.fromLTRB(14, 0, 14, 12),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors:[Color(0xFF3B174B),Color(0xFF7D2968),Color(0xFF24123D)]),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color:Colors.white.withValues(alpha:.07)),
          ),
          child: const Row(children:[
            Icon(Icons.workspace_premium_rounded,
              color:LymixPalette.gold,size:31),
            SizedBox(width:11),
            Expanded(child:Column(
              crossAxisAlignment:CrossAxisAlignment.start,children:[
                Text('VIP & Seviye Merkezi',
                  style:TextStyle(fontSize:14,fontWeight:FontWeight.w1000)),
                SizedBox(height:3),
                Text('Ayrıcalıklar • çerçeveler • giriş efektleri',
                  style:TextStyle(color:Colors.white60,fontSize:9.5)),
              ])),
            Icon(Icons.chevron_right_rounded,color:Colors.white70),
          ]),
        ),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal:14),
        child: Column(children:[
          LymixMenuTile(
            icon:Icons.graphic_eq_rounded,
            title:'Kendi Odam',
            subtitle:'Kalıcı odanı düzenle ve yönet',
            onTap:()=>Navigator.push(context,
              MaterialPageRoute(builder:(_)=>const RoomCreateScreen())),
          ),
          const SizedBox(height:8),
          LymixMenuTile(
            icon:Icons.card_giftcard_rounded,
            title:context.lx('myGifts'),
            subtitle:'Hediye kataloğu ve koleksiyon',
            onTap:()=>Navigator.push(context,
              MaterialPageRoute(builder:(_)=>const GiftCatalogScreen())),
          ),
          const SizedBox(height:8),
          LymixMenuTile(
            icon:Icons.account_balance_wallet_rounded,
            title:context.lx('wallet'),
            subtitle:'Coin • bakiye • işlem merkezi',
            onTap:()=>Navigator.push(context,
              MaterialPageRoute(builder:(_)=>const WalletScreen())),
          ),
          const SizedBox(height:8),
          LymixMenuTile(
            icon:Icons.inventory_2_rounded,
            title:context.lx('bag'),
            subtitle:'Çerçeve • efekt • rozet • varlıklar',
            onTap:()=>Navigator.push(context,
              MaterialPageRoute(builder:(_)=>const InventoryScreen())),
          ),
          const SizedBox(height:8),
          LymixMenuTile(
            icon:Icons.favorite_rounded,
            title:context.lx('favorites'),
            subtitle:'Favori oda ve kullanıcıların',
            onTap:()=>Navigator.push(context,
              MaterialPageRoute(builder:(_)=>const FavoritesScreen())),
          ),
          const SizedBox(height:8),
          LymixMenuTile(
            icon:Icons.verified_user_rounded,
            title:'Yayıncı Doğrulama',
            subtitle:'Telefon • canlı video • ajans başvurusu',
            onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const CreatorVerificationScreen())),
          ),
          const SizedBox(height:8),
          LymixMenuTile(
            icon:Icons.hub_rounded,
            title:'Ajans & Aile',
            subtitle:'Ajans statüsü • host yapısı • topluluk',
            onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const AgencyFamilyScreen())),
          ),
          const SizedBox(height:8),
          LymixMenuTile(
            icon:Icons.admin_panel_settings_rounded,
            title:context.lx('adminEconomy'),
            subtitle:'Baş admin • ekonomi • operasyon',
            onTap:()=>Navigator.push(context,
              MaterialPageRoute(builder:(_)=>const AdminHybridCenterScreen())),
          ),
          const SizedBox(height:8),
          LymixMenuTile(
            icon:Icons.payments_rounded,
            title:'Admin • Coin Gönder',
            subtitle:'Kullanıcı ID üzerinden test / operasyon coin transferi',
            onTap:()=>Navigator.push(context,
              MaterialPageRoute(builder:(_)=>const AdminCoinGrantScreen())),
          ),
          const SizedBox(height:8),
          LymixMenuTile(
            icon:Icons.support_agent_rounded,
            title:'Lymix Official',
            subtitle:'Sistem rehberi ve resmi destek',
            onTap:()=>Navigator.push(context,
              MaterialPageRoute(builder:(_)=>const OfficialChatScreen())),
          ),
          const SizedBox(height:8),
          LymixMenuTile(
            icon:Icons.settings_rounded,
            title:context.lx('settings'),
            subtitle:'Hesap • gizlilik • bildirim • dil',
            onTap:()=>Navigator.push(context,
              MaterialPageRoute(builder:(_)=>const AppSettingsScreen())),
          ),
        ]),
      ),
    ],
  );
}

class _ProfileAction extends StatelessWidget {
  final IconData icon; final String label; final VoidCallback onTap;
  const _ProfileAction(this.icon, this.label, this.onTap);
  @override Widget build(BuildContext context) => InkWell(
    onTap: onTap, borderRadius: BorderRadius.circular(19),
    child: Container(
      decoration: BoxDecoration(color: Colors.white.withValues(alpha: .035), borderRadius: BorderRadius.circular(19), border: Border.all(color: Colors.white.withValues(alpha: .06))),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, color: LymixPro.yellow, size: 29), const SizedBox(height: 6), Padding(padding: const EdgeInsets.symmetric(horizontal: 2), child: Text(label, textAlign: TextAlign.center, maxLines: 2, style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w700)))]),
    ),
  );
}

class _Stat extends StatelessWidget {
  final String n, t; const _Stat(this.n, this.t);
  @override Widget build(BuildContext c) => Column(children: [Text(n, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)), Text(t, style: const TextStyle(color: LymixPro.muted))]);
}
