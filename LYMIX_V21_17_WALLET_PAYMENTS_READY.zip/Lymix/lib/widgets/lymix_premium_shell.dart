import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../design/lymix_design_system.dart';
import '../design/lymix_icon_system.dart';

class LymixTopBrandBar extends StatelessWidget {
  final String title;
  final String? subtitle;
  final VoidCallback? onSearch;
  final VoidCallback? onNotifications;
  const LymixTopBrandBar({
    super.key,
    required this.title,
    this.subtitle,
    this.onSearch,
    this.onNotifications,
  });

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(16, 10, 12, 8),
    child: Row(children: [
      Container(
        width: 42, height: 42,
        decoration: BoxDecoration(
          gradient: LymixPalette.brand,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: LymixPalette.purple.withValues(alpha:.28),
              blurRadius: 18,
              offset: const Offset(0,7),
            )
          ],
        ),
        child: const Center(
          child: Text('L', style: TextStyle(
            color: Color(0xFF120E19),
            fontSize: 23,
            fontWeight: FontWeight.w1000,
          )),
        ),
      ),
      const SizedBox(width: 10),
      Expanded(child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(
            fontSize: 18, height: 1,
            fontWeight: FontWeight.w1000,
            letterSpacing: .15,
          )),
          if (subtitle != null) ...[
            const SizedBox(height: 4),
            Text(subtitle!, style: const TextStyle(
              color: LymixPalette.text3, fontSize: 9.5,
              fontWeight: FontWeight.w600,
            )),
          ],
        ],
      )),
      _HeaderIcon(icon: Icons.search_rounded, onTap: onSearch),
      const SizedBox(width: 6),
      _HeaderIcon(icon: Icons.notifications_none_rounded, onTap: onNotifications),
    ]),
  );
}

class _HeaderIcon extends StatelessWidget {
  final IconData icon;
  final VoidCallback? onTap;
  const _HeaderIcon({required this.icon, this.onTap});
  @override
  Widget build(BuildContext context) => LymixPressable(
    onTap: onTap,
    child: Container(
      width: 40, height: 40,
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha:.045),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withValues(alpha:.06)),
      ),
      child: Icon(icon, size: 20, color: LymixPalette.text2),
    ),
  );
}

class LymixSectionTabs extends StatelessWidget {
  final List<String> tabs;
  final int active;
  final ValueChanged<int>? onChanged;
  const LymixSectionTabs({
    super.key,
    required this.tabs,
    this.active = 0,
    this.onChanged,
  });

  @override
  Widget build(BuildContext context) => SizedBox(
    height: 42,
    child: ListView.separated(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      scrollDirection: Axis.horizontal,
      itemBuilder: (_, i) {
        final selected = i == active;
        return LymixPressable(
          onTap: onChanged == null ? null : () => onChanged!(i),
          child: AnimatedContainer(
            duration: LymixMotion.fast,
            padding: const EdgeInsets.symmetric(horizontal: 15),
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: selected
                  ? LymixPalette.gold.withValues(alpha:.11)
                  : Colors.transparent,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: selected
                    ? LymixPalette.gold.withValues(alpha:.30)
                    : Colors.transparent,
              ),
            ),
            child: Text(
              tabs[i],
              style: TextStyle(
                color: selected ? LymixPalette.text : LymixPalette.text3,
                fontWeight: selected ? FontWeight.w900 : FontWeight.w700,
                fontSize: 11,
              ),
            ),
          ),
        );
      },
      separatorBuilder: (_, __) => const SizedBox(width: 4),
      itemCount: tabs.length,
    ),
  );
}

class LymixRoomIdentityHeader extends StatelessWidget {
  final String roomName;
  final String roomId;
  final String? agencyName;
  final int online;
  final int contribution;
  final VoidCallback? onMore;
  const LymixRoomIdentityHeader({
    super.key,
    required this.roomName,
    required this.roomId,
    this.agencyName,
    this.online = 0,
    this.contribution = 0,
    this.onMore,
  });

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.fromLTRB(14, 10, 10, 11),
    decoration: BoxDecoration(
      color: const Color(0xB50D0914),
      border: Border(
        bottom: BorderSide(color: Colors.white.withValues(alpha:.055)),
      ),
    ),
    child: Column(children: [
      Row(children: [
        Container(
          width: 46, height: 46,
          padding: const EdgeInsets.all(2),
          decoration: BoxDecoration(
            gradient: LymixPalette.brand,
            borderRadius: BorderRadius.circular(15),
          ),
          child: Container(
            decoration: BoxDecoration(
              color: LymixPalette.surface,
              borderRadius: BorderRadius.circular(13),
            ),
            child: const Center(child: LymixIcon(LymixGlyph.room, size: 20, style: LymixIconStyle.plain, active: true)),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Flexible(child: Text(roomName,
                maxLines: 1, overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 15.5,
                  fontWeight: FontWeight.w1000))),
              const SizedBox(width: 5),
              const Icon(Icons.verified_rounded,
                color: LymixPalette.gold, size: 14),
            ]),
            const SizedBox(height: 3),
            Text(
              agencyName == null || agencyName!.isEmpty
                  ? 'Oda #$roomId'
                  : '${agencyName!} • Oda #$roomId',
              style: const TextStyle(
                color: LymixPalette.text3,
                fontSize: 9.5,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        )),
        _metric(Icons.workspace_premium_rounded, contribution.toString(),
          LymixPalette.gold),
        const SizedBox(width: 7),
        _metric(Icons.circle, online.toString(), LymixPalette.success),
        IconButton(
          onPressed: onMore,
          icon: const Icon(Icons.more_horiz_rounded),
        ),
      ]),
    ]),
  );

  Widget _metric(IconData icon, String text, Color color) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
    decoration: BoxDecoration(
      color: Colors.black.withValues(alpha:.20),
      borderRadius: BorderRadius.circular(999),
      border: Border.all(color: Colors.white.withValues(alpha:.05)),
    ),
    child: Row(children: [
      Icon(icon, size: 10, color: color),
      const SizedBox(width: 4),
      Text(text, style: TextStyle(
        fontSize: 9.5, fontWeight: FontWeight.w900, color: color)),
    ]),
  );
}

class LymixRoomProgressStrip extends StatelessWidget {
  final int level;
  final double progress;
  final String text;
  const LymixRoomProgressStrip({
    super.key,
    required this.level,
    required this.progress,
    required this.text,
  });

  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.fromLTRB(14, 8, 14, 8),
    padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 9),
    decoration: BoxDecoration(
      color: const Color(0xD20F0A18),
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: Colors.white.withValues(alpha:.055)),
    ),
    child: Row(children: [
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
        decoration: BoxDecoration(
          gradient: LymixPalette.brand,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Text('Lv$level', style: const TextStyle(
          color: Color(0xFF151018),
          fontSize: 10, fontWeight: FontWeight.w1000)),
      ),
      const SizedBox(width: 9),
      Expanded(child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(99),
            child: LinearProgressIndicator(
              minHeight: 5,
              value: progress.clamp(0,1),
              backgroundColor: Colors.white.withValues(alpha:.06),
              valueColor: const AlwaysStoppedAnimation(LymixPalette.purple),
            ),
          ),
          const SizedBox(height: 5),
          Text(text, style: const TextStyle(
            color: LymixPalette.text3,
            fontSize: 8.8, fontWeight: FontWeight.w600)),
        ],
      )),
    ]),
  );
}

class LymixJackpotStrip extends StatefulWidget {
  final String title;
  final String subtitle;
  final VoidCallback? onTap;
  const LymixJackpotStrip({
    super.key,
    this.title = 'Şanslı Hediye',
    this.subtitle = 'Özel hediyeler ve oda etkinlikleri',
    this.onTap,
  });

  @override
  State<LymixJackpotStrip> createState() => _LymixJackpotStripState();
}

class _LymixJackpotStripState extends State<LymixJackpotStrip>
    with SingleTickerProviderStateMixin {
  late final AnimationController c;
  @override
  void initState() {
    super.initState();
    c = AnimationController(vsync:this,
      duration: const Duration(seconds:3))..repeat();
  }
  @override
  void dispose() { c.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => LymixPressable(
    onTap: widget.onTap,
    child: Container(
      margin: const EdgeInsets.fromLTRB(12, 4, 12, 7),
      height: 68,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF4C1357), Color(0xFF9C176E), Color(0xFF3C155D)],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withValues(alpha:.08)),
        boxShadow: [
          BoxShadow(color: LymixPalette.pink.withValues(alpha:.15),
            blurRadius: 20, offset: const Offset(0,8))
        ],
      ),
      child: AnimatedBuilder(
        animation: c,
        builder: (_, __) => Stack(children: [
          Positioned(
            left: -70 + 280*c.value,
            top: -20,
            child: Transform.rotate(
              angle: -.35,
              child: Container(
                width: 40, height: 110,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.transparent,
                      Colors.white.withValues(alpha:.13),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Row(children: [
              Container(
                width: 44, height: 44,
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha:.09),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Center(child: LymixIcon(LymixGlyph.luckyGift, size: 20, style: LymixIconStyle.plain, active: true)),
              ),
              const SizedBox(width: 10),
              Expanded(child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(widget.title, style: const TextStyle(
                    fontWeight: FontWeight.w1000, fontSize: 14)),
                  const SizedBox(height: 3),
                  Text(widget.subtitle, style: const TextStyle(
                    color: Colors.white60, fontSize: 9.5)),
                ],
              )),
              const Icon(Icons.chevron_right_rounded,
                color: Colors.white70),
            ]),
          ),
        ]),
      ),
    ),
  );
}

class LymixSeatFrame extends StatefulWidget {
  final Widget avatar;
  final String label;
  final String contribution;
  final bool speaking;
  final bool locked;
  final bool muted;
  final VoidCallback? onTap;
  const LymixSeatFrame({
    super.key,
    required this.avatar,
    required this.label,
    this.contribution = '0',
    this.speaking = false,
    this.locked = false,
    this.muted = false,
    this.onTap,
  });

  @override
  State<LymixSeatFrame> createState() => _LymixSeatFrameState();
}

class _LymixSeatFrameState extends State<LymixSeatFrame>
    with SingleTickerProviderStateMixin {
  late final AnimationController c;
  @override
  void initState() {
    super.initState();
    c = AnimationController(vsync:this,
      duration: const Duration(milliseconds:1400))..repeat();
  }
  @override
  void dispose() { c.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => LymixPressable(
    onTap: widget.onTap,
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      AnimatedBuilder(
        animation: c,
        builder: (_, child) => Container(
          width: 58, height: 58,
          padding: const EdgeInsets.all(2.4),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: widget.speaking
                ? SweepGradient(
                    transform: GradientRotation(c.value * math.pi * 2),
                    colors: const [
                      LymixPalette.gold, LymixPalette.pink,
                      LymixPalette.purple, LymixPalette.cyan,
                      LymixPalette.gold,
                    ],
                  )
                : null,
            border: widget.speaking ? null :
              Border.all(color: Colors.white.withValues(alpha:.08)),
            boxShadow: widget.speaking ? [
              BoxShadow(
                color: LymixPalette.purple.withValues(alpha:.28),
                blurRadius: 18,
              )
            ] : null,
          ),
          child: Stack(children: [
            Positioned.fill(child: ClipOval(child: child!)),
            if (widget.locked)
              const Positioned.fill(child: DecoratedBox(
                decoration: BoxDecoration(
                  color: Color(0x77000000),
                  shape: BoxShape.circle,
                ),
                child: Icon(Icons.lock_rounded,
                  size: 19, color: Colors.white70),
              )),
            if (!widget.locked)
              Positioned(
                right: 0, bottom: 0,
                child: Container(
                  width: 18, height: 18,
                  decoration: BoxDecoration(
                    color: const Color(0xFF100B18),
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white12),
                  ),
                  child: Icon(
                    widget.muted ? Icons.mic_off_rounded : Icons.mic_rounded,
                    size: 9,
                    color: widget.muted ? LymixPalette.danger : LymixPalette.success,
                  ),
                ),
              ),
          ]),
        ),
        child: widget.avatar,
      ),
      const SizedBox(height: 4),
      SizedBox(
        width: 72,
        child: Text(widget.label,
          maxLines:1, overflow:TextOverflow.ellipsis,
          textAlign:TextAlign.center,
          style: const TextStyle(
            fontSize:8.8, fontWeight:FontWeight.w800,
            color:LymixPalette.text2)),
      ),
      const SizedBox(height: 3),
      Container(
        padding: const EdgeInsets.symmetric(horizontal:6,vertical:2.5),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors:[Color(0xCC9A2A9D),Color(0xCC5B25A8)]),
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color:Colors.white.withValues(alpha:.08)),
        ),
        child: Row(mainAxisSize:MainAxisSize.min,children:[
          const Icon(Icons.monetization_on_rounded,
            size:8,color:LymixPalette.gold),
          const SizedBox(width:2),
          Text(widget.contribution,style:const TextStyle(
            fontSize:7.8,fontWeight:FontWeight.w900)),
        ]),
      ),
    ]),
  );
}

class LymixMenuTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback? onTap;
  const LymixMenuTile({
    super.key, required this.icon, required this.title,
    required this.subtitle, this.onTap,
  });
  @override
  Widget build(BuildContext context) => LymixPressable(
    onTap:onTap,
    child: Container(
      padding:const EdgeInsets.symmetric(horizontal:13,vertical:12),
      decoration:BoxDecoration(
        color:Colors.white.withValues(alpha:.035),
        borderRadius:BorderRadius.circular(17),
        border:Border.all(color:Colors.white.withValues(alpha:.055)),
      ),
      child:Row(children:[
        Container(
          width:38,height:38,
          decoration:BoxDecoration(
            gradient:LinearGradient(colors:[
              LymixPalette.purple.withValues(alpha:.28),
              LymixPalette.pink.withValues(alpha:.12),
            ]),
            borderRadius:BorderRadius.circular(12),
          ),
          child:Icon(icon,color:LymixPalette.gold,size:20),
        ),
        const SizedBox(width:11),
        Expanded(child:Column(
          crossAxisAlignment:CrossAxisAlignment.start,children:[
            Text(title,style:const TextStyle(
              fontSize:11.5,fontWeight:FontWeight.w900)),
            const SizedBox(height:3),
            Text(subtitle,maxLines:1,overflow:TextOverflow.ellipsis,
              style:const TextStyle(
                color:LymixPalette.text3,fontSize:8.8)),
          ])),
        const Icon(Icons.chevron_right_rounded,
          color:LymixPalette.text3,size:18),
      ]),
    ),
  );
}
