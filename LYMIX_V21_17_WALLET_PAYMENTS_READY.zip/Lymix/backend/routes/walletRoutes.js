const express=require('express');
module.exports=function({wallet}){
  const r=express.Router();

  r.get('/me',(req,res)=>{
    const userId=String(req.user?.sub||req.query.userId||'current_user');
    res.json(wallet.getBalance(userId));
  });

  r.get('/packages',(req,res)=>res.json(wallet.listPackages()));

  r.post('/purchase-intent',(req,res)=>{
    try{
      const userId=String(req.user?.sub||'current_user');
      res.json(wallet.createPurchaseIntent(userId,String(req.body?.packageId||'')));
    }catch(e){
      res.status(400).json({error:String(e.message||'purchase_intent_failed')});
    }
  });

  return r;
};
