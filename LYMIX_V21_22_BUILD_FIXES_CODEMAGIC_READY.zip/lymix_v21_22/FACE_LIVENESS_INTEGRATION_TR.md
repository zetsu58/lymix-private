# LYMIX V21.19 — Yayıncı / Ajans Canlı Yüz Doğrulama

## Karar
Normal kullanıcı kaydı telefon numarası istemez. Telefon/SMS doğrulaması yalnızca “Yayıncı olarak katıl / Ajansa yayıncı olarak katıl” akışında zorunludur.

Canlı yüz doğrulaması için hedef sağlayıcı: **Regula Face SDK (Flutter, Active Liveness)**.

## Neden Regula
- Flutter için resmi kurulum yolu bulunur.
- Android ve iOS desteklenir.
- Active Liveness kullanıcıdan başını hareket ettirmesini/pozisyonunu ayarlamasını ister.
- Passive/Active liveness seçenekleri ve SDK sonucu vardır.
- Uygulama teması/arayüzü özelleştirilebilir.

## Lymix akışı
1. Kullanıcı normal hesap oluşturur: kullanıcı adı + görünen ad + şifre.
2. “Yayıncı olarak katıl” veya ajans başvurusu seçilir.
3. Telefon numarası girilir ve SMS OTP doğrulanır.
4. Canlı yüz doğrulaması başlatılır.
5. Kullanıcıya Lymix ön ekranında örnek hareketler açıklanır: sağa dön, sola dön, yukarı bak, gülümse/göz kırp. Gerçek challenge dizisini SDK belirlemelidir; istemcinin sabit bir sıraya güvenmesi güvenli değildir.
6. SDK liveness sonucu sunucu tarafında doğrulanır.
7. Başvuru PENDING olur; admin/ajans panelinde incelemeye düşer.
8. Onay sonrası creator yetkisi verilir.

## Güvenlik
- Sadece image_picker videosu veya ML Kit yüz hareketi “liveness passed” sayılmamalıdır. Replay/deepfake saldırılarına karşı yeterli değildir.
- Liveness sonucu istemciden gelen boolean ile kabul edilmemeli; provider session/result sunucu tarafından doğrulanmalıdır.
- Biyometrik veri için açık aydınlatma/onay, saklama süresi, silme talebi, erişim logu ve ülkeye göre hukuki uyum gerekir.

## Aktivasyon için gerekenler
- Regula müşteri/proje lisansı.
- Android package id ve iOS bundle id lisans eşlemesi.
- Gerekli SDK/core paketleri ve güncel sürüm pinleri.
- Backend provider session/result doğrulama ayarları.
- Android/iOS kamera izinleri ve gizlilik metinleri.

`lib/services/face_liveness_service.dart` fail-closed adapter olarak eklendi. Lisans bilgisi olmadan uygulama sahte bir “başarılı” liveness sonucu üretmez.
