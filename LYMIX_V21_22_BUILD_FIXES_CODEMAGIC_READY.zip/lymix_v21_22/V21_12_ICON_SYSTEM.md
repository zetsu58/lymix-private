# LYMIX V21.12 — Original Icon System

The icon system is newly authored for Lymix.
It does not include or redistribute proprietary competitor icon assets.

Added:
- single semantic glyph map for room / gift / PK / mic / seats / game / VIP / agency / wallet / moderation / creator verification / admin
- soft, compact, premium and plain icon containers
- active/inactive state styling
- notification dots
- unified accent mapping
- gradient/border/glow behavior shared across the app

Goal:
keep competitor-grade information density and interaction hierarchy while making
the visual identity recognizably Lymix.
