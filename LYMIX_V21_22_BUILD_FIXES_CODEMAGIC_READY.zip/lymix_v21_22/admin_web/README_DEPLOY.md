# LYMIX Admin Web — Deploy

En basit production topolojisi: `admin_web/` klasörünü Lymix backend ile aynı origin üzerinde `/admin/` altında servis etmek. Böylece CORS ve token aktarımı basitleşir.

Alternatif statik hosting için `app.js` içindeki API çağrıları bir `API_BASE` değişkeni üzerinden backend'e yönlendirilmelidir ve backend CORS yalnızca admin domainine izin vermelidir.

Güvenlik: admin endpointleri mutlaka HTTPS + JWT + owner/admin RBAC ile çalıştırılmalı. `LYMIX_REQUIRE_AUTH=true`, güçlü `JWT_SECRET` ve owner bootstrap değişkenleri production ortamında zorunludur.
