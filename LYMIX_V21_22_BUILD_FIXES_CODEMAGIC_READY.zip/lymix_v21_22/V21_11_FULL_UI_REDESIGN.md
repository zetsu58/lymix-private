# LYMIX V21.11 — Full UI Redesign

The Xena APK was used only as a behavior/layout-density reference.
No Xena proprietary artwork, icons, animations, source code or brand assets are included.

## APK UI structures referenced
- activity_audio_room / audio_room_content_constraint
- include_audio_room_live_banner / score board / traffic & trend cards
- dialog_audio_gift_panl / dialog_audio_send_gift
- item_audio_gift_receive_user_choose / item_audio_room_gift
- dialog_audio_mini_card_vs_action_layout
- include_layout_megaphone_vip_upgrade / game point
- fragment_audio_room_online_list / viewer search / admin list
- profile / chat / VIP center / agency search layouts
- PK countdown, scoreboard, follow guide, theme manager, room operation strips

## Lymix changes
- Unified premium dark shell for all primary surfaces
- Denser, edge-to-edge bottom navigation
- Brand header and category strip language
- Room identity header with room/agency/online/contribution hierarchy
- Room progress strip
- Lucky Gift / event strip
- New animated speaking seat frames
- Seat-level contribution pill
- Gift drawer made recipient-first and denser
- Profile rebuilt as hero + badges + VIP + structured menu list
- Existing Lymix colors, logo and identity retained
- No fake participants, fake jackpots or fake contribution totals
