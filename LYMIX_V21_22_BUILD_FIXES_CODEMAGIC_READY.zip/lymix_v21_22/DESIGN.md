# LYMIX Premium Visual System — V21.14

## Product feeling
Lymix is a premium social voice-room product: energetic, status-aware, layered, animated, but never visually noisy.
The UI must not look like a Flutter demo or a stack of generic cards.

## Core hierarchy
1. Identity: user/room/agency/VIP status must be readable in under one second.
2. Social state: speaking, seated, muted, locked, host, admin, VIP and PK must be visually distinct.
3. Economy: gift, contribution, wallet and level surfaces use gold/pink accents without implying fake balances.
4. Events: banners are visual media surfaces, not plain text containers.
5. Motion: motion communicates state changes; it is not decoration.

## Surface tokens
- Background: #07050D
- Raised: #0D0914
- Surface: #150E1E
- Surface strong: #20142D
- Gold: #F4C95D
- Purple: #8B5CF6
- Pink: #EC4899
- Cyan: #22D3EE
- Success: #36D399
- Danger: #FB7185

## Glass levels
- glassLow: 0.04 white overlay
- glassMid: 0.07 white overlay
- glassHigh: 0.11 white overlay
Blur is reserved for hero/banner/bottom-sheet surfaces. Never blur every card.

## Radius
- chip 999
- compact 12
- card 18
- hero 24
- sheet 26

## Motion
- tap 120ms
- state 180ms
- sheet 260ms
- seat 320ms
- hero 420ms
- ambient 2200–3600ms
Use easeOutCubic for entrances and easeInOutCubic for state transitions.

## Room
- Layered atmospheric background.
- Room identity header, event/lucky-gift media banner, level/contribution strip.
- 15-seat stage uses pedestal rings and state halos.
- Speaking state rotates/animates only the halo, not the avatar subtree.
- Empty seats remain visually intentional, not blank circles.
- PK creates a temporary stage mode and disables direct seat-to-seat switching.
- Bottom action dock stays reachable one-handed.

## Profile
- Hero identity card with avatar frame, verification, country/ID/level/status.
- Wealth/charm/contribution and VIP/agency/creator identity are separate.
- Menu uses grouped premium tiles rather than generic ListTiles.
- Achievement/showcase area must be ready for real data but never fabricate achievements.

## Gift
- Recipient-first flow.
- Recipient carousel supports one, selected seats, all seated, whole room; self excluded where required.
- Category rail + dense gift grid + animated selected preview + balance/send dock.
- Combo feedback uses transform/fade rather than expensive full-screen opacity animation.

## Home
- Media-quality event hero.
- Category tabs.
- Real room cards with visual identity and state; no fake occupants.
- Empty states are designed surfaces with meaningful CTAs.

## Performance
- Keep animation rebuild scope local.
- Prefer const widgets.
- AnimatedBuilder static subtrees go through child.
- Avoid animated Opacity and unnecessary clips/saveLayer.
- Profile in profile/release mode; target <=16ms frames on 60Hz.
