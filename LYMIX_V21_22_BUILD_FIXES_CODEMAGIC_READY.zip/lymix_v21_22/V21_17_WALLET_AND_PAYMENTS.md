# LYMIX V21.17 Wallet & Payments

Implemented:
- Wallet screen with Coins / Diamonds tabs
- Balance surface and expandable payment-channel bars
- Google Play package grid
- Credit/debit, TRC20 and ERC20/BSC channel placeholders
- Backend wallet balance and immutable-style ledger entry for admin grants
- Admin coin grant screen by target user ID
- Purchase-intent endpoint for later store-billing wiring

Important store rules:
- Digital coins sold inside Android apps distributed through Google Play should be implemented with Play Billing or an eligible external-payments program for the user's region.
- On Apple platforms, consumable virtual currency should use In-App Purchase / StoreKit unless a region-specific entitlement or permitted external purchase path applies.
- Direct card/crypto channels are disabled in this build by default until compliance and regional eligibility are confirmed.
- Admin grants are not purchases and should always create auditable ledger records.

Production next steps:
1. Create matching consumable products in Play Console and App Store Connect.
2. Replace package display prices with store-returned localized prices.
3. Verify purchase tokens/transactions on backend before crediting coins.
4. Add idempotency keys to avoid double-credit.
5. Persist balances + ledger in PostgreSQL.
6. Add refund/revocation handling.
7. Restrict admin grant API to server-verified owner/super-admin JWT roles.
