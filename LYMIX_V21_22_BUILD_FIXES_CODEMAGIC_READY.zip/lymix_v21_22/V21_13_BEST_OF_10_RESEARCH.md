# LYMIX V21.13 — Best-of-10 clean-room UX

Reference set (public store information + provided Xena APK behavior analysis):
Xena, Yalla, SUGO, YoHo, SoulChill, SoMatch, HalaMe, Yaahlan, MICO, BoBo.

No proprietary competitor source code or artwork is bundled.

## Product patterns adopted
- Xena: room density, PK as a first-class room mode, party framing.
- Yalla: games inside voice rooms, Moments/social layer, premium room identity.
- SUGO: party-first discovery and video/voice social positioning.
- YoHo: casual games + private voice/social flow.
- SoulChill: avatar identity and Moments/feed.
- SoMatch: interest-led match/discovery surface.
- HalaMe: stronger verification/safety framing and room games.
- Yaahlan: game variety, gift/entrance effects and regional party UX.
- MICO: live discovery and creator-centric profile hierarchy.
- BoBo: combined voice/live/game entertainment hub.

## V21.13 information architecture
Home: Recommend / Party / Türkiye / New + banners + quick starts + real-room list.
Match: Match / Moments / Following.
Room: identity + progress + event/gift strip + 15-seat state + PK/game/gift docks.
Games: provider-backed catalog, no fake catalog.
Messages: requests + notifications + official + presence/join privacy.
Profile: hero + VIP + permanent room + wallet + inventory + creator verification + agency + admin.
