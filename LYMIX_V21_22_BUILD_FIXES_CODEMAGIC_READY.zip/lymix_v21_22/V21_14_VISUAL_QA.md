# V21.14 Visual QA Gate

APK is not considered release-ready until these are checked on a real device.

## Home
- Hero/event banner has depth and no text clipping.
- Room cards do not fabricate users.
- Empty states look intentional.
- Bottom navigation is reachable and stable.

## Room
- Header remains readable on small screens.
- Seat states: empty / occupied / speaking / muted / locked visually differ.
- Speaking halo animates without rebuilding avatar subtree.
- 15 seats fit without overflow.
- Gift/event banner remains smooth.
- PK mode prevents direct seat switching.
- Bottom action dock remains usable with keyboard open.

## Gift
- Recipient selector is obvious.
- Self-send exclusion rules are enforced.
- Selected gift state is visible.
- Balance and send action remain visible.
- Combo feedback does not cover critical controls.

## Profile
- Avatar/identity is the strongest hierarchy.
- VIP/agency/creator states do not imply status unless backed by real data.
- Long names and localized strings do not overflow.

## Performance
- Profile mode, not debug mode.
- 60Hz target: no sustained frames above 16ms.
- 120Hz target: aim below 8ms when practical.
- Check first-run animation jank.
- Check low/mid-range Android device.
