import 'package:flutter/material.dart';
import '../models/room_models.dart';
import '../design/lymix_design_system.dart';

class RoomRoleBadge extends StatelessWidget {
  final RoomRole role;
  final bool compact;
  const RoomRoleBadge({super.key, required this.role, this.compact = true});

  @override
  Widget build(BuildContext context) {
    final isOwner = role == RoomRole.owner;
    if (role == RoomRole.member) return const SizedBox.shrink();
    final color = isOwner ? LymixPalette.gold : LymixPalette.cyan;
    final label = isOwner ? 'SAHİP' : 'ADMİN';
    final icon = isOwner ? Icons.workspace_premium_rounded : Icons.shield_rounded;

    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: compact ? 5 : 8,
        vertical: compact ? 2 : 4,
      ),
      decoration: BoxDecoration(
        color: color.withValues(alpha:.12),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: color.withValues(alpha:.28)),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: compact ? 8 : 10, color: color),
        const SizedBox(width: 3),
        Text(
          label,
          style: TextStyle(
            color: color,
            fontSize: compact ? 7.5 : 9,
            fontWeight: FontWeight.w900,
          ),
        ),
      ]),
    );
  }
}
