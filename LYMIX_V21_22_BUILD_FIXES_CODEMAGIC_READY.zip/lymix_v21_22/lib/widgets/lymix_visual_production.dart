import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../design/lymix_design_system.dart';

class LymixAtmosphere extends StatelessWidget {
  final Widget child;
  const LymixAtmosphere({super.key, required this.child});

  @override
  Widget build(BuildContext context) => DecoratedBox(
    decoration: const BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xFF120A1D), Color(0xFF07050D), Color(0xFF0B0712)],
      ),
    ),
    child: Stack(children: [
      const Positioned(
        left: -90, top: 80,
        child: _GlowOrb(size: 230, color: Color(0x338B5CF6)),
      ),
      const Positioned(
        right: -100, top: 270,
        child: _GlowOrb(size: 250, color: Color(0x26EC4899)),
      ),
      const Positioned(
        left: 40, bottom: -130,
        child: _GlowOrb(size: 280, color: Color(0x1822D3EE)),
      ),
      child,
    ]),
  );
}

class _GlowOrb extends StatelessWidget {
  final double size;
  final Color color;
  const _GlowOrb({required this.size, required this.color});
  @override
  Widget build(BuildContext context) => IgnorePointer(
    child: Container(
      width: size, height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [color, color.withValues(alpha: 0)],
        ),
      ),
    ),
  );
}

class LymixMediaBanner extends StatefulWidget {
  final String eyebrow;
  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback? onTap;
  const LymixMediaBanner({
    super.key,
    required this.eyebrow,
    required this.title,
    required this.subtitle,
    this.icon = Icons.auto_awesome_rounded,
    this.onTap,
  });

  @override
  State<LymixMediaBanner> createState() => _LymixMediaBannerState();
}

class _LymixMediaBannerState extends State<LymixMediaBanner>
    with SingleTickerProviderStateMixin {
  late final AnimationController c;
  @override
  void initState() {
    super.initState();
    c = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 3200),
    )..repeat();
  }
  @override
  void dispose() { c.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: widget.onTap,
    child: Container(
      height: 128,
      margin: const EdgeInsets.fromLTRB(14, 8, 14, 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF4A175F), Color(0xFF8D245E), Color(0xFF241448)],
        ),
        border: Border.all(color: Colors.white10),
        boxShadow: [
          BoxShadow(
            color: LymixPalette.purple.withValues(alpha: .18),
            blurRadius: 26,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: AnimatedBuilder(
          animation: c,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 14, 15),
            child: Row(children: [
              Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.black26,
                      borderRadius: BorderRadius.circular(999),
                      border: Border.all(color: Colors.white10),
                    ),
                    child: Text(widget.eyebrow.toUpperCase(),
                      style: const TextStyle(
                        color: LymixPalette.gold,
                        fontSize: 8.5,
                        fontWeight: FontWeight.w900,
                        letterSpacing: .8,
                      )),
                  ),
                  const Spacer(),
                  Text(widget.title, maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                      letterSpacing: -.3,
                    )),
                  const SizedBox(height: 4),
                  Text(widget.subtitle, maxLines: 2, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.white70,
                      height: 1.25,
                      fontSize: 10,
                    )),
                ],
              )),
              const SizedBox(width: 12),
              Container(
                width: 72, height: 72,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(
                    colors: [Color(0xFFFFE16B), Color(0xFFEC4899), Color(0xFF8B5CF6)],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: .25),
                      blurRadius: 18,
                      offset: const Offset(0, 8),
                    )
                  ],
                ),
                child: Icon(widget.icon, color: const Color(0xFF150D1A), size: 34),
              ),
            ]),
          ),
          builder: (_, child) {
            final x = -120 + (420 * c.value);
            return Stack(children: [
              child!,
              Positioned(
                left: x, top: -40,
                child: Transform.rotate(
                  angle: -.28,
                  child: Container(
                    width: 42, height: 210,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Colors.transparent,
                          Colors.white.withValues(alpha: .13),
                          Colors.transparent,
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ]);
          },
        ),
      ),
    ),
  );
}

enum LymixSeatVisualState { empty, occupied, speaking, muted, locked, host, vip }

class LymixSeatPedestal extends StatefulWidget {
  final Widget avatar;
  final String label;
  final String contribution;
  final LymixSeatVisualState state;
  final VoidCallback? onTap;
  const LymixSeatPedestal({
    super.key,
    required this.avatar,
    required this.label,
    required this.contribution,
    required this.state,
    this.onTap,
  });

  @override
  State<LymixSeatPedestal> createState() => _LymixSeatPedestalState();
}

class _LymixSeatPedestalState extends State<LymixSeatPedestal>
    with SingleTickerProviderStateMixin {
  late final AnimationController c;
  @override
  void initState() {
    super.initState();
    c = AnimationController(vsync: this, duration: const Duration(milliseconds: 2400))
      ..repeat();
  }
  @override
  void dispose() { c.dispose(); super.dispose(); }

  Color get accent => switch (widget.state) {
    LymixSeatVisualState.speaking => LymixPalette.success,
    LymixSeatVisualState.host => LymixPalette.gold,
    LymixSeatVisualState.vip => LymixPalette.pink,
    LymixSeatVisualState.locked => LymixPalette.gold,
    LymixSeatVisualState.muted => LymixPalette.danger,
    _ => LymixPalette.purple,
  };

  @override
  Widget build(BuildContext context) {
    final animate = widget.state == LymixSeatVisualState.speaking;
    return GestureDetector(
      onTap: widget.onTap,
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        AnimatedBuilder(
          animation: c,
          child: ClipOval(child: widget.avatar),
          builder: (_, child) => Stack(
            alignment: Alignment.center,
            clipBehavior: Clip.none,
            children: [
              if (animate)
                Transform.rotate(
                  angle: c.value * math.pi * 2,
                  child: Container(
                    width: 68, height: 68,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: SweepGradient(
                        colors: [
                          Colors.transparent,
                          accent,
                          LymixPalette.cyan,
                          Colors.transparent,
                        ],
                      ),
                    ),
                  ),
                ),
              Container(
                width: 62, height: 62,
                padding: const EdgeInsets.all(2.5),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFF110B19),
                  border: Border.all(
                    color: accent.withValues(alpha: animate ? .95 : .38),
                    width: animate ? 2 : 1,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: accent.withValues(alpha: animate ? .22 : .08),
                      blurRadius: animate ? 18 : 8,
                    )
                  ],
                ),
                child: child,
              ),
              Positioned(
                bottom: -3,
                child: Container(
                  width: 42, height: 9,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(999),
                    gradient: LinearGradient(
                      colors: [
                        accent.withValues(alpha: .18),
                        accent.withValues(alpha: .65),
                        accent.withValues(alpha: .18),
                      ],
                    ),
                    boxShadow: [
                      BoxShadow(color: accent.withValues(alpha: .25), blurRadius: 10),
                    ],
                  ),
                ),
              ),
              if (widget.state == LymixSeatVisualState.locked)
                const Icon(Icons.lock_rounded, color: LymixPalette.gold, size: 18),
              if (widget.state == LymixSeatVisualState.muted)
                const Positioned(
                  right: 1, bottom: 4,
                  child: CircleAvatar(
                    radius: 8,
                    backgroundColor: Color(0xFF160D1C),
                    child: Icon(Icons.mic_off_rounded, size: 9, color: LymixPalette.danger),
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(height: 7),
        SizedBox(
          width: 74,
          child: Text(widget.label, textAlign: TextAlign.center,
            maxLines: 1, overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: LymixPalette.text2,
              fontSize: 8.8,
              fontWeight: FontWeight.w800,
            )),
        ),
        const SizedBox(height: 3),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2.5),
          decoration: BoxDecoration(
            color: accent.withValues(alpha: .10),
            borderRadius: BorderRadius.circular(999),
            border: Border.all(color: accent.withValues(alpha: .18)),
          ),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.diamond_rounded, size: 8, color: accent),
            const SizedBox(width: 3),
            Text(widget.contribution,
              style: TextStyle(color: accent, fontSize: 7.8, fontWeight: FontWeight.w900)),
          ]),
        ),
      ]),
    );
  }
}

class LymixProfileHero extends StatelessWidget {
  final Widget avatar;
  final String name;
  final String subtitle;
  final List<Widget> badges;
  final VoidCallback? onTap;
  const LymixProfileHero({
    super.key,
    required this.avatar,
    required this.name,
    required this.subtitle,
    this.badges = const [],
    this.onTap,
  });

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      margin: const EdgeInsets.fromLTRB(14, 8, 14, 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF2A1637), Color(0xFF140D1E), Color(0xFF0C0912)],
        ),
        border: Border.all(color: Colors.white10),
        boxShadow: [
          BoxShadow(
            color: LymixPalette.purple.withValues(alpha: .15),
            blurRadius: 26,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: Row(children: [
        Container(
          width: 88, height: 88,
          padding: const EdgeInsets.all(3),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LymixPalette.brand,
            boxShadow: [
              BoxShadow(
                color: LymixPalette.pink.withValues(alpha: .18),
                blurRadius: 18,
              ),
            ],
          ),
          child: ClipOval(child: avatar),
        ),
        const SizedBox(width: 14),
        Expanded(child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(name, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 4),
            Text(subtitle, maxLines: 2, overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: LymixPalette.text3, fontSize: 10)),
            if (badges.isNotEmpty) ...[
              const SizedBox(height: 10),
              Wrap(spacing: 5, runSpacing: 5, children: badges),
            ],
          ],
        )),
        const Icon(Icons.chevron_right_rounded, color: LymixPalette.text3),
      ]),
    ),
  );
}
