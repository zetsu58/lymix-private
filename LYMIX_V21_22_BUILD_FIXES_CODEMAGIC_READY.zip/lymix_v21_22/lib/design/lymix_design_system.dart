import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

abstract final class LymixSpacing {
  static const double xxs = 4;
  static const double xs = 8;
  static const double sm = 12;
  static const double md = 16;
  static const double lg = 20;
  static const double xl = 24;
  static const double xxl = 32;
}

abstract final class LymixRadius {
  static const double sm = 12;
  static const double md = 16;
  static const double lg = 22;
  static const double xl = 28;
  static const double pill = 999;
}

abstract final class LymixMotion {
  static const Duration press = Duration(milliseconds: 105);
  static const Duration fast = Duration(milliseconds: 160);
  static const Duration page = Duration(milliseconds: 220);
  static const Duration sheet = Duration(milliseconds: 260);
  static const Curve standard = Curves.easeOutCubic;
  static const Curve emphasized = Curves.easeOutBack;
}

abstract final class LymixPalette {
  static const bg = Color(0xFF07050D);
  static const bgRaised = Color(0xFF0D0914);
  static const surface = Color(0xFF150E1E);
  static const surface2 = Color(0xFF20142D);
  static const surface3 = Color(0xFF2A173B);
  static const gold = Color(0xFFFFD338);
  static const amber = Color(0xFFFFA91A);
  static const purple = Color(0xFF8654FF);
  static const violet = Color(0xFFB37CFF);
  static const pink = Color(0xFFFF5FBE);
  static const cyan = Color(0xFF6BE7FF);
  static const success = Color(0xFF66E8A7);
  static const danger = Color(0xFFFF647B);
  static const text = Color(0xFFF8F5FC);
  static const text2 = Color(0xFFBDB4C7);
  static const text3 = Color(0xFF81788A);

  static const brand = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFFFFE16B), gold, pink, purple],
  );
}

class LymixPressable extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final BorderRadius? borderRadius;
  final bool haptic;
  const LymixPressable({
    super.key,
    required this.child,
    this.onTap,
    this.borderRadius,
    this.haptic = true,
  });

  @override
  State<LymixPressable> createState() => _LymixPressableState();
}

class _LymixPressableState extends State<LymixPressable> {
  bool down = false;

  void _set(bool value) {
    if (widget.onTap == null) return;
    if (down == value) return;
    setState(() => down = value);
  }

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: widget.onTap != null,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapDown: (_) {
          _set(true);
          if (widget.haptic) HapticFeedback.selectionClick();
        },
        onTapCancel: () => _set(false),
        onTapUp: (_) => _set(false),
        onTap: widget.onTap,
        child: AnimatedScale(
          scale: down ? .975 : 1,
          duration: LymixMotion.press,
          curve: LymixMotion.standard,
          child: AnimatedOpacity(
            opacity: down ? .88 : 1,
            duration: LymixMotion.press,
            child: widget.child,
          ),
        ),
      ),
    );
  }
}

class LymixGlassSurface extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final BorderRadius borderRadius;
  final Color? color;
  final bool elevated;
  const LymixGlassSurface({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.borderRadius = const BorderRadius.all(Radius.circular(LymixRadius.lg)),
    this.color,
    this.elevated = false,
  });

  @override
  Widget build(BuildContext context) => DecoratedBox(
    decoration: BoxDecoration(
      color: color ?? LymixPalette.surface.withValues(alpha: .94),
      borderRadius: borderRadius,
      border: Border.all(color: Colors.white.withValues(alpha: .07)),
      boxShadow: elevated
          ? const [BoxShadow(color: Color(0x33000000), blurRadius: 26, offset: Offset(0, 12))]
          : null,
    ),
    child: Padding(padding: padding, child: child),
  );
}

class LymixPremiumBadge extends StatelessWidget {
  final String label;
  final IconData? icon;
  const LymixPremiumBadge(this.label, {super.key, this.icon});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
    decoration: BoxDecoration(
      gradient: const LinearGradient(colors: [Color(0x33FFD338), Color(0x337B3FF2)]),
      borderRadius: BorderRadius.circular(LymixRadius.pill),
      border: Border.all(color: LymixPalette.gold.withValues(alpha: .32)),
    ),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      if (icon != null) ...[
        Icon(icon, size: 12, color: LymixPalette.gold),
        const SizedBox(width: 4),
      ],
      Text(label, style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w800, color: LymixPalette.text)),
    ]),
  );
}
