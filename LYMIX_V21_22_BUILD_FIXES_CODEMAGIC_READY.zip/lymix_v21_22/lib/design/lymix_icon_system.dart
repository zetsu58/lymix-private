import 'package:flutter/material.dart';
import 'lymix_design_system.dart';

enum LymixGlyph {
  room,
  gift,
  luckyGift,
  pk,
  mic,
  micMuted,
  seat,
  seatLocked,
  game,
  vip,
  agency,
  wallet,
  messages,
  profile,
  search,
  notifications,
  moderation,
  report,
  settings,
  inventory,
  favorites,
  creatorVerify,
  admin,
}

class LymixIcons {
  static IconData data(LymixGlyph glyph) => switch (glyph) {
    LymixGlyph.room => Icons.graphic_eq_rounded,
    LymixGlyph.gift => Icons.card_giftcard_rounded,
    LymixGlyph.luckyGift => Icons.auto_awesome_rounded,
    LymixGlyph.pk => Icons.flash_on_rounded,
    LymixGlyph.mic => Icons.mic_rounded,
    LymixGlyph.micMuted => Icons.mic_off_rounded,
    LymixGlyph.seat => Icons.event_seat_rounded,
    LymixGlyph.seatLocked => Icons.lock_rounded,
    LymixGlyph.game => Icons.sports_esports_rounded,
    LymixGlyph.vip => Icons.workspace_premium_rounded,
    LymixGlyph.agency => Icons.hub_rounded,
    LymixGlyph.wallet => Icons.account_balance_wallet_rounded,
    LymixGlyph.messages => Icons.forum_rounded,
    LymixGlyph.profile => Icons.person_rounded,
    LymixGlyph.search => Icons.search_rounded,
    LymixGlyph.notifications => Icons.notifications_none_rounded,
    LymixGlyph.moderation => Icons.shield_rounded,
    LymixGlyph.report => Icons.flag_rounded,
    LymixGlyph.settings => Icons.settings_rounded,
    LymixGlyph.inventory => Icons.inventory_2_rounded,
    LymixGlyph.favorites => Icons.favorite_rounded,
    LymixGlyph.creatorVerify => Icons.verified_user_rounded,
    LymixGlyph.admin => Icons.admin_panel_settings_rounded,
  };

  static Color accent(LymixGlyph glyph) => switch (glyph) {
    LymixGlyph.gift || LymixGlyph.luckyGift => LymixPalette.pink,
    LymixGlyph.pk || LymixGlyph.report => LymixPalette.danger,
    LymixGlyph.vip || LymixGlyph.wallet => LymixPalette.gold,
    LymixGlyph.agency || LymixGlyph.game => LymixPalette.cyan,
    LymixGlyph.moderation || LymixGlyph.creatorVerify => LymixPalette.success,
    _ => LymixPalette.purple,
  };
}

enum LymixIconStyle { plain, soft, premium, compact }

class LymixIcon extends StatelessWidget {
  final LymixGlyph glyph;
  final double size;
  final LymixIconStyle style;
  final bool active;
  final bool showDot;
  final VoidCallback? onTap;

  const LymixIcon(
    this.glyph, {
    super.key,
    this.size = 22,
    this.style = LymixIconStyle.soft,
    this.active = false,
    this.showDot = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final accent = LymixIcons.accent(glyph);
    final icon = Icon(
      LymixIcons.data(glyph),
      size: size,
      color: style == LymixIconStyle.plain
          ? (active ? accent : LymixPalette.text2)
          : (active ? const Color(0xFF130D19) : accent),
    );

    if (style == LymixIconStyle.plain) {
      return GestureDetector(onTap: onTap, child: icon);
    }

    final box = switch (style) {
      LymixIconStyle.compact => size + 14,
      LymixIconStyle.premium => size + 26,
      _ => size + 20,
    };

    return GestureDetector(
      onTap: onTap,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          AnimatedContainer(
            duration: LymixMotion.fast,
            width: box,
            height: box,
            decoration: BoxDecoration(
              gradient: active || style == LymixIconStyle.premium
                  ? LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        accent.withValues(alpha: .95),
                        LymixPalette.gold.withValues(alpha: .90),
                      ],
                    )
                  : null,
              color: active ? null : accent.withValues(alpha: .10),
              borderRadius: BorderRadius.circular(
                style == LymixIconStyle.compact ? 11 : 15,
              ),
              border: Border.all(
                color: active
                    ? Colors.white.withValues(alpha: .16)
                    : accent.withValues(alpha: .20),
              ),
              boxShadow: style == LymixIconStyle.premium
                  ? [
                      BoxShadow(
                        color: accent.withValues(alpha: .20),
                        blurRadius: 18,
                        offset: const Offset(0, 7),
                      )
                    ]
                  : null,
            ),
            child: Center(child: icon),
          ),
          if (showDot)
            Positioned(
              right: -1,
              top: -1,
              child: Container(
                width: 9,
                height: 9,
                decoration: BoxDecoration(
                  color: LymixPalette.danger,
                  shape: BoxShape.circle,
                  border: Border.all(color: LymixPalette.bg, width: 2),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class LymixIconLabel extends StatelessWidget {
  final LymixGlyph glyph;
  final String label;
  final bool active;
  final VoidCallback? onTap;

  const LymixIconLabel({
    super.key,
    required this.glyph,
    required this.label,
    this.active = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              LymixIcon(
                glyph,
                size: 19,
                style: LymixIconStyle.compact,
                active: active,
              ),
              const SizedBox(height: 4),
              Text(
                label,
                style: TextStyle(
                  color: active ? LymixPalette.text : LymixPalette.text3,
                  fontSize: 8.5,
                  fontWeight: active ? FontWeight.w900 : FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      );
}
