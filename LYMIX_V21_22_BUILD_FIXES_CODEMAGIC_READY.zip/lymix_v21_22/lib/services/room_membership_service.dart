import '../models/room_models.dart';

class RoomMembershipService {
  final Map<String, List<RoomMember>> _members = {};

  List<RoomMember> members(String roomId) =>
      List.unmodifiable(_members[roomId] ?? const []);

  RoomMember? find(String roomId, String userId) {
    for (final m in _members[roomId] ?? const <RoomMember>[]) {
      if (m.userId == userId) return m;
    }
    return null;
  }

  void ensureOwner({
    required String roomId,
    required String userId,
    required String displayName,
    String? avatarUrl,
  }) {
    final list = _members.putIfAbsent(roomId, () => []);
    final i = list.indexWhere((m) => m.userId == userId);
    final owner = RoomMember(
      userId: userId,
      displayName: displayName,
      avatarUrl: avatarUrl,
      role: RoomRole.owner,
      joinedAt: DateTime.now(),
      online: true,
    );
    if (i == -1) {
      list.add(owner);
    } else {
      list[i] = owner;
    }
  }

  void addMember({
    required String roomId,
    required String userId,
    required String displayName,
    String? avatarUrl,
  }) {
    final list = _members.putIfAbsent(roomId, () => []);
    if (list.any((m) => m.userId == userId)) return;
    list.add(RoomMember(
      userId: userId,
      displayName: displayName,
      avatarUrl: avatarUrl,
      role: RoomRole.member,
      joinedAt: DateTime.now(),
    ));
  }

  bool canManage(RoomMember? actor) =>
      actor?.role == RoomRole.owner || actor?.role == RoomRole.admin;

  void setAdmin({
    required String roomId,
    required String actorUserId,
    required String targetUserId,
    required bool enabled,
  }) {
    final actor = find(roomId, actorUserId);
    if (actor?.role != RoomRole.owner) {
      throw StateError('Sadece oda sahibi yönetici atayabilir.');
    }
    final list = _members[roomId];
    if (list == null) return;
    final i = list.indexWhere((m) => m.userId == targetUserId);
    if (i == -1) return;
    if (list[i].role == RoomRole.owner) return;
    list[i] = list[i].copyWith(
      role: enabled ? RoomRole.admin : RoomRole.member,
    );
  }

  void removeMember({
    required String roomId,
    required String actorUserId,
    required String targetUserId,
  }) {
    final actor = find(roomId, actorUserId);
    if (!canManage(actor)) {
      throw StateError('Bu işlem için yetkin yok.');
    }
    final list = _members[roomId];
    if (list == null) return;
    final target = find(roomId, targetUserId);
    if (target?.role == RoomRole.owner) {
      throw StateError('Oda sahibi üyelikten çıkarılamaz.');
    }
    list.removeWhere((m) => m.userId == targetUserId);
  }

  void banMember({
    required String roomId,
    required String actorUserId,
    required String targetUserId,
    required bool banned,
  }) {
    final actor = find(roomId, actorUserId);
    if (!canManage(actor)) throw StateError('Bu işlem için yetkin yok.');
    final list = _members[roomId];
    if (list == null) return;
    final i = list.indexWhere((m) => m.userId == targetUserId);
    if (i == -1 || list[i].role == RoomRole.owner) return;
    list[i] = list[i].copyWith(banned: banned);
  }
}
