import 'dart:math';
import 'package:flutter_face_api/flutter_face_api.dart';

/// Result boundary used by the creator/agency application flow.
enum FaceLivenessStatus { notStarted, unavailable, pending, passed, failed }

class FaceLivenessResult {
  final FaceLivenessStatus status;
  final String? provider;
  final String? sessionId;
  final String? message;
  const FaceLivenessResult(this.status, {this.provider, this.sessionId, this.message});
}

abstract class FaceLivenessService {
  Future<FaceLivenessResult> start();
}

/// Regula Face SDK 8.2 active-liveness integration.
///
/// Core Basic is intentionally used: Regula documents that it does not require
/// embedding the OL/ML license in the mobile application. The online liveness
/// transaction is validated by the configured Regula Face Web Service/license.
/// This avoids shipping the portal license as a readable Flutter asset.
class RegulaFaceLivenessService implements FaceLivenessService {
  const RegulaFaceLivenessService();

  static bool _initialized = false;

  Future<String?> _ensureInitialized() async {
    if (_initialized) return null;
    try {
      final (success, error) = await FaceSDK.instance.initialize();
      if (!success) {
        return error == null
            ? 'Regula Face SDK başlatılamadı.'
            : 'Regula Face SDK başlatılamadı: ${error.code} ${error.message}';
      }
      _initialized = true;
      return null;
    } catch (e) {
      return 'Regula Face SDK başlatma hatası: $e';
    }
  }

  String _tag() {
    final now = DateTime.now().toUtc().microsecondsSinceEpoch;
    final random = Random.secure().nextInt(1 << 32).toRadixString(16);
    return 'lymix_creator_${now}_$random';
  }

  @override
  Future<FaceLivenessResult> start() async {
    final initError = await _ensureInitialized();
    if (initError != null) {
      return FaceLivenessResult(
        FaceLivenessStatus.unavailable,
        provider: 'regula',
        message: initError,
      );
    }

    final tag = _tag();
    try {
      // Active liveness is Regula's default. It asks the user to move/turn the
      // head and adjust face position; we do not replace it with local motion
      // heuristics or a normal video recording.
      final response = await FaceSDK.instance.startLiveness(
        config: LivenessConfig(tag: tag),
      );

      if (response.liveness == LivenessStatus.PASSED) {
        return FaceLivenessResult(
          FaceLivenessStatus.passed,
          provider: 'regula',
          sessionId: tag,
        );
      }

      final error = response.error;
      return FaceLivenessResult(
        FaceLivenessStatus.failed,
        provider: 'regula',
        sessionId: tag,
        message: error == null
            ? 'Canlılık doğrulanamadı. Yüzünü kadrajda tutup tekrar dene.'
            : 'Canlılık doğrulaması tamamlanamadı: $error',
      );
    } catch (e) {
      return FaceLivenessResult(
        FaceLivenessStatus.failed,
        provider: 'regula',
        sessionId: tag,
        message: 'Yüz taraması başlatılamadı: $e',
      );
    }
  }
}
