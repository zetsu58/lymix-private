import 'package:flutter/material.dart';
import '../core/api_client.dart';
import '../design/lymix_design_system.dart';
import '../services/wallet_service.dart';

class AdminCoinGrantScreen extends StatefulWidget {
  const AdminCoinGrantScreen({super.key});
  @override
  State<AdminCoinGrantScreen> createState()=>_AdminCoinGrantScreenState();
}

class _AdminCoinGrantScreenState extends State<AdminCoinGrantScreen> {
  final _id=TextEditingController();
  final _coins=TextEditingController();
  final _reason=TextEditingController(text:'Test / operasyon kredisi');
  bool _busy=false;
  String? _message;

  @override
  void dispose(){_id.dispose();_coins.dispose();_reason.dispose();super.dispose();}

  Future<void> _send() async {
    final amount=int.tryParse(_coins.text.trim())??0;
    if(_id.text.trim().isEmpty||amount<=0){
      setState(()=>_message='Geçerli kullanıcı ID ve coin miktarı gir.');
      return;
    }
    setState(()=>_busy=true);
    try{
      await WalletService(const ApiClient()).adminGrant(
        targetUserId:_id.text.trim(),
        coins:amount,
        reason:_reason.text.trim(),
      );
      if(mounted)setState(()=>_message='Coin gönderme isteği işlendi.');
    }catch(_){
      if(mounted)setState(()=>_message='İşlem başarısız. Admin yetkisi ve backend bağlantısını kontrol et.');
    }finally{
      if(mounted)setState(()=>_busy=false);
    }
  }

  @override
  Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Admin • Coin Gönder')),
    body:ListView(
      padding:const EdgeInsets.all(16),
      children:[
        TextField(controller:_id,decoration:const InputDecoration(labelText:'Hedef kullanıcı ID',prefixIcon:Icon(Icons.badge_rounded))),
        const SizedBox(height:10),
        TextField(controller:_coins,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Coin miktarı',prefixIcon:Icon(Icons.monetization_on_rounded))),
        const SizedBox(height:10),
        TextField(controller:_reason,maxLines:2,decoration:const InputDecoration(labelText:'İşlem nedeni',prefixIcon:Icon(Icons.notes_rounded))),
        const SizedBox(height:14),
        FilledButton.icon(
          onPressed:_busy?null:_send,
          icon:const Icon(Icons.send_rounded),
          label:Text(_busy?'Gönderiliyor...':'Coin Gönder'),
        ),
        if(_message!=null)...[
          const SizedBox(height:12),
          Text(_message!,style:const TextStyle(color:LymixPalette.text2)),
        ],
        const SizedBox(height:18),
        Container(
          padding:const EdgeInsets.all(12),
          decoration:BoxDecoration(
            color:Colors.white.withValues(alpha:.035),
            borderRadius:BorderRadius.circular(16),
          ),
          child:const Text(
            'Bu ekran yalnızca owner/super-admin rolüne açık olmalıdır. Tüm manuel coin işlemleri immutable ledger kaydı üretmeli; miktar, hedef ID, admin ID, neden, tarih ve önceki/sonraki bakiye saklanmalıdır.',
            style:TextStyle(fontSize:9,color:LymixPalette.text3,height:1.45),
          ),
        ),
      ],
    ),
  );
}
