import 'package:flutter/material.dart';
import '../core/api_client.dart';
import '../services/auth_service.dart';
import '../services/device_identity_service.dart';
import 'register_screen.dart';

class LoginScreen extends StatefulWidget {
  final VoidCallback onAuthenticated;
  const LoginScreen({super.key, required this.onAuthenticated});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _login = TextEditingController();
  final _password = TextEditingController();
  bool _busy = false;
  bool _hidePassword = true;
  String? _error;

  @override
  void dispose() {
    _login.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_login.text.trim().isEmpty || _password.text.isEmpty) {
      setState(() => _error = 'Kullanıcı adı ve şifre gerekli.');
      return;
    }
    setState(() { _busy = true; _error = null; });
    try {
      final deviceId = await DeviceIdentityService.getOrCreate();
      final auth = AuthService(const ApiClient());
      await auth.login(login: _login.text, password: _password.text, deviceId: deviceId);
      if (mounted) widget.onAuthenticated();
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } catch (_) {
      if (mounted) setState(() => _error = 'Giriş yapılamadı. Tekrar dene.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: const Color(0xFF08070D),
    body: Stack(children: [
      Positioned(top: -120, left: -80, right: -80, child: Container(height: 330, decoration: const BoxDecoration(
        gradient: RadialGradient(colors: [Color(0x66FFCA28), Color(0x221C1232), Colors.transparent], radius: .72),
      ))),
      SafeArea(child: Center(child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 24, 20, 28),
        child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 450), child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 22),
            Center(child: Container(width: 72, height: 72, decoration: BoxDecoration(
              color: const Color(0xFFFFD43B), borderRadius: BorderRadius.circular(24),
              boxShadow: const [BoxShadow(color: Color(0x55FFD43B), blurRadius: 30, spreadRadius: 2)],
            ), child: const Icon(Icons.graphic_eq_rounded, color: Color(0xFF111015), size: 38))),
            const SizedBox(height: 18),
            const Text('LYMIX', textAlign: TextAlign.center, style: TextStyle(fontSize: 38, fontWeight: FontWeight.w900, letterSpacing: 4, color: Colors.white)),
            const SizedBox(height: 5),
            const Text('Sesinle Bağlan, Dünyanı Paylaş', textAlign: TextAlign.center, style: TextStyle(color: Colors.white54, fontSize: 13)),
            const SizedBox(height: 30),
            Container(
              padding: const EdgeInsets.fromLTRB(18, 20, 18, 18),
              decoration: BoxDecoration(
                color: const Color(0xFF14111D), borderRadius: BorderRadius.circular(28),
                border: Border.all(color: Colors.white.withValues(alpha: .07)),
                boxShadow: const [BoxShadow(color: Colors.black38, blurRadius: 28, offset: Offset(0, 16))],
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                const Text('Tekrar hoş geldin', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                const SizedBox(height: 4),
                const Text('Hesabına güvenli şekilde giriş yap.', style: TextStyle(color: Colors.white38, fontSize: 11)),
                const SizedBox(height: 18),
                TextField(controller: _login, enabled: !_busy, textInputAction: TextInputAction.next,
                  autofillHints: const [AutofillHints.username],
                  decoration: const InputDecoration(labelText: 'Kullanıcı adı', prefixIcon: Icon(Icons.person_outline_rounded))),
                const SizedBox(height: 12),
                TextField(controller: _password, enabled: !_busy, obscureText: _hidePassword,
                  autofillHints: const [AutofillHints.password], onSubmitted: (_) => _submit(),
                  decoration: InputDecoration(labelText: 'Şifre', prefixIcon: const Icon(Icons.lock_outline_rounded), suffixIcon: IconButton(
                    onPressed: () => setState(() => _hidePassword = !_hidePassword),
                    icon: Icon(_hidePassword ? Icons.visibility_outlined : Icons.visibility_off_outlined),
                  ))),
                if (_error != null) ...[const SizedBox(height: 10), Text(_error!, textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFFFF91A2), fontSize: 11))],
                const SizedBox(height: 16),
                SizedBox(height: 54, child: FilledButton(onPressed: _busy ? null : _submit,
                  style: FilledButton.styleFrom(backgroundColor: const Color(0xFFFFD43B), foregroundColor: const Color(0xFF111015), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
                  child: _busy ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('Giriş Yap', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15)))),
                const SizedBox(height: 14),
                Row(children: [Expanded(child: Divider(color: Colors.white.withValues(alpha: .08))), const Padding(padding: EdgeInsets.symmetric(horizontal: 10), child: Text('veya', style: TextStyle(color: Colors.white30, fontSize: 10))), Expanded(child: Divider(color: Colors.white.withValues(alpha: .08)))]),
                const SizedBox(height: 10),
                OutlinedButton.icon(
                  onPressed: _busy ? null : () async => Navigator.of(context).push(MaterialPageRoute(builder: (_) => RegisterScreen(onAuthenticated: widget.onAuthenticated))),
                  icon: const Icon(Icons.person_add_alt_1_rounded), label: const Text('Yeni Hesap Oluştur'),
                  style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(50), foregroundColor: Colors.white, side: BorderSide(color: Colors.white.withValues(alpha: .12)), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
                ),
              ]),
            ),
            const SizedBox(height: 16),
            const Text('Yayıncı / ajans doğrulaması hesap açılışından ayrıdır ve yalnızca yayıncı olarak katılım sırasında başlatılır.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white30, fontSize: 9.5, height: 1.4)),
          ],
        )),
      ))),
    ]),
  );
}
