import 'package:flutter/material.dart';
import '../design/lymix_design_system.dart';
import '../models/room_models.dart';
import '../widgets/room_role_badge.dart';

class SeatProfileSheet extends StatelessWidget {
  final RoomMember member;
  final VoidCallback? onLeaveSeat;
  final VoidCallback? onMute;
  const SeatProfileSheet({
    super.key,
    required this.member,
    this.onLeaveSeat,
    this.onMute,
  });

  @override
  Widget build(BuildContext context) => SafeArea(
    top:false,
    child: Container(
      padding:const EdgeInsets.fromLTRB(16,14,16,24),
      decoration:const BoxDecoration(
        color:Color(0xFF171025),
        borderRadius:BorderRadius.vertical(top:Radius.circular(28)),
      ),
      child:Column(mainAxisSize:MainAxisSize.min,children:[
        CircleAvatar(
          radius:46,
          backgroundColor:LymixPalette.surface2,
          backgroundImage:member.avatarUrl==null?null:NetworkImage(member.avatarUrl!),
          child:member.avatarUrl==null?const Icon(Icons.person_rounded,size:42):null,
        ),
        const SizedBox(height:10),
        Row(mainAxisAlignment:MainAxisAlignment.center,children:[
          Flexible(child:Text(member.displayName,
            style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900))),
          const SizedBox(width:6),
          RoomRoleBadge(role:member.role,compact:false),
        ]),
        const SizedBox(height:4),
        Text('ID: ${member.userId}',
          style:const TextStyle(color:LymixPalette.text3,fontSize:10)),
        const SizedBox(height:16),
        Row(children:[
          Expanded(child:_Action(Icons.volume_off_rounded,'Sesini kapat',onMute)),
          const SizedBox(width:8),
          if(onLeaveSeat!=null)
            Expanded(child:_Action(Icons.event_seat_rounded,'Koltuktan kalk',onLeaveSeat)),
        ]),
      ]),
    ),
  );
}

class _Action extends StatelessWidget{
  final IconData icon;
  final String label;
  final VoidCallback? onTap;
  const _Action(this.icon,this.label,this.onTap);
  @override
  Widget build(BuildContext context)=>InkWell(
    onTap:onTap,
    borderRadius:BorderRadius.circular(16),
    child:Container(
      padding:const EdgeInsets.symmetric(vertical:14),
      decoration:BoxDecoration(
        color:Colors.white.withValues(alpha:.04),
        borderRadius:BorderRadius.circular(16),
        border:Border.all(color:Colors.white.withValues(alpha:.055)),
      ),
      child:Column(children:[
        Icon(icon,color:LymixPalette.pink),
        const SizedBox(height:5),
        Text(label,style:const TextStyle(fontSize:9.5,fontWeight:FontWeight.w800)),
      ]),
    ),
  );
}
