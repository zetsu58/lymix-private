import 'package:flutter/material.dart';
import '../design/lymix_design_system.dart';
import '../models/room_models.dart';
import '../widgets/room_role_badge.dart';

class RoomDetailsSheet extends StatelessWidget {
  final RoomInfo info;
  final List<RoomMember> members;
  const RoomDetailsSheet({
    super.key,
    required this.info,
    required this.members,
  });

  @override
  Widget build(BuildContext context) {
    final admins = members.where((m) => m.role == RoomRole.admin).length;
    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
        decoration: const BoxDecoration(
          color: Color(0xFF140E20),
          borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            width: 42, height: 4,
            decoration: BoxDecoration(
              color: Colors.white24,
              borderRadius: BorderRadius.circular(99),
            ),
          ),
          const SizedBox(height: 14),
          Row(children: [
            CircleAvatar(
              radius: 28,
              backgroundColor: LymixPalette.surface2,
              backgroundImage: info.coverUrl == null ? null : NetworkImage(info.coverUrl!),
              child: info.coverUrl == null
                  ? const Icon(Icons.graphic_eq_rounded, color: LymixPalette.gold)
                  : null,
            ),
            const SizedBox(width: 12),
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  Flexible(child: Text(info.name,
                    maxLines:1, overflow:TextOverflow.ellipsis,
                    style: const TextStyle(fontSize:17,fontWeight:FontWeight.w900))),
                  if (info.verified) ...[
                    const SizedBox(width:5),
                    const Icon(Icons.verified_rounded,color:LymixPalette.gold,size:15),
                  ],
                ]),
                const SizedBox(height:4),
                Text('Oda ID: ${info.roomId}',
                  style: const TextStyle(color:LymixPalette.text3,fontSize:10)),
              ],
            )),
          ]),
          const SizedBox(height: 16),
          Row(children: [
            _Metric('Üye', info.memberCount.toString()),
            _Metric('Online', info.onlineCount.toString()),
            _Metric('Admin', admins.toString()),
            _Metric('Seviye', 'Lv${info.level}'),
          ]),
          const SizedBox(height: 14),
          _Row('Kategori', info.category),
          _Row('Ajans', info.agencyName ?? 'Bağımsız oda'),
          _Row('Oda sahibi', info.ownerUserId),
          if (info.announcement.isNotEmpty)
            _Row('Duyuru', info.announcement),
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.close_rounded),
            label: const Text('Kapat'),
          ),
        ]),
      ),
    );
  }
}

class _Metric extends StatelessWidget {
  final String label, value;
  const _Metric(this.label, this.value);
  @override
  Widget build(BuildContext context) => Expanded(
    child: Container(
      margin: const EdgeInsets.symmetric(horizontal:3),
      padding: const EdgeInsets.symmetric(vertical:10),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha:.035),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color:Colors.white.withValues(alpha:.05)),
      ),
      child: Column(children:[
        Text(value,style:const TextStyle(fontWeight:FontWeight.w900,fontSize:13)),
        const SizedBox(height:2),
        Text(label,style:const TextStyle(color:LymixPalette.text3,fontSize:8.5)),
      ]),
    ),
  );
}

class _Row extends StatelessWidget {
  final String a,b;
  const _Row(this.a,this.b);
  @override
  Widget build(BuildContext context)=>Padding(
    padding: const EdgeInsets.symmetric(vertical:6),
    child: Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
      SizedBox(width:90,child:Text(a,style:const TextStyle(color:LymixPalette.text3,fontSize:9.5))),
      Expanded(child:Text(b,style:const TextStyle(fontSize:10.5,fontWeight:FontWeight.w700))),
    ]),
  );
}
