import 'package:flutter/material.dart';
import '../core/api_client.dart';
import '../services/auth_service.dart';
import '../services/device_identity_service.dart';

class RegisterScreen extends StatefulWidget {
  final VoidCallback onAuthenticated;
  const RegisterScreen({super.key, required this.onAuthenticated});
  @override State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final login = TextEditingController();
  final displayName = TextEditingController();
  final password = TextEditingController();
  bool busy = false, hide = true;
  String? error;

  @override
  void dispose() {
    login.dispose();
    displayName.dispose();
    password.dispose();
    super.dispose();
  }

  Future<void> register() async {
    if (login.text.trim().length < 3 || displayName.text.trim().length < 2 || password.text.length < 8) {
      setState(() => error = 'Kullanıcı adı ve görünen adı doldur. Şifre en az 8 karakter olmalı.');
      return;
    }
    setState(() { busy = true; error = null; });
    try {
      final deviceId = await DeviceIdentityService.getOrCreate();
      await AuthService(const ApiClient()).register(
        login: login.text,
        displayName: displayName.text,
        password: password.text,
        deviceId: deviceId,
      );
      if (mounted) widget.onAuthenticated();
    } on ApiException catch (e) {
      if (mounted) setState(() => error = e.message);
    } catch (_) {
      if (mounted) setState(() => error = 'Kayıt tamamlanamadı. Tekrar dene.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: const Color(0xFF0D0B14),
    appBar: AppBar(backgroundColor: Colors.transparent, title: const Text('Hesap Oluştur')),
    body: SafeArea(
      child: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 440),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              const Icon(Icons.graphic_eq_rounded, size: 42, color: Color(0xFFFFD200)),
              const SizedBox(height: 12),
              const Text('LYMIX', textAlign: TextAlign.center, style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, letterSpacing: 3, color: Color(0xFFFFD200))),
              const SizedBox(height: 8),
              const Text('Hızlıca hesabını oluştur. Telefon doğrulaması yalnızca yayıncı/ajans başvurusunda istenir.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white54, height: 1.35)),
              const SizedBox(height: 24),
              TextField(controller: login, enabled: !busy, autocorrect: false, decoration: const InputDecoration(labelText: 'Kullanıcı adı', prefixIcon: Icon(Icons.alternate_email_rounded))),
              const SizedBox(height: 12),
              TextField(controller: displayName, enabled: !busy, decoration: const InputDecoration(labelText: 'Görünen ad', prefixIcon: Icon(Icons.person_outline_rounded))),
              const SizedBox(height: 12),
              TextField(
                controller: password,
                enabled: !busy,
                obscureText: hide,
                decoration: InputDecoration(
                  labelText: 'Şifre (en az 8 karakter)',
                  prefixIcon: const Icon(Icons.lock_outline_rounded),
                  suffixIcon: IconButton(onPressed: () => setState(() => hide = !hide), icon: Icon(hide ? Icons.visibility_outlined : Icons.visibility_off_outlined)),
                ),
              ),
              const SizedBox(height: 16),
              SizedBox(height: 52, child: FilledButton(onPressed: busy ? null : register, child: busy ? const CircularProgressIndicator(strokeWidth: 2) : const Text('Hesap Oluştur', style: TextStyle(fontWeight: FontWeight.w800)))),
              if (error != null) ...[
                const SizedBox(height: 12),
                Text(error!, textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFFFF91A2), fontSize: 12)),
              ],
            ]),
          ),
        ),
      ),
    ),
  );
}
