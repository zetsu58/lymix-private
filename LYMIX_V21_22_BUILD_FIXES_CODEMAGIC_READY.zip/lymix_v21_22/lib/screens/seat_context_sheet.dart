import 'package:flutter/material.dart';
import '../design/lymix_design_system.dart';

class SeatContextSheet extends StatelessWidget {
  final bool occupied;
  final bool currentUserSeated;
  final bool targetIsCurrentUser;
  final bool locked;
  final VoidCallback? onSit;
  final VoidCallback? onLeave;
  final VoidCallback? onInvite;
  final VoidCallback? onMute;
  final VoidCallback? onLockToggle;

  const SeatContextSheet({
    super.key,
    required this.occupied,
    required this.currentUserSeated,
    required this.targetIsCurrentUser,
    required this.locked,
    this.onSit,
    this.onLeave,
    this.onInvite,
    this.onMute,
    this.onLockToggle,
  });

  @override
  Widget build(BuildContext context) {
    final actions=<Widget>[];
    if(!occupied && !locked && !currentUserSeated && onSit!=null){
      actions.add(_A(Icons.event_seat_rounded,'Otur',onSit));
    }
    if(targetIsCurrentUser && onLeave!=null){
      actions.add(_A(Icons.exit_to_app_rounded,'Kalk',onLeave));
    }
    if(!occupied && onInvite!=null){
      actions.add(_A(Icons.mark_email_unread_rounded,'Davet et',onInvite));
    }
    if(occupied && onMute!=null){
      actions.add(_A(Icons.mic_off_rounded,'Sesini kapat',onMute));
    }
    if(onLockToggle!=null){
      actions.add(_A(locked?Icons.lock_open_rounded:Icons.lock_rounded,
        locked?'Koltuğu aç':'Koltuğu kapat',onLockToggle));
    }

    return SafeArea(
      top:false,
      child:Container(
        padding:const EdgeInsets.fromLTRB(16,12,16,22),
        decoration:const BoxDecoration(
          color:Color(0xFF171025),
          borderRadius:BorderRadius.vertical(top:Radius.circular(26)),
        ),
        child:Wrap(
          spacing:10,runSpacing:10,
          children:actions,
        ),
      ),
    );
  }
}

class _A extends StatelessWidget{
  final IconData icon;final String label;final VoidCallback? onTap;
  const _A(this.icon,this.label,this.onTap);
  @override
  Widget build(BuildContext context)=>SizedBox(
    width:84,
    child:InkWell(
      onTap:onTap,
      borderRadius:BorderRadius.circular(16),
      child:Column(children:[
        Container(
          width:62,height:62,
          decoration:BoxDecoration(
            color:Colors.white.withValues(alpha:.045),
            borderRadius:BorderRadius.circular(18),
            border:Border.all(color:Colors.white.withValues(alpha:.055)),
          ),
          child:Icon(icon,color:LymixPalette.text2),
        ),
        const SizedBox(height:6),
        Text(label,textAlign:TextAlign.center,
          style:const TextStyle(fontSize:9,color:LymixPalette.text2,fontWeight:FontWeight.w700)),
      ]),
    ),
  );
}
