import 'package:flutter/material.dart';
import '../design/lymix_design_system.dart';
import 'direct_message_screen.dart';
import 'room_screen.dart';
import 'report_center_screen.dart';

class UserProfileScreen extends StatefulWidget {
  final String userId;
  final String displayName;
  final int vipLevel;
  final String? openRoomId;
  final String? openRoomTitle;
  final bool privateRoom;

  const UserProfileScreen({
    super.key,
    required this.userId,
    required this.displayName,
    this.vipLevel = 0,
    this.openRoomId,
    this.openRoomTitle,
    this.privateRoom = false,
  });

  @override
  State<UserProfileScreen> createState() => _UserProfileScreenState();
}

class _UserProfileScreenState extends State<UserProfileScreen> {
  bool following = false;

  bool get canJoinRoom =>
      !widget.privateRoom &&
      (widget.openRoomId?.isNotEmpty ?? false);

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('Profil'),
          actions: [
            IconButton(
              tooltip: 'Şikayet / Engelle',
              onPressed: _safetySheet,
              icon: const Icon(Icons.more_horiz_rounded),
            ),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 32),
          children: [
            Center(
              child: Stack(
                alignment: Alignment.bottomRight,
                children: [
                  Container(
                    width: 118,
                    height: 118,
                    padding: const EdgeInsets.all(3),
                    decoration: const BoxDecoration(
                      gradient: LymixPalette.brand,
                      shape: BoxShape.circle,
                    ),
                    child: CircleAvatar(
                      backgroundColor: LymixPalette.surface2,
                      child: Text(
                        widget.displayName.isEmpty
                            ? '?'
                            : widget.displayName.characters.first.toUpperCase(),
                        style: const TextStyle(
                          fontSize: 38,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ),
                  if (widget.vipLevel > 0)
                    const LymixPremiumBadge('VIP', icon: Icons.workspace_premium_rounded),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Text(
              widget.displayName,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 4),
            Text(
              'Lymix ID: ${widget.userId}',
              textAlign: TextAlign.center,
              style: const TextStyle(color: LymixPalette.text3, fontSize: 11),
            ),
            const SizedBox(height: 18),
            Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    onPressed: () => setState(() => following = !following),
                    icon: Icon(following ? Icons.done_rounded : Icons.person_add_alt_1_rounded),
                    label: Text(following ? 'Takip Ediliyor' : 'Takip Et'),
                  ),
                ),
                const SizedBox(width: 9),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => DirectMessageScreen(
                          userId: widget.userId,
                          displayName: widget.displayName,
                          openRoomId: widget.openRoomId,
                          openRoomTitle: widget.openRoomTitle,
                          privateRoom: widget.privateRoom,
                        ),
                      ),
                    ),
                    icon: const Icon(Icons.chat_bubble_outline_rounded),
                    label: const Text('Mesaj'),
                  ),
                ),
              ],
            ),
            if (canJoinRoom) ...[
              const SizedBox(height: 9),
              SizedBox(
                height: 50,
                child: OutlinedButton.icon(
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => LymixRoomScreen(
                        roomId: widget.openRoomId!,
                        roomTitle: widget.openRoomTitle ?? 'Sesli Oda',
                      ),
                    ),
                  ),
                  icon: const Icon(Icons.graphic_eq_rounded, color: LymixPalette.gold),
                  label: Text('${widget.openRoomTitle ?? 'Açık oda'} • Yanına Git'),
                ),
              ),
            ],
            const SizedBox(height: 18),
            const LymixGlassSurface(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _ProfileMetric('0', 'Takipçi'),
                  _ProfileMetric('0', 'Takip'),
                  _ProfileMetric('0', 'Hediye'),
                ],
              ),
            ),
            const SizedBox(height: 14),
            const LymixGlassSurface(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Hakkında', style: TextStyle(fontWeight: FontWeight.w900)),
                  SizedBox(height: 7),
                  Text(
                    'Kullanıcı profil bilgileri backend’den geldiğinde burada görüntülenecek. Lymix sahte biyografi, takipçi veya hediye sayısı üretmez.',
                    style: TextStyle(color: LymixPalette.text2, height: 1.4),
                  ),
                ],
              ),
            ),
          ],
        ),
      );

  void _safetySheet() => showModalBottomSheet(
        context: context,
        builder: (ctx) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              ListTile(
                leading: const Icon(Icons.block_rounded),
                title: const Text('Engelle'),
                onTap: () {
                  Navigator.pop(ctx);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('${widget.displayName} engelleme isteği güvenlik servisine gönderildi.')),
                  );
                },
              ),
              ListTile(
                leading: const Icon(Icons.flag_outlined),
                title: const Text('Şikayet Et'),
                onTap: () {
                  Navigator.pop(ctx);
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: (_) => ReportCenterScreen(
                      targetUserId: widget.userId,
                      targetUserName: widget.displayName,
                    ),
                  ));
                },
              ),
            ]),
          ),
        ),
      );
}

class _ProfileMetric extends StatelessWidget {
  final String value;
  final String label;
  const _ProfileMetric(this.value, this.label);
  @override
  Widget build(BuildContext context) => Column(children: [
        Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
        const SizedBox(height: 2),
        Text(label, style: const TextStyle(color: LymixPalette.text3, fontSize: 10)),
      ]);
}
