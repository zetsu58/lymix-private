import 'package:flutter/material.dart';
import '../core/api_client.dart';
import '../services/session_service.dart';
import '../theme/lymix_theme.dart';

class AccountSecurityScreen extends StatefulWidget { const AccountSecurityScreen({super.key}); @override State<AccountSecurityScreen> createState()=>_AccountSecurityScreenState(); }
class _AccountSecurityScreenState extends State<AccountSecurityScreen>{
 final phone=TextEditingController(text:'+90'); final code=TextEditingController(); final current=TextEditingController(); final next=TextEditingController(); bool busy=false; bool codeSent=false;
 ApiClient get api=>ApiClient(tokenProvider:SessionService.token);
 @override void dispose(){phone.dispose();code.dispose();current.dispose();next.dispose();super.dispose();}
 void msg(String s){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s)));}
 Future<void> sendCode()async{if(busy)return;setState(()=>busy=true);try{await api.postJson('/api/security/phone/start',{'phone':phone.text.trim()});if(mounted)setState(()=>codeSent=true);msg('Doğrulama kodu SMS ile gönderildi.');}catch(e){msg('Kod gönderilemedi: $e');}finally{if(mounted)setState(()=>busy=false);}}
 Future<void> verify()async{if(busy)return;setState(()=>busy=true);try{await api.postJson('/api/security/phone/check',{'phone':phone.text.trim(),'code':code.text.trim()});msg('Telefon numarası doğrulandı.');}catch(e){msg('Kod doğrulanamadı: $e');}finally{if(mounted)setState(()=>busy=false);}}
 Future<void> changePassword()async{if(next.text.length<8){msg('Yeni şifre en az 8 karakter olmalı.');return;}setState(()=>busy=true);try{await api.postJson('/api/security/password/change',{'currentPassword':current.text,'newPassword':next.text});current.clear();next.clear();msg('Şifre değiştirildi.');}catch(e){msg('Şifre değiştirilemedi: $e');}finally{if(mounted)setState(()=>busy=false);}}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Hesap ve Güvenlik')),body:ListView(padding:const EdgeInsets.all(16),children:[
  _card('Telefon doğrulama',Icons.phone_android_rounded,[TextField(controller:phone,keyboardType:TextInputType.phone,decoration:const InputDecoration(labelText:'Telefon (+905...)')),const SizedBox(height:10),if(codeSent)...[TextField(controller:code,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'SMS doğrulama kodu')),const SizedBox(height:10)],Row(children:[Expanded(child:FilledButton(onPressed:busy?null:sendCode,child:Text(codeSent?'Kodu yeniden gönder':'Kod gönder'))),if(codeSent)...[const SizedBox(width:8),Expanded(child:OutlinedButton(onPressed:busy?null:verify,child:const Text('Doğrula')))]])]),
  const SizedBox(height:14),
  _card('Şifre değiştir',Icons.password_rounded,[TextField(controller:current,obscureText:true,decoration:const InputDecoration(labelText:'Mevcut şifre')),const SizedBox(height:10),TextField(controller:next,obscureText:true,decoration:const InputDecoration(labelText:'Yeni şifre (en az 8 karakter)')),const SizedBox(height:10),SizedBox(width:double.infinity,child:FilledButton(onPressed:busy?null:changePassword,child:const Text('Şifreyi değiştir')))]),
  const SizedBox(height:14),const Text('Güvenlik kodları yalnızca sunucu üzerinden doğrulanır. Twilio anahtarları APK içine gömülmez.',style:TextStyle(color:Colors.white38,fontSize:10,height:1.4))]));
 Widget _card(String title,IconData icon,List<Widget> children)=>Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:LymixColors.surface,borderRadius:BorderRadius.circular(20),border:Border.all(color:Colors.white10)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[Icon(icon,color:LymixColors.gold),const SizedBox(width:9),Text(title,style:const TextStyle(fontWeight:FontWeight.w900,fontSize:16))]),const SizedBox(height:14),...children]));
}
