import 'package:flutter/material.dart';
import '../design/lymix_design_system.dart';
import '../models/room_models.dart';

class RoomSettingsScreen extends StatelessWidget {
  final RoomInfo info;
  final VoidCallback onMembers;
  final VoidCallback onAdmins;
  const RoomSettingsScreen({
    super.key,
    required this.info,
    required this.onMembers,
    required this.onAdmins,
  });

  @override
  Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Oda Ayarları')),
    body:ListView(
      padding:const EdgeInsets.fromLTRB(14,10,14,30),
      children:[
        _section('Oda Kimliği',[
          _tile(Icons.image_rounded,'Kapak','Oda kapak görselini düzenle',(){}),
          _tile(Icons.sell_rounded,'Yayın odası etiketi',info.category,(){}),
          _tile(Icons.campaign_rounded,'Duyuru',info.announcement.isEmpty?'Henüz duyuru yok':info.announcement,(){}),
          _tile(Icons.photo_library_rounded,'Duyuru resmi','Oda içi duyuru görseli',(){}),
        ]),
        _section('Üyelik & Yönetim',[
          _tile(Icons.groups_rounded,'Oda üyeleri','Üye listesi, ID ve roller',onMembers),
          _tile(Icons.shield_rounded,'Yöneticiler','Admin atama / kaldırma',onAdmins),
        ]),
        _section('Koltuklar',[
          _tile(Icons.event_seat_rounded,'Koltuk yönetimi','Kilit, davet ve mikrofon izinleri',(){}),
          _tile(Icons.mic_rounded,'Mic modu','Koltuk mikrofon davranışını ayarla',(){}),
        ]),
        _section('İçerik & Medya',[
          _tile(Icons.music_note_rounded,'Müzik','Oda içi müzik kontrolleri',(){}),
          _tile(Icons.graphic_eq_rounded,'Ses efekti','Ses efektleri',(){}),
          _tile(Icons.wallpaper_rounded,'Arkaplan','Oda arka planı ve tema',(){}),
        ]),
        _section('Güvenlik',[
          _tile(Icons.lock_rounded,'Oda kilidi','Şifreli / kapalı oda ayarları',(){}),
          _tile(Icons.person_remove_rounded,'Engellenenler','Odaya giriş engeli verilen kullanıcılar',(){}),
          _tile(Icons.cleaning_services_rounded,'Metni temizle','Sohbet akışını temizle',(){}),
        ]),
        _section('PK & Oyun',[
          _tile(Icons.flash_on_rounded,'PK ayarları','Süre, reset ve koltuk davranışı',(){}),
          _tile(Icons.sports_esports_rounded,'Oyun merkezi','Oda içi mini oyunlar',(){}),
        ]),
      ],
    ),
  );

  Widget _section(String title,List<Widget> children)=>Padding(
    padding:const EdgeInsets.only(bottom:16),
    child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Padding(
        padding:const EdgeInsets.fromLTRB(4,0,4,7),
        child:Text(title,style:const TextStyle(fontSize:12,fontWeight:FontWeight.w900)),
      ),
      ...children,
    ]),
  );

  Widget _tile(IconData icon,String title,String subtitle,VoidCallback onTap)=>Padding(
    padding:const EdgeInsets.only(bottom:7),
    child:ListTile(
      onTap:onTap,
      tileColor:Colors.white.withValues(alpha:.035),
      shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(16)),
      leading:Container(
        width:40,height:40,
        decoration:BoxDecoration(
          color:LymixPalette.purple.withValues(alpha:.10),
          borderRadius:BorderRadius.circular(12),
        ),
        child:Icon(icon,color:LymixPalette.gold,size:20),
      ),
      title:Text(title,style:const TextStyle(fontSize:11,fontWeight:FontWeight.w900)),
      subtitle:Text(subtitle,style:const TextStyle(fontSize:8.8,color:LymixPalette.text3)),
      trailing:const Icon(Icons.chevron_right_rounded),
    ),
  );
}
