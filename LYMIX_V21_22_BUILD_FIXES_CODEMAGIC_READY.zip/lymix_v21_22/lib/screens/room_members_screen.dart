import 'package:flutter/material.dart';
import '../design/lymix_design_system.dart';
import '../models/room_models.dart';
import '../widgets/room_role_badge.dart';

class RoomMembersScreen extends StatelessWidget {
  final List<RoomMember> members;
  final String currentUserId;
  final void Function(RoomMember member, bool enabled) onAdminToggle;
  final void Function(RoomMember member) onRemove;
  final void Function(RoomMember member, bool banned) onBanToggle;

  const RoomMembersScreen({
    super.key,
    required this.members,
    required this.currentUserId,
    required this.onAdminToggle,
    required this.onRemove,
    required this.onBanToggle,
  });

  @override
  Widget build(BuildContext context) {
    if (members.isEmpty) {
      return const Scaffold(
        body: Center(child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.group_off_rounded,size:72,color:Colors.white24),
            SizedBox(height:12),
            Text('Henüz oda üyesi yok',
              style:TextStyle(color:LymixPalette.text3,fontWeight:FontWeight.w700)),
          ],
        )),
      );
    }

    return Scaffold(
      appBar: AppBar(title: Text('Oda üyeleri (${members.length})')),
      body: ListView.separated(
        padding: const EdgeInsets.fromLTRB(12,8,12,24),
        itemCount: members.length,
        separatorBuilder:(_,__)=>const SizedBox(height:8),
        itemBuilder:(_,i){
          final m=members[i];
          return Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha:.035),
              borderRadius: BorderRadius.circular(17),
              border: Border.all(color:Colors.white.withValues(alpha:.055)),
            ),
            child: Row(children:[
              CircleAvatar(
                radius:24,
                backgroundColor:LymixPalette.surface2,
                backgroundImage:m.avatarUrl==null?null:NetworkImage(m.avatarUrl!),
                child:m.avatarUrl==null?const Icon(Icons.person_rounded):null,
              ),
              const SizedBox(width:10),
              Expanded(child:Column(
                crossAxisAlignment:CrossAxisAlignment.start,
                children:[
                  Row(children:[
                    Flexible(child:Text(m.displayName,
                      maxLines:1,overflow:TextOverflow.ellipsis,
                      style:const TextStyle(fontWeight:FontWeight.w900))),
                    const SizedBox(width:5),
                    RoomRoleBadge(role:m.role),
                  ]),
                  const SizedBox(height:4),
                  Text('ID: ${m.userId}',
                    style:const TextStyle(color:LymixPalette.text3,fontSize:9)),
                  const SizedBox(height:2),
                  Text(
                    '${m.online ? "Çevrimiçi" : "Çevrimdışı"} • Üyelik ${m.joinedAt.year}-${m.joinedAt.month.toString().padLeft(2,"0")}-${m.joinedAt.day.toString().padLeft(2,"0")}',
                    style:TextStyle(
                      color:m.online?LymixPalette.success:LymixPalette.text3,
                      fontSize:8.5),
                  ),
                ],
              )),
              if(m.userId!=currentUserId)
                PopupMenuButton<String>(
                  onSelected:(v){
                    if(v=='adminOn')onAdminToggle(m,true);
                    if(v=='adminOff')onAdminToggle(m,false);
                    if(v=='remove')onRemove(m);
                    if(v=='ban')onBanToggle(m,true);
                    if(v=='unban')onBanToggle(m,false);
                  },
                  itemBuilder:(_)=>[
                    if(m.role==RoomRole.member)
                      const PopupMenuItem(value:'adminOn',child:Text('Yönetici yap')),
                    if(m.role==RoomRole.admin)
                      const PopupMenuItem(value:'adminOff',child:Text('Yöneticiliği kaldır')),
                    PopupMenuItem(
                      value:m.banned?'unban':'ban',
                      child:Text(m.banned?'Engeli kaldır':'Odaya girişini engelle'),
                    ),
                    const PopupMenuItem(value:'remove',child:Text('Üyelikten çıkar')),
                  ],
                ),
            ]),
          );
        },
      ),
    );
  }
}
