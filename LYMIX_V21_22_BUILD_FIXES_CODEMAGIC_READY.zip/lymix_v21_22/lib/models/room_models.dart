enum RoomRole { owner, admin, member }


class RoomMember {
  final String userId;
  final String displayName;
  final String? avatarUrl;
  final RoomRole role;
  final DateTime joinedAt;
  final bool online;
  final bool banned;

  const RoomMember({
    required this.userId,
    required this.displayName,
    this.avatarUrl,
    required this.role,
    required this.joinedAt,
    this.online = false,
    this.banned = false,
  });

  RoomMember copyWith({
    RoomRole? role,
    bool? online,
    bool? banned,
  }) => RoomMember(
    userId: userId,
    displayName: displayName,
    avatarUrl: avatarUrl,
    role: role ?? this.role,
    joinedAt: joinedAt,
    online: online ?? this.online,
    banned: banned ?? this.banned,
  );
}

class RoomInfo {
  final String roomId;
  final String name;
  final String ownerUserId;
  final String? agencyName;
  final String? coverUrl;
  final String category;
  final String announcement;
  final String? announcementImageUrl;
  final int memberCount;
  final int onlineCount;
  final int level;
  final bool verified;

  const RoomInfo({
    required this.roomId,
    required this.name,
    required this.ownerUserId,
    this.agencyName,
    this.coverUrl,
    this.category = 'Sohbet',
    this.announcement = '',
    this.announcementImageUrl,
    this.memberCount = 0,
    this.onlineCount = 0,
    this.level = 1,
    this.verified = false,
  });
}
