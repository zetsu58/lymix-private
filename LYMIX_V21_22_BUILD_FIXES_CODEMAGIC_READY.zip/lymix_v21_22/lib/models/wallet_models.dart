class CoinPackage {
  final String id;
  final int coins;
  final int vipExp;
  final String displayPrice;
  final String currency;
  final String channel;
  final bool enabled;

  const CoinPackage({
    required this.id,
    required this.coins,
    required this.vipExp,
    required this.displayPrice,
    required this.currency,
    required this.channel,
    this.enabled = true,
  });
}

class WalletBalance {
  final int coins;
  final int diamonds;
  const WalletBalance({required this.coins, required this.diamonds});
}
