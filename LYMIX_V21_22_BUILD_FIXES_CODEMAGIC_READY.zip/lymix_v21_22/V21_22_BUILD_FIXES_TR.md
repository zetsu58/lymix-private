# LYMIX V21.22 — Build / QA Düzeltmeleri

Bu sürüm V21.21 tabanından hazırlanmıştır.

- Codemagic yapılandırması V21.17'e bağlı eski ZIP arama/doğrulama akışından çıkarıldı ve doğrudan proje kökünden derleme yapacak şekilde yenilendi.
- `codemagic.yaml` artık Flutter stable + Java 17 ile pub get, backend JS syntax kontrolü, Flutter analyze, test ve debug APK üretimini çalıştırır.
- Yayıncı doğrulama ekranındaki koşulsuz `throw` sonrası tanımsız `row` kullanımından kaynaklanan derleme engeli kaldırıldı.
- Regula liveness sonucu `livenessSessionId` / provider metadata olarak başvuru API'sine bağlandı; yerel video dosyası zorunluluğu kaldırıldı.
- Cüzdan ekranındaki boş Canlı Destek ve İşlem Geçmişi butonları gerçek akışlara bağlandı; kullanıcıya ait son cüzdan hareketleri için endpoint eklendi.
- Profildeki "Şikayet Et" placeholder mesajı gerçek `ReportCenterScreen` navigasyonuna bağlandı.
- Baş Admin ve owner API rotaları genel QA auth ayarından bağımsız olarak zorunlu kimlik doğrulamaya geçirildi.
- Backend ve admin web JavaScript dosyalarının tamamında `node --check` kontrolü geçti.
- `codemagic.yaml` ve GitHub Actions YAML sözdizimi doğrulandı.

Not: Bu çalışma ortamında Flutter SDK kurulu olmadığı için yerel `flutter analyze` / APK build koşturulamadı. Codemagic workflow bu kontrolleri derleme sırasında zorunlu olarak çalıştıracak ve analyzer error varsa build'i durduracaktır.
