const express=require('express');
module.exports=function({wallet}){
  const r=express.Router();

  r.post('/grant',(req,res)=>{
    try{
      const role=String(req.user?.role||req.body?.actorRole||'');
      if(!['owner','super_admin'].includes(role)){
        return res.status(403).json({error:'admin_required'});
      }
      const targetUserId=String(req.body?.targetUserId||'').trim();
      const coins=Number(req.body?.coins||0);
      const reason=String(req.body?.reason||'').trim();
      if(!targetUserId)return res.status(400).json({error:'target_required'});
      const row=wallet.grant({
        adminUserId:String(req.user?.sub||'owner'),
        targetUserId,coins,reason,
      });
      res.json({ok:true,ledger:row});
    }catch(e){
      res.status(400).json({error:String(e.message||'grant_failed')});
    }
  });

  return r;
};
