const express = require('express');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');

function signAccess(user) {
  const secret = process.env.JWT_SECRET;
  if (!secret) throw new Error('JWT_SECRET_NOT_CONFIGURED');
  return jwt.sign(
    { role:user.role, name:user.displayName, level:user.level, badges:user.badges },
    secret,
    { algorithm:'HS256', issuer:process.env.JWT_ISSUER || 'lymix', audience:process.env.JWT_AUDIENCE || 'lymix-app', subject:String(user.id), expiresIn:'15m' }
  );
}

module.exports = function createAuthRoutes({ auth, devices }) {
  const r = express.Router();
  const registerLimiter = rateLimit({ windowMs:10*60*1000, limit:10, standardHeaders:true, legacyHeaders:false });

  // Normal Lymix membership intentionally does not require a phone number.
  // Phone/SMS verification belongs to creator/agency onboarding only.
  r.post('/register', registerLimiter, async (req,res) => {
    try {
      const login = String(req.body?.login || '').trim();
      const displayName = String(req.body?.displayName || login).trim();
      const password = String(req.body?.password || '');
      const deviceId = String(req.body?.deviceId || '');
      if (!/^[a-zA-Z0-9_.]{3,24}$/.test(login)) return res.status(400).json({ error:'invalid_login', message:'Kullanıcı adı 3-24 karakter olmalı; yalnızca harf, rakam, _ ve . kullanılabilir.' });
      if (displayName.length < 2 || displayName.length > 40) return res.status(400).json({ error:'invalid_display_name', message:'Görünen ad 2-40 karakter olmalı.' });
      if (password.length < 8) return res.status(400).json({ error:'weak_password', message:'Şifre en az 8 karakter olmalı.' });
      if (auth.loginExists(login)) return res.status(409).json({ error:'login_taken', message:'Bu kullanıcı adı zaten kullanılıyor.' });

      const user = auth.createUser({ login, displayName, password });
      if (deviceId) devices.upsert({ userId:user.id, deviceName:req.body?.deviceName, platform:req.body?.platform, appVersion:req.body?.appVersion, tokenHash:'' });
      const refreshToken = auth.issueRefreshToken(user.id, deviceId);
      return res.status(201).json({ accessToken:signAccess(user), refreshToken, expiresIn:900, user });
    } catch (e) {
      res.status(e.message === 'login_taken' ? 409 : 503).json({ error:e.message || 'register_failed' });
    }
  });

  r.post('/login', (req,res) => {
    const login = String(req.body?.login || '');
    const password = String(req.body?.password || '');
    const deviceId = String(req.body?.deviceId || '');
    if (!login || !password) return res.status(400).json({ error:'credentials_required' });
    const user = auth.authenticate(login, password);
    if (!user) return res.status(401).json({ error:'invalid_credentials', message:'Kullanıcı adı veya şifre hatalı.' });
    if (deviceId) devices.upsert({ userId:user.id, deviceName:req.body?.deviceName, platform:req.body?.platform, appVersion:req.body?.appVersion, tokenHash:'' });
    const refreshToken = auth.issueRefreshToken(user.id, deviceId);
    return res.json({ accessToken:signAccess(user), refreshToken, expiresIn:900, user });
  });

  r.post('/refresh', (req,res) => {
    const row = auth.consumeRefreshToken(req.body?.refreshToken);
    if (!row) return res.status(401).json({ error:'invalid_refresh_token' });
    const user = auth.findById(row.userId);
    if (!user) return res.status(401).json({ error:'unknown_user' });
    return res.json({ accessToken:signAccess(user), expiresIn:900, user });
  });

  r.post('/logout', (req,res) => {
    if (req.body?.refreshToken) auth.revokeRefreshToken(req.body.refreshToken);
    res.json({ ok:true });
  });

  return r;
};
