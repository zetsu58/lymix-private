const express = require('express');
const crypto = require('crypto');

// Lymix Admin API - demo/reference implementation.
// Production notes:
// - Put this router behind real admin JWT + RBAC.
// - Persist all mutations in PostgreSQL transactions.
// - Store raw IP/phone only when legally necessary; prefer normalized/hashed identifiers.
// - Verification media must be encrypted, access logged and deleted by retention policy.

module.exports = function createAdminRoutes({ users, rooms, io, creatorVerification, audit: auditService }) {
  const router = express.Router();
  const localAudit = [];
  const userMeta = new Map();
  const deviceBans = new Map();
  const ipBans = new Map();
  const accountBans = new Map();
  const agencies = new Map();
  const verificationCases = new Map();
  const featureFlags = new Map([
    ['room_gift_effects', true], ['vip_entry_effects', true], ['coin_rain', true],
    ['game_center', true], ['feed', true], ['agency_module', true]
  ]);
  const economy = { diamondToCoinRate: 1, receiverGiftPercent: 0.70, minCashoutDiamonds: 10000 };

  const now = () => new Date().toISOString();
  const id = (prefix) => `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const normalizePhone = (v) => String(v || '').replace(/[^0-9+]/g, '').slice(0, 24);
  const fingerprint = (v) => crypto.createHash('sha256').update(String(v || '')).digest('hex');
  const getMeta = (userId) => {
    const key = String(userId);
    if (!userMeta.has(key)) userMeta.set(key, {
      userId: key, customId: null, roles: ['user'], gender: null, phone: null,
      phoneVerified: false, deviceHashes: [], ipHashes: [], agencyId: null,
      broadcaster: false, agencyOwner: false, moderator: false,
      realUserVerified: false, vipLevel: 0, level: 1, notes: '', updatedAt: now()
    });
    return userMeta.get(key);
  };
  const actor = (req) => String(req.headers['x-admin-id'] || 'demo-admin');
  const log = (req, action, targetType, targetId, before, after, reason) => {
    localAudit.unshift({ id: id('audit'), at: now(), actorAdminId: actor(req), action, targetType,
      targetId: String(targetId || ''), before: before || null, after: after || null,
      reason: String(reason || '').slice(0, 500) });
    if (localAudit.length > 2000) localAudit.pop();
  };
  const requireUser = (req, res) => {
    const user = users.get(String(req.params.userId || req.body.userId));
    if (!user) { res.status(404).json({ error: 'Kullanıcı bulunamadı' }); return null; }
    return user;
  };

  router.get('/stats', (req, res) => {
    const sockets = io?.sockets?.sockets ? [...io.sockets.sockets.values()] : [];
    const activeUserIds = new Set(sockets.map(s => String(s.userId || '')).filter(Boolean));
    const occupiedSeats = [...rooms.values()].reduce((sum, r) => sum + (r.seats || []).filter(s => s.userId).length, 0);
    const listeners = [...rooms.values()].reduce((sum, r) => sum + Number(r.listeners?.size || 0), 0);
    const totalCoins = [...users.values()].reduce((sum, u) => sum + Number(u.coins || 0), 0);
    const totalDiamonds = [...users.values()].reduce((sum, u) => sum + Number(u.diamonds || 0), 0);
    const mem = process.memoryUsage();
    res.json({
      totalUsers: users.size,
      activeUsers: activeUserIds.size,
      socketConnections: sockets.length,
      activeRooms: rooms.size,
      occupiedSeats,
      roomListeners: listeners,
      totalCoins,
      totalDiamonds,
      uptimeSeconds: Math.floor(process.uptime()),
      memoryMb: Math.round(mem.rss / 1024 / 1024),
      serverTime: now(),
      accountBans: accountBans.size,
      deviceBans: deviceBans.size,
      ipBans: ipBans.size,
      pendingVerifications: [...verificationCases.values()].filter(v => v.status === 'PENDING').length,
      agencies: agencies.size,
      featureFlags: Object.fromEntries(featureFlags)
    });
  });

  router.get('/users', (req, res) => {
    const q = String(req.query.q || '').toLowerCase();
    const result = [...users.values()].map(u => ({ ...u, admin: getMeta(u.id), ban: accountBans.get(String(u.id)) || null }))
      .filter(u => !q || String(u.id).includes(q) || String(u.name || '').toLowerCase().includes(q) || String(u.admin.customId || '').toLowerCase().includes(q));
    res.json(result);
  });

  router.get('/users/:userId', (req, res) => {
    const user = requireUser(req, res); if (!user) return;
    res.json({ user, admin: getMeta(user.id), ban: accountBans.get(String(user.id)) || null });
  });

  router.post('/users/:userId/custom-id', (req, res) => {
    const user = requireUser(req, res); if (!user) return;
    const meta = getMeta(user.id); const before = { ...meta };
    const customId = String(req.body.customId || '').trim().slice(0, 32);
    if (!customId) return res.status(400).json({ error: 'ID boş olamaz' });
    if ([...userMeta.values()].some(m => m.userId !== String(user.id) && m.customId === customId)) return res.status(409).json({ error: 'Bu ID kullanımda' });
    meta.customId = customId; meta.updatedAt = now();
    log(req, 'SET_CUSTOM_ID', 'user', user.id, before, meta, req.body.reason);
    res.json({ success: true, admin: meta });
  });

  router.post('/users/adjust-balance', (req, res) => {
    const user = requireUser(req, res); if (!user) return;
    const type = req.body.type === 'diamonds' ? 'diamonds' : 'coins';
    const mode = req.body.mode === 'set' ? 'set' : 'delta';
    const amount = Math.trunc(Number(req.body.amount || 0));
    if (!Number.isFinite(amount)) return res.status(400).json({ error: 'Geçersiz miktar' });
    const before = { coins: user.coins, diamonds: user.diamonds };
    if (mode === 'set') user[type] = Math.max(0, amount); else user[type] = Math.max(0, Number(user[type] || 0) + amount);
    log(req, 'ADJUST_BALANCE', 'user', user.id, before, { coins: user.coins, diamonds: user.diamonds }, req.body.reason);
    res.json({ success: true, userId: user.id, coins: user.coins, diamonds: user.diamonds });
  });

  router.post('/users/:userId/roles', (req, res) => {
    const user = requireUser(req, res); if (!user) return;
    const meta = getMeta(user.id), before = { ...meta };
    const allowed = new Set(['user','broadcaster','agency_owner','moderator','support','finance','verified_real_user']);
    const roles = [...new Set((Array.isArray(req.body.roles) ? req.body.roles : []).filter(r => allowed.has(r)))];
    if (!roles.includes('user')) roles.unshift('user');
    meta.roles = roles; meta.broadcaster = roles.includes('broadcaster'); meta.agencyOwner = roles.includes('agency_owner');
    meta.moderator = roles.includes('moderator'); meta.realUserVerified = roles.includes('verified_real_user'); meta.updatedAt = now();
    log(req, 'SET_ROLES', 'user', user.id, before, meta, req.body.reason);
    res.json({ success: true, admin: meta });
  });

  router.post('/users/:userId/status', (req, res) => {
    const user = requireUser(req, res); if (!user) return;
    const meta = getMeta(user.id), before = { ...meta };
    if (req.body.gender !== undefined) meta.gender = ['female','male','other','unspecified'].includes(req.body.gender) ? req.body.gender : null;
    if (req.body.vipLevel !== undefined) meta.vipLevel = Math.max(0, Math.min(3, Number(req.body.vipLevel) || 0));
    if (req.body.level !== undefined) meta.level = Math.max(1, Number(req.body.level) || 1);
    if (req.body.notes !== undefined) meta.notes = String(req.body.notes || '').slice(0, 2000);
    meta.updatedAt = now();
    log(req, 'UPDATE_USER_STATUS', 'user', user.id, before, meta, req.body.reason);
    res.json({ success: true, admin: meta });
  });

  router.post('/users/:userId/contact-device', (req, res) => {
    const user = requireUser(req, res); if (!user) return;
    const meta = getMeta(user.id), before = { ...meta };
    if (req.body.phone !== undefined) meta.phone = normalizePhone(req.body.phone);
    if (req.body.phoneVerified !== undefined) meta.phoneVerified = Boolean(req.body.phoneVerified);
    if (req.body.deviceId) {
      const h = fingerprint(`device:${req.body.deviceId}`); if (!meta.deviceHashes.includes(h)) meta.deviceHashes.push(h);
    }
    if (req.body.ip) {
      const h = fingerprint(`ip:${req.body.ip}`); if (!meta.ipHashes.includes(h)) meta.ipHashes.push(h);
    }
    meta.updatedAt = now();
    log(req, 'UPDATE_CONTACT_DEVICE', 'user', user.id, before, { ...meta, phone: meta.phone ? '***' : null }, req.body.reason);
    res.json({ success: true, admin: { ...meta, deviceHashes: meta.deviceHashes.map(x => x.slice(0,12)+'…'), ipHashes: meta.ipHashes.map(x => x.slice(0,12)+'…') } });
  });

  router.post('/users/:userId/ban', (req, res) => {
    const user = requireUser(req, res); if (!user) return;
    const key = String(user.id), before = accountBans.get(key) || null;
    const ban = { userId: key, reason: String(req.body.reason || 'Yönetici işlemi').slice(0,500),
      scope: req.body.scope || 'account', until: req.body.until || null, createdAt: now(), createdBy: actor(req) };
    accountBans.set(key, ban); log(req, 'BAN_ACCOUNT', 'user', key, before, ban, ban.reason);
    io?.sockets?.sockets?.forEach(s => { if (String(s.userId) === key) s.disconnect(true); });
    res.json({ success: true, ban });
  });

  router.delete('/users/:userId/ban', (req, res) => {
    const key = String(req.params.userId); const before = accountBans.get(key) || null; accountBans.delete(key);
    log(req, 'UNBAN_ACCOUNT', 'user', key, before, null, req.body?.reason); res.json({ success: true });
  });

  router.post('/security/device-ban', (req, res) => {
    if (!req.body.deviceId) return res.status(400).json({ error: 'deviceId gerekli' });
    const hash = fingerprint(`device:${req.body.deviceId}`), ban = { hash, reason: String(req.body.reason || '').slice(0,500), until: req.body.until || null, createdAt: now(), createdBy: actor(req) };
    deviceBans.set(hash, ban); log(req, 'BAN_DEVICE', 'device', hash.slice(0,12), null, ban, ban.reason); res.json({ success: true, fingerprint: hash.slice(0,12)+'…' });
  });

  router.post('/security/ip-ban', (req, res) => {
    if (!req.body.ip) return res.status(400).json({ error: 'IP gerekli' });
    const hash = fingerprint(`ip:${req.body.ip}`), ban = { hash, reason: String(req.body.reason || '').slice(0,500), until: req.body.until || null, createdAt: now(), createdBy: actor(req) };
    ipBans.set(hash, ban); log(req, 'BAN_IP', 'ip', hash.slice(0,12), null, ban, ban.reason); res.json({ success: true, fingerprint: hash.slice(0,12)+'…' });
  });

  router.get('/security/bans', (req, res) => res.json({ accounts: [...accountBans.values()], devices: [...deviceBans.values()], ips: [...ipBans.values()] }));

  router.post('/agencies', (req, res) => {
    const agencyId = String(req.body.agencyId || id('agency'));
    const agency = { id: agencyId, name: String(req.body.name || 'Yeni Ajans').slice(0,120), ownerUserId: String(req.body.ownerUserId || ''), roomIds: [], broadcasterIds: [], active: true, createdAt: now() };
    agencies.set(agencyId, agency);
    if (agency.ownerUserId && users.has(agency.ownerUserId)) { const m = getMeta(agency.ownerUserId); m.agencyId = agencyId; m.agencyOwner = true; if (!m.roles.includes('agency_owner')) m.roles.push('agency_owner'); }
    log(req, 'CREATE_AGENCY', 'agency', agencyId, null, agency, req.body.reason); res.status(201).json(agency);
  });

  router.post('/agencies/:agencyId/owner', (req, res) => {
    const agency = agencies.get(String(req.params.agencyId)); if (!agency) return res.status(404).json({ error: 'Ajans bulunamadı' });
    const userId = String(req.body.userId || ''); if (!users.has(userId)) return res.status(404).json({ error: 'Kullanıcı bulunamadı' });
    const before = { ...agency }; agency.ownerUserId = userId; const m = getMeta(userId); m.agencyId = agency.id; m.agencyOwner = true; if (!m.roles.includes('agency_owner')) m.roles.push('agency_owner');
    log(req, 'SET_AGENCY_OWNER', 'agency', agency.id, before, agency, req.body.reason); res.json({ success: true, agency });
  });

  router.post('/agencies/:agencyId/broadcasters', (req, res) => {
    const agency = agencies.get(String(req.params.agencyId)); if (!agency) return res.status(404).json({ error: 'Ajans bulunamadı' });
    const userId = String(req.body.userId || ''); if (!users.has(userId)) return res.status(404).json({ error: 'Kullanıcı bulunamadı' });
    if (!agency.broadcasterIds.includes(userId)) agency.broadcasterIds.push(userId); const m = getMeta(userId); m.agencyId = agency.id; m.broadcaster = true; if (!m.roles.includes('broadcaster')) m.roles.push('broadcaster');
    log(req, 'ADD_AGENCY_BROADCASTER', 'agency', agency.id, null, { userId }, req.body.reason); res.json({ success: true, agency });
  });

  router.post('/rooms/:roomId/agency', (req, res) => {
    const room = rooms.get(String(req.params.roomId)); if (!room) return res.status(404).json({ error: 'Oda bulunamadı' });
    const agencyId = String(req.body.agencyId || ''); const agency = agencies.get(agencyId); if (!agency) return res.status(404).json({ error: 'Ajans bulunamadı' });
    const before = { agencyId: room.agencyId || null }; room.agencyId = agencyId; if (!agency.roomIds.includes(room.id)) agency.roomIds.push(room.id);
    log(req, 'MAKE_AGENCY_ROOM', 'room', room.id, before, { agencyId }, req.body.reason); res.json({ success: true, roomId: room.id, agencyId });
  });

  router.post('/rooms/:roomId/moderate', (req, res) => {
    const room = rooms.get(String(req.params.roomId)); if (!room) return res.status(404).json({ error: 'Oda bulunamadı' });
    const before = { title: room.title, locked: room.locked, suspended: room.suspended || false };
    if (req.body.title !== undefined) room.title = String(req.body.title).slice(0,120);
    if (req.body.locked !== undefined) room.locked = Boolean(req.body.locked);
    if (req.body.suspended !== undefined) room.suspended = Boolean(req.body.suspended);
    io?.to(room.id)?.emit('room_admin_update', { title: room.title, locked: room.locked, suspended: room.suspended || false, reason: req.body.reason || '' });
    log(req, 'MODERATE_ROOM', 'room', room.id, before, room, req.body.reason); res.json({ success: true, room });
  });

  // Manual broadcaster verification. This intentionally does NOT perform face recognition
  // or compare a person's face against other accounts. Duplicate-risk checks use account/device/contact signals.
  router.post('/verifications', (req, res) => {
    const userId = String(req.body.userId || ''); if (!users.has(userId)) return res.status(404).json({ error: 'Kullanıcı bulunamadı' });
    const row = { id: id('verify'), userId, type: req.body.type || 'female_broadcaster_manual', status: 'PENDING',
      evidenceRefs: Array.isArray(req.body.evidenceRefs) ? req.body.evidenceRefs.slice(0,10) : [],
      reviewerNote: '', createdAt: now(), updatedAt: now() };
    verificationCases.set(row.id, row); log(req, 'CREATE_VERIFICATION', 'verification', row.id, null, row, req.body.reason); res.status(201).json(row);
  });

  router.get('/verifications', (req, res) => res.json([...verificationCases.values()]));

  router.post('/verifications/:caseId/review', (req, res) => {
    const row = verificationCases.get(String(req.params.caseId)); if (!row) return res.status(404).json({ error: 'Doğrulama kaydı bulunamadı' });
    const before = { ...row }; const decision = ['APPROVED','REJECTED','NEEDS_MORE_INFO'].includes(req.body.decision) ? req.body.decision : 'NEEDS_MORE_INFO';
    row.status = decision; row.reviewerNote = String(req.body.note || '').slice(0,1000); row.updatedAt = now(); row.reviewedBy = actor(req);
    if (decision === 'APPROVED') { const m = getMeta(row.userId); m.realUserVerified = true; if (!m.roles.includes('verified_real_user')) m.roles.push('verified_real_user'); }
    log(req, 'REVIEW_VERIFICATION', 'verification', row.id, before, row, req.body.note); res.json({ success: true, verification: row });
  });

  router.get('/users/:userId/duplicate-risk', (req, res) => {
    const m = getMeta(String(req.params.userId));
    const matches = [...userMeta.values()].filter(x => x.userId !== m.userId).map(x => ({
      userId: x.userId,
      samePhone: Boolean(m.phone && x.phone && m.phone === x.phone),
      sameDevice: m.deviceHashes.some(h => x.deviceHashes.includes(h)),
      sameIp: m.ipHashes.some(h => x.ipHashes.includes(h))
    })).filter(x => x.samePhone || x.sameDevice || x.sameIp);
    res.json({ userId: m.userId, matches, note: 'Bu sonuç biyometrik yüz eşleştirmesi kullanmaz; telefon/cihaz/IP sinyallerine dayanır.' });
  });

  router.post('/system-message', (req, res) => {
    const payload = { id: id('sys'), userId: req.body.userId ? String(req.body.userId) : null, roomId: req.body.roomId ? String(req.body.roomId) : null,
      title: String(req.body.title || 'Lymix').slice(0,100), message: String(req.body.message || '').slice(0,1000), createdAt: now() };
    if (payload.roomId) io?.to(payload.roomId)?.emit('system_message', payload); else io?.emit?.('system_message', payload);
    log(req, 'SEND_SYSTEM_MESSAGE', payload.roomId ? 'room' : 'system', payload.roomId || payload.userId || 'all', null, payload, req.body.reason); res.json({ success: true, payload });
  });

  router.get('/config', (req, res) => res.json({ featureFlags: Object.fromEntries(featureFlags), economy }));
  router.post('/config/feature', (req, res) => { featureFlags.set(String(req.body.key), Boolean(req.body.enabled)); log(req, 'SET_FEATURE_FLAG', 'config', req.body.key, null, { enabled: Boolean(req.body.enabled) }, req.body.reason); res.json({ success: true }); });
  router.post('/config/economy', (req, res) => {
    const before = { ...economy };
    if (req.body.diamondToCoinRate !== undefined) economy.diamondToCoinRate = Math.max(0, Number(req.body.diamondToCoinRate));
    if (req.body.receiverGiftPercent !== undefined) economy.receiverGiftPercent = Math.max(0, Math.min(1, Number(req.body.receiverGiftPercent)));
    if (req.body.minCashoutDiamonds !== undefined) economy.minCashoutDiamonds = Math.max(0, Number(req.body.minCashoutDiamonds));
    log(req, 'SET_ECONOMY_CONFIG', 'config', 'economy', before, economy, req.body.reason); res.json({ success: true, economy });
  });

  router.get('/creator-verifications', (_req,res) => {
    const rows = creatorVerification?.list?.() || [];
    res.json(rows.map(x => ({
      id:x.id,userId:x.userId,legalName:x.legalName,phone:x.phoneMasked,
      countryCode:x.countryCode,gender:x.gender,agencyId:x.agencyId,
      platform:x.platform,osVersion:x.osVersion,status:x.status,
      createdAt:x.createdAt,updatedAt:x.updatedAt,reviewNote:x.reviewNote,
      livenessStatus:x.livenessStatus || x.faceLivenessStatus || null,
      hasVideo:Boolean(x.verificationVideoPath),
    })));
  });

  router.post('/creator-verifications/:userId/review', (req,res) => {
    try {
      const row = creatorVerification?.review?.(req.params.userId,{
        status:String(req.body?.status||''),
        reviewerId:req.auth?.sub || req.get('x-admin-id') || 'admin',
        note:req.body?.note,
      });
      if(!row)return res.status(404).json({error:'application_not_found'});
      auditService?.record?.({
        actorAdminId:req.auth?.sub || req.get('x-admin-id') || 'admin',
        action:'creator_verification_review',
        targetType:'creator_verification',
        targetId:String(req.params.userId),
        reason:String(req.body?.note||''),
        metadata:{status:row.status,applicationId:row.id},
      });
      res.json({ok:true,status:row.status});
    } catch(e) {
      res.status(400).json({error:e.message||'review_failed'});
    }
  });

  router.get('/agencies', (_req, res) => res.json([...agencies.values()]));
  router.get('/rooms', (_req, res) => res.json([...rooms.values()].map(r => ({
    id:r.id,title:r.title,ownerId:r.ownerId,locked:Boolean(r.locked),suspended:Boolean(r.suspended),
    listeners:Number(r.listeners?.size||0),occupiedSeats:(r.seats||[]).filter(s=>s.userId).length,agencyId:r.agencyId||null
  }))));

  router.get('/audit', (req, res) => {
    const own = localAudit.slice(0, Math.min(500, Number(req.query.limit || 100)));
    const external = auditService?.list?.({limit: Math.min(500, Number(req.query.limit || 100))}) || [];
    res.json([...own, ...external].sort((a,b)=>String(b.at||b.createdAt||'').localeCompare(String(a.at||a.createdAt||''))).slice(0,500));
  });

  return router;
};
