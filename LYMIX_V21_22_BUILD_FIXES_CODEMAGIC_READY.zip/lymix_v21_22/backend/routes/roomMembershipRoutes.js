const express=require('express');
module.exports=function({ roomMembership }){
  const r=express.Router();

  r.get('/:roomId/members',(req,res)=>{
    res.json({ members:roomMembership.list(String(req.params.roomId)) });
  });

  r.post('/:roomId/members',(req,res)=>{
    try{
      const member=roomMembership.add(
        String(req.params.roomId),
        String(req.body?.ownerUserId||req.user?.sub||''),
        String(req.body?.userId||'')
      );
      res.status(201).json({member});
    }catch(e){
      res.status(400).json({error:String(e.message||'member_add_failed')});
    }
  });

  r.post('/:roomId/admin',(req,res)=>{
    try{
      const member=roomMembership.setAdmin(
        String(req.params.roomId),
        String(req.user?.sub||req.body?.actorUserId||''),
        String(req.body?.userId||''),
        req.body?.enabled===true
      );
      res.json({member});
    }catch(e){
      res.status(403).json({error:String(e.message||'admin_update_failed')});
    }
  });

  r.delete('/:roomId/members/:userId',(req,res)=>{
    try{
      roomMembership.remove(
        String(req.params.roomId),
        String(req.user?.sub||req.body?.actorUserId||''),
        String(req.params.userId)
      );
      res.json({ok:true});
    }catch(e){
      res.status(403).json({error:String(e.message||'member_remove_failed')});
    }
  });

  r.post('/:roomId/ban',(req,res)=>{
    try{
      res.json(roomMembership.ban(
        String(req.params.roomId),
        String(req.user?.sub||req.body?.actorUserId||''),
        String(req.body?.userId||''),
        req.body?.banned===true
      ));
    }catch(e){
      res.status(403).json({error:String(e.message||'ban_update_failed')});
    }
  });

  return r;
};
