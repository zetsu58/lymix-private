const express=require('express');
const rateLimit=require('express-rate-limit');
module.exports=function createSecurityRoutes({auth,phoneVerification}){
  const r=express.Router();
  const otpLimiter=rateLimit({windowMs:10*60*1000,limit:5,standardHeaders:true,legacyHeaders:false});
  r.get('/phone',(req,res)=>res.json({phone:auth.getVerifiedPhone(req.auth?.userId||req.auth?.sub)||null,providerConfigured:phoneVerification.configured()}));
  r.post('/phone/start',otpLimiter,async(req,res)=>{try{const result=await phoneVerification.start(req.body?.phone);res.json({ok:true,status:result.status,phone:result.phone});}catch(e){res.status(e.message==='invalid_phone_e164'?400:503).json({error:e.message});}});
  r.post('/phone/check',otpLimiter,async(req,res)=>{try{const phone=phoneVerification.normalizePhone(req.body?.phone);const result=await phoneVerification.check(phone,req.body?.code);if(!result.approved)return res.status(400).json({error:'invalid_or_expired_code'});const row=auth.setVerifiedPhone(req.auth?.userId||req.auth?.sub,phone);res.json({ok:true,phone:row});}catch(e){res.status(400).json({error:e.message});}});
  r.post('/password/change',(req,res)=>{try{const ok=auth.changePassword(req.auth?.userId||req.auth?.sub,req.body?.currentPassword,req.body?.newPassword);if(!ok)return res.status(401).json({error:'current_password_invalid'});res.json({ok:true});}catch(e){res.status(400).json({error:e.message});}});
  return r;
};
