const express = require('express');

module.exports = function createCreatorVerificationRoutes({ verification, audit }) {
  const r = express.Router();

  r.get('/me', (req, res) => {
    const row = verification.get(req.auth.sub);
    if (!row) return res.json({ status: 'NOT_STARTED', phoneVerified: false });
    res.json({
      status: row.status,
      phone: row.phoneMasked,
      phoneVerified: true,
      agencyId: row.agencyId,
      countryCode: row.countryCode,
      updatedAt: row.updatedAt,
      reviewNote: row.reviewNote,
      livenessProvider: row.livenessProvider,
    });
  });

  r.post('/phone/request', (req, res) => {
    try {
      const row = verification.requestPhoneCode(req.auth.sub, req.body?.phone);
      res.json({ ok: true, phone: row.phone, debugCode: row.debugCode });
    } catch (_) {
      res.status(400).json({ error: 'invalid_phone', message: 'Telefon numarası geçersiz.' });
    }
  });

  r.post('/phone/confirm', (req, res) => {
    const ok = verification.confirmPhoneCode(req.auth.sub, req.body?.phone, req.body?.code);
    if (!ok) return res.status(400).json({ error: 'invalid_code', message: 'Kod geçersiz veya süresi dolmuş.' });
    res.json({ ok: true });
  });

  r.post('/submit', (req, res) => {
    try {
      const row = verification.submit(req.auth.sub, req.body || {});
      audit?.record?.({
        actorAdminId: req.auth.sub,
        action: 'creator_verification_submit',
        targetType: 'creator_verification',
        targetId: req.auth.sub,
        reason: 'Creator submitted verification',
        metadata: { applicationId: row.id, livenessProvider: row.livenessProvider },
      });
      res.status(201).json({ id: row.id, status: row.status });
    } catch (e) {
      const code = String(e.message || 'submit_failed');
      const messages = {
        phone_not_verified: 'Telefon doğrulaması tamamlanmamış.',
        liveness_required: 'Canlı yüz doğrulaması gerekli.',
        invalid_liveness_provider: 'Desteklenmeyen canlılık doğrulama sağlayıcısı.',
      };
      res.status(400).json({ error: code, message: messages[code] || 'Başvuru gönderilemedi.' });
    }
  });

  return r;
};
