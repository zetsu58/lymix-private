const crypto = require('crypto');

const applications = new Map();
const phoneChallenges = new Map();

function safePhone(v) {
  return String(v || '').replace(/[^\d+]/g, '').slice(0, 20);
}
function maskPhone(v) {
  const p = safePhone(v);
  return p.length < 6 ? '***' : `${p.slice(0,3)}***${p.slice(-3)}`;
}
function requestPhoneCode(userId, phone) {
  const normalized = safePhone(phone);
  if (normalized.length < 8) throw new Error('invalid_phone');
  const code = String(Math.floor(100000 + Math.random() * 900000));
  const row = {
    userId:String(userId), phone:normalized,
    codeHash:crypto.createHash('sha256').update(code).digest('hex'),
    expiresAt:Date.now()+5*60*1000, attempts:0, verified:false,
  };
  phoneChallenges.set(`${userId}:${normalized}`, row);
  // Production: send via SMS provider. Never log OTP in production.
  return { phone:normalized, debugCode:process.env.NODE_ENV === 'production' ? undefined : code };
}
function confirmPhoneCode(userId, phone, code) {
  const normalized=safePhone(phone);
  const key=`${userId}:${normalized}`;
  const row=phoneChallenges.get(key);
  if(!row || row.expiresAt<Date.now()) return false;
  row.attempts++;
  if(row.attempts>6) return false;
  const hash=crypto.createHash('sha256').update(String(code||'')).digest('hex');
  if(hash!==row.codeHash) return false;
  row.verified=true; row.verifiedAt=Date.now();
  return true;
}
function isPhoneVerified(userId, phone) {
  return phoneChallenges.get(`${userId}:${safePhone(phone)}`)?.verified === true;
}
function submit(userId, payload) {
  if(!isPhoneVerified(userId,payload.phone)) throw new Error('phone_not_verified');
  const provider=String(payload.livenessProvider||'').toLowerCase();
  const sessionId=String(payload.livenessSessionId||'').trim();
  if(!sessionId) throw new Error('liveness_required');
  if(provider!=='regula') throw new Error('invalid_liveness_provider');
  const now=new Date().toISOString();
  const id=applications.get(String(userId))?.id || `cv_${crypto.randomUUID()}`;
  const row={
    id,userId:String(userId),
    legalName:String(payload.legalName||'').trim().slice(0,120),
    phone:safePhone(payload.phone),
    phoneMasked:maskPhone(payload.phone),
    countryCode:String(payload.countryCode||'').toUpperCase().slice(0,3),
    gender:['female','male','other','unspecified'].includes(payload.gender)?payload.gender:'unspecified',
    agencyId:payload.agencyId?String(payload.agencyId).slice(0,80):null,
    installationId:String(payload.installationId||'').slice(0,100),
    platform:String(payload.platform||'').slice(0,30),
    osVersion:String(payload.osVersion||'').slice(0,180),
    livenessProvider:String(payload.livenessProvider||'').toLowerCase(),
    livenessSessionId:String(payload.livenessSessionId||'').slice(0,160),
    status:'PENDING',
    reviewerId:null,reviewNote:null,
    createdAt:applications.get(String(userId))?.createdAt||now,
    updatedAt:now,
  };
  applications.set(String(userId),row);
  return row;
}
function get(userId){return applications.get(String(userId))||null;}
function list(){return [...applications.values()].sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt));}
function review(userId,{status,reviewerId,note}) {
  const row=get(userId); if(!row)return null;
  const allowed=['APPROVED','REJECTED','NEEDS_REVERIFY'];
  if(!allowed.includes(status)) throw new Error('invalid_status');
  row.status=status; row.reviewerId=String(reviewerId||'admin'); row.reviewNote=String(note||'').slice(0,500); row.updatedAt=new Date().toISOString();
  return row;
}
module.exports={requestPhoneCode,confirmPhoneCode,isPhoneVerified,submit,get,list,review};
