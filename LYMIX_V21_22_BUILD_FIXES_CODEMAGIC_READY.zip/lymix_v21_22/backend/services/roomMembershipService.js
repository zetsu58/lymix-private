const rooms = new Map();

function ensureRoom(roomId, ownerUserId) {
  let room = rooms.get(roomId);
  if (!room) {
    room = { roomId, ownerUserId, members:new Map(), banned:new Set() };
    rooms.set(roomId, room);
  }
  if (!room.members.has(ownerUserId)) {
    room.members.set(ownerUserId, {
      userId:ownerUserId,
      role:'owner',
      joinedAt:new Date().toISOString(),
      online:true,
    });
  }
  return room;
}

function list(roomId) {
  return [...(rooms.get(roomId)?.members.values() || [])];
}

function add(roomId, ownerUserId, userId) {
  const room = ensureRoom(roomId, ownerUserId);
  if (room.banned.has(userId)) throw new Error('user_banned');
  if (!room.members.has(userId)) {
    room.members.set(userId, {
      userId,
      role:'member',
      joinedAt:new Date().toISOString(),
      online:false,
    });
  }
  return room.members.get(userId);
}

function requireOwner(room, actorUserId) {
  if (room.ownerUserId !== actorUserId) throw new Error('owner_required');
}
function requireManager(room, actorUserId) {
  const role = room.members.get(actorUserId)?.role;
  if (!['owner','admin'].includes(role)) throw new Error('manager_required');
}

function setAdmin(roomId, actorUserId, targetUserId, enabled) {
  const room = rooms.get(roomId);
  if (!room) throw new Error('room_not_found');
  requireOwner(room, actorUserId);
  const target = room.members.get(targetUserId);
  if (!target) throw new Error('member_not_found');
  if (target.role === 'owner') throw new Error('owner_immutable');
  target.role = enabled ? 'admin' : 'member';
  return target;
}

function remove(roomId, actorUserId, targetUserId) {
  const room = rooms.get(roomId);
  if (!room) throw new Error('room_not_found');
  requireManager(room, actorUserId);
  if (room.ownerUserId === targetUserId) throw new Error('owner_immutable');
  room.members.delete(targetUserId);
  return true;
}

function ban(roomId, actorUserId, targetUserId, banned) {
  const room = rooms.get(roomId);
  if (!room) throw new Error('room_not_found');
  requireManager(room, actorUserId);
  if (room.ownerUserId === targetUserId) throw new Error('owner_immutable');
  if (banned) room.banned.add(targetUserId); else room.banned.delete(targetUserId);
  return { userId:targetUserId, banned };
}

module.exports = { ensureRoom, list, add, setAdmin, remove, ban };
