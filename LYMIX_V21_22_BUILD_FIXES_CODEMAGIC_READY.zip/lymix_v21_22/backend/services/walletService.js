const balances=new Map();
const ledger=[];

const packages=[
  {id:'gp_3350',coins:3350,vipExp:3350,displayPrice:'₺28,99',currency:'TRY',channel:'google_play',enabled:true},
  {id:'gp_6700',coins:6700,vipExp:6700,displayPrice:'₺57,99',currency:'TRY',channel:'google_play',enabled:true},
  {id:'gp_33500',coins:33500,vipExp:33500,displayPrice:'₺289,99',currency:'TRY',channel:'google_play',enabled:true},
  {id:'gp_67500',coins:67500,vipExp:67500,displayPrice:'₺579,99',currency:'TRY',channel:'google_play',enabled:true},
  {id:'card_8200',coins:8200,vipExp:8200,displayPrice:'TRY 48.5',currency:'TRY',channel:'credit_card',enabled:false},
  {id:'card_41000',coins:41000,vipExp:41000,displayPrice:'TRY 242.5',currency:'TRY',channel:'credit_card',enabled:false},
  {id:'trc20_422500',coins:422500,vipExp:422500,displayPrice:'USD 50',currency:'USD',channel:'trc20',enabled:false},
  {id:'erc20_422500',coins:422500,vipExp:422500,displayPrice:'USD 50',currency:'USD',channel:'erc20_bsc',enabled:false},
];

function getBalance(userId){
  if(!balances.has(userId))balances.set(userId,{coins:0,diamonds:0});
  return balances.get(userId);
}

function grant({adminUserId,targetUserId,coins,reason}){
  const amount=Number(coins);
  if(!Number.isInteger(amount)||amount<=0)throw new Error('invalid_amount');
  const before=getBalance(targetUserId).coins;
  const after=before+amount;
  balances.set(targetUserId,{...getBalance(targetUserId),coins:after});
  const row={
    id:`grant_${Date.now()}_${Math.random().toString(36).slice(2,8)}`,
    type:'admin_grant',
    adminUserId,targetUserId,amount,reason:String(reason||''),
    before,after,createdAt:new Date().toISOString(),
  };
  ledger.push(row);
  return row;
}

function listPackages(){return packages;}
function createPurchaseIntent(userId,packageId){
  const p=packages.find(x=>x.id===packageId&&x.enabled);
  if(!p)throw new Error('package_unavailable');
  return {intentId:`pi_${Date.now()}`,userId,package:p,status:'requires_store_purchase'};
}

module.exports={getBalance,grant,listPackages,createPurchaseIntent,ledger};
