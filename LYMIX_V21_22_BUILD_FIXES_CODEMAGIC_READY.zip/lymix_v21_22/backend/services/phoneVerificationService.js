const https = require('https');

function configured() {
  return Boolean(process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN && process.env.TWILIO_VERIFY_SERVICE_SID);
}
function request(path, params) {
  return new Promise((resolve, reject) => {
    if (!configured()) return reject(new Error('TWILIO_VERIFY_NOT_CONFIGURED'));
    const body = new URLSearchParams(params).toString();
    const auth = Buffer.from(`${process.env.TWILIO_ACCOUNT_SID}:${process.env.TWILIO_AUTH_TOKEN}`).toString('base64');
    const req = https.request({ hostname:'verify.twilio.com', path, method:'POST', headers:{ Authorization:`Basic ${auth}`, 'Content-Type':'application/x-www-form-urlencoded', 'Content-Length':Buffer.byteLength(body) } }, res => {
      let data=''; res.on('data', c => data += c); res.on('end', () => {
        let parsed={}; try { parsed=JSON.parse(data||'{}'); } catch (_) {}
        if (res.statusCode >= 200 && res.statusCode < 300) return resolve(parsed);
        const err=new Error(parsed.message || `TWILIO_${res.statusCode}`); err.statusCode=res.statusCode; reject(err);
      });
    });
    req.on('error', reject); req.write(body); req.end();
  });
}
function normalizePhone(value) {
  const phone=String(value||'').replace(/[\s()-]/g,'');
  if (!/^\+[1-9]\d{7,14}$/.test(phone)) throw new Error('invalid_phone_e164');
  return phone;
}
async function start(phone) {
  phone=normalizePhone(phone);
  const sid=process.env.TWILIO_VERIFY_SERVICE_SID;
  const result=await request(`/v2/Services/${encodeURIComponent(sid)}/Verifications`, { To:phone, Channel:'sms' });
  return { phone, status:result.status, sid:result.sid };
}
async function check(phone, code) {
  phone=normalizePhone(phone); code=String(code||'').trim();
  if (!/^\d{4,10}$/.test(code)) throw new Error('invalid_code');
  const sid=process.env.TWILIO_VERIFY_SERVICE_SID;
  const result=await request(`/v2/Services/${encodeURIComponent(sid)}/VerificationCheck`, { To:phone, Code:code });
  return { approved:result.status === 'approved' && result.valid !== false, status:result.status };
}
module.exports={ configured, normalizePhone, start, check };
