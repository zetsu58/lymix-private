const express = require('express');
const paymentRoutes = require('./routes/paymentRoutes');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const { createLaunch, getProvider } = require('./services/gameProviderService');
const createAdminRoutes = require('./routes/adminRoutes');
const vipService = require('./services/vipService');
const createOwnerOpsRoutes = require('./routes/ownerOpsRoutes');
const opsControl = require('./services/opsControlService');
const luckyGift = require('./services/luckyGiftService');
const createPlatformRoutes = require('./routes/platformRoutes');
const createOwnerBootstrapRoutes = require('./routes/ownerBootstrapRoutes');
const createIdentityRoutes = require('./routes/identityRoutes');
const path = require('path');
const wallet = require('./services/walletService');
const createWalletRoutes = require('./routes/walletRoutes');
const createAdminWalletRoutes = require('./routes/adminWalletRoutes');
const roomMembership = require('./services/roomMembershipService');
const createRoomMembershipRoutes = require('./routes/roomMembershipRoutes');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const { httpAuth, socketAuth } = require('./middleware/auth');
const contribution = require('./services/roomContributionService');
const createRoomContributionRoutes = require('./routes/roomContributionRoutes');
const vipEntitlements = require('./services/vipEntitlementService');
const moderation = require('./services/moderationService');
const roleService = require('./services/roleService');
const discovery = require('./services/discoveryService');
const createDiscoveryRoutes = require('./routes/discoveryRoutes');
const antiAbuse = require('./services/antiAbuseService');
const directMessages = require('./services/directMessageService');
const accountRequests = require('./services/accountRequestService');
const audit = require('./services/auditLogService');
const createAuditRoutes = require('./routes/auditRoutes');
const createAccountRoutes = require('./routes/accountRoutes');
const createDirectMessageRoutes = require('./routes/directMessageRoutes');
const remoteConfig = require('./services/remoteConfigService');
const appeals = require('./services/appealService');
const devices = require('./services/deviceSessionService');
const createConfigRoutes = require('./routes/configRoutes');
const createAppealRoutes = require('./routes/appealRoutes');
const createDeviceRoutes = require('./routes/deviceRoutes');
const authService = require('./services/authService');
const createAuthRoutes = require('./routes/authRoutes');
const creatorVerification = require('./services/creatorVerificationService');
const createCreatorVerificationRoutes = require('./routes/creatorVerificationRoutes');
const createSecurityRoutes = require('./routes/securityRoutes');
const phoneVerification = require('./services/phoneVerificationService');

const createModerationRoutes = require('./routes/moderationRoutes');


const app = express();
app.disable('x-powered-by');
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(rateLimit({ windowMs: 60 * 1000, limit: 240, standardHeaders: true, legacyHeaders: false }));
app.use(cors({ origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(',') : '*' }));
app.use(express.json({ limit: '64kb' }));
app.use('/uploads/identity', express.static(path.join(__dirname, 'uploads', 'identity'), { maxAge: '7d', immutable: false }));

// Lymix Admin Web: same-origin static control center.
// Keeping it on the API host avoids leaking admin tokens through URL query strings.
const adminWebDir = path.join(__dirname, '..', 'admin_web');
app.use('/admin', express.static(adminWebDir, {
  maxAge: process.env.NODE_ENV === 'production' ? '10m' : 0,
  index: 'index.html',
}));
app.get('/admin', (_req, res) => res.redirect('/admin/'));

const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: process.env.CORS_ORIGIN || '*', methods: ['GET', 'POST'] }
});

const users = new Map();

// System account: automatically followed for official onboarding/messages.
users.set('lymix-official', {
  id: 'lymix-official',
  name: 'Lymix Official',
  coins: 0,
  diamonds: 0,
  avatar: '',
  role: 'SYSTEM_OFFICIAL',
  level: 9999,
  badges: ['OFFICIAL', 'SYSTEM'],
  systemFollow: true,
  excludedFromSocialCounters: true
});

const ownerAccount = authService.bootstrapOwnerFromEnv();
if (ownerAccount) users.set(ownerAccount.id, { id: ownerAccount.id, name: ownerAccount.displayName, coins: 0, diamonds: 0, avatar: '', role: ownerAccount.role, level: ownerAccount.level, badges: ownerAccount.badges });

const gifts = new Map([
  ['gift_rose', { id: 'gift_rose', name: 'Gül', price: 10, receiverPercent: .70, animationUrl: 'rose.json' }],
  ['gift_heart', { id: 'gift_heart', name: 'Kalp', price: 50, receiverPercent: .70, animationUrl: 'heart.json' }],
  ['gift_car', { id: 'gift_car', name: 'Spor Araba', price: 500, receiverPercent: .70, animationUrl: 'car.json' }],
  ['gift_crown', { id: 'gift_crown', name: 'Taç', price: 1000, receiverPercent: .70, animationUrl: 'crown.json' }]
]);

const rooms = new Map();
function makeRoom(id, title, ownerId) {
  return { id, title, ownerId, createdAt: new Date(), locked: false, listeners: new Set(), followers: new Set(), adminIds: new Set(), joinRequests: new Map(), approvedJoiners: new Set(), seats: Array.from({ length: 8 }, (_, index) => ({
    index, userId: null, userName: null, avatarUrl: null, isMuted: false, locked: false
  })), seatInvites: new Map() };
}

const apiAuth = httpAuth({ users });
const adminAuth = httpAuth({ users, required: true });

const messageRate = new Map();
const giftDedupe = new Map();
const seatGraceTimers = new Map();
function allowMessage(userId) {
  const now = Date.now();
  const row = messageRate.get(userId) || { start: now, count: 0 };
  if (now - row.start > 10000) { row.start = now; row.count = 0; }
  row.count++;
  messageRate.set(userId, row);
  return row.count <= 12;
}
function cleanMessage(value) {
  return String(value ?? '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').trim().slice(0, 500);
}
function getUser(socket) { return users.get(socket.userId); }
function getRoom(socket) { return rooms.get(socket.roomId); }
function requireAdminRole(req, res, next) {
  const role = String(req.auth?.role || 'user');
  if (!['admin','owner'].includes(role)) return res.status(403).json({ error: 'forbidden' });
  next();
}
function canModerateRoom(room, userId) { return !!room && (room.ownerId === userId || room.adminIds?.has(userId)); }
function firstAvailableSeat(room) { return room?.seats?.findIndex(s => !s.userId && !s.locked) ?? -1; }
function emitToRoomModerators(room, event, payload) {
  for (const s of io.sockets.sockets.values()) {
    if (s.roomId === room.id && canModerateRoom(room, s.userId)) s.emit(event, payload);
  }
}

app.get('/health', (_, res) => res.json({ ok: true, service: 'lymix', time: new Date().toISOString() }));
app.get('/api/rooms', (_, res) => res.json([...rooms.values()].map(r => ({
  id: r.id, title: r.title, ownerId: r.ownerId, locked: r.locked,
  listeners: r.listeners.size, occupiedSeats: r.seats.filter(s => s.userId).length
}))));


// Lymix Control Center admin API (protect with real admin JWT/RBAC in production)
app.use('/api/admin', adminAuth, requireAdminRole, createAdminRoutes({ users, rooms, io, creatorVerification, audit }));
app.use('/api/owner-ops', adminAuth, requireAdminRole, createOwnerOpsRoutes({ users, rooms, io }));
app.use('/api/platform', createPlatformRoutes({ io }));
app.use('/api/owner-bootstrap', createOwnerBootstrapRoutes());
app.post('/api/moderation-voice-webhook', (req, res) => {
  const secret = String(process.env.MODERATION_ASR_WEBHOOK_SECRET || '');
  const supplied = String(req.get('x-lymix-asr-secret') || '');
  if (!secret || supplied !== secret) return res.status(401).json({ error: 'invalid_webhook_secret' });

  const userId = String(req.body?.userId || '');
  const roomId = String(req.body?.roomId || '');
  const transcript = String(req.body?.transcript || '').slice(0, 2000);
  const confidence = Number(req.body?.confidence ?? 1);
  const isFinal = req.body?.isFinal !== false;

  if (!users.has(userId) || !rooms.has(roomId) || !transcript || !isFinal) {
    return res.status(202).json({ ok: true, ignored: true });
  }
  if (Number.isFinite(confidence) && confidence < 0.72) {
    return res.status(202).json({ ok: true, ignored: true, reason: 'low_confidence' });
  }

  const result = moderation.applyVoicePolicy(userId, transcript);
  if (result.action !== 'allow') {
    const payload = {
      userId, roomId,
      action: result.action,
      strikes: result.strikes,
      durationMs: result.durationMs || 0,
      message: result.action === 'warning'
        ? `Uygunsuz dil algılandı. Tekrarı halinde mikrofonun geçici olarak kapatılabilir. (${result.strikes}/3)`
        : result.action === 'voice_mute'
          ? 'Tekrarlanan uygunsuz dil nedeniyle mikrofonun 5 dakika süreyle kapatıldı.'
          : 'Tekrarlanan uygunsuz dil nedeniyle odadan 30 dakika uzaklaştırıldın.',
    };
    io.to(roomId).emit('moderation_action', payload);

    if (result.action === 'voice_mute') {
      const room = rooms.get(roomId);
      const seat = room?.seats?.find(s => s.userId === userId);
      if (seat) seat.isMuted = true;
      io.to(roomId).emit('seat_state_changed', { seats: room?.seats });
    }
    if (result.action === 'room_ban') {
      const room = rooms.get(roomId);
      const seat = room?.seats?.find(s => s.userId === userId);
      if (seat) Object.assign(seat, { userId: null, userName: null, avatarUrl: null, isMuted: false });
      io.to(roomId).emit('seat_state_changed', { seats: room?.seats });
      for (const s of io.sockets.sockets.values()) {
        if (s.userId === userId && s.roomId === roomId) {
          s.leave(roomId);
          s.roomId = null;
          s.emit('moderation_removed_from_room', payload);
        }
      }
    }

    moderation.createReport({
      reporterId: 'system-ai',
      targetUserId: userId,
      roomId,
      category: 'voice_profanity',
      description: 'AI ses moderasyonu otomatik kayıt oluşturdu.',
      source: 'voice_ai',
      evidence: [{ type: 'transcript_excerpt', value: transcript.slice(0, 240), confidence }],
    });
  }
  res.json({ ok: true, result });
});

app.use('/api/auth', createAuthRoutes({ auth: authService, devices, phoneVerification }));
app.use('/api/security', apiAuth, createSecurityRoutes({ auth: authService, phoneVerification }));
app.use('/api/creator-verification', apiAuth, createCreatorVerificationRoutes({ verification: creatorVerification, audit }));
app.use('/api/profile-identity', apiAuth, createIdentityRoutes({ users }));
app.use('/api/room-contributions', apiAuth, createRoomContributionRoutes({ contribution, users, rooms }));
app.use('/api/moderation', apiAuth, createModerationRoutes({ moderation, users, rooms, io }));
app.use('/api/config', createConfigRoutes({ config: remoteConfig, roleService }));
app.use('/api/appeals', apiAuth, createAppealRoutes({ appeals, roleService }));
app.use('/api/devices', apiAuth, createDeviceRoutes({ devices }));
app.use('/api/discovery', createDiscoveryRoutes({ discovery, users, rooms }));
app.use('/api/messages', apiAuth, createDirectMessageRoutes({ dm: directMessages, antiAbuse, moderation }));
app.use('/api/account', apiAuth, createAccountRoutes({ accountRequests }));
app.use('/api/audit', apiAuth, createAuditRoutes({ audit }));
app.get('/api/vip/:userId', apiAuth, (req,res)=>{ const status=vipService.status(String(req.params.userId)); res.json({...status, entitlements:vipEntitlements.listFor(status.tier)}); });
app.get('/api/lucky/:userId', (req,res)=>res.json(luckyGift.state(String(req.params.userId))));
app.post('/api/owner-ops/lucky/:userId', (req,res)=>res.json(luckyGift.setLuck(String(req.params.userId), req.body?.luck)));
app.use('/api', (req,res,next)=>{ if(opsControl.state.maintenance && !req.path.startsWith('/owner-ops') && req.path !== '/health') return res.status(503).json({error:'maintenance',message:opsControl.state.maintenanceMessage}); if(opsControl.state.readonlyMode && ['POST','PUT','PATCH','DELETE'].includes(req.method) && !req.path.startsWith('/owner-ops')) return res.status(503).json({error:'readonly_mode'}); next(); });

app.use('/api/payments', paymentRoutes);

io.use(socketAuth({ users }));

io.on('connection', socket => {
  socket.on('join_room', ({ roomId }) => {
    const joinGuard = antiAbuse.consume(socket.userId, 'room_join');
    if (!joinGuard.allowed) return socket.emit('room_error', { message: 'Çok sık oda değiştiriyorsun. Kısa bir süre bekleyip tekrar dene.', retryAfterMs: joinGuard.retryAfterMs });
    const room = rooms.get(String(roomId));
    const user = getUser(socket);
    if (!room || !user) return socket.emit('room_error', { message: 'Oda bulunamadı.' });
    const sanction = moderation.activeSanction(socket.userId);
    if (sanction?.type === 'room_ban') return socket.emit('room_error', { message: 'Bu odaya girişin geçici olarak kısıtlandı.', expiresAt: sanction.expiresAt });
    if (room.locked && !canModerateRoom(room, socket.userId)) return socket.emit('room_error', { message: 'Oda kilitli.' });
    socket.join(room.id); socket.roomId = room.id;
    const graceTimer = seatGraceTimers.get(socket.userId);
    if (graceTimer) {
      clearTimeout(graceTimer);
      seatGraceTimers.delete(socket.userId);
      const restoredSeat = room.seats.find(s => s.userId === socket.userId);
      if (restoredSeat) socket.emit('seat_restored', { seatIndex: restoredSeat.index, seatData: restoredSeat });
    } room.listeners.add(socket.userId);

    socket.emit('room_state', {
      id: room.id, title: room.title, ownerId: room.ownerId, admins: [...room.adminIds], locked: room.locked,
      seats: room.seats, listeners: room.listeners.size, followers: room.followers.size,
      pendingJoinRequests: canModerateRoom(room, socket.userId) ? [...room.joinRequests.values()] : undefined
    });
    socket.to(room.id).emit('presence_changed', { userId: socket.userId, online: true, listeners: room.listeners.size });

  });


  socket.on('room_follow', ({ roomId, follow = true }) => {
    const room = rooms.get(String(roomId));
    if (!room || room.id !== socket.roomId) return;
    if (follow) room.followers.add(socket.userId); else {
      room.followers.delete(socket.userId);
      room.joinRequests.delete(socket.userId);
    }
    socket.emit('room_followed', { roomId: room.id, following: Boolean(follow), followers: room.followers.size });
    io.to(room.id).emit('room_followers_changed', { roomId: room.id, followers: room.followers.size });
  });

  socket.on('room_join_request', ({ roomId }) => {
    const room = rooms.get(String(roomId)); const user = getUser(socket);
    if (!room || room.id !== socket.roomId || !user || canModerateRoom(room, socket.userId)) return;
    if (!room.followers.has(socket.userId)) return socket.emit('room_join_request_status', { status: 'follow_required', message: 'Önce odayı takip etmelisin.' });
    if (room.seats.some(s => s.userId === socket.userId)) return socket.emit('room_join_request_status', { status: 'already_on_seat' });
    const existing = room.joinRequests.get(socket.userId);
    if (existing?.status === 'pending') return socket.emit('room_join_request_status', existing);
    const requestId = `${room.id}:${socket.userId}:${Date.now()}`;
    const request = { requestId, roomId: room.id, userId: socket.userId, userName: user.name, avatarUrl: user.avatar, requestedAt: Date.now(), status: 'pending' };
    room.joinRequests.set(socket.userId, request);
    socket.emit('room_join_request_status', request);
    emitToRoomModerators(room, 'room_join_request', request);
  });

  socket.on('room_join_request_response', ({ roomId, requestUserId, approve, seatIndex }) => {
    const room = rooms.get(String(roomId));
    if (!room || room.id !== socket.roomId || !canModerateRoom(room, socket.userId)) return;
    const uid = String(requestUserId || '');
    const request = room.joinRequests.get(uid);
    if (!request || request.status !== 'pending') return socket.emit('seat_error', { message: 'Katılım isteği artık geçerli değil.' });
    room.joinRequests.delete(uid);
    const targetSocket = [...io.sockets.sockets.values()].find(s => s.userId === uid && s.roomId === room.id);
    if (!approve) {
      targetSocket?.emit('room_join_request_status', { ...request, status: 'rejected', reviewedBy: socket.userId });
      emitToRoomModerators(room, 'room_join_request_resolved', { userId: uid, approved: false, reviewedBy: socket.userId });
      return;
    }
    let idx = Number.isInteger(seatIndex) ? seatIndex : firstAvailableSeat(room);
    if (idx < 0 || idx >= room.seats.length || room.seats[idx].userId || room.seats[idx].locked) idx = firstAvailableSeat(room);
    if (idx < 0) {
      room.joinRequests.set(uid, request);
      return socket.emit('seat_error', { message: 'Onay için boş ve açık koltuk bulunamadı.' });
    }
    const user = users.get(uid);
    if (!user || !room.listeners.has(uid)) return socket.emit('seat_error', { message: 'Kullanıcı artık odada değil.' });
    room.approvedJoiners.add(uid);
    room.seats[idx] = { index: idx, userId: user.id, userName: user.name, avatarUrl: user.avatar, isMuted: false, locked: false };
    io.to(room.id).emit('seat_updated', { seatIndex: idx, seatData: room.seats[idx] });
    targetSocket?.emit('room_join_request_status', { ...request, status: 'approved', seatIndex: idx, reviewedBy: socket.userId });
    emitToRoomModerators(room, 'room_join_request_resolved', { userId: uid, approved: true, seatIndex: idx, reviewedBy: socket.userId });
  });

  socket.on('update_seat', ({ roomId, seatIndex, action, clientRequestId }) => {
    const room = rooms.get(String(roomId)); const user = getUser(socket);
    if (!room || room.id !== socket.roomId || !user || !Number.isInteger(seatIndex) || seatIndex < 0 || seatIndex >= room.seats.length) return;
    const seat = room.seats[seatIndex];

    if (action === 'sit') {
      if (room.seats.some(s => s.userId === user.id)) {
        return socket.emit('seat_error', { code: 'already_seated', message: 'Zaten bir koltuktasın.' });
      }
      if (seat.locked) return socket.emit('seat_error', { code: 'seat_locked', message: 'Bu koltuk kilitli.' });
      if (seat.userId) return socket.emit('seat_error', { code: 'seat_taken', message: 'Koltuk az önce doldu. Başka bir koltuk seçebilirsin.' });

      room.seats[seatIndex] = {
        index: seatIndex,
        userId: user.id,
        userName: user.name,
        avatarUrl: user.avatar,
        isMuted: false,
        locked: false,
        claimedAt: Date.now(),
        clientRequestId: clientRequestId || null,
      };
      room.approvedJoiners.delete(user.id);
      io.to(room.id).emit('seat_updated', { seatIndex, seatData: room.seats[seatIndex] });
      return;
    }

    if (action === 'leave' && seat.userId === user.id) {
      room.seats[seatIndex] = { index: seatIndex, userId: null, userName: null, avatarUrl: null, isMuted: false, locked: false };
      io.to(room.id).emit('seat_updated', { seatIndex, seatData: room.seats[seatIndex] });
    }
  });

  socket.on('room_lock', ({ roomId, locked }) => {
    const room = rooms.get(String(roomId));
    if (!room || !canModerateRoom(room, socket.userId)) return;
    room.locked = Boolean(locked);
    audit.record({ actorId: socket.userId, action: 'room.lock', targetType: 'room', targetId: room.id, roomId: room.id, meta: { locked: room.locked } });
    io.to(room.id).emit('room_settings', { locked: room.locked });
  });

  socket.on('disconnect', () => {
    const room = getRoom(socket);
    if (!room) return;
    room.listeners.delete(socket.userId);
    room.joinRequests.delete(socket.userId);
    room.approvedJoiners.delete(socket.userId);
    room.seats.forEach((seat, i) => {
      if (seat.userId === socket.userId) {
        // Keep the seat briefly for mobile network transitions/background reconnect.
        seat.disconnectedAt = Date.now();
        seat.isMuted = true;
        io.to(room.id).emit('seat_reconnecting', { seatIndex: i, userId: socket.userId, graceMs: 25000 });
        const previous = seatGraceTimers.get(socket.userId);
        if (previous) clearTimeout(previous);
        const timer = setTimeout(() => {
          const current = room.seats[i];
          if (current?.userId === socket.userId && current?.disconnectedAt) {
            room.seats[i] = { index: i, userId: null, userName: null, avatarUrl: null, isMuted: false, locked: false };
            io.to(room.id).emit('seat_updated', { seatIndex: i, seatData: room.seats[i] });
          }
          seatGraceTimers.delete(socket.userId);
        }, 25000);
        timer.unref?.();
        seatGraceTimers.set(socket.userId, timer);
      }
    });
    io.to(room.id).emit('presence_changed', { userId: socket.userId, online: false, listeners: room.listeners.size });
  });
});



// ---- Lymix VIP 1-10 + Crown, 30-day cycle ----
app.get('/api/vip/config', (_, res) => res.json({ cycleDays: vipService.CYCLE_DAYS, tiers: vipService.TIERS }));
app.get('/api/vip/:userId/status', (req, res) => res.json(vipService.status(String(req.params.userId))));
app.post('/api/vip/:userId/recharge', (req, res) => {
  try {
    const amount = Number(req.body?.amount || 0);
    res.json(vipService.addRecharge(String(req.params.userId), amount));
  } catch (e) { res.status(400).json({ error: e.message }); }
});

// ---- Lymix extended social/economy/game APIs ----
const reports = [];
const systemMessages = [];
const relationships = new Map();
const agencyQuotas = new Map([
  ['agency_1', { agencyId: 'agency_1', roomQuotaUsed: 8, roomQuotaLimit: 10, broadcasters: [
    { userId: '101', name: 'Oda Sahibi', receivedCoins: 420000, quotaTarget: 500000 },
    { userId: '102', name: 'Ahmet', receivedCoins: 155000, quotaTarget: 250000 }
  ] }]
]);
const gameAchievements = new Map();


const gameIds = new Set(['neon-cat','sky-rocket','deep-sea','lucky-reels','fruit-pop','wheel-arena','goal-master','tasty-rush','chicken-dash','beast-duel','triple-cards','western-poker']);
app.get('/api/games/:gameId/launch', (req, res) => {
  const gameId = String(req.params.gameId);
  if (!gameIds.has(gameId)) return res.status(404).json({ error: 'Oyun bulunamadı' });
  try {
    const payload = createLaunch({ gameId, roomId: String(req.query.roomId || 'global'), userId: String(req.query.userId || '') });
    res.json(payload);
  } catch (error) {
    res.status(503).json({ error: error.message, provider: getProvider() });
  }
});

app.get('/api/game-catalog', (_, res) => res.json([...gameIds].map(id => ({ id, provider: getProvider(), enabled: true }))));

app.get('/api/profile/:userId/summary', (req, res) => {
  const u = users.get(String(req.params.userId));
  if (!u) return res.status(404).json({ error: 'Kullanıcı bulunamadı' });
  res.json({
    ...u, age: 27, vipLevel: 2, level: 26, sentCoins: 420000, receivedCoins: 860000,
    personalRoomId: `room_${u.id}`, backpack: { frames: 3, rings: 1, badges: 8, entryEffects: 2 }
  });
});

app.post('/api/reports', (req, res) => {
  const row = { id: reports.length + 1, ...req.body, createdAt: new Date().toISOString(), status: 'open' };
  reports.push(row); res.status(201).json(row);
});

app.get('/api/agency/:agencyId/quota', (req, res) => {
  const row = agencyQuotas.get(String(req.params.agencyId));
  if (!row) return res.status(404).json({ error: 'Ajans bulunamadı' });
  res.json(row);
});

app.get('/api/users/:userId/quota', (req, res) => {
  const userId = String(req.params.userId);
  const receivedCoins = userId === '101' ? 420000 : 155000;
  const multiplier = receivedCoins >= 1000000 ? 2 : receivedCoins >= 500000 ? 1.5 : receivedCoins >= 150000 ? 1.0 : 0.5;
  const quota = receivedCoins >= 150000 ? 50000 : 0;
  res.json({ userId, receivedCoins, quota, multiplier, nextThreshold: receivedCoins < 150000 ? 150000 : receivedCoins < 500000 ? 500000 : 1000000 });
});

app.post('/api/wallet/diamonds-to-coins', (req, res) => {
  const user = users.get(String(req.body.userId));
  const diamonds = Math.max(0, Math.floor(Number(req.body.diamonds || 0)));
  if (!user || diamonds <= 0 || user.diamonds < diamonds) return res.status(400).json({ error: 'Geçersiz dönüşüm' });
  const rate = Number(process.env.DIAMOND_TO_COIN_RATE || 1);
  user.diamonds -= diamonds; user.coins += Math.floor(diamonds * rate);
  res.json({ coins: user.coins, diamonds: user.diamonds, rate });
});

app.get('/api/relationships/:userId', (req, res) => {
  const key = String(req.params.userId);
  res.json(relationships.get(key) || { userId: key, active: false });
});

app.post('/api/relationships', (req, res) => {
  const { userA, userB, ringId = 'aurora_ring' } = req.body;
  const row = { active: true, userA: String(userA), userB: String(userB), ringId, startedAt: new Date().toISOString(), sentAToB: 0, sentBToA: 0 };
  relationships.set(String(userA), row); relationships.set(String(userB), row); res.status(201).json(row);
});

app.post('/api/game-achievements', (req, res) => {
  const { userId, gameId, achievementId, score = 0 } = req.body;
  const key = String(userId); const list = gameAchievements.get(key) || [];
  const row = { gameId: String(gameId), achievementId: String(achievementId), score: Number(score), earnedAt: new Date().toISOString() };
  list.push(row); gameAchievements.set(key, list); res.status(201).json(row);
});

app.get('/api/game-achievements/:userId', (req, res) => res.json(gameAchievements.get(String(req.params.userId)) || []));

app.post('/api/system-messages', (req, res) => {
  const msg = { id: systemMessages.length + 1, ...req.body, createdAt: new Date().toISOString() };
  systemMessages.push(msg);
  if (msg.roomId) io.to(String(msg.roomId)).emit('system_message', msg);
  res.status(201).json(msg);
});

io.on('connection', socket => {
  socket.on('coin_rain', ({ roomId, amount = 100 }) => {
    const room = rooms.get(String(roomId)); const sender = getUser(socket);
    const cost = Math.max(1, Math.min(100000, Math.floor(Number(amount))));
    if (!room || room.id !== socket.roomId || !sender || sender.coins < cost) return;
    sender.coins -= cost;
    io.to(room.id).emit('coin_rain', { senderId: sender.id, amount: cost, createdAt: new Date().toISOString() });
  });
  socket.on('room_reaction', ({ roomId, emoji }) => {
    const room = rooms.get(String(roomId));
    if (room && room.id === socket.roomId) io.to(room.id).emit('room_reaction', { userId: socket.userId, emoji: String(emoji).slice(0, 8) });
  });
});


// V8.8 Ajans Ailesi: aile üyeliğinde sayı sınırı yok; ajans sahibi hariç en fazla 6 ajans admini.
const agencyFamilies = new Map([
  ['agency_1', {
    agencyId: 'agency_1', code: 'AJ-1001', name: 'Lymix Stars', ownerId: '101', maxAdmins: 6,
    members: new Map([['101',{userId:'101',role:'OWNER'}],['102',{userId:'102',role:'BROADCASTER'}],['103',{userId:'103',role:'BROADCASTER'}]]),
    joinRequests: new Map(), messages: [
      {id:'afm_1',senderUserId:'101',senderName:'Ajans Sahibi',content:'Ajans Ailesi sohbetine hoş geldiniz 👋',createdAt:new Date().toISOString()}
    ]
  }]
]);

function agencyFamily(req) { return agencyFamilies.get(String(req.params.agencyId || req.body?.agencyId || '')); }
function requestUserId(req) { return String(req.headers['x-user-id'] || req.body?.userId || req.query?.userId || ''); }
function isAgencyOwner(family, userId) { return Boolean(family && family.ownerId === String(userId)); }
function isAgencyFamilyMember(family, userId) { return Boolean(family?.members?.has(String(userId))); }

app.get('/api/agency/:agencyId/family', (req,res)=>{
  const family = agencyFamily(req); const userId = requestUserId(req);
  if (!family) return res.status(404).json({error:'Ajans bulunamadı'});
  if (!isAgencyFamilyMember(family,userId) && !isAgencyOwner(family,userId)) return res.status(403).json({error:'Ajans ailesi erişimin yok'});
  res.json({agencyId:family.agencyId,code:family.code,name:family.name,ownerId:family.ownerId,maxAdmins:family.maxAdmins,adminCount:[...family.members.values()].filter(x=>x.role==='ADMIN').length,members:[...family.members.values()]});
});

app.post('/api/agency/:agencyId/family/join-request', (req,res)=>{
  const family = agencyFamily(req); const userId = requestUserId(req); const user = users.get(userId);
  if (!family || !user) return res.status(404).json({error:'Ajans veya kullanıcı bulunamadı'});
  if (isAgencyFamilyMember(family,userId)) return res.status(409).json({error:'Zaten ajans ailesindesin'});
  const existing = family.joinRequests.get(userId);
  if (existing?.status === 'PENDING') return res.json(existing);
  const row={requestId:`afr_${Date.now()}_${userId}`,agencyId:family.agencyId,userId,userName:user.name,note:String(req.body?.note||'').slice(0,300),status:'PENDING',createdAt:new Date().toISOString()};
  family.joinRequests.set(userId,row);
  res.status(201).json(row);
});

app.get('/api/agency/:agencyId/family/join-requests', (req,res)=>{
  const family=agencyFamily(req); const ownerId=requestUserId(req);
  if (!family) return res.status(404).json({error:'Ajans bulunamadı'});
  if (!isAgencyOwner(family,ownerId)) return res.status(403).json({error:'Sadece ajans sahibi başvuruları görebilir'});
  res.json([...family.joinRequests.values()].filter(x=>x.status==='PENDING'));
});

app.post('/api/agency/:agencyId/family/join-request/:requestUserId/review', (req,res)=>{
  const family=agencyFamily(req); const ownerId=requestUserId(req); const targetId=String(req.params.requestUserId); const approve=Boolean(req.body?.approve);
  if (!family) return res.status(404).json({error:'Ajans bulunamadı'});
  if (!isAgencyOwner(family,ownerId)) return res.status(403).json({error:'Sadece ajans sahibi onay verebilir'});
  const row=family.joinRequests.get(targetId);
  if (!row || row.status!=='PENDING') return res.status(404).json({error:'Bekleyen başvuru bulunamadı'});
  row.status=approve?'APPROVED':'REJECTED'; row.reviewedBy=ownerId; row.reviewedAt=new Date().toISOString();
  if (approve) family.members.set(targetId,{userId:targetId,role:'MEMBER',approvedBy:ownerId,approvedAt:row.reviewedAt});
  res.json({request:row,memberCount:family.members.size,maxAdmins:family.maxAdmins});
});

app.delete('/api/agency/:agencyId/family/members/:memberUserId', (req,res)=>{
  const family=agencyFamily(req); const ownerId=requestUserId(req); const targetId=String(req.params.memberUserId);
  if (!family) return res.status(404).json({error:'Ajans bulunamadı'});
  if (!isAgencyOwner(family,ownerId)) return res.status(403).json({error:'Sadece ajans sahibi üye çıkarabilir'});
  if (targetId===family.ownerId) return res.status(400).json({error:'Ajans sahibi aileden çıkarılamaz'});
  family.members.delete(targetId); res.json({ok:true,memberCount:family.members.size});
});


app.post('/api/agency/:agencyId/family/admins/:memberUserId', (req,res)=>{
  const family=agencyFamily(req); const ownerId=requestUserId(req); const targetId=String(req.params.memberUserId);
  if (!family) return res.status(404).json({error:'Ajans bulunamadı'});
  if (!isAgencyOwner(family,ownerId)) return res.status(403).json({error:'Sadece ajans sahibi admin atayabilir'});
  if (targetId===family.ownerId) return res.status(400).json({error:'Ajans sahibi zaten en üst yetkilidir'});
  const member=family.members.get(targetId);
  if (!member) return res.status(404).json({error:'Kullanıcı ajans ailesinde değil'});
  const adminCount=[...family.members.values()].filter(x=>x.role==='ADMIN').length;
  if (member.role!=='ADMIN' && adminCount>=family.maxAdmins) return res.status(409).json({error:'Ajans admin limiti dolu',maxAdmins:family.maxAdmins});
  member.role='ADMIN'; member.promotedBy=ownerId; member.promotedAt=new Date().toISOString();
  res.json({ok:true,userId:targetId,role:member.role,adminCount:adminCount+(member.role==='ADMIN'?1:0),maxAdmins:family.maxAdmins});
});

app.delete('/api/agency/:agencyId/family/admins/:memberUserId', (req,res)=>{
  const family=agencyFamily(req); const ownerId=requestUserId(req); const targetId=String(req.params.memberUserId);
  if (!family) return res.status(404).json({error:'Ajans bulunamadı'});
  if (!isAgencyOwner(family,ownerId)) return res.status(403).json({error:'Sadece ajans sahibi admin yetkisini kaldırabilir'});
  const member=family.members.get(targetId);
  if (!member) return res.status(404).json({error:'Kullanıcı ajans ailesinde değil'});
  member.role='MEMBER'; member.demotedBy=ownerId; member.demotedAt=new Date().toISOString();
  res.json({ok:true,userId:targetId,role:member.role,maxAdmins:family.maxAdmins});
});

app.get('/api/agency/:agencyId/family/messages', (req,res)=>{
  const family=agencyFamily(req); const userId=requestUserId(req);
  if (!family) return res.status(404).json({error:'Ajans bulunamadı'});
  if (!isAgencyFamilyMember(family,userId)) return res.status(403).json({error:'Ajans ailesi sohbetine erişimin yok'});
  res.json(family.messages.slice(-100));
});

app.post('/api/agency/:agencyId/family/messages', (req,res)=>{
  const family=agencyFamily(req); const userId=requestUserId(req); const user=users.get(userId); const content=cleanMessage(req.body?.content);
  if (!family || !user) return res.status(404).json({error:'Ajans veya kullanıcı bulunamadı'});
  if (!isAgencyFamilyMember(family,userId)) return res.status(403).json({error:'Ajans ailesi sohbetine erişimin yok'});
  if (!content) return res.status(400).json({error:'Mesaj boş olamaz'});
  const row={id:`afm_${Date.now()}_${userId}`,senderUserId:userId,senderName:user.name,content:content.slice(0,500),createdAt:new Date().toISOString()};
  family.messages.push(row); if (family.messages.length>500) family.messages.splice(0,family.messages.length-500);
  io.to(`agency_family:${family.agencyId}`).emit('agency_family_message',row);
  res.status(201).json(row);
});

io.on('connection', socket=>{
  socket.on('agency_family_join_chat', ({agencyId})=>{
    const family=agencyFamilies.get(String(agencyId));
    if (!family || !isAgencyFamilyMember(family,socket.userId)) return socket.emit('agency_family_error',{message:'Ajans ailesi sohbetine erişimin yok.'});
    socket.join(`agency_family:${family.agencyId}`);
    socket.emit('agency_family_chat_ready',{agencyId:family.agencyId,memberCount:family.members.size,maxAdmins:family.maxAdmins,adminCount:[...family.members.values()].filter(x=>x.role==='ADMIN').length});
  });
  socket.on('agency_family_send_message', ({agencyId,message})=>{
    const family=agencyFamilies.get(String(agencyId)); const user=users.get(socket.userId); const content=cleanMessage(message);
    if (!family || !user || !isAgencyFamilyMember(family,socket.userId) || !content) return;
    const row={id:`afm_${Date.now()}_${socket.userId}`,senderUserId:socket.userId,senderName:user.name,content:content.slice(0,500),createdAt:new Date().toISOString()};
    family.messages.push(row); if (family.messages.length>500) family.messages.splice(0,family.messages.length-500);
    io.to(`agency_family:${family.agencyId}`).emit('agency_family_message',row);
  });
});

const PORT = Number(process.env.PORT || 3000);
server.listen(PORT, () => console.log(`Lymix backend listening on :${PORT}`));

app.use('/api/wallet', createWalletRoutes({ wallet }));
app.use('/api/admin/wallet', createAdminWalletRoutes({ wallet }));
