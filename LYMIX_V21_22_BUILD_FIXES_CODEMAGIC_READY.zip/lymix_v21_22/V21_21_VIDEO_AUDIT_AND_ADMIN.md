# LYMIX V21.21 — Video Audit + Admin Control Center

## Bu sürümde uygulananlar
- Admin backend route dosyasındaki syntax/route yerleşim hatası düzeltildi.
- `/api/admin/stats` canlı operasyon metrikleri genişletildi: toplam kullanıcı, aktif kullanıcı, socket bağlantısı, aktif oda, dolu koltuk, dinleyici, toplam XCoin/diamond, uptime, bellek ve sunucu zamanı.
- Admin web panelinde 5 saniyelik canlı yenileme ve Socket.IO bağlantısı eklendi.
- Kullanıcı ekranına XCoin düzenleme, rol düzenleme, ban/ban kaldırma eklendi.
- Oda listesi admin yetkili endpoint üzerinden okunur hale getirildi.
- Ajans listeleme endpoint'i eklendi.
- Yayıncı doğrulama kuyruğu Regula liveness durumunu taşıyabilecek şekilde genişletildi.
- Web panel uygulamadaki Baş Admin > Web Yönetim Paneli üzerinden aynı backend `/admin/` yoluna bağlanmaya devam eder.
- Giriş ekranı kısa referans videodaki daha güçlü onboarding yaklaşımından esinlenerek Lymix'e özgü sarı/siyah premium görsel yapıyla yenilendi; normal hesap açılışı yayıncı doğrulamasından ayrı tutuldu.

## Altyazılı video auditinden kayda alınan sonraki iş paketleri
- Favoriler: boş genel alan yerine gerçek favori odaları/kullanıcıları kart olarak gösterme.
- Mesajlar: Lymix Official sistem kutusu yerine gerçek konuşma/sistem mesajı davranışı; mesaj balonları ve özel varlıklar.
- Bildirim merkezi ve bildirim tercihleri: açılmayan/boş alanların gerçek veriye bağlanması.
- Yayıncı doğrulama: yalnızca ajansa/yayıncı olarak katılımda telefon + Regula liveness.
- Gizlilik: kullanıcı tarafından açılıp kapatılabilen ve VIP yetkileriyle uyumlu gerçek backend tercihleri.
- Oda: oda oluşturduktan sonra gereksiz ara ekran yerine doğrudan oda; şans/yonca özelliğinin oda içine yerleştirilmesi.
- Akış/Moments: medyanın gerçek akışta görünmesi.
- VIP: GIF profil resmi ve premium varlıkların gerçek entitlement kontrolüne bağlanması.
- Hediyeler: ayrı demo galeri mantığını azaltıp gerçek hediye kataloğunu genişletme.
- Cüzdan: açılmayan coin kanallarını gerçek mağaza/uygun ödeme akışına bağlama.
- Hesap ve güvenlik: telefon doğrulamasını normal hesaptan ayırma; şifre değiştirme akışını production hata durumlarıyla tamamlama.

## Hosting
Admin panel statik dosyaları backend tarafından `/admin/` altında servis edilir. Böylece ayrıca ayrı bir hosting zorunlu değildir. İstenirse aynı `admin_web` klasörü Cloudflare Pages veya Firebase Hosting gibi statik hosting'e taşınabilir; API adresi ayrı yapılandırılır.
