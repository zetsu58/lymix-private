# LYMIX V21.16 — Connected Room Operating System

Implemented in this pass:
- seat tap semantics changed: occupied avatar opens profile; it no longer means leave-seat
- explicit leave-seat action in seat profile/context surfaces
- room member model with owner/admin/member roles
- owner/admin visual badges
- room members screen with Lymix ID, joined date, online state and role
- owner can grant/revoke admin
- managers can remove members and ban/unban room access
- room identity bar opens detailed room information
- room details include ID, owner, agency, member count, online count, admin count, level and category
- reorganized room settings: identity, membership, seats, media, security, PK & games
- premium empty state for no room members
- seat profile sheet architecture for avatar/role/actions
- backend room-membership service and API routes

Important production note:
The local Flutter membership service is an immediate UI/state layer. For multi-device
production behavior, room role/membership/seat/presence must be bound to the backend
and realtime socket state rather than local memory.
