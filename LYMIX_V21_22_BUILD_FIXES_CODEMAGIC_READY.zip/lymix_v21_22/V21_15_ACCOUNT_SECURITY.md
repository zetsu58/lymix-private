# Lymix V21.15 — Account Security

V21.14 tabanı korunarak hesap güvenliği katmanı etkinleştirildi.

- Ayarlar > Hesap ve Veriler içindeki pasif telefon/şifre satırları gerçek ekrana bağlandı.
- Telefon numarası E.164 biçiminde alınır.
- SMS OTP Twilio Verify v2 üzerinden backend tarafından gönderilir ve doğrulanır.
- Twilio kimlik bilgileri mobil uygulamaya gömülmez.
- OTP endpointlerinde rate limiting vardır.
- Mevcut şifre doğrulanmadan parola değiştirilemez; yeni parola minimum 8 karakterdir.
- Doğrulanmış telefon ve doğrulama zamanı hesap güvenlik kaydına işlenir.

## Production secrets
TWILIO_ACCOUNT_SID
TWILIO_AUTH_TOKEN
TWILIO_VERIFY_SERVICE_SID
JWT_SECRET

Twilio Verify Service oluşturulmadan gerçek SMS gönderimi başlamaz; uygulama bu durumda yapılandırma hatası döndürür.
