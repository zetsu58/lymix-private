# V8.16.0
- First APK core package
- Premium timed launch screen
- Super Admin identity UI
- Cloud Android debug APK workflow
- Weekly reset configuration

## V8.8 — Ajans admin limiti düzeltmesi
- Aile üye limiti kaldırıldı.
- Ajans sahibi hariç en fazla 6 ajans admini atanabilir.
- Admin yetkisi aile üyeliğinden ayrıldı.

# Lymix update

## 1.1.0
- Rebuilt the initial app shell into a 5-tab social experience.
- Added discovery, smart-match style recommendations, moments, notifications and profile/VIP/wallet screens.
- Expanded live room UX with speaker seats, chat, gifts, user actions, follow and room controls.
- Added party/PK/mini-game entry points.
- Added safety/moderation UX and production-oriented database tables.
- Added Socket.IO client dependency and a cleaner backend with auth hook, validation, rate limiting and room events.
- Added a standalone backend package under `backend/`.
- Removed unused duplicate nested Dart source trees that could cause analyzer/build problems.

## 8.3
- Command Center hardening contracts, ledger/idempotency helpers, room rules, greeting quick action, room/agency identity, self mic and room-audio mute controls.

## V8.7 — Ajans Ailesi Mesajları
- Ajans üyelerine özel mesaj odası eklendi.
- Ajansa/aileye katılma başvuruları için ayrı ajans sahibi onay paneli eklendi.
- Onay yetkisi yalnızca ajans sahibinde olacak şekilde backend kontrolü eklendi.
- Ajans sahibi dahil aile kapasitesi maksimum 6 kişi olarak sınırlandı.
- Onaylanan üyelerin özel ajans sohbetine erişimi; çıkarılan üyelerin erişim kaybı için API/Socket altyapısı eklendi.

## V21.22.0+237 — QA/Build hardening
- Replaced stale V21.17-specific Codemagic workflow with root-project Android QA workflow.
- Fixed creator verification submit compile blocker (undefined `row` after unconditional throw).
- Creator verification now submits Regula liveness session metadata instead of expecting a local video file.
- Added wallet transaction history endpoint and connected wallet support/history actions.
- Admin and owner API routes now require authenticated admin/owner access even when general API auth is relaxed for local QA.
- Added backend/admin JavaScript syntax validation to CI.
