# Lymix V21.20 — Regula Face SDK

- Flutter Face SDK 8.2 API + Core Basic eklendi.
- Yayıncı/ajans doğrulamasında Regula Active Liveness başlatılır.
- Active Liveness Regula tarafından yönlendirilir; uygulama sahte yerel hareket kontrolü yapmaz.
- Portal OL lisansı APK içine asset olarak gömülmedi. Core Basic mobil başlatma için lisans dosyası gerektirmez; online liveness lisansı Face Web Service tarafında uygulanır.
- Telefon doğrulaması yalnızca yayıncı/ajans başvuru akışında kalır.
- İlk hedef: Android cihazda gerçek Regula kamera/liveness ekranının açılması ve PASSED/FAILED sonucunun alınması.

Not: Başvuruyu backend'e kesin onayla bağlamadan önce liveness transaction/tag değerinin sunucu tarafında Regula Web Service üzerinden doğrulanması gerekir.
