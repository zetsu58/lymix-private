class AppConfig {
  static const apiBase = String.fromEnvironment('LYMIX_API_BASE', defaultValue: 'http://10.0.2.2:3000');
  static const requireAuth = bool.fromEnvironment('LYMIX_REQUIRE_AUTH', defaultValue: false);
  static const appName = 'Lymix';
  static const supportEmail = String.fromEnvironment('LYMIX_SUPPORT_EMAIL', defaultValue: 'support@lymix.app');
}
