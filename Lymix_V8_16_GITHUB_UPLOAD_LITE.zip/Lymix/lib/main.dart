
import 'package:flutter/material.dart';
import 'lymix_pro_theme.dart';
import 'lymix_pro_showcase.dart';

void main()=>runApp(const LymixApp());
class LymixApp extends StatelessWidget {
 const LymixApp({super.key});
 @override Widget build(BuildContext context)=>MaterialApp(
   debugShowCheckedModeBanner:false,
   title:'LYMIX',
   theme:LymixPro.theme(),
   home:const LymixProShowcase(),
 );
}
