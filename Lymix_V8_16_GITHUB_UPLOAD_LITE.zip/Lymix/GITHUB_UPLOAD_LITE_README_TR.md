# LYMIX V8.16 GitHub Upload Lite

Bu paket GitHub'ın mobil web yükleme sınırını aşmamak için hafifletildi.

İçerir:
- Flutter/Dart kaynak kodu
- GitHub Actions Android debug APK workflow'u
- V8.16 ilk APK çekirdeği
- Splash / onboarding / temel UI kodları
- Super Admin geliştirme kimliği bileşenleri

İlk APK build'ini engellemeyen ağır reklam görselleri, büyük önizlemeler ve medya dosyaları çıkarıldı.
Bu varlıklar sonraki aşamada ayrı olarak eklenebilir.
