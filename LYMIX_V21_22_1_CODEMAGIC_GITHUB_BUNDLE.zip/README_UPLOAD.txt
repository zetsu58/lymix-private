Upload codemagic.yaml and LYMIX_V21_22_BUILD_FIXES_CODEMAGIC_HARDENED.zip to the repository root.
