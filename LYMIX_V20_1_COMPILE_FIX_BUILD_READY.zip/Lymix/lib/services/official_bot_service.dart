import 'package:shared_preferences/shared_preferences.dart';

class OfficialBotService {
  static const String accountId = 'lymix-official';
  static const String displayName = 'Lymix Official';
  static const String handle = '@lymixofficial';
  static const String _welcomeKey = 'lymix_official_welcome_delivered_v20';

  static const List<String> welcomeMessages = [
    'LYMIX’e hoş geldin! 🎙️ Hesabın temiz başladı. Sosyal takiplerin, takipçilerin ve hediye geçmişin gerçek kullanımınla oluşacak.',
    'Ben Lymix Official. Sistem hesabıyım ve uygulama duyuruları, güvenlik kuralları, seviye/VIP bilgileri ve etkinlikleri sana buradan ileteceğim.',
    'Kısa kural: saygılı ol, taciz/spam yapma, kişisel bilgilerini koru ve rahatsız edici içerikleri Şikayet Et üzerinden bildir.',
    'Coin ile hediyeler gönderebilir, oda etkinliklerine katılabilir ve seviye/VIP ilerlemeni geliştirebilirsin. Harcama öncesi tutar her zaman gösterilir.',
    'Başlamak için Ana Sayfa veya Plaza’daki açık odalardan birine katıl. Kilitli/gizli odalar kullanıcı gizliliği nedeniyle önerilmez ve yanına git özelliğinde görünmez.',
  ];

  static Future<bool> shouldShowWelcome() async {
    final prefs = await SharedPreferences.getInstance();
    return !(prefs.getBool(_welcomeKey) ?? false);
  }

  static Future<void> markWelcomeDelivered() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_welcomeKey, true);
  }
}
