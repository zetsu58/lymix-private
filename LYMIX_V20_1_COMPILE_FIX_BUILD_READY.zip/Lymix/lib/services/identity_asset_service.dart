import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../core/app_config.dart';

class IdentityAssetService {
  static const int maxFontBytes = 5 * 1024 * 1024;
  static const int maxIconBytes = 3 * 1024 * 1024;
  static const Set<String> fontExtensions = {'ttf', 'otf'};
  static const Set<String> iconExtensions = {'png', 'jpg', 'jpeg', 'webp'};

  static String extensionOf(String name) {
    final i = name.lastIndexOf('.');
    return i < 0 ? '' : name.substring(i + 1).toLowerCase();
  }

  static String? validateFont(String name, Uint8List bytes) {
    final ext = extensionOf(name);
    if (!fontExtensions.contains(ext)) return 'Yalnızca TTF veya OTF yazı tipi yüklenebilir.';
    if (bytes.isEmpty || bytes.length > maxFontBytes) return 'Yazı tipi dosyası 5 MB sınırını aşamaz.';
    return null;
  }

  static String? validateIcon(String name, Uint8List bytes) {
    final ext = extensionOf(name);
    if (!iconExtensions.contains(ext)) return 'Simge için PNG, JPG veya WebP kullan.';
    if (bytes.isEmpty || bytes.length > maxIconBytes) return 'Simge dosyası 3 MB sınırını aşamaz.';
    return null;
  }

  static Future<String> loadRuntimeFont({
    required Uint8List bytes,
    required String stableFamilyName,
  }) async {
    final loader = FontLoader(stableFamilyName);
    loader.addFont(Future.value(ByteData.sublistView(bytes)));
    await loader.load();
    return stableFamilyName;
  }

  static Future<String> loadRemoteFont({
    required Uri url,
    required String stableFamilyName,
  }) async {
    final response = await http.get(url);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw StateError('Yazı tipi indirilemedi.');
    }
    final loader = FontLoader(stableFamilyName);
    loader.addFont(Future.value(ByteData.sublistView(response.bodyBytes)));
    await loader.load();
    return stableFamilyName;
  }


  static const String apiBase = AppConfig.apiBase;

  static Uri assetUri(String relativeOrAbsolute) {
    final parsed = Uri.tryParse(relativeOrAbsolute);
    if (parsed != null && parsed.hasScheme) return parsed;
    return Uri.parse('$apiBase$relativeOrAbsolute');
  }

  static Future<Map<String, dynamic>> uploadFont({
    required String userId,
    required String filename,
    required Uint8List bytes,
  }) async {
    final error = validateFont(filename, bytes);
    if (error != null) throw ArgumentError(error);
    final request = http.MultipartRequest('POST', Uri.parse('$apiBase/api/profile-identity/$userId/font'));
    request.files.add(http.MultipartFile.fromBytes('file', bytes, filename: filename));
    final response = await http.Response.fromStream(await request.send());
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw StateError('Yazı tipi sunucuya yüklenemedi (${response.statusCode}).');
    }
    return jsonDecode(response.body) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> uploadIcon({
    required String userId,
    required String filename,
    required Uint8List bytes,
  }) async {
    final error = validateIcon(filename, bytes);
    if (error != null) throw ArgumentError(error);
    final request = http.MultipartRequest('POST', Uri.parse('$apiBase/api/profile-identity/$userId/icon'));
    request.files.add(http.MultipartFile.fromBytes('file', bytes, filename: filename));
    final response = await http.Response.fromStream(await request.send());
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw StateError('Simge sunucuya yüklenemedi (${response.statusCode}).');
    }
    return jsonDecode(response.body) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>?> fetchIdentity(String userId) async {
    final response = await http.get(Uri.parse('$apiBase/api/profile-identity/$userId'));
    if (response.statusCode != 200) return null;
    return (jsonDecode(response.body) as Map<String, dynamic>)['identity'] as Map<String, dynamic>?;
  }

  static const String backendContract = '/api/profile-identity/:userId';
}
