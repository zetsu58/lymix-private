import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class CoinWalletService extends ChangeNotifier {
  CoinWalletService._();
  static final instance = CoinWalletService._();
  static const _balanceKey = 'lymix_demo_coin_balance_v2';
  int _balance = 250000;
  bool _loaded = false;

  int get balance => _balance;
  bool get loaded => _loaded;

  Future<void> init() async {
    if (_loaded) return;
    final p = await SharedPreferences.getInstance();
    _balance = p.getInt(_balanceKey) ?? 250000;
    _loaded = true;
    notifyListeners();
  }

  Future<bool> spend(int amount) async {
    if (amount <= 0 || _balance < amount) return false;
    _balance -= amount;
    final p = await SharedPreferences.getInstance();
    await p.setInt(_balanceKey, _balance);
    notifyListeners();
    return true;
  }

  Future<void> creditDemo(int amount) async {
    _balance += amount.clamp(0, 10000000).toInt();
    final p = await SharedPreferences.getInstance();
    await p.setInt(_balanceKey, _balance);
    notifyListeners();
  }
}
