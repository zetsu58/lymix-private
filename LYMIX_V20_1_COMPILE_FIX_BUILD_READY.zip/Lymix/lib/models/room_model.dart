enum SeatStatus { empty, occupied, locked }

class RoomSeat {
  final int index;
  SeatStatus status;
  String? userId;
  String? userName;
  String? avatarUrl;
  bool isMuted;
  bool isSpeaking;

  RoomSeat({
    required this.index,
    this.status = SeatStatus.empty,
    this.userId,
    this.userName,
    this.avatarUrl,
    this.isMuted = false,
    this.isSpeaking = false,
  });
}
