import 'package:flutter/material.dart';

enum GiftTier { spark, social, premium, epic, legend }
enum GiftMotion { pop, orbit, rain, streak, burst, crown, portal, comet }

class LymixGiftItem {
  final String id;
  final String name;
  final String symbol;
  final int coins;
  final String category;
  final GiftTier tier;
  final GiftMotion motion;
  final IconData icon;
  final bool roomWide;
  const LymixGiftItem({
    required this.id,
    required this.name,
    required this.symbol,
    required this.coins,
    required this.category,
    required this.tier,
    required this.motion,
    required this.icon,
    this.roomWide = false,
  });
}

const lymixGiftCatalog = <LymixGiftItem>[
  LymixGiftItem(id:'rose', name:'Lymix Gülü', symbol:'🌹', coins:10, category:'Mini', tier:GiftTier.spark, motion:GiftMotion.pop, icon:Icons.local_florist_rounded),
  LymixGiftItem(id:'heart', name:'Kalp', symbol:'💜', coins:50, category:'Mini', tier:GiftTier.spark, motion:GiftMotion.burst, icon:Icons.favorite_rounded),
  LymixGiftItem(id:'star', name:'Yıldız', symbol:'⭐', coins:100, category:'Mini', tier:GiftTier.spark, motion:GiftMotion.streak, icon:Icons.star_rounded),
  LymixGiftItem(id:'mic', name:'Altın Mikrofon', symbol:'🎙️', coins:250, category:'Mini', tier:GiftTier.social, motion:GiftMotion.orbit, icon:Icons.mic_rounded),
  LymixGiftItem(id:'coffee', name:'Gece Kahvesi', symbol:'☕', coins:400, category:'Sosyal', tier:GiftTier.social, motion:GiftMotion.pop, icon:Icons.coffee_rounded),
  LymixGiftItem(id:'fire', name:'Alev', symbol:'🔥', coins:750, category:'Sosyal', tier:GiftTier.social, motion:GiftMotion.rain, icon:Icons.local_fire_department_rounded),
  LymixGiftItem(id:'crown', name:'Kraliyet Tacı', symbol:'👑', coins:1500, category:'Sosyal', tier:GiftTier.premium, motion:GiftMotion.crown, icon:Icons.workspace_premium_rounded),
  LymixGiftItem(id:'diamond', name:'Mor Elmas', symbol:'💎', coins:3000, category:'Premium', tier:GiftTier.premium, motion:GiftMotion.burst, icon:Icons.diamond_rounded),
  LymixGiftItem(id:'sports_car', name:'Neon Araba', symbol:'🏎️', coins:6500, category:'Premium', tier:GiftTier.premium, motion:GiftMotion.streak, icon:Icons.directions_car_filled_rounded),
  LymixGiftItem(id:'rocket', name:'Lymix Roketi', symbol:'🚀', coins:12000, category:'Premium', tier:GiftTier.epic, motion:GiftMotion.comet, icon:Icons.rocket_launch_rounded, roomWide:true),
  LymixGiftItem(id:'plane', name:'Gökyüzü Yolculuğu', symbol:'✈️', coins:20000, category:'Epik', tier:GiftTier.epic, motion:GiftMotion.streak, icon:Icons.flight_takeoff_rounded, roomWide:true),
  LymixGiftItem(id:'aurora', name:'Aurora', symbol:'🌌', coins:35000, category:'Epik', tier:GiftTier.epic, motion:GiftMotion.rain, icon:Icons.auto_awesome_rounded, roomWide:true),
  LymixGiftItem(id:'yacht', name:'Gece Yatı', symbol:'🛥️', coins:60000, category:'Epik', tier:GiftTier.epic, motion:GiftMotion.streak, icon:Icons.sailing_rounded, roomWide:true),
  LymixGiftItem(id:'castle', name:'Kalp Kalesi', symbol:'🏰', coins:100000, category:'Efsane', tier:GiftTier.legend, motion:GiftMotion.portal, icon:Icons.castle_rounded, roomWide:true),
  LymixGiftItem(id:'lion', name:'Altın Aslan', symbol:'🦁', coins:180000, category:'Efsane', tier:GiftTier.legend, motion:GiftMotion.crown, icon:Icons.pets_rounded, roomWide:true),
  LymixGiftItem(id:'galaxy', name:'Lymix Galaksisi', symbol:'🪐', coins:300000, category:'Efsane', tier:GiftTier.legend, motion:GiftMotion.orbit, icon:Icons.public_rounded, roomWide:true),
  LymixGiftItem(id:'phoenix', name:'Mor Anka', symbol:'🔥', coins:500000, category:'Efsane', tier:GiftTier.legend, motion:GiftMotion.comet, icon:Icons.whatshot_rounded, roomWide:true),
  LymixGiftItem(id:'universe', name:'Lymix Evreni', symbol:'✨', coins:1000000, category:'Efsane', tier:GiftTier.legend, motion:GiftMotion.portal, icon:Icons.blur_circular_rounded, roomWide:true),
];

Color giftTierColor(GiftTier tier) => switch (tier) {
  GiftTier.spark => const Color(0xFFFFD200),
  GiftTier.social => const Color(0xFFB76CFF),
  GiftTier.premium => const Color(0xFF7C3CFF),
  GiftTier.epic => const Color(0xFF00D7FF),
  GiftTier.legend => const Color(0xFFFFB300),
};
