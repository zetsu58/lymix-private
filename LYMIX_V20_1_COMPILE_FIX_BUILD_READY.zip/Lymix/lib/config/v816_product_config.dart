class LymixV816 {
  static const version = '20.0.0';
  static const appName = 'LYMIX';
  static const slogan = 'Sesinle Bağlan, Dünyanı Paylaş';

  // Development-only identity. Production auth must replace this.
  static const devAdminDisplayName = 'LYMIX OWNER';
  static const devAdminRole = 'SUPER_ADMIN';
  static const devAdminLevel = 999;

  static const splashSeconds = 5;
  static const weeklyResetHour = 5; // Europe/Istanbul, Monday
  static const weeklyResetWeekday = DateTime.monday;

  static const firstApkModules = <String>[
    'splash',
    'onboarding',
    'home',
    'room_list',
    'live_room',
    'profile',
    'super_admin_badge',
    'trusted_device_ui',
    'admin_room_entry_effect',
  ];

  static const deferredModules = <String>[
    'vip_1_15',
    'agency_league',
    'quota_rewards',
    'seasonal_rings',
    'season_gifts',
    'inventory',
    'achievements',
    'scheduled_bonus_hours',
    'liveops_12_months',
  ];
}
