// lib/services/agora_service.dart (Genişletilmiş Ses Profili)
import 'package:agora_rtc_engine/agora_rtc_engine.dart';

Future<void> configureHighQualityAudio(RtcEngine engine) async {
  // Ultra HD Stereo Ses Profili (Yayıncılar ve Müzik Odaları için)
  await engine.setAudioProfile(
    profile: AudioProfileType.audioProfileMusicHighQualityStereo, // 48 kHz, 128 kbps, Stereo
    scenario: AudioScenarioType.audioScenarioGameStreaming,
  );

  // Gelişmiş Ses Modu ve Yapay Zeka Tabanlı Gürültü Engelleme (AINS)
  await engine.setParameters('{"che.audio.ains_mode": 2}'); // Deep AI Noise Suppression
  await engine.setParameters('{"che.audio.3d_voice": true}'); // 3D Ses Efekti Entegrasyonu
}