import 'package:flutter/material.dart';
import 'admin_economy_center_screen.dart';

class OwnerOpsCenterScreen extends StatefulWidget {
  const OwnerOpsCenterScreen({super.key});
  @override State<OwnerOpsCenterScreen> createState() => _OwnerOpsCenterScreenState();
}

class _OwnerOpsCenterScreenState extends State<OwnerOpsCenterScreen> {
  bool maintenance = false;
  bool emergency = false;
  final flags = {'Oyunlar': true, 'Hediyeler': true, 'Akış': true, 'Ajanslar': true, 'VIP': true};

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: const Color(0xFF080A0F),
    appBar: AppBar(title: const Text('Lymix Owner Ops'), backgroundColor: const Color(0xFF11141B)),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('SADECE SAHİP / ROOT ADMIN', style: TextStyle(color: Color(0xFFFFD54F), fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      Wrap(spacing: 8, runSpacing: 8, children: [_metric('API','ONLINE'), _metric('Realtime','128'), _metric('Odalar','42'), _metric('RAM','61%'), _metric('Latency','84 ms'), _metric('Errors','0.3%')]),
      const SizedBox(height: 16),
      SwitchListTile(value: maintenance, onChanged: (v) => setState(() => maintenance = v), title: const Text('Bakım Modu'), subtitle: const Text('Yeni istekleri kontrollü şekilde durdur')),
      SwitchListTile(value: emergency, onChanged: (v) => setState(() => emergency = v), title: const Text('Acil Durum / Read-only'), subtitle: const Text('Yazma işlemlerini durdur, servisleri koru')),
      const Divider(),
      const Text('Canlı Özellik Anahtarları', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
      ...flags.entries.map((e) => SwitchListTile(value: e.value, title: Text(e.key), onChanged: (v) => setState(() => flags[e.key] = v))),
      const Divider(),
      const Text('Müdahale Araçları', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
      _action('Tüm kullanıcılara sistem duyurusu', Icons.campaign),
      _action('Kullanıcı oturumunu anında kes', Icons.person_off),
      _actionGo('Ekonomi & hediye kontrolü', Icons.toll_rounded, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminEconomyCenterScreen()))),
      _action('Sorunlu oyunu/hediyeyi kapat', Icons.power_settings_new),
      _action('Olay kaydı oluştur', Icons.warning_amber),
      _action('Audit log / müdahale geçmişi', Icons.history),
      const SizedBox(height: 12),
      const Text('Production: Bu ekran normal admin menüsünde görünmez. Ayrı owner rolü + MFA + VPN/IP allowlist + server-side token zorunlu tutulmalıdır.', style: TextStyle(color: Colors.white54, fontSize: 12)),
    ]),
  );

  Widget _metric(String a, String b) => Container(width: 105, padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: const Color(0xFF151922), borderRadius: BorderRadius.circular(14)), child: Column(children: [Text(a, style: const TextStyle(color: Colors.white54, fontSize: 11)), const SizedBox(height: 5), Text(b, style: const TextStyle(color: Color(0xFFFFD54F), fontWeight: FontWeight.bold))]));
  Widget _actionGo(String t, IconData i, VoidCallback onTap) => Card(child: ListTile(onTap: onTap, leading: Icon(i, color: const Color(0xFFFFD54F)), title: Text(t), trailing: const Icon(Icons.chevron_right)));
  Widget _action(String t, IconData i) => Card(child: ListTile(leading: Icon(i, color: const Color(0xFFFFD54F)), title: Text(t), trailing: const Icon(Icons.chevron_right)));
}
