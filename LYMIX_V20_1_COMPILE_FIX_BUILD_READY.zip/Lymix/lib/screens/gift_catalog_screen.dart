import 'package:flutter/material.dart';
import '../models/gift_model.dart';
import '../services/coin_wallet_service.dart';
import 'coin_store_screen.dart';

class GiftCatalogScreen extends StatefulWidget {
  const GiftCatalogScreen({super.key});
  @override State<GiftCatalogScreen> createState()=>_GiftCatalogScreenState();
}

class _GiftCatalogScreenState extends State<GiftCatalogScreen> {
  String category='Mini';
  final cats=const ['Mini','Sosyal','Premium','Epik','Efsane'];
  @override void initState(){super.initState();CoinWalletService.instance.init();}
  @override Widget build(BuildContext context){final list=lymixGiftCatalog.where((g)=>g.category==category).toList();return Scaffold(
    backgroundColor:const Color(0xFF0B0811),
    appBar:AppBar(title:const Text('Hediye Galaksisi'),actions:[AnimatedBuilder(animation:CoinWalletService.instance,builder:(_,__)=>TextButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const CoinStoreScreen())),icon:const Icon(Icons.toll_rounded,color:Color(0xFFFFD200)),label:Text('${CoinWalletService.instance.balance}',style:const TextStyle(color:Color(0xFFFFD200),fontWeight:FontWeight.w900))))]),
    body:Column(children:[
      _hero(),
      SizedBox(height:42,child:ListView(scrollDirection:Axis.horizontal,padding:const EdgeInsets.symmetric(horizontal:14),children:cats.map((c)=>Padding(padding:const EdgeInsets.only(right:8),child:ChoiceChip(selected:category==c,label:Text(c),onSelected:(_)=>setState(()=>category=c),selectedColor:const Color(0xFFFFD200),labelStyle:TextStyle(color:category==c?Colors.black:Colors.white70,fontWeight:FontWeight.w800)))).toList())),
      Expanded(child:GridView.builder(padding:const EdgeInsets.all(14),gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:3,crossAxisSpacing:10,mainAxisSpacing:10,childAspectRatio:.82),itemCount:list.length,itemBuilder:(_,i)=>_tile(list[i]))),
    ]),
  );}
  Widget _hero()=>Container(margin:const EdgeInsets.fromLTRB(14,8,14,14),height:130,padding:const EdgeInsets.all(18),decoration:BoxDecoration(borderRadius:BorderRadius.circular(26),gradient:const LinearGradient(colors:[Color(0xFF2D1351),Color(0xFF7132FF),Color(0xFFFFC400)])),child:const Row(children:[Icon(Icons.auto_awesome_rounded,size:42),SizedBox(width:14),Expanded(child:Column(mainAxisAlignment:MainAxisAlignment.center,crossAxisAlignment:CrossAxisAlignment.start,children:[Text('18 ÖZGÜN LYMIX HEDİYESİ',style:TextStyle(fontWeight:FontWeight.w900,fontSize:17)),SizedBox(height:4),Text('10 Coin’den 1.000.000 Coin’e • oda çapı efektler • combo destekli',style:TextStyle(color:Colors.white70,fontSize:10))]))]));
  Widget _tile(LymixGiftItem g){final c=giftTierColor(g.tier);return InkWell(borderRadius:BorderRadius.circular(20),onTap:()=>_preview(g),child:Container(padding:const EdgeInsets.all(10),decoration:BoxDecoration(color:c.withValues(alpha: .055),borderRadius:BorderRadius.circular(20),border:Border.all(color:c.withValues(alpha: .25))),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Text(g.symbol,style:const TextStyle(fontSize:42)),const SizedBox(height:7),Text(g.name,textAlign:TextAlign.center,maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(fontWeight:FontWeight.w900,fontSize:11)),const SizedBox(height:4),Text('${g.coins} Coin',style:TextStyle(color:c,fontWeight:FontWeight.w900,fontSize:10)),if(g.roomWide)const Padding(padding:EdgeInsets.only(top:4),child:Text('ODA ÇAPI EFEKT',style:TextStyle(color:Colors.white38,fontSize:7,fontWeight:FontWeight.w800)))])));}
  void _preview(LymixGiftItem g)=>showDialog(context:context,builder:(_)=>AlertDialog(title:Text('${g.symbol} ${g.name}'),content:Text('${g.coins} Coin\nKategori: ${g.category}\nEfekt: ${g.motion.name}\n${g.roomWide?'Odadaki herkes tam ekran efekti görür.':'Hızlı ve hafif hediye efekti.'}\n\nGönderim oda ekranındaki Hediye butonundan yapılır.'),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Kapat'))]));
}
