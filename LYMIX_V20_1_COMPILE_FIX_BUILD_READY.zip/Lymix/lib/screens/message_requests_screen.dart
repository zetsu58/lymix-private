import 'package:flutter/material.dart';
import '../core/api_client.dart';
import '../services/session_service.dart';
import '../theme/lymix_theme.dart';
import '../widgets/lymix_states.dart';

class MessageRequestsScreen extends StatefulWidget {
  const MessageRequestsScreen({super.key});
  @override State<MessageRequestsScreen> createState()=>_MessageRequestsScreenState();
}

class _MessageRequestsScreenState extends State<MessageRequestsScreen>{
  bool loading=true;
  String? error;
  List<Map<String,dynamic>> rows=[];

  @override void initState(){super.initState();_load();}

  Future<void> _load() async{
    setState((){loading=true;error=null;});
    try{
      final raw=await ApiClient(tokenProvider:SessionService.token).getJson('/api/messages/requests');
      final map=Map<String,dynamic>.from(raw as Map);
      final list=(map['rows'] as List? ?? const[]).map((e)=>Map<String,dynamic>.from(e as Map)).toList();
      if(mounted)setState((){rows=list;loading=false;});
    }catch(e){if(mounted)setState((){loading=false;error=e.toString();});}
  }

  Future<void> _decide(Map<String,dynamic> row,bool accept) async{
    try{
      await ApiClient(tokenProvider:SessionService.token).postJson('/api/messages/requests/${row['id']}/decision',{'accept':accept});
      setState(()=>rows.remove(row));
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}
  }

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Mesaj İstekleri')),
    body:RefreshIndicator(
      color:LymixColors.gold,onRefresh:_load,
      child:ListView(
        physics:const AlwaysScrollableScrollPhysics(),
        padding:const EdgeInsets.fromLTRB(16,10,16,28),
        children:[
          Container(
            padding:const EdgeInsets.all(14),
            decoration:BoxDecoration(color:Color(0xFF15101F),borderRadius:BorderRadius.circular(18),border:Border.all(color:Colors.white.withValues(alpha: .05))),
            child:const Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
              Icon(Icons.mark_chat_unread_outlined,color:LymixColors.gold,size:21),
              SizedBox(width:9),
              Expanded(child:Text('Takip etmediğin veya daha önce konuşmadığın kişiler önce mesaj isteği gönderir. Kabul etmeden sohbet açılmaz.',style:TextStyle(color:Color(0x7AFFFFFF),fontSize:9.5,height:1.4))),
            ]),
          ),
          const SizedBox(height:14),
          if(loading) const LymixLoadingCard(label:'Mesaj istekleri yükleniyor...')
          else if(error!=null) LymixStateCard(icon:Icons.cloud_off_rounded,title:'İstekler yüklenemedi',message:error!,actionLabel:'Tekrar dene',onAction:_load)
          else if(rows.isEmpty) const LymixStateCard(icon:Icons.mark_chat_read_outlined,title:'Yeni mesaj isteği yok',message:'Yeni bir kullanıcı sana yazmak istediğinde isteği burada göreceksin.')
          else ...rows.map((r)=>Container(
            margin:const EdgeInsets.only(bottom:10),
            padding:const EdgeInsets.all(13),
            decoration:BoxDecoration(color:LymixColors.surface,borderRadius:BorderRadius.circular(18),border:Border.all(color:Colors.white.withValues(alpha: .05))),
            child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
              Row(children:[
                CircleAvatar(backgroundColor:const Color(0xFF2A1C34),child:Text((r['senderId']??'?').toString().isEmpty?'?':(r['senderId']??'?').toString().substring(0,1).toUpperCase())),
                const SizedBox(width:9),
                Expanded(child:Text('Kullanıcı ${r['senderId']}',style:const TextStyle(fontWeight:FontWeight.w800,fontSize:11.5))),
              ]),
              const SizedBox(height:8),
              Text((r['preview']??'').toString(),maxLines:3,overflow:TextOverflow.ellipsis,style:const TextStyle(color:Color(0x80FFFFFF),fontSize:9.5,height:1.35)),
              const SizedBox(height:10),
              Row(children:[
                Expanded(child:OutlinedButton(onPressed:()=>_decide(r,false),child:const Text('Reddet'))),
                const SizedBox(width:8),
                Expanded(child:FilledButton(onPressed:()=>_decide(r,true),child:const Text('Kabul Et'))),
              ]),
            ]),
          )),
        ],
      ),
    ),
  );
}
