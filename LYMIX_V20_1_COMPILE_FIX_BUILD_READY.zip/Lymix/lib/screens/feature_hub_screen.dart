import 'package:flutter/material.dart';
import '../lymix_pro_theme.dart';

class FeatureHubScreen extends StatelessWidget {
  final String title;
  final IconData icon;
  final String description;
  const FeatureHubScreen({super.key, required this.title, required this.icon, required this.description});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(title)),
        body: ListView(padding: const EdgeInsets.all(18), children: [
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              gradient: LymixPro.premiumGradient,
              borderRadius: BorderRadius.circular(26),
            ),
            child: Row(children: [
              Icon(icon, size: 42),
              const SizedBox(width: 14),
              Expanded(child: Text(title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900))),
            ]),
          ),
          const SizedBox(height: 16),
          Text(description, style: const TextStyle(color: Colors.white70, height: 1.45)),
          const SizedBox(height: 18),
          const ListTile(leading: Icon(Icons.check_circle_outline_rounded, color: LymixPro.yellow), title: Text('Bu bölüm gerçek bir route ile bağlıdır.')),
          const ListTile(leading: Icon(Icons.security_rounded, color: LymixPro.yellow), title: Text('Gizlilik ve yetki kontrolleri korunur.')),
        ]),
      );
}
