import 'package:flutter/material.dart';
import '../core/api_client.dart';
import '../services/session_service.dart';
import '../theme/lymix_theme.dart';

class AppealScreen extends StatefulWidget {
  final String sanctionType;
  final String? roomId;
  final DateTime? expiresAt;
  const AppealScreen({super.key, required this.sanctionType, this.roomId, this.expiresAt});
  @override State<AppealScreen> createState()=>_AppealScreenState();
}

class _AppealScreenState extends State<AppealScreen>{
  final controller=TextEditingController();
  bool sending=false;

  @override void dispose(){controller.dispose();super.dispose();}

  Future<void> _send() async{
    if(controller.text.trim().length<10){
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('İtiraz nedenini biraz daha ayrıntılı yaz.')));
      return;
    }
    setState(()=>sending=true);
    try{
      await ApiClient(tokenProvider:SessionService.token).postJson('/api/appeals',{
        'sanctionType':widget.sanctionType,
        'roomId':widget.roomId,
        'reason':controller.text.trim(),
      });
      if(!mounted)return;
      await showDialog(context:context,builder:(ctx)=>AlertDialog(
        title:const Text('İtiraz alındı'),
        content:const Text('Kaydın moderasyon ekibine iletildi. Aynı yaptırım için tekrar tekrar itiraz göndermene gerek yok.'),
        actions:[FilledButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Tamam'))],
      ));
      if(mounted)Navigator.pop(context,true);
    }catch(e){
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('İtiraz gönderilemedi: $e')));
    }finally{
      if(mounted)setState(()=>sending=false);
    }
  }

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Moderasyon İtirazı')),
    body:ListView(padding:const EdgeInsets.fromLTRB(16,10,16,30),children:[
      Container(
        padding:const EdgeInsets.all(16),
        decoration:BoxDecoration(
          gradient:const LinearGradient(colors:[Color(0xFF241621),Color(0xFF100C16)]),
          borderRadius:BorderRadius.circular(22),
          border:Border.all(color:Color(0x33FFD643)),
        ),
        child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
          const Icon(Icons.gavel_rounded,color:LymixColors.gold,size:26),
          const SizedBox(width:11),
          Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            const Text('Karara itiraz edebilirsin',style:TextStyle(fontSize:14,fontWeight:FontWeight.w900)),
            const SizedBox(height:4),
            Text(
              widget.expiresAt==null
                ? 'Yaptırım türü: ${widget.sanctionType}'
                : 'Yaptırım türü: ${widget.sanctionType}\nBitiş: ${widget.expiresAt}',
              style:const TextStyle(color:Color(0x7AFFFFFF),fontSize:9.5,height:1.4),
            ),
          ])),
        ]),
      ),
      const SizedBox(height:16),
      const Text('Neden yanlış olduğunu düşünüyorsun?',style:TextStyle(fontWeight:FontWeight.w900)),
      const SizedBox(height:8),
      TextField(
        controller:controller,
        minLines:5,maxLines:8,maxLength:1000,
        decoration:const InputDecoration(hintText:'Bağlamı, ne söylediğini/yaptığını ve kararın neden yeniden incelenmesi gerektiğini açıkla...'),
      ),
      const SizedBox(height:8),
      const Text('İtiraz, mevcut yaptırımı otomatik olarak kaldırmaz. İnceleme sonucuna göre işlem güncellenebilir.',style:TextStyle(color:Colors.white38,fontSize:9.2,height:1.4)),
      const SizedBox(height:18),
      DecoratedBox(
        decoration:BoxDecoration(gradient:LymixColors.brandGradient,borderRadius:BorderRadius.circular(17)),
        child:ElevatedButton.icon(
          onPressed:sending?null:_send,
          icon:Icon(sending?Icons.sync_rounded:Icons.send_rounded),
          label:Text(sending?'Gönderiliyor...':'İtirazı Gönder'),
          style:ElevatedButton.styleFrom(backgroundColor:Colors.transparent,shadowColor:Colors.transparent,foregroundColor:const Color(0xFF150E18),padding:const EdgeInsets.symmetric(vertical:13)),
        ),
      ),
    ]),
  );
}
