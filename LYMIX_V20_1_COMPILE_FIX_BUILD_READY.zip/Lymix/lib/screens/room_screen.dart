import 'dart:math';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/room_model.dart';
import 'game_center_screen.dart';
import 'room_contribution_screen.dart';
import '../widgets/gift_animation_overlay.dart';
import '../widgets/gift_send_sheet.dart';
import '../models/gift_model.dart';
import '../theme/lymix_theme.dart';
import '../widgets/user_identity_name.dart';
import '../services/moderation_service.dart';
import 'report_center_screen.dart';
import 'moderation_safety_screen.dart';
import 'room_event_screen.dart';

class LymixRoomScreen extends StatefulWidget {
  final String roomId;
  final String roomTitle;
  const LymixRoomScreen({super.key, required this.roomId, required this.roomTitle});
  @override State<LymixRoomScreen> createState() => _LymixRoomScreenState();
}

class _LymixRoomScreenState extends State<LymixRoomScreen> {
  late List<RoomSeat> seats;
  final chat = TextEditingController();
  final List<Map<String, String>> messages = [
    {'u':'Sistem','m':'Lymix odasına hoş geldiniz.'},
    {'u':'Sistem','m':'👋 Ece odaya katıldı. Selam vermek ister misin?','greet':'Ece'},
    {'u':'Sistem','m':'🎉 Tugay VIP 2 seviyesine yükseldi!'},
    {'u':'Oda Sahibi','m':'Herkese selamlar 🎉'},
  ];
  int mySeat = -1;
  bool muted = false;
  bool speakerMuted = false;
  String agencyCode = 'AJ-1001';
  late final String roomPublicId;
  Map<String, String>? replyToMessage;
  bool someoneTyping = false;
  final List<String> roomRules = [
    'Saygılı konuş, hakaret ve taciz yasaktır.',
    'İzinsiz reklam, spam ve bağlantı paylaşımı yasaktır.',
    'Oda sahibi ve yetkililerin mikrofon düzenine uy.',
  ];
  bool following = false;
  bool coinRain = false;
  int roomThrows = 3650000;
  bool roomEffectsEnabled = true;
  bool entranceEffectsEnabled = true;
  GiftOverlayData? activeGiftOverlay;
  VipEntranceData? activeEntranceOverlay;
  Timer? _clockTimer;
  DateTime _now = DateTime.now();
  static const String _appVersionLabel = 'v8.18.0';
  final bool currentUserIsRoomOwner = true; // Demo; production'da room owner/role claim'inden gelir.
  final bool currentUserIsRoomAdmin = false;
  bool joinRequestPending = false;
  final List<Map<String, String>> pendingJoinRequests = [
    {'id':'104','name':'Deniz','vip':'VIP 2'},
    {'id':'106','name':'Can','vip':'VIP 1'},
  ];
  bool get canModerateJoinRequests => currentUserIsRoomOwner || currentUserIsRoomAdmin;
  final List<Map<String, String>> roomVisitors = const [
    {'id':'103','name':'Ece','vip':'VIP 4'},
    {'id':'104','name':'Deniz','vip':'VIP 2'},
    {'id':'105','name':'Mira','vip':'VIP 6'},
    {'id':'106','name':'Can','vip':'VIP 1'},
  ];
  final Map<String, int> pendingSeatInvites = {};

  @override
  void initState() {
    super.initState();
    roomPublicId = 'LMX-${widget.roomId}';
    _clockTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      if (mounted) setState(() => _now = DateTime.now());
    });
    seats = List.generate(15, (i) => RoomSeat(index: i));
    seats[0] = RoomSeat(index: 0, status: SeatStatus.occupied, userId: '101', userName: 'NAZLI', avatarUrl: 'https://i.pravatar.cc/120?img=11', isSpeaking: true);
    seats[1] = RoomSeat(index: 1, status: SeatStatus.occupied, userId: '102', userName: 'TUGAY', avatarUrl: 'https://i.pravatar.cc/120?img=33');
    seats[7] = RoomSeat(index: 7, status: SeatStatus.occupied, userId: '103', userName: 'UKALA', avatarUrl: 'https://i.pravatar.cc/120?img=47');
  }

  @override void dispose(){ _clockTimer?.cancel(); chat.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: const Color(0xFF07050C),
    appBar: AppBar(
      backgroundColor: const Color(0xFF110B19),
      leading: IconButton(icon: const Icon(Icons.chevron_left), onPressed: () => Navigator.pop(context)),
      titleSpacing: 0,
      title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(widget.roomTitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
        Text('Oda ID: $roomPublicId • Ajans: $agencyCode', style: const TextStyle(fontSize: 10, color: Colors.white54)),
      ]),
      actions: [
        Center(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 4), child: Text('🏆 ${(roomThrows/1000000).toStringAsFixed(1)}M', style: const TextStyle(color: Colors.amber, fontWeight: FontWeight.bold)))),
        if (!canModerateJoinRequests)
          TextButton.icon(
            onPressed: _toggleFollowRoom,
            icon: Icon(following ? Icons.check_circle : Icons.add_circle_outline, size: 15, color: following ? Colors.greenAccent : Colors.amber),
            label: Text(following ? 'Takipte' : 'Takip Et', style: TextStyle(fontSize: 10, color: following ? Colors.greenAccent : Colors.amber)),
          ),
        if (!canModerateJoinRequests && following)
          TextButton(
            onPressed: joinRequestPending ? null : _requestToJoinStage,
            child: Text(joinRequestPending ? 'İstek Bekliyor' : 'Katılma İsteği', style: const TextStyle(fontSize: 9)),
          ),
        IconButton(icon: const Icon(Icons.more_horiz), onPressed: _roomMenu),
      ],
    ),
    body: Stack(children: [
      Positioned(
        top: 4,
        right: 10,
        child: IgnorePointer(
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
            decoration: BoxDecoration(
              color: Colors.black.withValues(alpha: .28),
              borderRadius: BorderRadius.circular(7),
              border: Border.all(color: Colors.white.withValues(alpha: .06)),
            ),
            child: Text(
              _roomMetaText(),
              style: const TextStyle(
                color: Colors.white38,
                fontSize: 7.5,
                fontWeight: FontWeight.w500,
                letterSpacing: .15,
              ),
            ),
          ),
        ),
      ),
      Column(children: [
        _eventCarousel(),
        _quickActions(),
        Expanded(child: SingleChildScrollView(child: Column(children: [_seatGrid(), _roomStats(), SizedBox(height: 180, child: _chatList())]))),
        _composer(),
      ]),
      if (coinRain && roomEffectsEnabled) ..._rainCoins(),
      if (activeGiftOverlay != null && roomEffectsEnabled)
        GiftAnimationOverlay(
          data: activeGiftOverlay!,
          onFinished: () { if (mounted) setState(() => activeGiftOverlay = null); },
        ),
      if (activeEntranceOverlay != null && roomEffectsEnabled && entranceEffectsEnabled)
        VipEntranceOverlay(
          data: activeEntranceOverlay!,
          onFinished: () { if (mounted) setState(() => activeEntranceOverlay = null); },
        ),
    ]),
  );


  String _two(int v) => v.toString().padLeft(2, '0');

  String _roomMetaText() {
    final d = _now;
    return '${_two(d.day)}.${_two(d.month)}.${d.year}  ${_two(d.hour)}:${_two(d.minute)}  •  $_appVersionLabel';
  }

  Widget _eventCarousel() => SizedBox(height: 54, child: PageView(children: const [
    _EventBanner('🎉 Lymix Gece Etkinliği', 'Görevleri tamamla, özel çerçeve kazan'),
    _EventBanner('🎡 Lucky Wheel', 'Bugünkü ücretsiz çevirmeni kullan'),
    _EventBanner('🏆 Oyun Sezonu', 'Rozet topla ve sıralamaya gir'),
  ]));

  Widget _quickActions() => SizedBox(height: 58, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7), children: [
    _quick(Icons.sports_esports, 'Oyun', () => Navigator.push(context, MaterialPageRoute(builder: (_) => GameCenterScreen(roomId: widget.roomId)))),
    _quick(Icons.leaderboard_rounded, 'Atışlar', () => Navigator.push(context, MaterialPageRoute(builder: (_) => RoomContributionScreen(roomId: widget.roomId, roomTitle: widget.roomTitle)))),
    _quick(Icons.emoji_emotions_outlined, 'Emoji', _emojiPicker),
    _quick(Icons.water_drop_outlined, 'Coin Rain', _startCoinRain),
    _quick(Icons.casino_outlined, 'Lucky', _luckyWheel),
    _quick(Icons.event, 'Etkinlik', _events),
    _quick(Icons.people_alt_outlined, 'Ziyaretçi', _visitors),
    _quick(Icons.chat_bubble_outline, 'Sohbetler', _directChats),
    _quick(Icons.storefront, 'Mağaza', _store),
    if (canModerateJoinRequests) _quick(Icons.how_to_reg, 'Katılım İstekleri', _joinRequestCenter),
  ]));

  Widget _quick(IconData icon, String label, VoidCallback onTap) => Padding(padding: const EdgeInsets.only(right: 7), child: InkWell(onTap:onTap, borderRadius: BorderRadius.circular(12), child: Container(padding: const EdgeInsets.symmetric(horizontal: 10), decoration: BoxDecoration(color: Colors.white.withValues(alpha: .055), borderRadius: BorderRadius.circular(12)), child: Row(children: [Icon(icon,size:16,color:LymixColors.gold), const SizedBox(width:5), Text(label,style:const TextStyle(color:Colors.white70,fontSize:10))]))));

  Widget _seatGrid() => Padding(padding: const EdgeInsets.fromLTRB(14, 8, 14, 0), child: GridView.builder(
    shrinkWrap:true, physics:const NeverScrollableScrollPhysics(), itemCount:15,
    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:5, mainAxisSpacing:7, crossAxisSpacing:8, childAspectRatio:.78),
    itemBuilder:(_,i){ final s=seats[i]; return InkWell(onTap:()=>_seatTap(i), child: Column(children:[
      Stack(alignment:Alignment.center, children:[
        if(s.isSpeaking) Container(width:52,height:52,decoration:BoxDecoration(shape:BoxShape.circle,border:Border.all(color:LymixColors.gold,width:2))),
        CircleAvatar(radius:23, backgroundColor:Colors.white.withValues(alpha: .06), backgroundImage:s.avatarUrl==null?null:NetworkImage(s.avatarUrl!), child:s.avatarUrl==null?Icon(s.status==SeatStatus.locked?Icons.lock:Icons.chair_outlined,color:s.status==SeatStatus.locked?Colors.amber:Colors.white30,size:21):null),
        if(s.status==SeatStatus.occupied) Positioned(right:0,bottom:0,child:Container(padding:const EdgeInsets.all(2),decoration:const BoxDecoration(color:Color(0xFF090611),shape:BoxShape.circle),child:Icon(s.isMuted?Icons.mic_off:Icons.mic,size:9,color:s.isMuted?Colors.redAccent:Colors.greenAccent))),
      ]),
      const SizedBox(height:3),
      if(s.status==SeatStatus.occupied)
        SizedBox(width:68,child:Center(child:UserIdentityName(userId:s.userId??'',name:s.userName??'Kullanıcı',style:const TextStyle(color:Colors.white70,fontSize:8))))
      else
        Text(s.status==SeatStatus.locked?'Kilitli':'${i+1}',maxLines:1,overflow:TextOverflow.ellipsis,style:TextStyle(color:s.status==SeatStatus.locked?Colors.amber:Colors.white24,fontSize:8)),
      if(s.status==SeatStatus.occupied) Text(i==0?'VIP3 • Lv38':'VIP${(i%3)+1} • Lv${18+i}',style:const TextStyle(color:Colors.amber,fontSize:6.5)),
    ])); },
  ));

  Widget _roomStats() => Padding(padding: const EdgeInsets.fromLTRB(14, 7, 14, 2), child: Row(children:[
    InkWell(onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>RoomContributionScreen(roomId:widget.roomId,roomTitle:widget.roomTitle))),borderRadius:BorderRadius.circular(7),child:_tag('🎁 Oda atışları: 3.65M')),
    const SizedBox(width:6), _tag('👥 4 ziyaretçi'), const Spacer(), Text('💬 ${messages.length}',style:const TextStyle(color:Colors.white38,fontSize:10)),
  ]));
  Widget _tag(String t)=>Container(padding:const EdgeInsets.symmetric(horizontal:7,vertical:4),decoration:BoxDecoration(color:Colors.white.withValues(alpha: .05),borderRadius:BorderRadius.circular(7)),child:Text(t,style:const TextStyle(color:Colors.white54,fontSize:8)));

  Widget _chatList()=>ListView.builder(
    padding:const EdgeInsets.fromLTRB(14,5,14,8),
    itemCount:messages.length,
    itemBuilder:(_,i){
      final m=messages[i]; final system=m['u']=='Sistem'; final greet=m['greet'];
      return Padding(padding:const EdgeInsets.symmetric(vertical:4),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        GestureDetector(
          onLongPress: system ? null : () => _messageActions(m),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 2),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              if((m['replyTo']??'').isNotEmpty)
                Container(
                  margin: const EdgeInsets.only(bottom: 4),
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                  decoration: BoxDecoration(color: Colors.white.withValues(alpha: .035), borderRadius: BorderRadius.circular(8), border: const Border(left: BorderSide(color: LymixColors.gold, width: 2))),
                  child: Text('↩ ${m['replyTo']}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white38, fontSize: 8.5)),
                ),
              RichText(text:TextSpan(children:[
                TextSpan(text:'${m['u']}: ',style:TextStyle(color:system?Colors.amber:const Color(0xFFB68CFF),fontWeight:FontWeight.bold,fontSize:10)),
                TextSpan(text:m['m'],style:const TextStyle(color:Colors.white70,fontSize:10)),
              ])),
              if((m['reaction']??'').isNotEmpty)
                Padding(padding: const EdgeInsets.only(top: 4), child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                  decoration: BoxDecoration(color: const Color(0x14FFD643), borderRadius: BorderRadius.circular(9), border: Border.all(color: const Color(0x22FFD643))),
                  child: Text(m['reaction']!, style: const TextStyle(fontSize: 10)),
                )),
            ]),
          ),
        ),
        if(greet!=null) Padding(padding:const EdgeInsets.only(top:5),child:OutlinedButton.icon(
          style:OutlinedButton.styleFrom(visualDensity:VisualDensity.compact,foregroundColor:const Color(0xFFFFC928),side:const BorderSide(color:Color(0x66FFC928))),
          onPressed:()=>setState((){messages.add({'u':'Siz','m':'👋 Selam $greet, hoş geldin!'});m.remove('greet');}),
          icon:const Icon(Icons.waving_hand_outlined,size:14),label:const Text('Selam ver',style:TextStyle(fontSize:10)),
        )),
      ]));
    });

  Widget _composer()=>Container(
    padding:const EdgeInsets.fromLTRB(8,5,8,9),
    decoration:const BoxDecoration(color:Color(0xFF110B19),border:Border(top:BorderSide(color:Color(0x18FFFFFF)))),
    child:Column(mainAxisSize:MainAxisSize.min,children:[
      if(replyToMessage!=null)
        Container(
          margin:const EdgeInsets.only(bottom:5),
          padding:const EdgeInsets.symmetric(horizontal:10,vertical:6),
          decoration:BoxDecoration(color:Colors.white.withValues(alpha: .04),borderRadius:BorderRadius.circular(12)),
          child:Row(children:[
            const Icon(Icons.reply_rounded,color:LymixColors.gold,size:16),
            const SizedBox(width:7),
            Expanded(child:Text('${replyToMessage!['u']}: ${replyToMessage!['m']}',maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(color:Color(0x80FFFFFF),fontSize:9))),
            IconButton(onPressed:()=>setState(()=>replyToMessage=null),icon:const Icon(Icons.close_rounded,size:16,color:Colors.white38),visualDensity:VisualDensity.compact),
          ]),
        ),
      if(someoneTyping)
        const Align(alignment:Alignment.centerLeft,child:Padding(padding:EdgeInsets.only(left:48,bottom:3),child:Text('Birisi yazıyor...',style:TextStyle(color:Colors.white30,fontSize:8.5)))),
      Row(children:[
        IconButton(tooltip:'Hediye gönder',icon:const Icon(Icons.card_giftcard,color:LymixColors.pink),onPressed:_showGiftModal,visualDensity:VisualDensity.compact),
        Expanded(child:TextField(
          controller:chat,
          style:const TextStyle(color:Colors.white,fontSize:11),
          onChanged:(v){},
          onSubmitted:(_){_send();},
          textCapitalization:TextCapitalization.sentences,
          decoration:InputDecoration(
            hintText:replyToMessage==null?'Mesaj yaz...':'Yanıt yaz...',
            hintStyle:const TextStyle(color:Colors.white30),
            filled:true,
            fillColor:Colors.white.withValues(alpha: .05),
            border:OutlineInputBorder(borderRadius:BorderRadius.circular(18),borderSide:BorderSide.none),
            contentPadding:const EdgeInsets.symmetric(horizontal:12,vertical:8),
          ),
        )),
        IconButton(tooltip:'Emoji',icon:const Icon(Icons.emoji_emotions_outlined,color:Colors.white60),onPressed:_emojiPicker,visualDensity:VisualDensity.compact),
        IconButton(tooltip:'Gönder',icon:const Icon(Icons.send_rounded,color:LymixColors.pink),onPressed:_send,visualDensity:VisualDensity.compact),
        IconButton(tooltip:'Oda sesini aç/kapat',icon:Icon(speakerMuted?Icons.volume_off:Icons.volume_up,color:speakerMuted?Colors.redAccent:Colors.white70),onPressed:()=>setState(()=>speakerMuted=!speakerMuted),visualDensity:VisualDensity.compact),
        IconButton(tooltip:'Mikrofonumu aç/kapat',icon:Icon(muted?Icons.mic_off:Icons.mic,color:muted?Colors.redAccent:Colors.greenAccent),onPressed:mySeat<0?null:()=>setState((){muted=!muted;seats[mySeat].isMuted=muted;}),visualDensity:VisualDensity.compact),
      ]),
    ]),
  );


  Future<void> _send() async {
    final v = chat.text.trim();
    if (v.isEmpty) return;
    if (v.length > 300) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Mesaj en fazla 300 karakter olabilir.')));
      return;
    }
    final result = await ModerationService().checkText(v);
    if (!mounted) return;
    if (!result.allowed) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(result.message ?? 'Mesaj gönderilemedi: uygunsuz ifade algılandı.'),
        action: SnackBarAction(label: 'Kurallar', onPressed: _roomRules),
      ));
      return;
    }
    setState(() {
      messages.add({
        'u':'Siz',
        'm':v,
        if(replyToMessage!=null) 'replyTo':'${replyToMessage!['u']}: ${replyToMessage!['m']}',
      });
      replyToMessage=null;
      chat.clear();
    });
  }

  void _messageActions(Map<String,String> message) {
    showModalBottomSheet(
      context:context,
      backgroundColor:LymixColors.surface,
      shape:const RoundedRectangleBorder(borderRadius:BorderRadius.vertical(top:Radius.circular(24))),
      builder:(ctx)=>SafeArea(child:Padding(
        padding:const EdgeInsets.fromLTRB(14,8,14,18),
        child:Column(mainAxisSize:MainAxisSize.min,children:[
          _sheetAction(Icons.reply_rounded,'Yanıtla',(){Navigator.pop(ctx);setState(()=>replyToMessage=message);}),
          _sheetAction(Icons.emoji_emotions_outlined,'Tepki bırak',(){Navigator.pop(ctx);_reactionPicker(message);}),
          _sheetAction(Icons.copy_rounded,'Mesajı kopyala',() async {await Clipboard.setData(ClipboardData(text:message['m']??''));if(ctx.mounted)Navigator.pop(ctx);}),
          _sheetAction(Icons.flag_outlined,'Şikayet et',(){Navigator.pop(ctx);Navigator.push(context,MaterialPageRoute(builder:(_)=>ReportCenterScreen(targetUserName:message['u'],roomId:widget.roomId,roomTitle:widget.roomTitle,evidenceText:message['m'])));}),
        ]),
      )),
    );
  }

  void _reactionPicker(Map<String,String> message) => showModalBottomSheet(
    context:context,
    backgroundColor:LymixColors.surface,
    builder:(ctx)=>SafeArea(child:Padding(
      padding:const EdgeInsets.all(16),
      child:Wrap(
        alignment:WrapAlignment.spaceAround,
        children:['❤️','😂','👏','🔥','🎉','😮'].map((emoji)=>InkWell(
          borderRadius:BorderRadius.circular(14),
          onTap:(){Navigator.pop(ctx);setState(()=>message['reaction']='$emoji 1');},
          child:Padding(padding:const EdgeInsets.all(12),child:Text(emoji,style:const TextStyle(fontSize:26))),
        )).toList(),
      ),
    )),
  );

  void _seatTap(int i) {
    final s = seats[i];
    if (i == mySeat) {
      setState(() { seats[i] = RoomSeat(index: i); mySeat = -1; muted = false; });
      return;
    }
    if (s.status == SeatStatus.occupied) {
      _showUserActions(s);
      return;
    }

    // Oda sahibi veya admin koltuğa dokunduğunda yönetim menüsü açılır.
    if (currentUserIsRoomOwner || currentUserIsRoomAdmin) {
      _showAdminSeatMenu(i);
      return;
    }

    // Normal yayıncı/kullanıcı boş ve açık koltuğa tek dokunuşla doğrudan oturur.
    if (s.status == SeatStatus.locked) {
      _info('Koltuk kilitli', '${i + 1}. koltuk oda sahibi veya yetkili tarafından kilitlendi.');
      return;
    }
    if (mySeat == -1) {
      _sitOnSeat(i);
    }
  }

  void _sitOnSeat(int i) {
    if (seats[i].status != SeatStatus.empty || mySeat != -1) return;
    setState(() {
      mySeat = i;
      seats[i] = RoomSeat(index:i,status:SeatStatus.occupied,userId:'me',userName:'Siz',avatarUrl:'https://i.pravatar.cc/120?img=32');
    });
    _playVipEntrance('Siz',3);
  }

  void _showAdminSeatMenu(int seatIndex) {
    final seat = seats[seatIndex];
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: LymixColors.surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Row(children: [
              Container(
                width: 44, height: 44,
                decoration: BoxDecoration(gradient: LymixColors.brandGradient, borderRadius: BorderRadius.circular(14)),
                child: const Icon(Icons.chair_alt_rounded, color: Color(0xFF150E18)),
              ),
              const SizedBox(width: 11),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Koltuk İşlemleri', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w900)),
                Text('${seatIndex + 1}. koltuk • ${seat.status == SeatStatus.locked ? 'Kilitli' : seat.status == SeatStatus.occupied ? 'Dolu' : 'Boş'}',
                  style: const TextStyle(color: Color(0x73FFFFFF), fontSize: 9.5)),
              ])),
              IconButton(onPressed: () => Navigator.pop(ctx), icon: const Icon(Icons.close_rounded, color: Colors.white54)),
            ]),
            const SizedBox(height: 14),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: 2.65,
              children: [
                _adminSeatAction(
                  icon: Icons.chair_alt_outlined,
                  label: 'Otur',
                  subtitle: 'Bu koltuğa geç',
                  enabled: seat.status == SeatStatus.empty && mySeat == -1,
                  onTap: () { Navigator.pop(ctx); _sitOnSeat(seatIndex); },
                ),
                _adminSeatAction(
                  icon: Icons.person_add_alt_1_rounded,
                  label: 'Davet et',
                  subtitle: 'Odadan kullanıcı seç',
                  enabled: seat.status == SeatStatus.empty,
                  onTap: () { Navigator.pop(ctx); _pickUserForSeatInvite(seatIndex); },
                ),
                _adminSeatAction(
                  icon: Icons.mic_off_outlined,
                  label: 'Sesini kapat',
                  subtitle: 'Mikrofonu sustur',
                  enabled: seat.status == SeatStatus.occupied,
                  onTap: () {
                    Navigator.pop(ctx);
                    if (seat.status == SeatStatus.occupied) {
                      setState(() => seats[seatIndex].isMuted = true);
                      messages.add({'u':'Sistem','m':'🔇 ${seat.userName ?? 'Kullanıcı'} susturuldu.'});
                    }
                  },
                ),
                _adminSeatAction(
                  icon: seat.status == SeatStatus.locked ? Icons.lock_open_rounded : Icons.lock_outline_rounded,
                  label: seat.status == SeatStatus.locked ? 'Kilidi aç' : 'Koltuğu kapat',
                  subtitle: seat.status == SeatStatus.locked ? 'Koltuğu yeniden aç' : 'Yeni oturumu engelle',
                  enabled: seat.status != SeatStatus.occupied,
                  onTap: () { Navigator.pop(ctx); _toggleSeatLock(seatIndex); },
                ),
              ],
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
              decoration: BoxDecoration(color: Colors.white.withValues(alpha: .035), borderRadius: BorderRadius.circular(14)),
              child: const Row(children: [
                Icon(Icons.admin_panel_settings_outlined, color: LymixColors.gold, size: 16),
                SizedBox(width: 8),
                Expanded(child: Text('Bu menü yalnızca oda sahibi ve yetkili yöneticilere gösterilir.', style: TextStyle(color: Color(0x73FFFFFF), fontSize: 9.5))),
              ]),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _adminSeatAction({
    required IconData icon,
    required String label,
    required String subtitle,
    required VoidCallback onTap,
    bool enabled = true,
  }) {
    final fg = enabled ? Colors.white : Colors.white24;
    return InkWell(
      onTap: enabled ? onTap : null,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 9),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: enabled ? .055 : .025),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: enabled ? Colors.white.withValues(alpha: .07) : Colors.white.withValues(alpha: .025)),
        ),
        child: Row(children: [
          Container(
            width: 38, height: 38,
            decoration: BoxDecoration(
              color: enabled ? const Color(0x18FFD643) : Colors.white.withValues(alpha: .02),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: enabled ? LymixColors.gold : Colors.white24, size: 20),
          ),
          const SizedBox(width: 9),
          Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: fg, fontSize: 10.5, fontWeight: FontWeight.w800)),
            const SizedBox(height: 2),
            Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: enabled ? Colors.white38 : Colors.white12, fontSize: 8)),
          ])),
        ]),
      ),
    );
  }

  void _showSeatManagement(int seatIndex) {
    final seat = seats[seatIndex];
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF17101F),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => SafeArea(child: Padding(
        padding: const EdgeInsets.fromLTRB(16,16,16,22),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Row(children:[
            CircleAvatar(backgroundColor:const Color(0x22FFC928),child:Text('${seatIndex+1}',style:const TextStyle(color:Colors.amber,fontWeight:FontWeight.bold))),
            const SizedBox(width:10),
            Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
              Text('${seatIndex+1}. Koltuk',style:const TextStyle(color:Colors.white,fontSize:17,fontWeight:FontWeight.bold)),
              Text(seat.status==SeatStatus.locked?'Kilitli':'Boş',style:TextStyle(color:seat.status==SeatStatus.locked?Colors.amber:Colors.white54,fontSize:11)),
            ])),
          ]),
          const SizedBox(height:8),
          if (seat.status == SeatStatus.empty && mySeat == -1)
            _sheetAction(Icons.event_seat,'Bu koltuğa otur',(){Navigator.pop(ctx);_sitOnSeat(seatIndex);}),
          if (seat.status != SeatStatus.occupied)
            _sheetAction(
              seat.status==SeatStatus.locked?Icons.lock_open:Icons.lock,
              seat.status==SeatStatus.locked?'Koltuk kilidini aç':'Koltuk kilitle',
              (){Navigator.pop(ctx);_toggleSeatLock(seatIndex);},
            ),
          if (seat.status == SeatStatus.empty)
            _sheetAction(Icons.person_add_alt_1,'Kullanıcıyı koltuğa davet et',(){Navigator.pop(ctx);_pickUserForSeatInvite(seatIndex);}),
          if (seat.status == SeatStatus.locked)
            const Padding(padding:EdgeInsets.only(top:4),child:Text('Kilitli koltuğa normal kullanıcı oturamaz. Oda sahibi/yetkili kilidi açabilir.',style:TextStyle(color:Colors.white38,fontSize:10))),
        ]),
      )),
    );
  }

  void _toggleSeatLock(int seatIndex) {
    final seat = seats[seatIndex];
    if (seat.status == SeatStatus.occupied) return;
    setState(() {
      seats[seatIndex] = RoomSeat(index: seatIndex, status: seat.status == SeatStatus.locked ? SeatStatus.empty : SeatStatus.locked);
      messages.add({'u':'Sistem','m': seat.status == SeatStatus.locked ? '🔓 ${seatIndex+1}. koltuğun kilidi açıldı.' : '🔒 ${seatIndex+1}. koltuk kilitlendi.'});
    });
  }

  void _pickUserForSeatInvite(int seatIndex) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF17101F),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder:(ctx)=>SafeArea(child:Padding(
        padding:const EdgeInsets.fromLTRB(16,16,16,22),
        child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text('${seatIndex+1}. koltuğa davet et',style:const TextStyle(color:Colors.white,fontSize:18,fontWeight:FontWeight.bold)),
          const SizedBox(height:5),
          const Text('Odada bulunan bir kullanıcıyı seç.',style:TextStyle(color:Colors.white54,fontSize:11)),
          const SizedBox(height:8),
          ...roomVisitors.map((u)=>ListTile(
            contentPadding:EdgeInsets.zero,
            leading:CircleAvatar(backgroundColor:const Color(0x22B68CFF),child:Text(u['name']!.substring(0,1))),
            title:Text(u['name']!,style:const TextStyle(color:Colors.white)),
            subtitle:Text('${u['vip']} • ID ${u['id']}',style:const TextStyle(color:Colors.white38,fontSize:10)),
            trailing:const Icon(Icons.send_rounded,color:Color(0xFFFFC928),size:18),
            onTap:(){Navigator.pop(ctx);_sendSeatInvite(u,seatIndex);},
          )),
        ]),
      )),
    );
  }

  void _sendSeatInvite(Map<String,String> user, int seatIndex) {
    if (seats[seatIndex].status != SeatStatus.empty) return;
    pendingSeatInvites[user['id']!] = seatIndex;
    setState(()=>messages.add({'u':'Sistem','m':'🎙️ ${user['name']} kullanıcısı ${seatIndex+1}. koltuğa davet edildi.'}));
    _showInvitePreviewForDemo(user,seatIndex);
  }

  void _showInvitePreviewForDemo(Map<String,String> user, int seatIndex) {
    showDialog(
      context:context,
      builder:(ctx)=>AlertDialog(
        backgroundColor:const Color(0xFF1A1027),
        title:const Text('Koltuk Daveti'),
        content:Text('Oda sahibi ${user['name']} kullanıcısını ${seatIndex+1}. koltuğa davet etti.\n\nGerçek uygulamada bu pencere davet edilen kullanıcının cihazında açılır.'),
        actions:[
          TextButton(onPressed:(){pendingSeatInvites.remove(user['id']);Navigator.pop(ctx);setState(()=>messages.add({'u':'Sistem','m':'❌ ${user['name']} koltuk davetini reddetti.'}));},child:const Text('Reddet')),
          FilledButton(onPressed:(){Navigator.pop(ctx);_acceptSeatInvite(user,seatIndex);},child:const Text('Kabul Et')),
        ],
      ),
    );
  }

  void _acceptSeatInvite(Map<String,String> user, int seatIndex) {
    if (seats[seatIndex].status != SeatStatus.empty || pendingSeatInvites[user['id']] != seatIndex) return;
    setState(() {
      seats[seatIndex] = RoomSeat(index:seatIndex,status:SeatStatus.occupied,userId:user['id'],userName:user['name'],avatarUrl:'https://i.pravatar.cc/120?u=${user['id']}');
      pendingSeatInvites.remove(user['id']);
      messages.add({'u':'Sistem','m':'✅ ${user['name']} daveti kabul etti ve ${seatIndex+1}. koltuğa oturdu.'});
    });
  }


  void _toggleFollowRoom() {
    setState(() {
      following = !following;
      if (!following) joinRequestPending = false;
      messages.add({'u':'Sistem','m': following ? '⭐ Odayı takip etmeye başladın. Artık istersen Katılma İsteği gönderebilirsin.' : '☆ Oda takibinden çıktın.'});
    });
  }

  void _requestToJoinStage() {
    if (canModerateJoinRequests || !following || mySeat >= 0 || joinRequestPending) return;
    setState(() {
      joinRequestPending = true;
      messages.add({'u':'Sistem','m':'🎙️ Katılma isteğin oda sahibi ve oda adminlerine gönderildi.'});
    });
    _info('Katılma isteği gönderildi', 'Oda sahibi veya oda adminlerinden biri onayladığında uygun bir koltuğa alınacaksın.');
  }

  void _joinRequestCenter() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF17101F),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => SafeArea(child: StatefulBuilder(builder:(ctx,setLocal)=>Padding(
        padding: const EdgeInsets.fromLTRB(16,16,16,22),
        child: Column(mainAxisSize: MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
          const Text('Katılım İstekleri',style:TextStyle(color:Colors.white,fontSize:18,fontWeight:FontWeight.bold)),
          const SizedBox(height:4),
          const Text('Yalnızca odayı kendi isteğiyle takip eden kullanıcılar Katılma İsteği gönderebilir. İstekler oda sahibi veya oda adminlerinden biri tarafından onaylanır.',style:TextStyle(color:Colors.white54,fontSize:10)),
          const SizedBox(height:10),
          if (pendingJoinRequests.isEmpty) const Padding(padding:EdgeInsets.all(14),child:Text('Bekleyen katılım isteği yok.',style:TextStyle(color:Colors.white38))),
          ...pendingJoinRequests.map((u)=>ListTile(
            contentPadding:EdgeInsets.zero,
            leading:CircleAvatar(backgroundColor:const Color(0x22B68CFF),child:Text(u['name']!.substring(0,1))),
            title:Text(u['name']!,style:const TextStyle(color:Colors.white)),
            subtitle:Text('${u['vip']} • ID ${u['id']}',style:const TextStyle(color:Colors.white38,fontSize:10)),
            trailing:Wrap(spacing:4,children:[
              IconButton(tooltip:'Reddet',icon:const Icon(Icons.close,color:Colors.redAccent),onPressed:(){setState(()=>pendingJoinRequests.remove(u));setLocal((){});messages.add({'u':'Sistem','m':'❌ ${u['name']} katılım isteği reddedildi.'});}),
              IconButton(tooltip:'Onayla',icon:const Icon(Icons.check_circle,color:Colors.greenAccent),onPressed:(){_approveJoinRequest(u);setLocal((){});}),
            ]),
          )),
        ]),
      ))),
    );
  }

  void _approveJoinRequest(Map<String,String> user) {
    final idx = seats.indexWhere((s)=>s.status==SeatStatus.empty);
    if (idx < 0) { _info('Boş koltuk yok','Katılımı onaylamak için açık bir koltuk gerekli.'); return; }
    setState(() {
      pendingJoinRequests.remove(user);
      seats[idx] = RoomSeat(index:idx,status:SeatStatus.occupied,userId:user['id'],userName:user['name'],avatarUrl:'https://i.pravatar.cc/120?u=${user['id']}');
      messages.add({'u':'Sistem','m':'✅ ${user['name']} katılım isteği onaylandı ve ${idx+1}. koltuğa alındı.'});
    });
  }

  void _playVipEntrance(String name, int vipLevel) {
    if (!roomEffectsEnabled || !entranceEffectsEnabled || vipLevel <= 0) return;
    setState(() => activeEntranceOverlay = VipEntranceData(userName: name, vipLevel: vipLevel));
  }

  void _showUserActions(RoomSeat s)=>showModalBottomSheet(context:context,backgroundColor:const Color(0xFF17101F),builder:(_)=>SafeArea(child:Padding(padding:const EdgeInsets.all(18),child:Column(mainAxisSize:MainAxisSize.min,children:[
    CircleAvatar(radius:30,backgroundImage:NetworkImage(s.avatarUrl!)),const SizedBox(height:7),Text(s.userName!,style:const TextStyle(color:Colors.white,fontWeight:FontWeight.bold)),const Text('27 yaş • VIP 2 • Lv.26  |  Atış 420K • Alınan 860K',style:TextStyle(color:Colors.white54,fontSize:9)),
    _sheetAction(Icons.person,'Profili Gör',(){}),_sheetAction(Icons.chat,'Mesaj Gönder',(){}),_sheetAction(Icons.card_giftcard,'Hediye Gönder',(){Navigator.pop(context);_showGiftModal(s.userName ?? 'Kullanıcı');}),_sheetAction(Icons.flag_outlined,'Şikayet Et',(){Navigator.pop(context);Navigator.push(context,MaterialPageRoute(builder:(_)=>ReportCenterScreen(targetUserId:s.userId,targetUserName:s.userName,roomId:widget.roomId,roomTitle:widget.roomTitle)));}),
  ]))));

  void _showGiftModal([String receiverName='Oda'])=>showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => GiftSendSheet(
      receiverName: receiverName,
      onSend: (gift, quantity) async {
        final total = gift.coins * quantity;
        if (!mounted) return;
        HapticFeedback.mediumImpact();
        setState(() {
          roomThrows += total;
          activeGiftOverlay = GiftOverlayData(
            senderName: 'Siz',
            receiverName: receiverName,
            giftName: gift.name,
            giftEmoji: gift.symbol,
            coinValue: total,
            tier: gift.tier,
            motion: gift.motion,
            quantity: quantity,
          );
          messages.add({'u':'Sistem','m':'🎁 Siz, $receiverName için ${gift.name} x$quantity gönderdi • $total Coin'});
        });
      },
    ),
  );

  void _roomMenu()=>showModalBottomSheet(context:context,backgroundColor:const Color(0xFF17101F),builder:(_)=>SafeArea(child:Column(mainAxisSize:MainAxisSize.min,children:[
    if (canModerateJoinRequests) _sheetAction(Icons.how_to_reg,'Katılım istekleri',(){Navigator.pop(context);_joinRequestCenter();}),_sheetAction(Icons.event_rounded,'Etkinlikler',(){Navigator.pop(context);Navigator.push(context,MaterialPageRoute(builder:(_)=>RoomEventScreen(roomId:widget.roomId,roomTitle:widget.roomTitle)));}),_sheetAction(Icons.rule,'Oda kuralları',(){Navigator.pop(context);_roomRules();}),_sheetAction(Icons.health_and_safety_outlined,'Moderasyon ve Güvenlik',(){Navigator.pop(context);Navigator.push(context,MaterialPageRoute(builder:(_)=>const ModerationSafetyScreen()));}),_sheetAction(Icons.badge_outlined,'Oda / Ajans kimliği',(){Navigator.pop(context);_roomIdentity();}),_sheetAction(Icons.tune,'Oda ayarları',(){Navigator.pop(context);_roomSettings();}),_sheetAction(Icons.share_outlined,'Odayı paylaş',_share),_sheetAction(Icons.event,'Etkinlik',_events),_sheetAction(Icons.storefront,'Mağaza',_store),_sheetAction(Icons.report_outlined,'Odayı şikayet et',(){Navigator.pop(context);Navigator.push(context,MaterialPageRoute(builder:(_)=>ReportCenterScreen(roomId:widget.roomId,roomTitle:widget.roomTitle)));}),_sheetAction(Icons.exit_to_app,'Odadan ayrıl',()=>Navigator.pop(context)),
  ])));
  Widget _sheetAction(IconData i,String t,VoidCallback f)=>ListTile(onTap:f,leading:Icon(i,color:Colors.white70),title:Text(t,style:const TextStyle(color:Colors.white)));


  void _roomSettings()=>showModalBottomSheet(
    context:context,
    backgroundColor:const Color(0xFF17101F),
    shape:const RoundedRectangleBorder(borderRadius:BorderRadius.vertical(top:Radius.circular(24))),
    builder:(ctx)=>StatefulBuilder(builder:(ctx,setLocal)=>SafeArea(child:Padding(
      padding:const EdgeInsets.fromLTRB(18,18,18,26),
      child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('Oda Ayarları',style:TextStyle(color:Colors.white,fontSize:20,fontWeight:FontWeight.bold)),
        const SizedBox(height:8),
        const Text('Görsel efektleri kendi cihazında yönet.',style:TextStyle(color:Colors.white54,fontSize:11)),
        const SizedBox(height:10),
        SwitchListTile.adaptive(
          value:roomEffectsEnabled,
          activeThumbColor:const Color(0xFFFFC928),
          title:const Text('Oda efektleri',style:TextStyle(color:Colors.white,fontWeight:FontWeight.w600)),
          subtitle:const Text('Hediye, coin yağmuru ve oda içi jenerik efektleri göster.',style:TextStyle(color:Colors.white54,fontSize:11)),
          onChanged:(v){setState(()=>roomEffectsEnabled=v);setLocal((){});},
        ),
        SwitchListTile.adaptive(
          value:entranceEffectsEnabled,
          activeThumbColor:const Color(0xFFFFC928),
          title:const Text('VIP giriş efektleri',style:TextStyle(color:Colors.white,fontWeight:FontWeight.w600)),
          subtitle:const Text('VIP kullanıcılar odaya girdiğinde seviyeye özel giriş animasyonu göster.',style:TextStyle(color:Colors.white54,fontSize:11)),
          onChanged:roomEffectsEnabled?(v){setState(()=>entranceEffectsEnabled=v);setLocal((){});}:null,
        ),
        const Divider(color:Color(0x22FFFFFF)),
        const Text('Lymix VIP giriş stilleri',style:TextStyle(color:Colors.white70,fontWeight:FontWeight.bold)),
        const SizedBox(height:10),
        Wrap(spacing:8,runSpacing:8,children:const[
          _VipStyleChip('VIP 1','Altın Işık','✦'),
          _VipStyleChip('VIP 2','Kraliyet İz','♛'),
          _VipStyleChip('VIP 3','Lymix Aurora','✧'),
        ]),
      ]),
    ))),
  );


  void _applyRuleTemplate(String type) {
    final templates = <String,List<String>>{
      'Sohbet': ['Saygılı iletişim kur.', 'Hakaret, taciz ve ayrımcılık yapma.', 'Mikrofon sırasına dikkat et.', 'Spam ve reklam yapma.'],
      'Müzik': ['Telif ve yayın kurallarına dikkat et.', 'Mikrofonu gereksiz açık bırakma.', 'Sanatçı ve dinleyicilere saygılı ol.', 'Spam ve reklam yapma.'],
      'Oyun': ['Oyunculara hakaret etme.', 'Hile veya zararlı bağlantı paylaşma.', 'Takım iletişiminde saygılı ol.', 'Spam yapma.'],
      'Tanışma': ['Kişisel bilgileri zorla isteme.', 'Israrlı mesaj ve taciz yapma.', 'Yaş ve kimlik konusunda yanıltıcı davranma.', 'Rahatsız eden kullanıcıyı şikayet et.'],
    };
    final next = templates[type];
    if (next == null) return;
    setState(() {
      roomRules
        ..clear()
        ..addAll(next);
    });
  }

  void _roomRules()=>showModalBottomSheet(
    context:context,backgroundColor:const Color(0xFF17101F),isScrollControlled:true,
    builder:(ctx)=>SafeArea(child:Padding(padding:EdgeInsets.fromLTRB(18,18,18,18+MediaQuery.of(ctx).viewInsets.bottom),child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('Oda Kuralları',style:TextStyle(color:Colors.white,fontSize:19,fontWeight:FontWeight.bold)),
      const SizedBox(height:6),const Text('Oda sahibi kuralları düzenleyebilir. Katılan kullanıcılar menüden görebilir.',style:TextStyle(color:Colors.white54,fontSize:10)),
      const SizedBox(height:10),...roomRules.asMap().entries.map((e)=>ListTile(dense:true,contentPadding:EdgeInsets.zero,leading:CircleAvatar(radius:10,backgroundColor:const Color(0x33FFC928),child:Text('${e.key+1}',style:const TextStyle(fontSize:9,color:Color(0xFFFFC928)))),title:Text(e.value,style:const TextStyle(color:Colors.white70,fontSize:11)),trailing:IconButton(icon:const Icon(Icons.edit,size:16,color:Colors.white38),onPressed:()=>_editRule(e.key)))),
      TextButton.icon(onPressed:()=>_addRule(),icon:const Icon(Icons.add),label:const Text('Yeni kural ekle')),
    ]))));

  void _editRule(int index){
    final c=TextEditingController(text:roomRules[index]);
    showDialog(context:context,builder:(ctx)=>AlertDialog(backgroundColor:const Color(0xFF1A1027),title:const Text('Kuralı düzenle'),content:TextField(controller:c,maxLength:180,style:const TextStyle(color:Colors.white)),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('İptal')),FilledButton(onPressed:(){final v=c.text.trim();if(v.isNotEmpty)setState(()=>roomRules[index]=v);Navigator.pop(ctx);},child:const Text('Kaydet'))]));
  }
  void _addRule(){
    final c=TextEditingController();
    showDialog(context:context,builder:(ctx)=>AlertDialog(backgroundColor:const Color(0xFF1A1027),title:const Text('Yeni oda kuralı'),content:TextField(controller:c,maxLength:180,style:const TextStyle(color:Colors.white)),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('İptal')),FilledButton(onPressed:(){final v=c.text.trim();if(v.isNotEmpty&&roomRules.length<12)setState(()=>roomRules.add(v));Navigator.pop(ctx);},child:const Text('Ekle'))]));
  }

  void _roomIdentity()=>_info('Oda / Ajans Kimliği','Oda ID: $roomPublicId\nAjans Kodu: $agencyCode\n\nOda ID kalıcı oda kimliğidir. Ajans kodu, oda bir ajansa bağlıysa ajans paneli ve kota takibinde kullanılır.');

  void simulateUserJoin(String userName,{bool femaleBroadcaster=false}){
    setState(()=>messages.add({'u':'Sistem','m':'👋 $userName odaya katıldı.${femaleBroadcaster?' • Doğrulanmış kadın yayıncı':''}','greet':userName}));
  }

  void _emojiPicker()=>showModalBottomSheet(context:context,backgroundColor:const Color(0xFF17101F),builder:(ctx)=>SafeArea(child:Wrap(children:['😀','😂','🥰','😍','🔥','👏','🎉','❤️','💎','👑','🥳','😎'].map((e)=>InkWell(onTap:(){Navigator.pop(ctx);setState(()=>messages.add({'u':'Siz','m':e}));},child:Padding(padding:const EdgeInsets.all(16),child:Text(e,style:const TextStyle(fontSize:28))))).toList())));
  void _startCoinRain(){setState(()=>coinRain=true);Future.delayed(const Duration(seconds:3),(){if(mounted)setState(()=>coinRain=false);});}
  List<Widget> _rainCoins()=>List.generate(20,(i)=>Positioned(top:(i%5)*70.0,left:((i*47)%360).toDouble(),child:TweenAnimationBuilder<double>(tween:Tween(begin:0,end:1),duration:Duration(milliseconds:1600+(i%4)*250),builder:(_,v,child)=>Transform.translate(offset:Offset(0,v*460),child:Opacity(opacity:1-v*.6,child:child)),child:Text(i%3==0?'💎':'🪙',style:const TextStyle(fontSize:24)))));
  void _luckyWheel(){final prizes=['100 Coin','500 Coin','VIP puanı','Çerçeve','Tekrar Dene','1.000 Coin'];final p=prizes[Random().nextInt(prizes.length)];_info('🎡 Lucky Wheel','Kazandın: $p');}
  void _events()=>_info('Etkinlikler','• Gece Yıldızları\n• 7 Günlük Oyun Sezonu\n• VIP Haftası\n• Coin Rain Saati');
  void _visitors()=>_info('Ziyaretçiler • VIP görünürlük','VIP 3  👑 Naz\nVIP 2  💜 Tugay\nVIP 1  ✨ Ece\nNormal ziyaretçiler VIP seviyene göre kısmi görünür.');
  void _directChats()=>_info('Sohbetler','Özel mesaj kutusuna geçiş hazır. Oda kapanmadan DM ekranı açılabilir.');
  void _store()=>_info('Mağaza','VIP 1 / VIP 2 / VIP 3 • Çerçeve • Yüzük • Giriş efekti • Coin paketleri');
  void _share()=>_info('Odayı Paylaş','Davet bağlantısı: lymix://room/${widget.roomId}');
  void _report()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ReportCenterScreen(roomId:widget.roomId,roomTitle:widget.roomTitle)));
  void _info(String title,String text)=>showDialog(context:context,builder:(_)=>AlertDialog(backgroundColor:const Color(0xFF1A1027),title:Text(title),content:Text(text),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Kapat'))]));
}


class _VipStyleChip extends StatelessWidget {
  final String level; final String name; final String symbol;
  const _VipStyleChip(this.level,this.name,this.symbol);
  @override Widget build(BuildContext context)=>Container(
    padding:const EdgeInsets.symmetric(horizontal:10,vertical:8),
    decoration:BoxDecoration(
      color:Color(0xFF21172C),
      borderRadius:BorderRadius.circular(12),
      border:Border.all(color:Color(0x55FFC928)),
    ),
    child:Row(mainAxisSize:MainAxisSize.min,children:[
      Text(symbol,style:const TextStyle(color:Color(0xFFFFC928),fontSize:16)),
      const SizedBox(width:6),
      Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text(level,style:const TextStyle(color:Colors.white,fontSize:10,fontWeight:FontWeight.bold)),
        Text(name,style:const TextStyle(color:Colors.white54,fontSize:8)),
      ]),
    ]),
  );
}

class _EventBanner extends StatelessWidget {
  final String title; final String sub; const _EventBanner(this.title,this.sub);
  @override Widget build(BuildContext context)=>Container(margin:const EdgeInsets.fromLTRB(10,6,10,2),padding:const EdgeInsets.symmetric(horizontal:13),decoration:BoxDecoration(gradient:const LinearGradient(colors:[Color(0xFF351149),Color(0xFF171025)]),borderRadius:BorderRadius.circular(12)),child:Row(children:[Expanded(child:Column(mainAxisAlignment:MainAxisAlignment.center,crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(color:Colors.white,fontSize:11,fontWeight:FontWeight.bold)),Text(sub,style:const TextStyle(color:Colors.white54,fontSize:8))])),const Icon(Icons.chevron_right,color:Colors.white38)]));
}
