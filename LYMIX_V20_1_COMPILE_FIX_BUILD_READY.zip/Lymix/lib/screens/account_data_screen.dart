import 'package:flutter/material.dart';
import '../theme/lymix_theme.dart';
import '../core/api_client.dart';
import '../services/session_service.dart';

class AccountDataScreen extends StatefulWidget {
  const AccountDataScreen({super.key});
  @override State<AccountDataScreen> createState()=>_AccountDataScreenState();
}

class _AccountDataScreenState extends State<AccountDataScreen>{
  bool busy=false;
  ApiClient get api=>ApiClient(tokenProvider:SessionService.token);

  Future<void> _export() async{
    if(busy)return;
    setState(()=>busy=true);
    try{
      await api.postJson('/api/account/data-export',{});
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Veri dışa aktarım talebi oluşturuldu. Hazır olduğunda bildirim gönderilecek.')));
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Talep oluşturulamadı: $e')));}
    finally{if(mounted)setState(()=>busy=false);}
  }

  Future<void> _deleteRequest() async{
    final confirmed=await showDialog<bool>(
      context:context,
      builder:(ctx)=>AlertDialog(
        title:const Text('Hesap silme talebi'),
        content:const Text('Bu işlem geri alınamaz. Güvenlik nedeniyle üretimde devam etmeden önce yeniden kimlik doğrulaması yapılır.'),
        actions:[
          TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Vazgeç')),
          FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Devam Et')),
        ],
      ),
    )??false;
    if(!confirmed)return;
    try{
      await api.postJson('/api/account/delete-request',{'reauthenticated':false});
    }catch(e){
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Hesap silme talebi için yeniden giriş/doğrulama gerekiyor.')));
    }
  }

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Hesap ve Veriler')),
    body:ListView(padding:const EdgeInsets.fromLTRB(16,10,16,28),children:[
      _tile(Icons.download_for_offline_outlined,'Verilerimi indir','Profil, oda, güvenlik ve hesap verilerinin dışa aktarım talebini oluştur.',busy?null:_export),
      const SizedBox(height:10),
      _tile(Icons.mark_email_read_outlined,'E-posta / telefon doğrulama','Hesap kurtarma için doğrulanmış iletişim yöntemlerini yönet.',(){}),
      const SizedBox(height:10),
      _tile(Icons.password_rounded,'Şifre ve doğrulama','Şifreyi değiştir ve iki adımlı doğrulama seçeneklerini yönet.',(){}),
      const SizedBox(height:18),
      Container(
        padding:const EdgeInsets.all(14),
        decoration:BoxDecoration(color:Color(0xFF261218),borderRadius:BorderRadius.circular(18),border:Border.all(color:Color(0x33FF667A))),
        child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          const Row(children:[Icon(Icons.warning_amber_rounded,color:Color(0xFFFF9AAA)),SizedBox(width:8),Text('Hesap silme',style:TextStyle(fontWeight:FontWeight.w900))]),
          const SizedBox(height:5),
          const Text('Silme talebi yeniden kimlik doğrulaması sonrası başlatılır. Aktif mağaza abonelikleri ayrıca mağaza hesabından yönetilmelidir.',style:TextStyle(color:Color(0x75FFFFFF),fontSize:9.5,height:1.4)),
          const SizedBox(height:10),
          OutlinedButton.icon(
            onPressed:_deleteRequest,
            icon:const Icon(Icons.delete_forever_outlined),
            label:const Text('Hesabımı sil'),
            style:OutlinedButton.styleFrom(foregroundColor:const Color(0xFFFFA8B6),side:const BorderSide(color:Color(0x44FF667A))),
          ),
        ]),
      ),
    ]),
  );

  Widget _tile(IconData icon,String title,String sub,VoidCallback? tap)=>ListTile(
    onTap:tap,tileColor:LymixColors.surface,
    shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(18)),
    leading:Container(width:42,height:42,decoration:BoxDecoration(color:Color(0x14FFD643),borderRadius:BorderRadius.circular(13)),child:Icon(icon,color:LymixColors.gold)),
    title:Text(title,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:11.5)),
    subtitle:Text(sub,style:const TextStyle(color:Colors.white38,fontSize:9.2)),
    trailing:tap==null?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2,color:LymixColors.gold)):const Icon(Icons.chevron_right_rounded,color:Colors.white30),
  );
}
