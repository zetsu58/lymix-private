import 'package:flutter/material.dart';
import '../features/admin/super_admin_identity.dart';
import '../config/v816_product_config.dart';
import '../lymix_pro_theme.dart';
import 'owner_ops_center_screen.dart';
import 'admin_economy_center_screen.dart';

class SuperAdminProfileScreen extends StatelessWidget {
  const SuperAdminProfileScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Baş Admin Kimliği')),
        body: ListView(padding: const EdgeInsets.all(18), children: [
          Center(child: Container(
            width: 118, height: 118,
            decoration: BoxDecoration(shape: BoxShape.circle, gradient: LymixPro.brandGradient, boxShadow: [BoxShadow(color: LymixPro.purple.withValues(alpha: .35), blurRadius: 30)]),
            padding: const EdgeInsets.all(7),
            child: const CircleAvatar(backgroundColor: Color(0xFF160F20), backgroundImage: AssetImage('assets/branding/lymix_mark_1024.png')),
          )),
          const SizedBox(height: 16),
          const Center(child: SuperAdminIdentity()),
          const SizedBox(height: 6),
          const Center(child: Text('Owner Level 999 • ROOT CONTROL', style: TextStyle(color: Colors.white54, fontSize: 10))),
          const SizedBox(height: 20),
          _tile(context, 'Owner Ops', Icons.monitor_heart_rounded, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const OwnerOpsCenterScreen()))),
          _tile(context, 'Ekonomi & Hediyeler', Icons.toll_rounded, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminEconomyCenterScreen()))),
          const ListTile(leading: Icon(Icons.verified_user_rounded, color: LymixPro.yellow), title: Text('Rol'), subtitle: Text(LymixV816.devAdminRole)),
          const ListTile(leading: Icon(Icons.fingerprint_rounded, color: LymixPro.yellow), title: Text('Kimlik'), subtitle: Text('Sadece owner hesabında görünür.')),
        ]),
      );

  Widget _tile(BuildContext context, String title, IconData icon, VoidCallback onTap) => Card(child: ListTile(onTap: onTap, leading: Icon(icon, color: LymixPro.yellow), title: Text(title), trailing: const Icon(Icons.chevron_right_rounded)));
}
