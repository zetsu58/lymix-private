import 'package:flutter/material.dart';
import '../core/api_client.dart';
import '../services/session_service.dart';
import '../theme/lymix_theme.dart';
import '../widgets/lymix_states.dart';

enum ContributionPeriod { daily, weekly, monthly }

class RoomContributionScreen extends StatefulWidget {
  final String roomId;
  final String roomTitle;
  const RoomContributionScreen({super.key, required this.roomId, required this.roomTitle});

  @override
  State<RoomContributionScreen> createState() => _RoomContributionScreenState();
}

class _RoomContributionScreenState extends State<RoomContributionScreen> {
  ContributionPeriod period = ContributionPeriod.daily;
  bool loading = true;
  String? error;
  int total = 0;
  List<Map<String, dynamic>> rows = [];

  ApiClient get _api => ApiClient(tokenProvider: SessionService.token);

  @override
  void initState() {
    super.initState();
    _load();
  }

  String get _periodKey => switch (period) {
    ContributionPeriod.daily => 'daily',
    ContributionPeriod.weekly => 'weekly',
    ContributionPeriod.monthly => 'monthly',
  };

  Future<void> _load() async {
    setState(() { loading = true; error = null; });
    try {
      final data = await _api.getJson('/api/room-contributions/${widget.roomId}?period=$_periodKey&limit=50');
      final map = Map<String, dynamic>.from(data as Map);
      final list = (map['rows'] as List? ?? const []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
      if (!mounted) return;
      setState(() {
        total = (map['total'] as num?)?.toInt() ?? 0;
        rows = list;
        loading = false;
      });
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() { loading = false; error = e.message; });
    } catch (_) {
      if (!mounted) return;
      setState(() { loading = false; error = 'Sıralama şu anda yüklenemedi.'; });
    }
  }

  String _n(int value) {
    if (value >= 1000000) return '${(value / 1000000).toStringAsFixed(value % 1000000 == 0 ? 0 : 1)}M';
    if (value >= 1000) return '${(value / 1000).toStringAsFixed(value % 1000 == 0 ? 0 : 1)}K';
    return '$value';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: LymixColors.bg,
      appBar: AppBar(
        titleSpacing: 0,
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Oda Atışları', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
          Text(widget.roomTitle, style: const TextStyle(color: Colors.white38, fontSize: 9)),
        ]),
        actions: [
          IconButton(onPressed: _info, tooltip: 'Oda atışları hakkında', icon: const Icon(Icons.info_outline_rounded)),
        ],
      ),
      body: RefreshIndicator(
        color: LymixColors.gold,
        onRefresh: _load,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(14, 14, 14, 28),
          children: [
            _periodPicker(),
            const SizedBox(height: 14),
            if (loading) const LymixLoadingCard(label: 'Oda katkıları hazırlanıyor...')
            else if (error != null) LymixStateCard(
              icon: Icons.cloud_off_rounded,
              title: 'Sıralama yüklenemedi',
              message: error!,
              actionLabel: 'Tekrar dene',
              onAction: _load,
            )
            else if (rows.isEmpty) const LymixStateCard(
              icon: Icons.card_giftcard_rounded,
              title: 'Henüz atış yok',
              message: 'Bu dönemde odada henüz hediye gönderilmedi. İlk katkı geldiğinde sıralama burada görünecek.',
            )
            else ...[
              _summary(total),
              const SizedBox(height: 14),
              if (rows.length >= 3) _podium(rows.take(3).toList()),
              if (rows.length >= 3) const SizedBox(height: 14),
              Row(children: [
                const Text('Katkı sıralaması', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w900)),
                const Spacer(),
                Text('${rows.length} destekçi', style: const TextStyle(color: Colors.white38, fontSize: 9)),
              ]),
              const SizedBox(height: 8),
              ...rows.asMap().entries.map((e) => _rankRow(e.key + 1, e.value)),
            ],
          ],
        ),
      ),
    );
  }

  Widget _summary(int total) => Container(
    padding: const EdgeInsets.all(17),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(22),
      gradient: const LinearGradient(colors: [Color(0xFF2A1630), Color(0xFF17101E), Color(0xFF252009)]),
      border: Border.all(color: const Color(0x44FFD45A)),
    ),
    child: Row(children: [
      Container(
        width: 58, height: 58,
        decoration: const BoxDecoration(shape: BoxShape.circle, gradient: LymixColors.brandGradient),
        child: const Icon(Icons.card_giftcard_rounded, color: Color(0xFF160E17), size: 30),
      ),
      const SizedBox(width: 13),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Toplam oda katkısı', style: TextStyle(color: Colors.white54, fontSize: 10)),
        const SizedBox(height: 3),
        Text(_n(total), style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900)),
        const Text('Seçili dönemde gönderilen hediyelerin coin karşılığı', style: TextStyle(color: Colors.white38, fontSize: 8.5)),
      ])),
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
        decoration: BoxDecoration(color: const Color(0x18FFD45A), borderRadius: BorderRadius.circular(12)),
        child: const Text('LYMIX', style: TextStyle(color: LymixColors.gold, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1.1)),
      ),
    ]),
  );

  Widget _periodPicker() => Container(
    padding: const EdgeInsets.all(5),
    decoration: BoxDecoration(color: Colors.white.withValues(alpha: .045), borderRadius: BorderRadius.circular(16)),
    child: Row(children: [
      _periodButton(ContributionPeriod.daily, 'Günlük', Icons.today_rounded),
      _periodButton(ContributionPeriod.weekly, 'Haftalık', Icons.date_range_rounded),
      _periodButton(ContributionPeriod.monthly, 'Aylık', Icons.calendar_month_rounded),
    ]),
  );

  Widget _periodButton(ContributionPeriod value, String label, IconData icon) {
    final active = value == period;
    return Expanded(
      child: InkWell(
        onTap: () {
          if (period == value) return;
          setState(() => period = value);
          _load();
        },
        borderRadius: BorderRadius.circular(12),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: active ? const Color(0xFF2B1932) : Colors.transparent,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: active ? const Color(0x66FFD45A) : Colors.transparent),
          ),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(icon, size: 15, color: active ? LymixColors.gold : Colors.white38),
            const SizedBox(width: 5),
            Text(label, style: TextStyle(color: active ? Colors.white : Color(0x75FFFFFF), fontSize: 10, fontWeight: FontWeight.w800)),
          ]),
        ),
      ),
    );
  }

  Widget _podium(List<Map<String, dynamic>> top) => Container(
    padding: const EdgeInsets.fromLTRB(12, 20, 12, 15),
    decoration: BoxDecoration(color: LymixColors.surface, borderRadius: BorderRadius.circular(22), border: Border.all(color: Colors.white.withValues(alpha: .06))),
    child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
      Expanded(child: _podiumUser(2, top[1], 72)),
      Expanded(child: _podiumUser(1, top[0], 90)),
      Expanded(child: _podiumUser(3, top[2], 66)),
    ]),
  );

  Widget _podiumUser(int rank, Map<String, dynamic> user, double size) {
    final name = (user['name'] ?? 'Kullanıcı').toString();
    final amount = (user['amount'] as num?)?.toInt() ?? 0;
    final vip = (user['vip'] as num?)?.toInt() ?? 0;
    final avatar = user['avatar']?.toString();
    final medal = rank == 1 ? LymixColors.gold : rank == 2 ? const Color(0xFFC7D3E8) : const Color(0xFFD79362);

    return Column(mainAxisAlignment: MainAxisAlignment.end, children: [
      Stack(clipBehavior: Clip.none, alignment: Alignment.center, children: [
        Container(
          width: size, height: size,
          decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: medal, width: 2), gradient: const LinearGradient(colors: [Color(0xFF362647), Color(0xFF15111C)])),
          clipBehavior: Clip.antiAlias,
          child: avatar == null || avatar.isEmpty
              ? Center(child: Text(name.isEmpty?'?':name.substring(0,1).toUpperCase(), style: TextStyle(color: Colors.white, fontSize: size * .34, fontWeight: FontWeight.w900)))
              : Image.network(avatar, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Center(child: Text(name.isEmpty?'?':name.substring(0,1).toUpperCase()))),
        ),
        Positioned(
          top: -9,
          child: Container(
            width: 25, height: 25, alignment: Alignment.center,
            decoration: BoxDecoration(shape: BoxShape.circle, color: medal, boxShadow: [BoxShadow(color: medal.withValues(alpha: .25), blurRadius: 10)]),
            child: Text('$rank', style: const TextStyle(color: Color(0xFF161018), fontWeight: FontWeight.w900, fontSize: 11)),
          ),
        ),
      ]),
      const SizedBox(height: 8),
      Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w800)),
      const SizedBox(height: 2),
      Text(vip > 0 ? 'VIP $vip' : 'Destekçi', style: const TextStyle(color: Color(0xFFBE79FF), fontSize: 8)),
      const SizedBox(height: 2),
      Text(_n(amount), style: const TextStyle(color: LymixColors.gold, fontSize: 10, fontWeight: FontWeight.w900)),
    ]);
  }

  Widget _rankRow(int rank, Map<String, dynamic> user) {
    final name = (user['name'] ?? 'Kullanıcı').toString();
    final amount = (user['amount'] as num?)?.toInt() ?? 0;
    final vip = (user['vip'] as num?)?.toInt() ?? 0;
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(color: Colors.white.withValues(alpha: .032), borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white.withValues(alpha: .05))),
      child: Row(children: [
        SizedBox(width: 28, child: Text('$rank', style: const TextStyle(color: Colors.white38, fontWeight: FontWeight.w800))),
        CircleAvatar(radius: 19, backgroundColor: const Color(0xFF2A1C34), child: Text(name.isEmpty?'?':name.substring(0,1).toUpperCase(), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900))),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(name, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800)),
          Text(vip > 0 ? 'VIP $vip • oda destekçisi' : 'Oda destekçisi', style: const TextStyle(color: Colors.white38, fontSize: 8.5)),
        ])),
        const Icon(Icons.toll_rounded, size: 15, color: LymixColors.gold),
        const SizedBox(width: 4),
        Text(_n(amount), style: const TextStyle(color: LymixColors.gold, fontSize: 11, fontWeight: FontWeight.w900)),
      ]),
    );
  }

  void _info() => showDialog(
    context: context,
    builder: (_) => AlertDialog(
      title: const Text('Oda Atışları'),
      content: const Text(
        'Bu bölüm odada gönderilen hediyelerin coin karşılığını gösterir. Günlük, haftalık ve aylık sıralamalar gerçek hediye işlemlerinden ayrı ayrı hesaplanır.',
        style: TextStyle(color: Colors.white70),
      ),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Kapat'))],
    ),
  );
}
