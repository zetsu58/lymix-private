import 'package:flutter/material.dart';
import '../services/official_bot_service.dart';
import '../lymix_pro_theme.dart';
import 'room_screen.dart';

class OfficialChatScreen extends StatelessWidget {
  const OfficialChatScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          titleSpacing: 8,
          title: const Row(children: [
            CircleAvatar(
              radius: 17,
              backgroundColor: LymixPro.yellow,
              child: Icon(Icons.graphic_eq_rounded, color: LymixPro.bg, size: 20),
            ),
            SizedBox(width: 9),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Text(OfficialBotService.displayName, style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900)),
                SizedBox(width: 4),
                Icon(Icons.verified_rounded, color: LymixPro.yellow, size: 16),
              ]),
              Text('Sistem hesabı • takip zorunlu', style: TextStyle(fontSize: 9, color: Colors.white54)),
            ])
          ]),
        ),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(14, 16, 14, 110),
          children: [
            const Center(child: Text('LYMIX RESMİ KARŞILAMA', style: TextStyle(color: Colors.white38, fontSize: 9, letterSpacing: 1.2))),
            const SizedBox(height: 14),
            ...OfficialBotService.welcomeMessages.map((message) => Align(
                  alignment: Alignment.centerLeft,
                  child: Container(
                    constraints: const BoxConstraints(maxWidth: 340),
                    margin: const EdgeInsets.only(bottom: 9),
                    padding: const EdgeInsets.all(13),
                    decoration: BoxDecoration(
                      color: const Color(0xFF17111F),
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: Colors.white.withValues(alpha: .06)),
                    ),
                    child: Text(message, style: const TextStyle(height: 1.38, fontSize: 12)),
                  ),
                )),
            const SizedBox(height: 8),
            FilledButton.icon(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LymixRoomScreen(roomId: 'welcome-lounge', roomTitle: 'LYMIX Hoş Geldin Odası'))),
              icon: const Icon(Icons.graphic_eq_rounded),
              label: const Text('Açık bir odaya katıl'),
            ),
          ],
        ),
      );
}
