import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../theme/lymix_theme.dart';
import 'home_screen.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController page = PageController();
  int index = 0;

  static const items = <(IconData, String, String)>[
    (Icons.mic_none_rounded, 'Sana uygun odaları keşfet', 'İlgi alanlarına göre odaları bul, dinleyici olarak katıl veya koltuğa geçip sohbete dahil ol.'),
    (Icons.card_giftcard_rounded, 'Etkileşimde kal', 'Hediyeler, VIP avantajları, oda etkinlikleri ve sıralamalarla topluluğun parçası ol.'),
    (Icons.health_and_safety_outlined, 'Güvenli sohbet', 'Mesaj filtresi, ses moderasyonu, şikayet ve itiraz araçları daha güvenli bir deneyim için birlikte çalışır.'),
    (Icons.auto_awesome_rounded, 'Kendin gibi görün', 'Profilini ve görünümünü kişiselleştir; Lymix deneyimini iOS ve Android’de tutarlı tutar.'),
  ];

  Future<void> _finish() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('lymix.onboarding.complete', true);
    if (!mounted) return;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const LymixHomeScreen()),
    );
  }

  @override
  void dispose() {
    page.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Align(
              alignment: Alignment.centerRight,
              child: TextButton(onPressed: _finish, child: const Text('Atla')),
            ),
            Expanded(
              child: PageView.builder(
                controller: page,
                itemCount: items.length,
                onPageChanged: (i) => setState(() => index = i),
                itemBuilder: (_, i) {
                  final item = items[i];
                  return Padding(
                    padding: const EdgeInsets.fromLTRB(28, 24, 28, 20),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 118,
                          height: 118,
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: LymixColors.brandGradient,
                            boxShadow: [BoxShadow(color: Color(0x338A2BE2), blurRadius: 30)],
                          ),
                          child: Icon(item.$1, size: 52, color: const Color(0xFF150E18)),
                        ),
                        const SizedBox(height: 34),
                        Text(
                          item.$2,
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900, letterSpacing: -.4),
                        ),
                        const SizedBox(height: 12),
                        Text(
                          item.$3,
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: Color(0x80FFFFFF), fontSize: 12, height: 1.55),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                items.length,
                (i) => AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  width: i == index ? 24 : 7,
                  height: 7,
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  decoration: BoxDecoration(
                    color: i == index ? LymixColors.gold : Colors.white24,
                    borderRadius: BorderRadius.circular(99),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: SizedBox(
                width: double.infinity,
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LymixColors.brandGradient,
                    borderRadius: BorderRadius.circular(17),
                  ),
                  child: ElevatedButton(
                    onPressed: () {
                      if (index == items.length - 1) {
                        _finish();
                      } else {
                        page.nextPage(
                          duration: const Duration(milliseconds: 240),
                          curve: Curves.easeOutCubic,
                        );
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.transparent,
                      shadowColor: Colors.transparent,
                      foregroundColor: const Color(0xFF150E18),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                    child: Text(
                      index == items.length - 1 ? 'Lymix’e Başla' : 'Devam',
                      style: const TextStyle(fontWeight: FontWeight.w900),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
