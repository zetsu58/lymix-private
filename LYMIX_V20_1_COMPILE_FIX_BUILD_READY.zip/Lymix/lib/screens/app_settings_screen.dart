import 'package:flutter/material.dart';
import '../services/localization_service.dart';
import '../theme/lymix_theme.dart';
import 'language_screen.dart';
import 'privacy_center_screen.dart';
import 'moderation_safety_screen.dart';
import 'appeal_screen.dart';
import 'account_data_screen.dart';
import 'message_requests_screen.dart';
import 'notification_preferences_screen.dart';
import 'comfort_settings_screen.dart';
import 'audio_quality_screen.dart';
import 'device_sessions_screen.dart';

class AppSettingsScreen extends StatefulWidget {
  const AppSettingsScreen({super.key});
  @override State<AppSettingsScreen> createState()=>_AppSettingsScreenState();
}

class _AppSettingsScreenState extends State<AppSettingsScreen>{
  final localeController=LymixLocaleController();
  bool notifications=true;
  bool entranceEffects=true;
  bool roomEffects=true;
  bool autoPlay=false;
  bool reduceMotion=false;
  bool dataSaver=false;

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Ayarlar')),
    body:ListView(
      padding:const EdgeInsets.fromLTRB(16,8,16,28),
      children:[
        _group('Uygulama',[
          _tile(Icons.language_rounded,'Dil',lymixLanguageNames[localeController.locale.languageCode]??'Türkçe',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>LanguageScreen(controller:localeController))).then((_)=>setState((){}))),
          _tile(Icons.notifications_active_outlined,'Bildirim Tercihleri','Mesaj, oda, hediye, VIP ve sessiz saat ayarları',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const NotificationPreferencesScreen()))),
          _tile(Icons.mark_chat_unread_outlined,'Mesaj İstekleri','Yeni kişilerden gelen güvenli mesaj istekleri',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const MessageRequestsScreen()))),
        ]),
        const SizedBox(height:14),
        _group('Görsel deneyim',[
          _switch(Icons.auto_awesome_rounded,'Giriş efektleri','VIP ve özel giriş animasyonları',entranceEffects,(v)=>setState(()=>entranceEffects=v)),
          _switch(Icons.blur_on_rounded,'Oda efektleri','Hediye, coin rain ve oda efektleri',roomEffects,(v)=>setState(()=>roomEffects=v)),
          _switch(Icons.play_circle_outline_rounded,'Otomatik oynatma','Hareketli içerikleri otomatik oynat',autoPlay,(v)=>setState(()=>autoPlay=v)),
          _switch(Icons.motion_photos_off_outlined,'Hareketi azalt','Yoğun animasyonları ve büyük efektleri azalt',reduceMotion,(v)=>setState(()=>reduceMotion=v)),
          _tile(Icons.visibility_outlined,'Görsel Rahatlık','Sakin mod, parıltı azaltma ve tek elle kullanım',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const ComfortSettingsScreen()))),
          _tile(Icons.graphic_eq_rounded,'Ses Kalitesi','Gürültü, yankı, otomatik ses seviyesi ve ses çıkışı',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const AudioQualityScreen()))),
          _switch(Icons.data_saver_on_rounded,'Veri tasarrufu','Hücresel bağlantıda daha küçük görseller ve daha az ön yükleme',dataSaver,(v)=>setState(()=>dataSaver=v)),

        ]),
        const SizedBox(height:14),
        _group('Güvenlik ve hesap',[
          _tile(Icons.shield_outlined,'Gizlilik','Profil, mesaj ve görünürlük izinleri',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const PrivacyCenterScreen()))),
          _tile(Icons.health_and_safety_outlined,'Moderasyon ve Güvenlik','Mesaj filtresi, ses moderasyonu ve şikayet politikası',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const ModerationSafetyScreen()))),
          _tile(Icons.devices_outlined,'Cihazlar','Giriş yapılan cihazları ve oturumları yönet',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const DeviceSessionsScreen()))),
          _tile(Icons.lock_outline_rounded,'Hesap ve Veriler','Şifre, doğrulama, veri indirme ve hesap silme',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const AccountDataScreen()))),
        ]),
        const SizedBox(height:18),
        const Text('Lymix • v1.0.0',textAlign:TextAlign.center,style:TextStyle(color:Colors.white30,fontSize:10)),
      ],
    ),
  );

  Widget _group(String title,List<Widget> children)=>Container(
    padding:const EdgeInsets.fromLTRB(12,12,12,4),
    decoration:BoxDecoration(color:LymixColors.surface,borderRadius:BorderRadius.circular(22),border:Border.all(color:Colors.white.withValues(alpha: .05))),
    child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Padding(padding:const EdgeInsets.fromLTRB(5,2,5,7),child:Text(title,style:const TextStyle(color:Colors.white54,fontSize:10,fontWeight:FontWeight.w800,letterSpacing:.7))),
      ...children,
    ]),
  );

  Widget _tile(IconData icon,String title,String sub,VoidCallback onTap)=>ListTile(
    onTap:onTap,
    leading:_icon(icon),
    title:Text(title,style:const TextStyle(fontWeight:FontWeight.w700,fontSize:13)),
    subtitle:Text(sub,style:const TextStyle(color:Colors.white38,fontSize:9.5)),
    trailing:const Icon(Icons.chevron_right_rounded,color:Colors.white30),
  );

  Widget _switch(IconData icon,String title,String sub,bool value,ValueChanged<bool> onChanged)=>SwitchListTile.adaptive(
    value:value,onChanged:onChanged,activeThumbColor:LymixColors.gold,
    secondary:_icon(icon),
    title:Text(title,style:const TextStyle(fontWeight:FontWeight.w700,fontSize:13)),
    subtitle:Text(sub,style:const TextStyle(color:Colors.white38,fontSize:9.5)),
  );

  Widget _icon(IconData icon)=>Container(
    width:39,height:39,
    decoration:BoxDecoration(color:Colors.white.withValues(alpha: .045),borderRadius:BorderRadius.circular(12)),
    child:Icon(icon,color:LymixColors.gold,size:19),
  );
}
