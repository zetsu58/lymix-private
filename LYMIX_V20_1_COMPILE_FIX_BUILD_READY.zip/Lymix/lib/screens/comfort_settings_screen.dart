import 'package:flutter/material.dart';
import '../services/comfort_preferences_service.dart';
import '../theme/lymix_theme.dart';

class ComfortSettingsScreen extends StatefulWidget {
  const ComfortSettingsScreen({super.key});
  @override State<ComfortSettingsScreen> createState()=>_ComfortSettingsScreenState();
}
class _ComfortSettingsScreenState extends State<ComfortSettingsScreen>{
  bool loading=true, calm=false, reduceGlow=false, compact=false, autoHide=true, oneHanded=true;
  @override void initState(){super.initState();_load();}
  Future<void> _load() async{
    final p=await ComfortPreferencesService.load();
    if(!mounted)return;
    setState((){calm=p.calmMode;reduceGlow=p.reduceGlow;compact=p.compactCards;autoHide=p.autoHideBars;oneHanded=p.oneHandedActions;loading=false;});
  }
  Future<void> _save() async{
    await ComfortPreferencesService.save(ComfortPreferences(calmMode:calm,reduceGlow:reduceGlow,compactCards:compact,autoHideBars:autoHide,oneHandedActions:oneHanded));
    if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Görsel rahatlık ayarları kaydedildi.')));
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Görsel Rahatlık')),
    body:loading?const Center(child:CircularProgressIndicator(color:LymixColors.gold)):ListView(
      padding:const EdgeInsets.fromLTRB(16,10,16,28),
      children:[
        _sw('Sakin mod','Daha az parıltı, daha yumuşak animasyon ve daha dingin yüzeyler.',calm,(v)=>setState(()=>calm=v)),
        _sw('Parıltıyı azalt','VIP/hediye ışımalarını daha sakin göster.',reduceGlow,(v)=>setState(()=>reduceGlow=v)),
        _sw('Kompakt kartlar','Ana listelerde daha fazla içerik gör.',compact,(v)=>setState(()=>compact=v)),
        _sw('Kaydırırken çubukları gizle','İçerik okurken üst/alt barın görsel yükünü azalt.',autoHide,(v)=>setState(()=>autoHide=v)),
        _sw('Tek elle erişim','Önemli oda aksiyonlarını ekranın altına yakın tut.',oneHanded,(v)=>setState(()=>oneHanded=v)),
        const SizedBox(height:16),
        SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:_save,icon:const Icon(Icons.check_rounded),label:const Text('Kaydet'))),
      ],
    ),
  );
  Widget _sw(String t,String s,bool v,ValueChanged<bool> c)=>Container(
    margin:const EdgeInsets.only(bottom:9),
    decoration:BoxDecoration(color:LymixColors.surface,borderRadius:BorderRadius.circular(18),border:Border.all(color:Colors.white.withValues(alpha: .05))),
    child:SwitchListTile.adaptive(value:v,onChanged:c,activeThumbColor:LymixColors.gold,title:Text(t,style:const TextStyle(fontSize:11.5,fontWeight:FontWeight.w800)),subtitle:Text(s,style:const TextStyle(color:Colors.white38,fontSize:9.2))),
  );
}
