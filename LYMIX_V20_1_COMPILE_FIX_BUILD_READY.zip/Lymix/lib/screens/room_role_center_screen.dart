import 'package:flutter/material.dart';

class RoomRoleCenterScreen extends StatefulWidget {
  const RoomRoleCenterScreen({super.key});

  @override
  State<RoomRoleCenterScreen> createState() => _RoomRoleCenterScreenState();
}

class _RoomRoleCenterScreenState extends State<RoomRoleCenterScreen> {
  int roomLevel = 4;
  final Map<String, bool> roles = {
    'Baş Yetkili': true,
    'Mikrofon Yetkilisi': true,
    'Düzen Yetkilisi': true,
    'Etkinlik Yetkilisi': false,
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Oda Yetki Merkezi')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            'Oda Seviyesi $roomLevel • Yetkili limiti ${2 + roomLevel}',
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          const Text(
            'Oda seviyesi yükseldikçe daha fazla yetkili slotu ve gelişmiş moderasyon araçları açılır.',
            style: TextStyle(color: Colors.white54),
          ),
          const Divider(),
          ...roles.entries.map(
            (e) => SwitchListTile(
              value: e.value,
              onChanged: (v) => setState(() => roles[e.key] = v),
              title: Text(e.key),
              subtitle: Text(
                e.key == 'Mikrofon Yetkilisi'
                    ? 'Ses aç/kapat, koltuk yönetimi'
                    : 'Odadan çıkarma, susturma, etkinlik ve düzen yetkileri rol bazında verilir.',
              ),
            ),
          ),
          const Divider(),
          const Text('VIP moderasyon kuralları', style: TextStyle(fontWeight: FontWeight.bold)),
          ...List.generate(10, (i) {
            final v = i + 1;
            final description = v < 4
                ? 'Rozet + temel giriş efekti'
                : v < 7
                    ? 'Özel giriş + öncelikli koltuk + düşük seviye moderatör atmasına karşı koruma'
                    : v < 10
                        ? 'Gelişmiş giriş + ziyaretçi görünürlüğü + eşit/düşük yetki koruması'
                        : 'Mythic giriş + yalnız oda sahibi veya eşdeğer/yüksek VIP yetkili tarafından çıkarılabilme';
            return ListTile(
              leading: CircleAvatar(child: Text('$v')),
              title: Text('VIP $v'),
              subtitle: Text(description),
            );
          }),
        ],
      ),
    );
  }
}
