import 'package:flutter/material.dart';
import '../core/api_client.dart';
import '../services/session_service.dart';
import '../theme/lymix_theme.dart';
import '../widgets/lymix_states.dart';

class MyReportsScreen extends StatefulWidget {
  const MyReportsScreen({super.key});
  @override State<MyReportsScreen> createState()=>_MyReportsScreenState();
}

class _MyReportsScreenState extends State<MyReportsScreen>{
  bool loading=true;
  String? error;
  List<Map<String,dynamic>> rows=[];

  @override void initState(){super.initState();_load();}

  Future<void> _load() async{
    setState((){loading=true;error=null;});
    try{
      final data=await ApiClient(tokenProvider:SessionService.token).getJson('/api/moderation/reports/mine');
      final map=Map<String,dynamic>.from(data as Map);
      final list=(map['rows'] as List? ?? const []).map((e)=>Map<String,dynamic>.from(e as Map)).toList();
      if(mounted)setState((){rows=list;loading=false;});
    }catch(e){
      if(mounted)setState((){error=e.toString();loading=false;});
    }
  }

  String _status(String value)=>switch(value){
    'open'=>'İnceleme bekliyor',
    'reviewing'=>'İnceleniyor',
    'resolved'=>'Sonuçlandı',
    'dismissed'=>'Kapatıldı',
    _=>'İncelemede',
  };

  Color _statusColor(String value)=>switch(value){
    'resolved'=>const Color(0xFF5BE3A5),
    'dismissed'=>Colors.white38,
    'reviewing'=>const Color(0xFFFFD643),
    _=>const Color(0xFF73D5FF),
  };

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Şikayetlerim')),
    body:RefreshIndicator(
      color:LymixColors.gold,
      onRefresh:_load,
      child:ListView(
        physics:const AlwaysScrollableScrollPhysics(),
        padding:const EdgeInsets.fromLTRB(16,10,16,28),
        children:[
          if(loading) const LymixLoadingCard(label:'Şikayet kayıtların yükleniyor...')
          else if(error!=null) LymixStateCard(icon:Icons.cloud_off_rounded,title:'Kayıtlar yüklenemedi',message:error!,actionLabel:'Tekrar dene',onAction:_load)
          else if(rows.isEmpty) const LymixStateCard(icon:Icons.flag_outlined,title:'Henüz şikayetin yok',message:'Gönderdiğin kullanıcı veya oda şikayetlerinin durumunu burada takip edebilirsin.')
          else ...rows.map(_row),
        ],
      ),
    ),
  );

  Widget _row(Map<String,dynamic> r){
    final status=(r['status']??'open').toString();
    final color=_statusColor(status);
    return Container(
      margin:const EdgeInsets.only(bottom:10),
      padding:const EdgeInsets.all(13),
      decoration:BoxDecoration(color:LymixColors.surface,borderRadius:BorderRadius.circular(18),border:Border.all(color:Colors.white.withValues(alpha: .05))),
      child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Row(children:[
          Container(width:36,height:36,decoration:BoxDecoration(color:color.withValues(alpha: .10),borderRadius:BorderRadius.circular(11)),child:Icon(Icons.flag_outlined,color:color,size:18)),
          const SizedBox(width:9),
          Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Text((r['category']??'Şikayet').toString(),style:const TextStyle(fontSize:11.5,fontWeight:FontWeight.w800)),
            Text((r['createdAt']??'').toString(),style:const TextStyle(color:Colors.white30,fontSize:8.5)),
          ])),
          Container(padding:const EdgeInsets.symmetric(horizontal:8,vertical:5),decoration:BoxDecoration(color:color.withValues(alpha: .10),borderRadius:BorderRadius.circular(9)),child:Text(_status(status),style:TextStyle(color:color,fontSize:8.5,fontWeight:FontWeight.w800))),
        ]),
        const SizedBox(height:9),
        Text((r['description']??'').toString(),maxLines:3,overflow:TextOverflow.ellipsis,style:const TextStyle(color:Colors.white54,fontSize:9.5,height:1.4)),
      ]),
    );
  }
}
