import 'package:flutter/material.dart';
import '../theme/lymix_theme.dart';

class LymixLoadingCard extends StatelessWidget {
  final String label;
  const LymixLoadingCard({super.key, this.label = 'Yükleniyor...'});
  @override Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(22),
    decoration: BoxDecoration(color: LymixColors.surface, borderRadius: BorderRadius.circular(22), border: Border.all(color: Colors.white.withValues(alpha: .05))),
    child: Column(children: [
      const SizedBox(width: 26, height: 26, child: CircularProgressIndicator(strokeWidth: 2.4, color: LymixColors.gold)),
      const SizedBox(height: 12),
      Text(label, style: const TextStyle(color: Colors.white54, fontSize: 11)),
    ]),
  );
}

class LymixStateCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String message;
  final String? actionLabel;
  final VoidCallback? onAction;
  const LymixStateCard({super.key, required this.icon, required this.title, required this.message, this.actionLabel, this.onAction});

  @override Widget build(BuildContext context) => Container(
    width: double.infinity,
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF16111F), Color(0xFF100C16)]), borderRadius: BorderRadius.circular(22), border: Border.all(color: Colors.white.withValues(alpha: .05))),
    child: Column(children: [
      Container(width: 48, height: 48, decoration: BoxDecoration(color: const Color(0x16FFD643), borderRadius: BorderRadius.circular(16)), child: Icon(icon, color: LymixColors.gold, size: 24)),
      const SizedBox(height: 12),
      Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900)),
      const SizedBox(height: 5),
      Text(message, textAlign: TextAlign.center, style: const TextStyle(color: Color(0x73FFFFFF), fontSize: 10.5, height: 1.4)),
      if (actionLabel != null && onAction != null) ...[
        const SizedBox(height: 13),
        TextButton.icon(onPressed: onAction, icon: const Icon(Icons.refresh_rounded, size: 17), label: Text(actionLabel!)),
      ],
    ]),
  );
}
