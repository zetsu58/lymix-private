import 'package:flutter/material.dart';
import '../theme/lymix_theme.dart';

class ProfilePeekCard extends StatelessWidget {
  final String name;
  final String subtitle;
  final String? avatarUrl;
  final VoidCallback? onOpen;
  final VoidCallback? onFollow;
  const ProfilePeekCard({super.key,required this.name,required this.subtitle,this.avatarUrl,this.onOpen,this.onFollow});

  @override Widget build(BuildContext context)=>Container(
    padding:const EdgeInsets.all(14),
    decoration:BoxDecoration(
      gradient:const LinearGradient(colors:[Color(0xFF1B1224),Color(0xFF100D16)]),
      borderRadius:BorderRadius.circular(20),
      border:Border.all(color:Color(0x22FFD643)),
    ),
    child:Row(children:[
      CircleAvatar(radius:28,backgroundColor:const Color(0xFF291C34),backgroundImage:avatarUrl==null?null:NetworkImage(avatarUrl!),child:avatarUrl==null?Text(name.isEmpty?'?':name.substring(0,1).toUpperCase()):null),
      const SizedBox(width:11),
      Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text(name,style:const TextStyle(fontWeight:FontWeight.w900,fontSize:12)),
        const SizedBox(height:3),
        Text(subtitle,style:const TextStyle(color:Colors.white38,fontSize:9)),
      ])),
      if(onFollow!=null)OutlinedButton(onPressed:onFollow,child:const Text('Takip')),
      if(onOpen!=null)IconButton(onPressed:onOpen,icon:const Icon(Icons.chevron_right_rounded,color:Colors.white38)),
    ]),
  );
}
