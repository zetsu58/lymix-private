import 'package:flutter/material.dart';

class SoftSurface extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final EdgeInsets margin;
  final double radius;
  final bool elevated;
  const SoftSurface({
    super.key,
    required this.child,
    this.padding=const EdgeInsets.all(14),
    this.margin=EdgeInsets.zero,
    this.radius=20,
    this.elevated=false,
  });

  @override Widget build(BuildContext context)=>Container(
    margin:margin,
    padding:padding,
    decoration:BoxDecoration(
      color:Color(0xFF12101A),
      borderRadius:BorderRadius.circular(radius),
      border:Border.all(color:Colors.white.withValues(alpha: .045)),
      boxShadow:elevated?const[
        BoxShadow(color:Color(0x22000000),blurRadius:22,offset:Offset(0,10)),
      ]:null,
    ),
    child:child,
  );
}
