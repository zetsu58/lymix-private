import 'package:flutter/material.dart';
import '../models/gift_model.dart';
import '../services/coin_wallet_service.dart';

typedef GiftSendCallback = Future<void> Function(LymixGiftItem gift, int quantity);

class GiftSendSheet extends StatefulWidget {
  final String receiverName;
  final GiftSendCallback onSend;
  const GiftSendSheet({super.key, required this.receiverName, required this.onSend});

  @override
  State<GiftSendSheet> createState() => _GiftSendSheetState();
}

class _GiftSendSheetState extends State<GiftSendSheet> {
  String category = 'Mini';
  int selected = 0;
  int qty = 1;
  bool sending = false;
  final cats = const ['Mini', 'Sosyal', 'Premium', 'Epik', 'Efsane'];

  List<LymixGiftItem> get list => lymixGiftCatalog.where((g) => g.category == category).toList();

  @override
  void initState() {
    super.initState();
    CoinWalletService.instance.init();
  }

  @override
  Widget build(BuildContext context) {
    final items = list;
    if (selected >= items.length) selected = 0;
    final gift = items[selected];

    return SafeArea(
      child: Container(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 18),
        decoration: const BoxDecoration(
          color: Color(0xFF100B18),
          borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(9))),
            const SizedBox(height: 12),
            Row(children: [
              const Text('Hediye Atışı', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
              const SizedBox(width: 7),
              Text('→ ${widget.receiverName}', style: const TextStyle(color: Colors.white54, fontSize: 11)),
              const Spacer(),
              AnimatedBuilder(
                animation: CoinWalletService.instance,
                builder: (_, __) => Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                  decoration: BoxDecoration(color: const Color(0x22FFD200), borderRadius: BorderRadius.circular(999)),
                  child: Text('🪙 ${CoinWalletService.instance.balance}', style: const TextStyle(color: Color(0xFFFFD200), fontWeight: FontWeight.w900, fontSize: 12)),
                ),
              ),
            ]),
            const SizedBox(height: 12),
            SizedBox(
              height: 38,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: cats.map((c) => Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(c),
                    selected: category == c,
                    onSelected: (_) => setState(() { category = c; selected = 0; }),
                    selectedColor: const Color(0xFFFFD200),
                    labelStyle: TextStyle(color: category == c ? Colors.black : Colors.white70, fontWeight: FontWeight.w800),
                  ),
                )).toList(),
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 216,
              child: GridView.builder(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4, crossAxisSpacing: 8, mainAxisSpacing: 8, childAspectRatio: .82),
                itemCount: items.length,
                itemBuilder: (_, i) {
                  final g = items[i];
                  final active = i == selected;
                  final color = giftTierColor(g.tier);
                  return GestureDetector(
                    onTap: () => setState(() => selected = i),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 150),
                      padding: const EdgeInsets.all(7),
                      decoration: BoxDecoration(
                        color: active ? color.withValues(alpha: .11) : Colors.white.withValues(alpha: .025),
                        borderRadius: BorderRadius.circular(17),
                        border: Border.all(color: active ? color : Colors.white.withValues(alpha: .05), width: active ? 1.5 : 1),
                      ),
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Text(g.symbol, style: TextStyle(fontSize: active ? 34 : 30)),
                        const SizedBox(height: 4),
                        Text(g.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w800)),
                        Text('${g.coins}', style: TextStyle(fontSize: 9, color: color, fontWeight: FontWeight.w900)),
                        if (g.roomWide) const Text('ODA', style: TextStyle(fontSize: 7, color: Colors.white38)),
                      ]),
                    ),
                  );
                },
              ),
            ),
            Row(children: [
              for (final q in [1, 5, 10, 99])
                Padding(
                  padding: const EdgeInsets.only(right: 7),
                  child: ChoiceChip(
                    label: Text('x$q'),
                    selected: qty == q,
                    onSelected: (_) => setState(() => qty = q),
                    selectedColor: const Color(0xFF783FF2),
                  ),
                ),
              const Spacer(),
              Text('${gift.coins * qty} Coin', style: const TextStyle(color: Color(0xFFFFD200), fontWeight: FontWeight.w900)),
            ]),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFFFFD200), foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                ),
                onPressed: sending ? null : () async {
                  final total = gift.coins * qty;
                  final ok = await CoinWalletService.instance.spend(total);
                  if (!mounted) return;
                  if (!ok) {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Yetersiz Coin. Coin mağazasından bakiye yükleyebilirsin.')));
                    return;
                  }
                  setState(() => sending = true);
                  await widget.onSend(gift, qty);
                  if (mounted) Navigator.pop(context);
                },
                icon: Icon(sending ? Icons.hourglass_top_rounded : Icons.auto_awesome_rounded),
                label: Text(sending ? 'Gönderiliyor...' : 'Gönder • ${gift.name}', style: const TextStyle(fontWeight: FontWeight.w900)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
