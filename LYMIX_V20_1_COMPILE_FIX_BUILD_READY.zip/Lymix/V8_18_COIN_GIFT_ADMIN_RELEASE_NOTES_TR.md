# LYMIX V8.18 — Coin, Atış, Hediye Animasyonları ve Admin Ekonomisi

Bu sürümde referans videolardaki ürün kalıpları Lymix marka diliyle yeniden tasarlandı; başka uygulamanın görsel kimliği veya fontları birebir kopyalanmadı.

## Coin ve atış
- Oda içindeki tüm hediye atışları LymCoin bakiyesinden düşer.
- Demo/test cüzdanı cihazda kalıcı tutulur; production'da bakiye ve harcama backend doğrulamalı olmalıdır.
- x1, x5, x10 ve x99 seri gönderim seçenekleri eklendi.
- Hediye gönderimi oda toplam atışına ve sohbet sistem mesajına yansır.
- Kullanıcı koltuğundan hediye seçildiğinde alıcı kullanıcı adı olarak işlenir.

## 18 Lymix hediyesi
10 Coin ile 1.000.000 Coin arasında Mini, Sosyal, Premium, Epik ve Efsane katmanları oluşturuldu. Oda çapı hediyeler ve hafif hızlı hediyeler ayrıldı.

## Animasyon motoru
Pop, burst, rain, orbit, streak, crown, portal ve comet hareket aileleri eklendi. Epik/Efsane hediyelerde parçacık yoğunluğu ve oda çapı görsel vurgu artar.

## Admin
Profil > Admin ve Owner Ops üzerinden Ekonomi & Hediyeler merkezi açılır. Hediye sistemi, lucky, oda çapı efektleri, anti-abuse ve etkinlik fiyat çarpanı kontrol ekranları eklendi. Katalog öğeleri demo olarak tek tek açılıp kapatılabilir.

## Build
- Lymix app icon korunur.
- Android scaffold Codemagic'te kurulu Flutter stable sürümünden üretilir.
- shared_preferences ve url_launcher doğrudan pubspec'e sabitlendi.
