import 'package:flutter_test/flutter_test.dart';
import 'package:lymix/main.dart';

void main() {
  testWidgets('LYMIX app smoke test', (WidgetTester tester) async {
    await tester.pumpWidget(const LymixApp());
    await tester.pump();
    expect(find.text('LYMIX'), findsWidgets);
  });
}
