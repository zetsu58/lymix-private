# Lymix oyun sağlayıcı entegrasyon notu

Bu proje oyun sağlayıcısını uygulamadan ayırır. Flutter tarafı `GameProviderService` üzerinden backend'e gider; sağlayıcı anahtarı/secret uygulamanın içine yazılmaz.

## Önerilen sıra

1. Önce **SUD / SudGIP** ile görüş. Voice-room ve social-app mini-game kullanımına doğrudan odaklanıyor; Android/iOS/Web ve Flutter istemci dokümantasyonu var. Sağlayıcı hesabı açıldığında `App ID`, `App Key`, test/prod ortamı ve kullanacağın oyunların `mgId` değerlerini al.
2. Alternatif olarak **ByteSun** için Agora'nın partner/extension kanalı üzerinden iletişim kur. ByteSun oyunları H5 embed ile veya daha derin entegrasyon için SDK ile sunulabiliyor.
3. Ses odası altyapısı için mevcut Agora entegrasyonu korunabilir. Oyun SDK'sı, RTC'den bağımsız bir katman olarak çalışır.

## SUD akışı

- SUD hesabı/iş ortaklığı açılır.
- Dashboard veya teknik ekipten `App ID`, `App Key` ve oyun `mgId` değerleri alınır.
- Flutter/native tarafta SDK init edilir.
- Kullanıcı + oda + mgId için kısa süreli `code` backend'den istenir.
- SDK `loadMG` ile aynı `roomId`'deki oyuncuları aynı oyuna sokar.
- Oyunun durum event'leri uygulamaya dönerek oda UI'ı, başarı rozeti ve sonuç ekranı güncellenir.

> Üretimde kısa süreli code üretimini SUD'un resmi server auth akışına bağla. AppKey'i APK/IPA içine gömme.

## ByteSun akışı

- Ticari erişim/oyun kataloğu için partner/sales ile anlaşılır.
- H5 launch URL veya SDK + token bilgileri alınır.
- H5 verilirse backend kısa ömürlü launch URL üretir, Flutter WebView'da açar.
- SDK verilirse Flutter platform channel veya sağlayıcının resmi Flutter paketi üzerinden native entegrasyon yapılır.

## Lymix tarafındaki hazır noktalar

- `lib/services/game_provider_service.dart`: Flutter -> backend launch isteği
- `backend/services/gameProviderService.js`: provider adapter
- `backend/.env.example`: anahtarların yerleri
- `lib/screens/game_center_screen.dart`: özgün Lymix oyun merkezi
- `lib/screens/gift_catalog_screen.dart`: özgün hediye kataloğu taslağı

## Güvenlik

- Provider secret/AppKey yalnızca backend'de.
- Launch/token'lar kısa ömürlü ve userId/roomId'ye bağlı olmalı.
- Oyun sonucu ve coin hareketleri istemciden körü körüne kabul edilmemeli; provider callback/webhook veya server-side imza doğrulaması kullanılmalı.
- Gerçek paraya çevrilebilen bahis/şans oyunları eklenirse ülke mevzuatı ve mağaza politikaları ayrıca incelenmeli. Lymix sanal coin sistemi için de sağlayıcının izin verdiği ekonomi modelini sözleşmede netleştir.
