# LYMIX Android telefonda anlık deneme

Bu paket, telefonda gerçek uygulama olarak deneyebilmek için hazırlanmıştır.

## En kolay yöntem (Windows)
1. ZIP'i klasöre çıkarın.
2. Bilgisayarda Flutter SDK'nın çalıştığını doğrulayın:
   `flutter --version`
3. `BUILD_ANDROID_PREVIEW.bat` dosyasına çift tıklayın.
4. İşlem bittiğinde APK burada oluşur:
   `build/app/outputs/flutter-apk/app-debug.apk`
5. APK'yı Android telefona gönderip kurun.

## USB ile doğrudan telefonda açmak
Telefon:
- Geliştirici seçeneklerini açın.
- USB hata ayıklamayı açın.
- USB ile bilgisayara bağlayın.

Proje klasöründe:
`flutter devices`
`flutter run`

Bu yöntem APK kurup tekrar tekrar göndermekten daha hızlıdır; kod değiştikçe hot reload kullanılabilir.

## Kontrol sonucu
- lib altındaki göreli Dart importlarında eksik dosya bulunmadı.
- Branding ve room_backgrounds asset klasörleri mevcut.
- V8.15 canlı pulse helper içindeki bir Dart yazım hatası düzeltildi.
- Bu çalışma ortamında Flutter SDK kurulu olmadığı için burada APK derlenemedi.
- Mevcut Android klasörü eksik Flutter platform scaffold dosyaları içerdiği için build script ilk adımda
  `flutter create --platforms=android ... .` komutuyla eksikleri otomatik tamamlar.
