# LYMIX V8.12 — Production Polish + Moderation

Bu sürüm V8.11 üzerine kapsamlı ürünleştirme katmanı ekler.

## Profesyonel ürün deneyimi
- Merkezi LYMIX tasarım sistemi ve marka renkleri korunur.
- Bildirim Merkezi, Gizlilik Merkezi ve Şikayetlerim ekranları eklendi.
- Çevrimdışı durum bandı, loading/error/empty state bileşenleri eklendi.
- Ayarlara hareket azaltma ve veri tasarrufu seçenekleri eklendi.
- Eski Flutter dışı kaynaklar lib klasöründen legacy_migration alanına taşındı.
- Güvenli oturum için flutter_secure_storage altyapısı ve token-aware API istemcisi eklendi.

## Oda + VIP + Atış
- Oda Atışları günlük/haftalık/aylık sıralaması artık backend hediye ledger'ından hesaplanır.
- Hediye tekrar işlem/idempotency koruması eklendi.
- VIP avantajları server-side entitlement modeline taşındı.
- Oda admin/koltuk menüsü ve LYMIX profesyonel UI iyileştirmeleri korunur.

## Mesaj ve ses moderasyonu
- Mesaj gönderilmeden önce cihaz tarafı hızlı filtre + backend kesin kontrol.
- Küfür/uygunsuz ifade içeren mesaj gönderilmez ve kullanıcı hata alır.
- Ses için AI/ASR transkript moderasyon hattı eklendi.
- Düşük güven skorları yaptırım üretmez.
- Tekrarlanan ses ihlali politikası:
  1-2 ihlal: uyarı
  3-4 ihlal: 5 dakika mikrofon kapatma
  5+ ihlal: 30 dakika oda uzaklaştırması
- AI ses moderasyon kaydı otomatik şikayet/evidence kaydı oluşturur.
- Kullanıcı, oda veya mesaja uzun basarak şikayet oluşturabilir.
- Şikayet geçmişi kullanıcı tarafından takip edilebilir.
- Moderatörler için rapor kuyruğu ve durum güncelleme API'si eklendi.

## Ses AI entegrasyon notu
- Lymix tarafında yaptırım, webhook, kanıt ve UI altyapısı hazırdır.
- Gerçek canlı konuşmayı metne dönüştürmek için üretimde bir ASR sağlayıcısı (veya kendi konuşmadan-metne sunucunuz) Agora ses hattına bağlanmalıdır.
- Sağlayıcı final transkriptleri `/api/moderation-voice-webhook` adresine `x-lymix-asr-secret` ile göndermelidir.
- Ham ses yerine kısa transkript parçalarının tutulması varsayılan gizlilik yaklaşımıdır.

## Harici üretim bağımlılıkları
- Google Play ve App Store ödeme doğrulaması gerçek mağaza kimlik bilgileri olmadan güvenli biçimde tamamlanamaz. Mevcut backend bu durumda FAIL-CLOSED davranır ve coin kredi etmez.
- JWT zorunluluğu üretimde `LYMIX_REQUIRE_AUTH=true` yapılmalı ve güçlü `JWT_SECRET` tanımlanmalıdır.
- `LYMIX_API_BASE` HTTPS üretim API adresine ayarlanmalıdır.
- Font/simge dosyaları üretimde CDN/object storage'a taşınmalıdır.
