import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:in_app_purchase/in_app_purchase.dart';

class IAPService {
  final InAppPurchase _iap = InAppPurchase.instance;
  late StreamSubscription<List<PurchaseDetails>> _subscription;

  // Google Play Console ve App Store Connect'te tanımladığımız Tüketilebilir (Consumable) ürün ID'leri
  static const Set<String> _kProductIds = {
    'lymix_coins_100',
    'lymix_coins_500',
    'lymix_coins_1000',
    'lymix_coins_5000',
  };

  List<ProductDetails> products = [];
  bool isAvailable = false;
  String currentUserId = "";

  // 1. Ödeme Servisini Başlatma ve Mağaza Ürünlerini Çekme
  Future<void> initIAP(String userId, Function(int newBalance) onPurchaseSuccess, Function(String error) onError) async {
    currentUserId = userId;
    isAvailable = await _iap.isAvailable();

    if (!isAvailable) {
      onError("Uygulama içi satın alma servisi şu an kullanılabilir değil.");
      return;
    }

    // Satın Alma Dinleyicisi (Stream) Kaydı
    final Stream<List<PurchaseDetails>> purchaseUpdated = _iap.purchaseStream;
    _subscription = purchaseUpdated.listen(
      (List<PurchaseDetails> purchaseDetailsList) {
        _listenToPurchaseUpdated(purchaseDetailsList, onPurchaseSuccess, onError);
      },
      onDone: () => _subscription.cancel(),
      onError: (error) => onError("Ödeme akışı hatası: $error"),
    );

    // Mağazadaki Ürün Detaylarını Çekme
    final ProductDetailsResponse response = await _iap.queryProductDetails(_kProductIds);
    if (response.notFoundIDs.isNotEmpty) {
      debugPrint("Bulunamayan Ürün ID'leri: ${response.notFoundIDs}");
    }
    products = response.productDetails;
  }

  // 2. Satın Alma İşlemini Başlatma
  Future<void> buyCoins(ProductDetails product) async {
    final PurchaseParam purchaseParam = PurchaseParam(productDetails: product);
    // Coin tüketilebilir bir nesne olduğu için buyConsumable çağrılır
    await _iap.buyConsumable(purchaseParam: purchaseParam);
  }

  // 3. Satın Alma Durumlarını Dinleme
  Future<void> _listenToPurchaseUpdated(
    List<PurchaseDetails> purchaseDetailsList,
    Function(int newBalance) onPurchaseSuccess,
    Function(String error) onError,
  ) async {
    for (var purchaseDetails in purchaseDetailsList) {
      if (purchaseDetails.status == PurchaseStatus.pending) {
        debugPrint("Ödeme bekleniyor...");
      } else if (purchaseDetails.status == PurchaseStatus.error) {
        onError(purchaseDetails.error?.message ?? "Ödeme işlemi başarısız.");
        if (purchaseDetails.pendingCompletePurchase) {
          await _iap.completePurchase(purchaseDetails);
        }
      } else if (purchaseDetails.status == PurchaseStatus.purchased ||
                 purchaseDetails.status == PurchaseStatus.restored) {
        
        // 4. Sunucu Tarafı Makbuz Doğrulama (Server-Side Verification)
        bool isValid = await _verifyPurchaseOnBackend(purchaseDetails);

        if (isValid) {
          // Mağazaya işlemin teslim edildiğini bildir (Tüketilebilir olarak işaretle)
          if (purchaseDetails.pendingCompletePurchase) {
            await _iap.completePurchase(purchaseDetails);
          }
          onPurchaseSuccess(100); // Örnek bakiye güncelleme tetiklemesi
        } else {
          onError("Ödeme doğrulaması sunucu tarafından reddedildi!");
        }
      }
    }
  }

  // 4. Node.js Backend Verification İsteği
  Future<bool> _verifyPurchaseOnBackend(PurchaseDetails purchaseDetails) async {
    try {
      final response = await http.post(
        Uri.parse("https://api.lymix.app/api/v1/payments/verify"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "userId": currentUserId,
          "productId": purchaseDetails.productID,
          "purchaseToken": purchaseDetails.verificationData.serverVerificationData,
          "platform": Platform.isAndroid ? "android" : "ios",
          "transactionId": purchaseDetails.purchaseID,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data["success"] == true;
      }
      return false;
    } catch (e) {
      debugPrint("Backend doğrulama hatası: $e");
      return false;
    }
  }

  void dispose() {
    _subscription.cancel();
  }
}