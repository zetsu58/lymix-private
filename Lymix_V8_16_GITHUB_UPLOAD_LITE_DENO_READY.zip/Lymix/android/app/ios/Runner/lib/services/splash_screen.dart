// lib/splash_screen.dart
import 'package:flutter/material.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    // Örnek: 3 saniye sonra ana ekrana yönlendir
    Future.delayed(const Duration(seconds: 3), () {
      // Navigator.pushReplacementNamed(context, '/home'); // Ana ekrana git
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Lymix Tema: Derin Gece Moru Gradyan Arka Plan
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF1C0C36), // Üst koyu mor
              Color(0xFF0A0414), // Alt siyah-mor
            ],
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // YENİ TASARLANAN LOGOYU BURADA EKLEDİK
              Image.asset(
                'assets/images/lymix_main_logo.png',
                width: 250, // İstenilen genişlik
                fit: BoxFit.contain,
              ),
              const SizedBox(height: 30),
              // İsteğe bağlı yükleniyor animasyonu (Sarı renkte)
              const CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFFFD700)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}