// lib/main.dart
import 'package:flutter/material.dart';
import 'splash_screen.dart'; // Yeni ekranı import edin

void main() {
  runApp(const LymixApp());
}

class LymixApp extends StatelessWidget {
  const LymixApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Lymix',
      theme: ThemeData.dark(), // Koyu tema
      home: const SplashScreen(), // Uygulama SplashScreen ile başlar
    );
  }
}