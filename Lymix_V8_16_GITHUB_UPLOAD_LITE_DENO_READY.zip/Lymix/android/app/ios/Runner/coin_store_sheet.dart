// lib/widgets/coin_store_sheet.dart
import 'package:flutter/material.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import '../services/iap_service.dart';

class CoinStoreSheet extends StatefulWidget {
  final String userId;
  final Function(int addedCoins) onCoinsUpdated;

  const CoinStoreSheet({
    Key? key,
    required this.userId,
    required this.onCoinsUpdated,
  }) : super(key: key);

  @override
  State<CoinStoreSheet> createState() => _CoinStoreSheetState();
}

class _CoinStoreSheetState extends State<CoinStoreSheet> {
  final IAPService _iapService = IAPService();
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _initStore();
  }

  Future<void> _initStore() async {
    await _iapService.initIAP(
      widget.userId,
      (newCoins) {
        widget.onCoinsUpdated(newCoins);
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Tebrikler! Coin bakiyeniz güncellendi. 🎉")),
        );
      },
      (error) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Hata: $error"), backgroundColor: Colors.red),
        );
      },
    );

    if (mounted) {
      setState(() => _isLoading = false);
    }
  }

  @override
  void dispose() {
    _iapService.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 450,
      padding: const EdgeInsets.all(20),
      decoration: const BoxDecoration(
        color: Color(0xFF1E1035),
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Row(
                children: [
                  Icon(Icons.monetization_on, color: Colors.amber, size: 28),
                  SizedBox(width: 8),
                  Text(
                    "Lymix Coin Mağazası",
                    style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              IconButton(
                icon: const Icon(Icons.close, color: Colors.white54),
                onPressed: () => Navigator.pop(context),
              )
            ],
          ),
          const SizedBox(height: 16),
          _isLoading
              ? const Expanded(child: Center(child: CircularProgressIndicator(color: Color(0xFFFF2D55))))
              : Expanded(
                  child: GridView.builder(
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      childAspectRatio: 1.2,
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 12,
                    ),
                    itemCount: _iapService.products.length,
                    itemBuilder: (context, index) {
                      final product = _iapService.products[index];
                      return _buildCoinTile(product);
                    },
                  ),
                ),
        ],
      ),
    );
  }

  Widget _buildCoinTile(ProductDetails product) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF2A1B4E),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.amber.withOpacity(0.3), width: 1),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Icon(Icons.stars, color: Colors.amber, size: 36),
          Text(
            product.title, // Örn: 500 Lymix Coins
            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13),
            textAlign: TextAlign.center,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          ElevatedButton(
            onPressed: () => _iapService.buyCoins(product),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFFF2D55),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            ),
            child: Text(
              product.price, // Örn: ₺49,99 veya $1.99
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12),
            ),
          )
        ],
      ),
    );
  }
}