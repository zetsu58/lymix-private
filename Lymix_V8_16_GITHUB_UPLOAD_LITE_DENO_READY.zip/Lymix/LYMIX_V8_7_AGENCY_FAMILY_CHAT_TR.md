# Lymix V8.8 — Ajans Ailesi & Admin Limiti Düzeltmesi

- Ajans ailesine üye alımında sayı sınırı yoktur.
- Aileye katılma başvurularını ajans sahibi onaylar veya reddeder.
- Onaylanan tüm aile üyeleri ajansın özel mesaj odasına erişebilir.
- Ajans sahibi, aile üyeleri arasından en fazla 6 kişiye `Admin` yetkisi verebilir.
- Ajans sahibi bu 6 kişilik admin limitine dahil değildir; en üst yetkili olarak kalır.
- Admin yetkisi aile üyeliğinden ayrıdır; admin yetkisi kaldırıldığında kullanıcı aile üyesi ve sohbet katılımcısı olmaya devam eder.
- Aileden çıkarılan kullanıcı özel ajans sohbetine erişimini kaybeder.
- Production'da admin atama/kaldırma işlemleri audit log'a yazılmalı ve yalnızca ajans sahibi JWT rolüyle yapılmalıdır.
