# Lymix Admin API kısa liste

Base path: `/api/admin`

- `GET /stats`
- `GET /users?q=`
- `GET /users/:userId`
- `POST /users/:userId/custom-id`
- `POST /users/adjust-balance`
- `POST /users/:userId/roles`
- `POST /users/:userId/status`
- `POST /users/:userId/contact-device`
- `POST /users/:userId/ban`
- `DELETE /users/:userId/ban`
- `POST /security/device-ban`
- `POST /security/ip-ban`
- `GET /security/bans`
- `POST /agencies`
- `POST /agencies/:agencyId/owner`
- `POST /agencies/:agencyId/broadcasters`
- `POST /rooms/:roomId/agency`
- `POST /rooms/:roomId/moderate`
- `POST /verifications`
- `GET /verifications`
- `POST /verifications/:caseId/review`
- `GET /users/:userId/duplicate-risk`
- `POST /system-message`
- `GET /config`
- `POST /config/feature`
- `POST /config/economy`
- `GET /audit`
