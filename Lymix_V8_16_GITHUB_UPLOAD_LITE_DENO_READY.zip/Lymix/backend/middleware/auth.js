const jwt = require('jsonwebtoken');

function parseBearer(req) {
  const raw = req.get('authorization') || '';
  return raw.toLowerCase().startsWith('bearer ') ? raw.slice(7).trim() : '';
}

function verifyToken(token) {
  const secret = process.env.JWT_SECRET;
  if (!secret) throw new Error('JWT_SECRET_NOT_CONFIGURED');
  return jwt.verify(token, secret, {
    algorithms: ['HS256'],
    issuer: process.env.JWT_ISSUER || 'lymix',
    audience: process.env.JWT_AUDIENCE || 'lymix-app',
  });
}

function httpAuth({ users, required = process.env.LYMIX_REQUIRE_AUTH === 'true' }) {
  return (req, res, next) => {
    const token = parseBearer(req);
    if (!token && !required) {
      const demoId = String(req.get('x-demo-user-id') || req.body?.userId || req.query?.userId || '');
      if (demoId && users.has(demoId)) req.auth = { userId: demoId, demo: true };
      return next();
    }
    if (!token) return res.status(401).json({ error: 'auth_required', message: 'Oturum doğrulaması gerekli.' });
    try {
      const payload = verifyToken(token);
      const userId = String(payload.sub || payload.userId || '');
      if (!users.has(userId)) return res.status(401).json({ error: 'unknown_user' });
      req.auth = { userId, role: payload.role || 'user', demo: false };
      next();
    } catch (e) {
      return res.status(401).json({ error: 'invalid_token', message: 'Oturum geçersiz veya süresi dolmuş.' });
    }
  };
}

function socketAuth({ users, required = process.env.LYMIX_REQUIRE_AUTH === 'true' }) {
  return (socket, next) => {
    const token = String(socket.handshake.auth?.token || '');
    if (!token && !required) {
      const userId = String(socket.handshake.auth?.userId || socket.handshake.query?.userId || '');
      if (!userId || !users.has(userId)) return next(new Error('Geçersiz kullanıcı kimliği'));
      socket.userId = userId;
      socket.auth = { userId, demo: true };
      return next();
    }
    if (!token) return next(new Error('Oturum doğrulaması gerekli'));
    try {
      const payload = verifyToken(token);
      const userId = String(payload.sub || payload.userId || '');
      if (!users.has(userId)) return next(new Error('Bilinmeyen kullanıcı'));
      socket.userId = userId;
      socket.auth = { userId, role: payload.role || 'user', demo: false };
      next();
    } catch (_) {
      next(new Error('Oturum geçersiz veya süresi dolmuş'));
    }
  };
}

module.exports = { httpAuth, socketAuth };
