const express = require('express');
const robust = require('../services/robustnessService');
const governance = require('../services/roomGovernanceService');

module.exports = function createRobustnessRoutes({ rooms, users, io }) {
  const r = express.Router();
  const ownerToken = () => process.env.OWNER_OPS_TOKEN || '';
  function owner(req, res, next) {
    const supplied = String(req.headers['x-owner-token'] || '');
    if (!ownerToken() || supplied !== ownerToken()) return res.status(403).json({ error: 'owner_only' });
    next();
  }

  r.get('/health/summary', owner, (req, res) => res.json(robust.snapshot({ activeRooms: rooms.size, users: users.size, sockets: io.engine.clientsCount })));
  r.get('/audit', owner, (req, res) => res.json(robust.audit.slice(0, 500)));
  r.get('/ledger', owner, (req, res) => res.json(robust.ledger.slice(0, 1000)));
  r.get('/fraud', owner, (req, res) => res.json(robust.fraudSignals.slice(0, 500)));
  r.get('/incidents', owner, (req, res) => res.json(robust.incidents.slice(0, 200)));
  r.post('/incidents', owner, (req, res) => res.status(201).json(robust.createIncident(req.body?.title, req.body?.severity, req.body?.detail)));
  r.patch('/feature-flags', owner, (req, res) => {
    const allowed = Object.keys(robust.state.featureFlags);
    for (const k of allowed) if (k in (req.body || {})) robust.state.featureFlags[k] = Boolean(req.body[k]);
    robust.appendAudit({ actorId: 'OWNER_ROOT', action: 'feature_flags_update', targetType: 'system', targetId: 'global', after: robust.state.featureFlags, ip: req.ip });
    res.json(robust.state.featureFlags);
  });
  r.patch('/min-version', owner, (req, res) => {
    robust.state.minClientVersion = String(req.body?.version || robust.state.minClientVersion).slice(0, 32);
    res.json({ minClientVersion: robust.state.minClientVersion });
  });

  r.get('/rooms/:roomId/governance', (req, res) => {
    const room = rooms.get(String(req.params.roomId)); if (!room) return res.status(404).json({ error: 'room_not_found' });
    res.json(governance.publicMeta(room));
  });
  r.put('/rooms/:roomId/rules', owner, (req, res) => {
    const room = rooms.get(String(req.params.roomId)); if (!room) return res.status(404).json({ error: 'room_not_found' });
    try { const out = governance.updateRules(room, req.body?.rules); io.to(room.id).emit('room_rules_updated', out); res.json(out); }
    catch (e) { res.status(400).json({ error: e.message }); }
  });
  r.put('/rooms/:roomId/agency', owner, (req, res) => {
    const room = rooms.get(String(req.params.roomId)); if (!room) return res.status(404).json({ error: 'room_not_found' });
    const out = governance.updateAgency(room, req.body || {}); io.to(room.id).emit('room_agency_updated', out); res.json(out);
  });

  return r;
};
