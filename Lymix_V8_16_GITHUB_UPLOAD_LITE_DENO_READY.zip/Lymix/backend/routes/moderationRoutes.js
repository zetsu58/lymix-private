const express = require('express');

module.exports = function createModerationRoutes({ moderation, users, rooms, io }) {
  const router = express.Router();

  router.post('/text/check', (req, res) => {
    const userId = req.auth?.userId || req.body?.userId;
    const result = moderation.applyTextPolicy(userId, req.body?.text);
    res.json(result);
  });

  router.post('/voice/transcript', (req, res) => {
    const userId = req.auth?.userId || req.body?.userId;
    const roomId = String(req.body?.roomId || '');
    const transcript = String(req.body?.transcript || '').slice(0, 2000);
    if (!userId || !rooms.has(roomId)) return res.status(400).json({ error: 'invalid_context' });

    const result = moderation.applyVoicePolicy(userId, transcript);
    if (result.action !== 'allow') {
      const payload = {
        userId: String(userId),
        roomId,
        action: result.action,
        strikes: result.strikes,
        durationMs: result.durationMs || 0,
        message: result.action === 'warning'
          ? `Uygunsuz dil algılandı. Tekrarı halinde mikrofonun geçici olarak kapatılabilir. (${result.strikes}/3)`
          : result.action === 'voice_mute'
            ? 'Tekrarlanan uygunsuz dil nedeniyle mikrofonun 5 dakika süreyle kapatıldı.'
            : 'Tekrarlanan uygunsuz dil nedeniyle odadan 30 dakika uzaklaştırıldın.',
      };
      io.to(roomId).emit('moderation_action', payload);
      moderation.createReport({
        reporterId: 'system-ai',
        targetUserId: userId,
        roomId,
        category: 'voice_profanity',
        description: 'AI ses moderasyonu tarafından oluşturulan otomatik kayıt.',
        source: 'voice_ai',
        evidence: [{ type: 'transcript_excerpt', value: transcript.slice(0, 240) }],
      });
    }
    res.json(result);
  });

  router.post('/reports', (req, res) => {
    const reporterId = req.auth?.userId || req.body?.reporterId;
    const row = moderation.createReport({
      reporterId,
      targetUserId: req.body?.targetUserId,
      roomId: req.body?.roomId,
      category: req.body?.category,
      description: req.body?.description,
      source: 'user',
      evidence: req.body?.evidence,
    });
    res.status(201).json(row);
  });

  router.get('/reports/mine', (req, res) => {
    const reporterId = req.auth?.userId || req.query?.userId;
    res.json({ rows: moderation.listReports({ reporterId }) });
  });

  router.get('/reports/queue', (req, res) => {
    if (!['admin','owner','moderator'].includes(String(req.auth?.role || ''))) {
      return res.status(403).json({ error: 'forbidden' });
    }
    res.json({ rows: moderation.listReports({ status: req.query?.status || undefined }) });
  });

  router.patch('/reports/:reportId', (req, res) => {
    if (!['admin','owner','moderator'].includes(String(req.auth?.role || ''))) {
      return res.status(403).json({ error: 'forbidden' });
    }
    const row = moderation.reports.find(r => r.id === String(req.params.reportId));
    if (!row) return res.status(404).json({ error: 'report_not_found' });
    const allowed = new Set(['open','reviewing','resolved','dismissed']);
    const next = String(req.body?.status || '');
    if (!allowed.has(next)) return res.status(400).json({ error: 'invalid_status' });
    row.status = next;
    row.reviewedAt = new Date().toISOString();
    row.reviewedBy = req.auth.userId;
    row.resolutionNote = String(req.body?.note || '').slice(0, 1000);
    res.json(row);
  });

  return router;
};
