const express=require('express');

module.exports=function createAccountRoutes({accountRequests}){
  const router=express.Router();

  router.post('/data-export',(req,res)=>{
    const userId=req.auth?.userId||req.body?.userId;
    if(!userId)return res.status(401).json({error:'auth_required'});
    res.status(202).json(accountRequests.create({userId,type:'data_export'}));
  });

  router.post('/delete-request',(req,res)=>{
    const userId=req.auth?.userId||req.body?.userId;
    if(!userId)return res.status(401).json({error:'auth_required'});
    if(req.body?.reauthenticated!==true){
      return res.status(428).json({error:'reauth_required',message:'Hesap silme için yeniden doğrulama gerekli.'});
    }
    res.status(202).json(accountRequests.create({userId,type:'account_delete'}));
  });

  router.get('/requests',(req,res)=>{
    const userId=req.auth?.userId||req.query?.userId;
    res.json({rows:accountRequests.mine(userId)});
  });

  return router;
};
