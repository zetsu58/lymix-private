const express = require('express');

module.exports = function createAppealRoutes({ appeals, roleService }) {
  const router = express.Router();

  router.post('/', (req, res) => {
    const userId = req.auth?.userId || req.body?.userId;
    if (!userId) return res.status(401).json({ error: 'auth_required' });
    const row = appeals.create({
      userId,
      roomId: req.body?.roomId,
      sanctionType: req.body?.sanctionType,
      reason: req.body?.reason,
    });
    res.status(201).json(row);
  });

  router.get('/mine', (req, res) => {
    const userId = req.auth?.userId || req.query?.userId;
    if (!userId) return res.status(401).json({ error: 'auth_required' });
    res.json({ rows: appeals.mine(userId) });
  });

  router.get('/queue', (req, res) => {
    const role = req.auth?.role || 'user';
    if (!['moderator','admin','owner'].includes(role)) return res.status(403).json({ error: 'forbidden' });
    res.json({ rows: appeals.queue(req.query?.status) });
  });

  router.patch('/:id', (req, res) => {
    const role = req.auth?.role || 'user';
    if (!['moderator','admin','owner'].includes(role)) return res.status(403).json({ error: 'forbidden' });
    const allowed = new Set(['open','reviewing','accepted','rejected']);
    const status = String(req.body?.status || '');
    if (!allowed.has(status)) return res.status(400).json({ error: 'invalid_status' });
    const row = appeals.update(req.params.id, {
      status,
      reviewerId: req.auth?.userId,
      note: req.body?.note,
    });
    if (!row) return res.status(404).json({ error: 'appeal_not_found' });
    res.json(row);
  });

  return router;
};
