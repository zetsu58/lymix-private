const express = require('express');

module.exports = function createDeviceRoutes({ devices }) {
  const router = express.Router();

  router.get('/', (req, res) => {
    const userId = req.auth?.userId || req.query?.userId;
    if (!userId) return res.status(401).json({ error: 'auth_required' });
    res.json({ rows: devices.list(userId) });
  });

  router.post('/register', (req, res) => {
    const userId = req.auth?.userId || req.body?.userId;
    if (!userId) return res.status(401).json({ error: 'auth_required' });
    res.status(201).json(devices.upsert({
      userId,
      deviceName: req.body?.deviceName,
      platform: req.body?.platform,
      appVersion: req.body?.appVersion,
      tokenHash: req.body?.tokenHash,
    }));
  });

  router.delete('/:id', (req, res) => {
    const userId = req.auth?.userId || req.query?.userId;
    if (!devices.revoke(userId, req.params.id)) return res.status(404).json({ error: 'device_not_found' });
    res.json({ ok: true });
  });

  router.post('/revoke-others', (req, res) => {
    const userId = req.auth?.userId || req.body?.userId;
    devices.revokeOthers(userId, req.body?.currentId);
    res.json({ ok: true });
  });

  return router;
};
