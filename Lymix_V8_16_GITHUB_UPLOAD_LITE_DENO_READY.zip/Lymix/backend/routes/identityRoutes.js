const express = require('express');
const multer = require('multer');
const sharp = require('sharp');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const router = express.Router();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024, files: 1 }
});

const rootDir = path.join(__dirname, '..', 'uploads', 'identity');
fs.mkdirSync(rootDir, { recursive: true });

function safeId(v) {
  return String(v || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 64);
}
function ext(name) {
  return path.extname(String(name || '')).replace('.', '').toLowerCase();
}
function checksum(buffer) {
  return crypto.createHash('sha256').update(buffer).digest('hex');
}

module.exports = function createIdentityRoutes({ users }) {
  router.get('/:userId', (req, res) => {
    const user = users.get(String(req.params.userId));
    if (!user) return res.status(404).json({ error: 'user_not_found' });
    res.json({
      userId: user.id,
      identity: user.identity || {
        fontFamily: null, fontUrl: null, iconUrl: null, fontChecksum: null, iconChecksum: null
      }
    });
  });

  router.post('/:userId/font', upload.single('file'), async (req, res) => {
    const userId = safeId(req.params.userId);
    const user = users.get(userId);
    if (!user) return res.status(404).json({ error: 'user_not_found' });
    if (!req.file) return res.status(400).json({ error: 'file_required' });
    const extension = ext(req.file.originalname);
    if (!['ttf', 'otf'].includes(extension)) return res.status(415).json({ error: 'unsupported_font' });

    const sum = checksum(req.file.buffer);
    const family = `lymix_user_${userId}_${sum.slice(0, 10)}`;
    const filename = `${family}.${extension}`;
    fs.writeFileSync(path.join(rootDir, filename), req.file.buffer);

    user.identity = {
      ...(user.identity || {}),
      fontFamily: family,
      fontUrl: `/uploads/identity/${filename}`,
      fontChecksum: sum
    };
    res.json({ ok: true, identity: user.identity });
  });

  router.post('/:userId/icon', upload.single('file'), async (req, res) => {
    const userId = safeId(req.params.userId);
    const user = users.get(userId);
    if (!user) return res.status(404).json({ error: 'user_not_found' });
    if (!req.file) return res.status(400).json({ error: 'file_required' });
    const extension = ext(req.file.originalname);
    if (!['png', 'jpg', 'jpeg', 'webp'].includes(extension)) return res.status(415).json({ error: 'unsupported_icon' });

    try {
      // Orientation, color space and aspect ratio are normalized so iOS/Android render the same pixels.
      const normalized = await sharp(req.file.buffer, { failOn: 'error' })
        .rotate()
        .resize(512, 512, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
        .ensureAlpha()
        .webp({ quality: 92, effort: 4 })
        .toBuffer();

      const sum = checksum(normalized);
      const filename = `icon_${userId}_${sum.slice(0, 12)}.webp`;
      fs.writeFileSync(path.join(rootDir, filename), normalized);

      user.identity = {
        ...(user.identity || {}),
        iconUrl: `/uploads/identity/${filename}`,
        iconChecksum: sum
      };
      res.json({ ok: true, identity: user.identity });
    } catch (_) {
      res.status(422).json({ error: 'invalid_image' });
    }
  });

  return router;
};
