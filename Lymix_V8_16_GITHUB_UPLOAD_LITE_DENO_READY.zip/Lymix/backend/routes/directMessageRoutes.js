const express=require('express');

module.exports=function createDirectMessageRoutes({dm,antiAbuse,moderation}){
  const router=express.Router();

  router.get('/requests',(req,res)=>{
    const userId=req.auth?.userId||req.query?.userId;
    res.json({rows:dm.listRequests(userId)});
  });

  router.post('/requests',(req,res)=>{
    const senderId=req.auth?.userId||req.body?.senderId;
    const receiverId=String(req.body?.receiverId||'');
    const text=String(req.body?.text||'').trim();
    const rate=antiAbuse.consume(senderId,'room_invite');
    if(!rate.allowed)return res.status(429).json({error:'rate_limited',retryAfterMs:rate.retryAfterMs});
    const mod=moderation.applyTextPolicy(senderId,text);
    if(!mod.allowed)return res.status(422).json({error:'profanity',message:'Mesaj isteği uygunsuz dil içeriyor.'});
    try{return res.status(201).json(dm.createRequest({senderId,receiverId,text}));}
    catch(_){return res.status(403).json({error:'blocked'});}
  });

  router.post('/requests/:id/decision',(req,res)=>{
    const userId=req.auth?.userId||req.body?.userId;
    const row=dm.decide({userId,requestId:req.params.id,accept:req.body?.accept===true});
    if(!row)return res.status(404).json({error:'request_not_found'});
    res.json(row);
  });

  router.post('/send',(req,res)=>{
    const senderId=req.auth?.userId||req.body?.senderId;
    const receiverId=String(req.body?.receiverId||'');
    const text=String(req.body?.text||'').trim();
    const rate=antiAbuse.consume(senderId,'chat');
    if(!rate.allowed)return res.status(429).json({error:'rate_limited',retryAfterMs:rate.retryAfterMs});
    const mod=moderation.applyTextPolicy(senderId,text);
    if(!mod.allowed)return res.status(422).json({error:'profanity',message:'Mesaj gönderilemedi: uygunsuz ifade algılandı.'});
    try{
      const result=dm.send({senderId,receiverId,text});
      if(result.needsRequest)return res.status(409).json({error:'message_request_required'});
      res.status(201).json(result.message);
    }catch(_){res.status(403).json({error:'blocked'});}
  });

  return router;
};
