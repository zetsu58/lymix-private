const express=require('express');

module.exports=function createAuditRoutes({audit}){
  const router=express.Router();
  router.get('/',(req,res)=>{
    const role=String(req.auth?.role||'user');
    if(!['moderator','admin','owner'].includes(role))return res.status(403).json({error:'forbidden'});
    res.json({rows:audit.list({roomId:req.query?.roomId,actorId:req.query?.actorId,limit:req.query?.limit})});
  });
  return router;
};
