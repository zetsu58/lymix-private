const express = require('express');

module.exports = function createConfigRoutes({ config, roleService }) {
  const router = express.Router();

  router.get('/public', (req, res) => {
    const value = config.get();
    res.json({
      moderation: {
        voiceConfidenceMin: value.moderation?.voiceConfidenceMin,
      },
      ux: value.ux,
      features: value.features,
      vip: { enabled: value.vip?.enabled !== false },
    });
  });

  router.patch('/admin', (req, res) => {
    const role = req.auth?.role || 'user';
    if (!roleService.can(role, 'room.edit') && role !== 'owner') {
      return res.status(403).json({ error: 'forbidden' });
    }
    res.json(config.patch(req.body || {}));
  });

  return router;
};
