const express=require('express');
module.exports=({io})=>{const r=express.Router();const tickets=new Map();const policies={agencyTransferLockDays:90,broadcasterQuotaRequired:true};
 r.get('/policies',(_,res)=>res.json(policies));
 r.get('/support/:userId',(req,res)=>res.json(tickets.get(req.params.userId)||[]));
 r.post('/support/:userId/message',(req,res)=>{const id=req.params.userId;const list=tickets.get(id)||[];const m={id:Date.now().toString(),from:req.body.from||'user',text:String(req.body.text||'').slice(0,1000),seen:false,at:new Date().toISOString()};list.push(m);tickets.set(id,list);io.to('support:'+id).emit('support_message',m);res.json(m)});
 r.post('/support/:userId/seen',(req,res)=>{const list=tickets.get(req.params.userId)||[];list.forEach(x=>x.seen=true);io.to('support:'+req.params.userId).emit('support_seen',{at:new Date().toISOString()});res.json({ok:true})});
 return r;};
