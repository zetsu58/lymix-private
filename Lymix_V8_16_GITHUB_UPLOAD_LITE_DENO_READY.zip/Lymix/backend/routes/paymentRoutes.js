'use strict';
const express = require('express');
const crypto = require('crypto');
const { STORE_PRODUCTS, DIRECT_TRY_PRODUCTS, getStoreProduct } = require('../services/paymentCatalogService');
const ledger = require('../services/paymentLedgerService');
const { verifyStorePurchase } = require('../services/storeVerificationService');

const router = express.Router();

router.get('/catalog', (req,res) => res.json({
  store: STORE_PRODUCTS,
  direct: process.env.DIRECT_BILLING_ENABLED === 'true' ? DIRECT_TRY_PRODUCTS : {},
  directBillingEnabled: process.env.DIRECT_BILLING_ENABLED === 'true',
  luckyOddsDisclosureRequired: true,
}));

router.post('/verify-store', async (req,res) => {
  try {
    const { userId, platform, sku, transactionId, verificationData } = req.body || {};
    const product = getStoreProduct(sku);
    if (!userId || !product) return res.status(400).json({error:'invalid product/user'});
    if (ledger.has(transactionId)) return res.status(409).json({error:'duplicate transaction'});
    await verifyStorePurchase({ platform, sku, transactionId, verificationData });
    const row = ledger.record({ txId: transactionId, userId:String(userId), platform, sku, coins:product.coins, status:'verified' });
    // PRODUCTION DB TRANSACTION: increment user coin balance + ledger row atomically here.
    return res.json({ok:true, coinsGranted:product.coins, ledger:row});
  } catch (e) {
    return res.status(e.code?.includes('NOT_CONFIGURED') || e.code === 'STORE_VERIFIER_PENDING' ? 503 : 400).json({error:e.code || 'verification_failed', message:e.message});
  }
});

router.post('/iyzico/session', async (req,res) => {
  if (process.env.DIRECT_BILLING_ENABLED !== 'true') return res.status(403).json({error:'direct billing disabled'});
  if (!process.env.IYZICO_API_KEY || !process.env.IYZICO_SECRET_KEY) return res.status(503).json({error:'iyzico not configured'});
  // Store-distributed builds must not call this endpoint unless an eligible alternative-billing program applies.
  // Use iyzico Checkout Form / 3DS from the backend; never collect raw card data in Flutter.
  return res.status(501).json({error:'merchant credentials required', message:'Complete iyzico merchant onboarding, then wire the official Checkout Form/3DS SDK here.'});
});

router.post('/webhook/iyzico', express.json({type:'application/json'}), (req,res) => {
  // Verify iyzico webhook signature according to the merchant account integration before processing.
  res.status(202).json({received:true});
});

router.get('/ledger', (req,res) => {
  if (req.get('x-owner-token') !== process.env.OWNER_OPS_TOKEN) return res.status(403).json({error:'forbidden'});
  res.json(ledger.list(req.query.limit));
});

module.exports = router;
