const express = require('express');

module.exports = function createRoomContributionRoutes({ contribution, users, rooms }) {
  const router = express.Router();
  router.get('/:roomId', (req, res) => {
    const roomId = String(req.params.roomId || '');
    if (!rooms.has(roomId)) return res.status(404).json({ error: 'room_not_found', message: 'Oda bulunamadı.' });
    const period = String(req.query.period || 'daily');
    if (!['daily', 'weekly', 'monthly'].includes(period)) return res.status(400).json({ error: 'invalid_period' });
    res.json(contribution.leaderboard(roomId, period, req.query.limit, id => users.get(String(id))));
  });
  return router;
};
