const express=require('express'); const crypto=require('crypto');
module.exports=()=>{const r=express.Router();
 r.post('/claim',(req,res)=>{const expected=process.env.OWNER_BOOTSTRAP_CODE||''; if(!expected||req.body?.code!==expected) return res.status(403).json({error:'invalid_claim'}); const userId=String(req.body?.userId||''); if(!userId) return res.status(400).json({error:'userId_required'}); const token=crypto.randomBytes(32).toString('hex'); res.json({ok:true,userId,role:'OWNER_ROOT',ownerToken:token,note:'Production: persist a hashed token, require MFA and rotate bootstrap code immediately.'});});
 return r;};
