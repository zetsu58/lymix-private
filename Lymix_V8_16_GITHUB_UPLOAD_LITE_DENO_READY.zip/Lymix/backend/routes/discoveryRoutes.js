const express = require('express');

module.exports = function createDiscoveryRoutes({ discovery, users, rooms }) {
  const router = express.Router();

  router.get('/search', (req, res) => {
    const q = String(req.query.q || '').slice(0, 80);
    res.json(discovery.search({ query: q, users, rooms, limit: req.query.limit }));
  });

  router.get('/discover', (req, res) => {
    const interests = String(req.query.interests || '')
      .split(',')
      .map(x => x.trim())
      .filter(Boolean)
      .slice(0, 20);
    const personalized = req.query.personalized !== 'false';
    res.json(discovery.discover({ rooms, personalized, interests }));
  });

  return router;
};
