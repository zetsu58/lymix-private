const express = require('express');
const jwt = require('jsonwebtoken');

function signAccess(user) {
  const secret = process.env.JWT_SECRET;
  if (!secret) throw new Error('JWT_SECRET_NOT_CONFIGURED');
  return jwt.sign(
    { role:user.role, name:user.displayName, level:user.level, badges:user.badges },
    secret,
    { algorithm:'HS256', issuer:process.env.JWT_ISSUER || 'lymix', audience:process.env.JWT_AUDIENCE || 'lymix-app', subject:String(user.id), expiresIn:'15m' }
  );
}

module.exports = function createAuthRoutes({ auth, devices }) {
  const r = express.Router();

  r.post('/login', (req,res) => {
    const login = String(req.body?.login || '');
    const password = String(req.body?.password || '');
    const deviceId = String(req.body?.deviceId || '');
    if (!login || !password) return res.status(400).json({ error:'credentials_required' });
    const user = auth.authenticate(login, password);
    if (!user) return res.status(401).json({ error:'invalid_credentials', message:'Kullanıcı adı veya şifre hatalı.' });
    if (deviceId) devices.upsert({ userId:user.id, deviceName:req.body?.deviceName, platform:req.body?.platform, appVersion:req.body?.appVersion, tokenHash:'' });
    const refreshToken = auth.issueRefreshToken(user.id, deviceId);
    return res.json({ accessToken:signAccess(user), refreshToken, expiresIn:900, user });
  });

  r.post('/refresh', (req,res) => {
    const row = auth.consumeRefreshToken(req.body?.refreshToken);
    if (!row) return res.status(401).json({ error:'invalid_refresh_token' });
    const user = auth.findById(row.userId);
    if (!user) return res.status(401).json({ error:'unknown_user' });
    return res.json({ accessToken:signAccess(user), expiresIn:900, user });
  });

  r.post('/logout', (req,res) => {
    if (req.body?.refreshToken) auth.revokeRefreshToken(req.body.refreshToken);
    res.json({ ok:true });
  });

  return r;
};
