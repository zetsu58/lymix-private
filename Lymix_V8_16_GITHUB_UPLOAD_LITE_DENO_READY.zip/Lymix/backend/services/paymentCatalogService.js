'use strict';

// Coin amounts intentionally include a modest pack-size bonus versus the reference UI.
// Store price is always authoritative in Google Play / App Store; never trust client price.
const STORE_PRODUCTS = Object.freeze({
  lymix_coins_1700:   { coins: 1700,   tier: 1 },
  lymix_coins_5800:   { coins: 5800,   tier: 2 },
  lymix_coins_23500:  { coins: 23500,  tier: 3 },
  lymix_coins_64000:  { coins: 64000,  tier: 4 },
  lymix_coins_131000: { coins: 131000, tier: 5 },
  lymix_coins_340000: { coins: 340000, tier: 6 },
  lymix_coins_690000: { coins: 690000, tier: 7 },
});

// Optional web/direct-distribution catalogue. DO NOT expose this inside Play/App Store builds
// unless enrolled in and compliant with an eligible alternative billing program.
const DIRECT_TRY_PRODUCTS = Object.freeze({
  tr_47_50:  { try: 47.50, coins: 7000 },
  tr_190:    { try: 190, coins: 29000 },
  tr_475:    { try: 475, coins: 74000 },
  tr_950:    { try: 950, coins: 154000 },
  tr_2375:   { try: 2375, coins: 400000 },
  tr_4750:   { try: 4750, coins: 820000 },
  tr_14250:  { try: 14250, coins: 2550000 },
});

function getStoreProduct(sku) { return STORE_PRODUCTS[String(sku)] || null; }
function getDirectProduct(id) { return DIRECT_TRY_PRODUCTS[String(id)] || null; }
module.exports = { STORE_PRODUCTS, DIRECT_TRY_PRODUCTS, getStoreProduct, getDirectProduct };
