const crypto = require('crypto');

const textStrikes = new Map();
const voiceStrikes = new Map();
const sanctions = new Map();
const reports = [];

const bannedRoots = [
  // Turkish / Azerbaijani common abuse roots
  'amk','aq','orospu','siktir','sikik','siker','sikeyim','piç','pic','pezevenk','ibne',
  'kaltak','kahpe','yavşak','yavsak','gerizekalı','gerizekali','salak','aptal',
  // English
  'fuck','fucking','motherfucker','bitch','asshole','dickhead','shithead',
  // German
  'arschloch','hurensohn','fotze','wichser',
  // Russian (transliterated + Cyrillic common severe profanity roots)
  'blyat','suka','нахуй','блять','сука','пизд',
  // Additional Azerbaijani variants
  'sikdir','gicdillaq','qehbe','qəhbə'
];

function normalize(input) {
  return String(input || '')
    .toLocaleLowerCase('tr-TR')
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[4@]/g, 'a')
    .replace(/[1!|]/g, 'i')
    .replace(/[0]/g, 'o')
    .replace(/[3]/g, 'e')
    .replace(/[5$]/g, 's')
    .replace(/[7]/g, 't')
    .replace(/[^\p{L}\p{N}\s]/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function scan(input) {
  const normalized = normalize(input);
  const compact = normalized.replace(/\s+/g, '');
  const hits = bannedRoots.filter(root => normalized.includes(root) || compact.includes(root));
  return { blocked: hits.length > 0, hits, normalized };
}

function now() { return Date.now(); }
function activeSanction(userId) {
  const s = sanctions.get(String(userId));
  if (!s) return null;
  if (s.expiresAt && s.expiresAt <= now()) { sanctions.delete(String(userId)); return null; }
  return s;
}

function addStrike(map, userId, reason) {
  const id = String(userId);
  const current = map.get(id) || [];
  const cutoff = now() - 24 * 60 * 60 * 1000;
  const recent = current.filter(x => x.at >= cutoff);
  recent.push({ at: now(), reason });
  map.set(id, recent);
  return recent.length;
}

function applyVoicePolicy(userId, transcript) {
  const result = scan(transcript);
  if (!result.blocked) return { action: 'allow', strikes: (voiceStrikes.get(String(userId)) || []).length };

  const strikes = addStrike(voiceStrikes, userId, 'voice_profanity');
  let action = 'warning';
  let durationMs = 0;

  if (strikes >= 5) { action = 'room_ban'; durationMs = 30 * 60 * 1000; }
  else if (strikes >= 3) { action = 'voice_mute'; durationMs = 5 * 60 * 1000; }

  if (durationMs > 0) {
    sanctions.set(String(userId), {
      type: action,
      reason: 'Tekrarlanan uygunsuz/küfürlü konuşma',
      createdAt: now(),
      expiresAt: now() + durationMs,
    });
  }
  return { action, strikes, durationMs, hits: result.hits };
}

function applyTextPolicy(userId, text) {
  const result = scan(text);
  if (!result.blocked) return { allowed: true, strikes: (textStrikes.get(String(userId)) || []).length };
  const strikes = addStrike(textStrikes, userId, 'text_profanity');
  return { allowed: false, strikes, hits: result.hits };
}

function createReport({ reporterId, targetUserId, roomId, category, description, source = 'user', evidence = [] }) {
  const row = {
    id: crypto.randomUUID(),
    reporterId: String(reporterId || ''),
    targetUserId: targetUserId ? String(targetUserId) : null,
    roomId: roomId ? String(roomId) : null,
    category: String(category || 'other'),
    description: String(description || '').slice(0, 1000),
    source,
    evidence: Array.isArray(evidence) ? evidence.slice(0, 10) : [],
    status: 'open',
    createdAt: new Date().toISOString(),
  };
  reports.push(row);
  if (reports.length > 5000) reports.splice(0, reports.length - 5000);
  return row;
}

function listReports({ reporterId, status } = {}) {
  return reports.filter(r => (!reporterId || r.reporterId === String(reporterId)) && (!status || r.status === status)).slice(-200).reverse();
}

module.exports = {
  normalize, scan, applyTextPolicy, applyVoicePolicy, activeSanction,
  createReport, listReports, sanctions, reports
};
