const crypto = require('crypto');

const appeals = [];

function create({ userId, sanctionType, roomId, reason }) {
  const existing = appeals.find(a =>
    a.userId === String(userId) &&
    a.roomId === String(roomId || '') &&
    a.sanctionType === String(sanctionType || '') &&
    ['open','reviewing'].includes(a.status)
  );
  if (existing) return existing;

  const row = {
    id: crypto.randomUUID(),
    userId: String(userId),
    roomId: roomId ? String(roomId) : null,
    sanctionType: String(sanctionType || ''),
    reason: String(reason || '').slice(0, 1000),
    status: 'open',
    createdAt: new Date().toISOString(),
  };
  appeals.push(row);
  if (appeals.length > 5000) appeals.splice(0, appeals.length - 5000);
  return row;
}

function mine(userId) {
  return appeals.filter(a => a.userId === String(userId)).slice(-200).reverse();
}
function queue(status) {
  return appeals.filter(a => !status || a.status === status).slice(-500).reverse();
}
function update(id, { status, reviewerId, note }) {
  const row = appeals.find(a => a.id === String(id));
  if (!row) return null;
  row.status = status;
  row.reviewedBy = reviewerId;
  row.reviewedAt = new Date().toISOString();
  row.note = String(note || '').slice(0, 1000);
  return row;
}

module.exports = { appeals, create, mine, queue, update };
