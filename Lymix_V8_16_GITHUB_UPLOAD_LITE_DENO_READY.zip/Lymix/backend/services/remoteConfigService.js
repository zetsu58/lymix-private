const defaults = {
  moderation: {
    voiceConfidenceMin: 0.72,
    voiceWarnAt: 1,
    voiceMuteAt: 3,
    voiceBanAt: 5,
    voiceMuteMinutes: 5,
    voiceBanMinutes: 30,
  },
  ux: {
    enableSkeletons: true,
    enableHaptics: true,
    reduceMotionDefault: false,
    dataSaverDefault: false,
  },
  features: {
    roomContribution: true,
    customIdentity: true,
    moderationAppeal: true,
    messageReactions: true,
    messageReply: true,
    typingIndicator: true,
    smartDiscovery: false,
    aBExperiments: false,
  },
  vip: {
    enabled: true,
  },
};

let current = JSON.parse(JSON.stringify(defaults));

function get() { return current; }
function patch(next) {
  current = deepMerge(current, next || {});
  return current;
}
function deepMerge(a, b) {
  const out = Array.isArray(a) ? [...a] : { ...a };
  for (const [k, v] of Object.entries(b || {})) {
    out[k] = v && typeof v === 'object' && !Array.isArray(v)
      ? deepMerge(out[k] || {}, v)
      : v;
  }
  return out;
}
function feature(name, fallback = false) {
  return current.features?.[name] ?? fallback;
}
module.exports = { defaults, get, patch, feature };
