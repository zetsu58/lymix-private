// Lymix VIP 30-day cycle engine. Replace in-memory storage with DB/Redis in production.
const DAY_MS = 24 * 60 * 60 * 1000;
const CYCLE_DAYS = 30;

const TIERS = [
  { code: 'VIP1', level: 1, entry: 50000, renew: 30000 },
  { code: 'VIP2', level: 2, entry: 100000, renew: 60000 },
  { code: 'VIP3', level: 3, entry: 250000, renew: 150000 },
  { code: 'VIP4', level: 4, entry: 500000, renew: 300000 },
  { code: 'VIP5', level: 5, entry: 1000000, renew: 600000 },
  { code: 'VIP6', level: 6, entry: 2000000, renew: 1200000 },
  { code: 'VIP7', level: 7, entry: 4000000, renew: 2400000 },
  { code: 'VIP8', level: 8, entry: 7500000, renew: 4500000 },
  { code: 'VIP9', level: 9, entry: 12000000, renew: 7200000 },
  { code: 'VIP10', level: 10, entry: 20000000, renew: 12000000 },
  { code: 'CROWN', level: 11, entry: 35000000, renew: 21000000 },
];

const vipState = new Map();

function stateFor(userId) {
  if (!vipState.has(userId)) {
    const now = Date.now();
    vipState.set(userId, { userId, tier: 0, cycleStart: now, cycleEnd: now + CYCLE_DAYS * DAY_MS, cycleLoad: 0, lifetimeLoad: 0, history: [] });
  }
  return vipState.get(userId);
}

function tierByLevel(level) { return TIERS.find(t => t.level === level) || null; }
function highestByEntry(amount) { return [...TIERS].reverse().find(t => amount >= t.entry) || null; }
function highestByRenew(amount) { return [...TIERS].reverse().find(t => amount >= t.renew) || null; }

function settleIfExpired(s, now = Date.now()) {
  if (now < s.cycleEnd) return s;
  const oldTier = s.tier;
  const eligible = highestByRenew(s.cycleLoad);
  s.tier = eligible?.level || 0;
  s.history.push({ type: 'cycle_settle', at: new Date(now).toISOString(), oldTier, newTier: s.tier, load: s.cycleLoad });
  s.cycleStart = now;
  s.cycleEnd = now + CYCLE_DAYS * DAY_MS;
  s.cycleLoad = 0;
  return s;
}

function addRecharge(userId, amount) {
  if (!Number.isFinite(amount) || amount <= 0) throw new Error('Geçersiz yükleme tutarı');
  const s = settleIfExpired(stateFor(String(userId)));
  s.cycleLoad += Math.floor(amount);
  s.lifetimeLoad += Math.floor(amount);
  const earned = highestByEntry(s.cycleLoad);
  if (earned && earned.level > s.tier) {
    const oldTier = s.tier;
    s.tier = earned.level;
    s.history.push({ type: 'upgrade', at: new Date().toISOString(), oldTier, newTier: s.tier, load: s.cycleLoad });
  }
  return status(userId);
}

function status(userId) {
  const s = settleIfExpired(stateFor(String(userId)));
  const tier = tierByLevel(s.tier);
  const next = TIERS.find(t => t.level === s.tier + 1) || null;
  return {
    ...s,
    tierInfo: tier,
    nextTier: next,
    daysLeft: Math.max(0, Math.ceil((s.cycleEnd - Date.now()) / DAY_MS)),
    renewTarget: tier?.renew || 0,
    renewMet: tier ? s.cycleLoad >= tier.renew : false,
    nextEntryRemaining: next ? Math.max(0, next.entry - s.cycleLoad) : 0,
    cycleDays: CYCLE_DAYS,
  };
}

module.exports = { TIERS, CYCLE_DAYS, addRecharge, status, settleIfExpired };
