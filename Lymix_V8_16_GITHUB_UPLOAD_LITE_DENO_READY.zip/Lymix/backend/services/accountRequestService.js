const crypto = require('crypto');
const requests = [];

function create({ userId, type }) {
  const active = requests.find(r => r.userId === String(userId) && r.type === type && ['queued','processing'].includes(r.status));
  if (active) return active;
  const row = {
    id: crypto.randomUUID(),
    userId: String(userId),
    type,
    status: 'queued',
    createdAt: new Date().toISOString(),
  };
  requests.push(row);
  return row;
}
function mine(userId) {
  return requests.filter(r => r.userId === String(userId)).slice(-100).reverse();
}
module.exports = { requests, create, mine };
