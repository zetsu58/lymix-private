const crypto=require('crypto');
const rows=[];

function record({actorId,action,targetType,targetId,roomId,meta={}}){
  const row={
    id:crypto.randomUUID(),
    actorId:String(actorId||'system'),
    action:String(action||'unknown'),
    targetType:String(targetType||''),
    targetId:targetId?String(targetId):null,
    roomId:roomId?String(roomId):null,
    meta,
    createdAt:new Date().toISOString(),
  };
  rows.push(row);
  if(rows.length>10000)rows.splice(0,rows.length-10000);
  return row;
}
function list({roomId,actorId,limit=200}={}){
  return rows
    .filter(r=>(!roomId||r.roomId===String(roomId))&&(!actorId||r.actorId===String(actorId)))
    .slice(-Math.min(Number(limit)||200,500))
    .reverse();
}
module.exports={record,list,rows};
