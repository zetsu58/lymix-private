const windows = new Map();

const LIMITS = {
  chat: { windowMs: 10_000, limit: 8, cooldownMs: 20_000 },
  room_join: { windowMs: 60_000, limit: 18, cooldownMs: 60_000 },
  room_invite: { windowMs: 60_000, limit: 12, cooldownMs: 120_000 },
  follow: { windowMs: 60_000, limit: 25, cooldownMs: 60_000 },
  report: { windowMs: 10 * 60_000, limit: 15, cooldownMs: 30 * 60_000 },
};

function bucketKey(userId, action) { return `${userId}:${action}`; }
function consume(userId, action, now = Date.now()) {
  const cfg = LIMITS[action];
  if (!cfg) return { allowed: true, remaining: Infinity, risk: 0 };
  const key = bucketKey(userId, action);
  const entry = windows.get(key) || { hits: [], blockedUntil: 0 };
  if (entry.blockedUntil > now) {
    return { allowed: false, retryAfterMs: entry.blockedUntil - now, remaining: 0, risk: 1 };
  }
  entry.hits = entry.hits.filter(x => x > now - cfg.windowMs);
  entry.hits.push(now);
  const risk = Math.min(1, entry.hits.length / cfg.limit);
  if (entry.hits.length > cfg.limit) {
    entry.blockedUntil = now + cfg.cooldownMs;
    windows.set(key, entry);
    return { allowed: false, retryAfterMs: cfg.cooldownMs, remaining: 0, risk };
  }
  windows.set(key, entry);
  return { allowed: true, remaining: Math.max(0, cfg.limit - entry.hits.length), risk };
}

function similarity(a, b) {
  const x = String(a || '').trim().toLowerCase();
  const y = String(b || '').trim().toLowerCase();
  if (!x || !y) return 0;
  if (x === y) return 1;
  if (x.length < 4 || y.length < 4) return 0;
  let same = 0;
  const max = Math.max(x.length, y.length);
  for (let i = 0; i < Math.min(x.length, y.length); i++) if (x[i] === y[i]) same++;
  return same / max;
}

const recentMessages = new Map();
function messageRisk(userId, text, now = Date.now()) {
  const id = String(userId);
  const recent = (recentMessages.get(id) || []).filter(x => x.at > now - 30_000);
  let duplicates = 0;
  for (const item of recent) if (similarity(item.text, text) > .9) duplicates++;
  recent.push({ text: String(text || ''), at: now });
  recentMessages.set(id, recent.slice(-10));
  return { duplicateCount: duplicates, blocked: duplicates >= 3 };
}

module.exports = { LIMITS, consume, messageRisk };
