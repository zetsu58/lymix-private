const crypto = require('crypto');

const SUPPORTED_PROVIDERS = new Set(['generic-web', 'sud', 'bytesun']);

function getProvider() {
  const provider = String(process.env.GAME_PROVIDER || 'generic-web').toLowerCase();
  return SUPPORTED_PROVIDERS.has(provider) ? provider : 'generic-web';
}

function createGenericLaunch({ gameId, roomId, userId }) {
  const base = String(process.env.GAME_PROVIDER_BASE_URL || '').replace(/\/$/, '');
  if (!base) throw new Error('GAME_PROVIDER_BASE_URL yapılandırılmadı');
  const p = new URLSearchParams({ gameId, roomId, userId, bridge: 'LymixGameBridge' });
  if (process.env.GAME_PROVIDER_DEMO_TOKEN) p.set('token', process.env.GAME_PROVIDER_DEMO_TOKEN);
  return { mode: 'webview', launchUrl: `${base}/${encodeURIComponent(gameId)}?${p}` };
}

function createSudLaunch({ gameId, roomId, userId }) {
  // SudGIP native/Flutter entegrasyonunda uygulamaya URL değil, kısa süreli "code" + mgId verilir.
  // APP_ID/APP_KEY yalnızca güvenli sunucu yapılandırmasında tutulmalıdır.
  const appId = process.env.SUD_APP_ID;
  const appKey = process.env.SUD_APP_KEY;
  const mgId = process.env[`SUD_MG_${gameId.replace(/-/g, '_').toUpperCase()}`];
  if (!appId || !appKey || !mgId) throw new Error('SUD_APP_ID, SUD_APP_KEY veya oyun mgId eşlemesi eksik');

  // Bu proje gerçek SUD kimlik bilgileri olmadan ağ isteği yapmaz. Provider onayından sonra
  // resmi auth akışına göre code üretimi bu noktaya bağlanır. Dev ortamında kısa ömürlü mock code döner.
  const expiresAt = Date.now() + 60_000;
  const mockCode = crypto.createHmac('sha256', appKey).update(`${userId}:${roomId}:${mgId}:${expiresAt}`).digest('hex');
  return {
    mode: 'sud_native',
    provider: 'sud',
    appId,
    mgId,
    roomId,
    userId,
    code: mockCode,
    expiresAt,
    testOnly: true,
    note: 'Gerçek üretim code değeri SUD resmi server auth akışından alınmalıdır.'
  };
}

function createByteSunLaunch({ gameId, roomId, userId }) {
  const base = String(process.env.BYTESUN_GAME_BASE_URL || '').replace(/\/$/, '');
  if (!base) throw new Error('BYTESUN_GAME_BASE_URL yapılandırılmadı');
  const p = new URLSearchParams({ game: gameId, room: roomId, uid: userId, lang: 'tr' });
  const token = process.env.BYTESUN_DEMO_TOKEN;
  if (token) p.set('token', token);
  return { mode: 'webview', provider: 'bytesun', launchUrl: `${base}?${p}` };
}

function createLaunch(payload) {
  switch (getProvider()) {
    case 'sud': return createSudLaunch(payload);
    case 'bytesun': return createByteSunLaunch(payload);
    default: return createGenericLaunch(payload);
  }
}

module.exports = { getProvider, createLaunch };
