const crypto = require('crypto');

const threads = new Map();
const requests = new Map();
const blocks = new Set();

function pair(a,b){ return [String(a),String(b)].sort().join(':'); }
function blocked(a,b){ return blocks.has(`${a}:${b}`) || blocks.has(`${b}:${a}`); }

function requestKey(senderId, receiverId){ return `${senderId}:${receiverId}`; }

function createRequest({ senderId, receiverId, text }) {
  if (blocked(senderId, receiverId)) throw new Error('blocked');
  const key = requestKey(senderId, receiverId);
  const existing = requests.get(key);
  if (existing && existing.status === 'pending') return existing;
  const row = {
    id: crypto.randomUUID(),
    senderId:String(senderId), receiverId:String(receiverId),
    preview:String(text||'').slice(0,160),
    status:'pending', createdAt:Date.now()
  };
  requests.set(key,row);
  return row;
}
function listRequests(userId){
  return [...requests.values()].filter(r=>r.receiverId===String(userId)&&r.status==='pending').sort((a,b)=>b.createdAt-a.createdAt);
}
function decide({ userId, requestId, accept }){
  const row=[...requests.values()].find(r=>r.id===String(requestId)&&r.receiverId===String(userId));
  if(!row)return null;
  row.status=accept?'accepted':'declined';
  row.reviewedAt=Date.now();
  if(accept){
    const key=pair(row.senderId,row.receiverId);
    if(!threads.has(key))threads.set(key,{id:crypto.randomUUID(),members:[row.senderId,row.receiverId],messages:[]});
  }
  return row;
}
function send({ senderId, receiverId, text }){
  if(blocked(senderId,receiverId))throw new Error('blocked');
  const key=pair(senderId,receiverId);
  const thread=threads.get(key);
  if(!thread)return { needsRequest:true };
  const message={id:crypto.randomUUID(),senderId:String(senderId),receiverId:String(receiverId),text:String(text||'').slice(0,1000),createdAt:Date.now(),readAt:null};
  thread.messages.push(message);
  if(thread.messages.length>1000)thread.messages.splice(0,thread.messages.length-1000);
  return {needsRequest:false,message};
}
function block(blockerId,targetId){blocks.add(`${blockerId}:${targetId}`);}
module.exports={createRequest,listRequests,decide,send,block,threads,requests};
