const os = require('os');
const startedAt = Date.now();
const state = {
  maintenance: false, maintenanceMessage: 'Lymix kısa süreli bakımda.',
  readonlyMode: false, emergencyMode: false,
  featureFlags: { games:true, gifts:true, feed:true, agencies:true, relationships:true, vip:true, newRegistrations:true },
  incidents: [], actions: [], thresholds: { memoryWarnPct:85, errorRateWarnPct:5, latencyWarnMs:1200 }
};
function snapshot({io, rooms, users}) {
  const mem = process.memoryUsage(); const total = os.totalmem(); const free=os.freemem();
  return { status: state.emergencyMode?'critical':state.maintenance?'maintenance':'healthy',
    now:new Date().toISOString(), uptimeSec:Math.floor((Date.now()-startedAt)/1000),
    process:{pid:process.pid,node:process.version,rssMB:+(mem.rss/1048576).toFixed(1),heapUsedMB:+(mem.heapUsed/1048576).toFixed(1)},
    host:{platform:os.platform(),cpus:os.cpus().length,load:os.loadavg(),memoryUsedPct:+(((total-free)/total)*100).toFixed(1)},
    realtime:{connectedSockets:io?.engine?.clientsCount||0,rooms:rooms.size,users:users.size},
    controls:{maintenance:state.maintenance,readonlyMode:state.readonlyMode,emergencyMode:state.emergencyMode,featureFlags:state.featureFlags},
    recentIncidents:state.incidents.slice(-10).reverse(), recentActions:state.actions.slice(-20).reverse() };
}
function audit(action, actor='owner', details={}) { state.actions.push({at:new Date().toISOString(),actor,action,details}); if(state.actions.length>500)state.actions.shift(); }
module.exports={state,snapshot,audit};
