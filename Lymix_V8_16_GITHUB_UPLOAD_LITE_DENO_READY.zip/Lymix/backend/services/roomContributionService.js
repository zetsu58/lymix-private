const rows = [];
const MAX_ROWS = 50000;

function record({ roomId, senderId, receiverId, giftId, amount, createdAt = Date.now() }) {
  const row = {
    id: `${roomId}:${senderId}:${giftId}:${createdAt}:${Math.random().toString(36).slice(2, 8)}`,
    roomId: String(roomId),
    senderId: String(senderId),
    receiverId: String(receiverId),
    giftId: String(giftId),
    amount: Math.max(0, Math.floor(Number(amount) || 0)),
    createdAt: Number(createdAt),
  };
  rows.push(row);
  if (rows.length > MAX_ROWS) rows.splice(0, rows.length - MAX_ROWS);
  return row;
}

function periodStart(period, now = new Date()) {
  const d = new Date(now);
  if (period === 'daily') {
    d.setHours(0, 0, 0, 0);
  } else if (period === 'weekly') {
    const day = (d.getDay() + 6) % 7;
    d.setDate(d.getDate() - day);
    d.setHours(0, 0, 0, 0);
  } else if (period === 'monthly') {
    d.setDate(1);
    d.setHours(0, 0, 0, 0);
  } else {
    throw new Error('invalid_period');
  }
  return d.getTime();
}

function leaderboard(roomId, period = 'daily', limit = 50, userLookup = () => null) {
  const start = periodStart(period);
  const sums = new Map();
  for (const row of rows) {
    if (row.roomId !== String(roomId) || row.createdAt < start) continue;
    sums.set(row.senderId, (sums.get(row.senderId) || 0) + row.amount);
  }
  const list = [...sums.entries()]
    .map(([userId, amount]) => {
      const user = userLookup(userId) || {};
      return {
        userId,
        name: user.name || `Kullanıcı ${userId}`,
        avatar: user.avatar || null,
        vip: user.vipLevel || 0,
        amount,
      };
    })
    .sort((a, b) => b.amount - a.amount)
    .slice(0, Math.max(1, Math.min(Number(limit) || 50, 100)));
  return {
    roomId: String(roomId),
    period,
    periodStart: new Date(start).toISOString(),
    total: list.reduce((sum, x) => sum + x.amount, 0),
    rows: list,
  };
}

module.exports = { record, leaderboard, periodStart };
