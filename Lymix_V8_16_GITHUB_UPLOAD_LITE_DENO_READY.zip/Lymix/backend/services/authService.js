const crypto = require('crypto');

const usersByLogin = new Map();
const refreshTokens = new Map();

function normalizeLogin(v) { return String(v || '').trim().toLowerCase(); }
function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.scryptSync(String(password), salt, 64).toString('hex');
  return `${salt}:${hash}`;
}
function verifyPassword(password, stored) {
  const [salt, expected] = String(stored || '').split(':');
  if (!salt || !expected) return false;
  const actual = crypto.scryptSync(String(password), salt, 64);
  const expectedBuf = Buffer.from(expected, 'hex');
  return actual.length === expectedBuf.length && crypto.timingSafeEqual(actual, expectedBuf);
}
function upsertUser({ id, login, displayName, password, role='user', level=1, badges=[] }) {
  const key = normalizeLogin(login);
  if (!key) throw new Error('login_required');
  const prev = usersByLogin.get(key);
  const row = {
    id: String(id || prev?.id || crypto.randomUUID()),
    login: key,
    displayName: String(displayName || prev?.displayName || login),
    passwordHash: password ? hashPassword(password) : prev?.passwordHash,
    role,
    level: Number(level || 1),
    badges: Array.isArray(badges) ? badges : [],
    active: true,
    createdAt: prev?.createdAt || new Date().toISOString(),
  };
  usersByLogin.set(key, row);
  return publicUser(row);
}
function publicUser(u) {
  return { id:u.id, login:u.login, displayName:u.displayName, role:u.role, level:u.level, badges:u.badges, active:u.active };
}
function authenticate(login, password) {
  const u = usersByLogin.get(normalizeLogin(login));
  if (!u || !u.active || !verifyPassword(password, u.passwordHash)) return null;
  return publicUser(u);
}
function issueRefreshToken(userId, deviceId) {
  const token = crypto.randomBytes(48).toString('base64url');
  const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
  refreshTokens.set(tokenHash, { userId:String(userId), deviceId:String(deviceId||''), createdAt:Date.now(), revoked:false });
  return token;
}
function consumeRefreshToken(token) {
  const h = crypto.createHash('sha256').update(String(token||'')).digest('hex');
  const row = refreshTokens.get(h);
  if (!row || row.revoked) return null;
  return row;
}
function revokeRefreshToken(token) {
  const h = crypto.createHash('sha256').update(String(token||'')).digest('hex');
  const row = refreshTokens.get(h); if (row) row.revoked = true;
}
function findById(id) {
  for (const u of usersByLogin.values()) if (u.id === String(id)) return publicUser(u);
  return null;
}
function bootstrapOwnerFromEnv() {
  const login = process.env.LYMIX_ADMIN_LOGIN;
  const password = process.env.LYMIX_ADMIN_PASSWORD;
  if (!login || !password) return null;
  return upsertUser({
    id: process.env.LYMIX_ADMIN_USER_ID || 'owner_emre',
    login,
    displayName: process.env.LYMIX_ADMIN_DISPLAY_NAME || 'Lymix Emre',
    password,
    role:'owner', level:999,
    badges:['SUPER_ADMIN','FOUNDER']
  });
}

module.exports = { upsertUser, authenticate, issueRefreshToken, consumeRefreshToken, revokeRefreshToken, findById, bootstrapOwnerFromEnv, publicUser };
