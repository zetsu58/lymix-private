const ENTITLEMENTS = {
  0: [],
  1: ['vip_badge','profile_highlight'],
  2: ['name_tint','mini_card_theme'],
  3: ['room_entry_trace','profile_frame'],
  4: ['enhanced_entry','chat_highlight'],
  5: ['gift_showcase','animated_profile_detail'],
  6: ['priority_visibility','premium_room_card'],
  7: ['premium_entry_scene','season_badge'],
  8: ['room_theme','advanced_avatar_ring'],
  9: ['legend_profile_trace','limited_collection'],
  10:['mythic_entry_scene','identity_effect'],
  11:['crown_credits','top_profile_showcase','crown_room_identity'],
};

function listFor(level) {
  const n = Math.max(0, Math.min(11, Number(level) || 0));
  const result = new Set();
  for (let i = 0; i <= n; i++) for (const item of ENTITLEMENTS[i] || []) result.add(item);
  return [...result];
}
function has(level, entitlement) { return listFor(level).includes(String(entitlement)); }

module.exports = { ENTITLEMENTS, listFor, has };
