function normalize(v) {
  return String(v || '').toLocaleLowerCase('tr-TR').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').trim();
}
function levenshtein(a, b) {
  a = normalize(a); b = normalize(b);
  if (!a) return b.length; if (!b) return a.length;
  const dp = Array.from({ length: a.length + 1 }, (_, i) => [i]);
  for (let j = 0; j <= b.length; j++) dp[0][j] = j;
  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      dp[i][j] = Math.min(
        dp[i-1][j] + 1,
        dp[i][j-1] + 1,
        dp[i-1][j-1] + (a[i-1] === b[j-1] ? 0 : 1)
      );
    }
  }
  return dp[a.length][b.length];
}
function similarity(a, b) {
  const x = normalize(a), y = normalize(b);
  if (!x || !y) return 0;
  if (x.includes(y) || y.includes(x)) return .9;
  const max = Math.max(x.length, y.length);
  return max === 0 ? 1 : Math.max(0, 1 - levenshtein(x, y) / max);
}

function roomQuality(room) {
  const listeners = Number(room.listeners || room.usersCount || 0);
  const activeSpeakers = (room.seats || []).filter(s => s?.userId && !s?.isMuted).length;
  const moderationRate = Number(room.moderationRate || 0);
  const recentReturns = Number(room.returnRate || .35);
  const spamRisk = Number(room.spamRisk || 0);
  return Math.max(0, Math.min(100,
    listeners * .12 +
    activeSpeakers * 8 +
    recentReturns * 35 -
    moderationRate * 20 -
    spamRisk * 30
  ));
}

function search({ query, users, rooms, limit = 20 }) {
  const q = normalize(query);
  if (!q) return { users: [], rooms: [] };

  const userRows = [...users.values()]
    .map(u => ({
      userId: String(u.id),
      name: u.name || `Kullanıcı ${u.id}`,
      avatar: u.avatar || null,
      vip: u.vipLevel || 0,
      score: Math.max(similarity(q, u.name), similarity(q, u.id)),
    }))
    .filter(x => x.score >= .35)
    .sort((a,b) => b.score - a.score)
    .slice(0, limit);

  const roomRows = [...rooms.values()]
    .map(r => ({
      roomId: String(r.id),
      title: r.title || r.name || `Oda ${r.id}`,
      ownerId: r.ownerId || null,
      listeners: Number(r.listeners || r.usersCount || 0),
      quality: roomQuality(r),
      score: Math.max(similarity(q, r.title || r.name), similarity(q, r.id)),
    }))
    .filter(x => x.score >= .35)
    .sort((a,b) => (b.score * .7 + b.quality / 100 * .3) - (a.score * .7 + a.quality / 100 * .3))
    .slice(0, limit);

  return { users: userRows, rooms: roomRows };
}

function discover({ rooms, personalized = true, interests = [] }) {
  const list = [...rooms.values()].map(r => ({
    roomId: String(r.id),
    title: r.title || r.name || `Oda ${r.id}`,
    listeners: Number(r.listeners || r.usersCount || 0),
    quality: roomQuality(r),
    tags: Array.isArray(r.tags) ? r.tags : [],
  }));

  const score = r => {
    let value = r.quality;
    if (personalized && interests.length) {
      const matches = r.tags.filter(t => interests.map(normalize).includes(normalize(t))).length;
      value += matches * 12;
    }
    return value;
  };

  return {
    forYou: [...list].sort((a,b) => score(b) - score(a)).slice(0, 20),
    trending: [...list].sort((a,b) => (b.listeners + b.quality) - (a.listeners + a.quality)).slice(0, 20),
    newRooms: [...list].slice(-20).reverse(),
  };
}

module.exports = { search, discover, roomQuality, similarity };
