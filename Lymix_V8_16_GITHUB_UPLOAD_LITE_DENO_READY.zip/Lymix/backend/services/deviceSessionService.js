const crypto = require('crypto');
const sessions = new Map();

function list(userId) {
  return [...sessions.values()].filter(s => s.userId === String(userId)).sort((a,b)=>b.lastSeenAt-a.lastSeenAt);
}
function upsert({ userId, deviceName, platform, appVersion, tokenHash }) {
  const key = tokenHash || crypto.randomUUID();
  const existing = sessions.get(key) || {
    id: crypto.randomUUID(),
    createdAt: Date.now(),
  };
  const row = {
    ...existing,
    userId: String(userId),
    deviceName: String(deviceName || 'Bilinmeyen cihaz').slice(0, 100),
    platform: String(platform || 'unknown').slice(0, 30),
    appVersion: String(appVersion || '').slice(0, 30),
    tokenHash: key,
    lastSeenAt: Date.now(),
    revokedAt: null,
  };
  sessions.set(key, row);
  return row;
}
function revoke(userId, id) {
  const row = [...sessions.values()].find(s => s.id === String(id) && s.userId === String(userId));
  if (!row) return false;
  row.revokedAt = Date.now();
  return true;
}
function revokeOthers(userId, currentId) {
  for (const row of sessions.values()) {
    if (row.userId === String(userId) && row.id !== String(currentId)) row.revokedAt = Date.now();
  }
}
module.exports = { list, upsert, revoke, revokeOthers };
