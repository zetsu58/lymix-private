const ORDER = ['user','speaker','moderator','admin','owner'];

const PERMISSIONS = {
  user: [
    'room.join','room.leave','seat.sit','chat.send','gift.send','report.create','profile.edit'
  ],
  speaker: [
    'room.join','room.leave','seat.sit','chat.send','gift.send','report.create','profile.edit'
  ],
  moderator: [
    'room.join','room.leave','seat.sit','chat.send','gift.send','report.create','profile.edit',
    'seat.invite','seat.mute','seat.remove','message.moderate','room.warn'
  ],
  admin: [
    'room.join','room.leave','seat.sit','chat.send','gift.send','report.create','profile.edit',
    'seat.invite','seat.mute','seat.remove','seat.lock','message.moderate','room.warn','room.kick','room.edit'
  ],
  owner: ['*'],
};

function level(role) {
  const i = ORDER.indexOf(String(role || 'user'));
  return i < 0 ? 0 : i;
}
function can(role, permission) {
  const list = PERMISSIONS[String(role || 'user')] || PERMISSIONS.user;
  return list.includes('*') || list.includes(permission);
}
function canManage(actorRole, targetRole) {
  return level(actorRole) > level(targetRole);
}
function roomRole(room, userId) {
  const id = String(userId || '');
  if (String(room?.ownerId || '') === id) return 'owner';
  const admins = room?.adminIds instanceof Set ? [...room.adminIds] : (room?.admins || []);
  const moderators = room?.moderatorIds instanceof Set ? [...room.moderatorIds] : (room?.moderators || []);
  const speakers = room?.speakerIds instanceof Set ? [...room.speakerIds] : (room?.speakers || []);
  if (admins.map(String).includes(id)) return 'admin';
  if (moderators.map(String).includes(id)) return 'moderator';
  if (speakers.map(String).includes(id)) return 'speaker';
  return 'user';
}
module.exports = { ORDER, PERMISSIONS, level, can, canManage, roomRole };
