'use strict';
const rows = [];
const seen = new Set();
function has(txId) { return seen.has(String(txId)); }
function record(row) {
  const txId = String(row.txId || '');
  if (!txId) throw new Error('txId required');
  if (seen.has(txId)) return rows.find(x => x.txId === txId);
  const item = Object.freeze({ ...row, txId, createdAt: new Date().toISOString() });
  seen.add(txId); rows.push(item); return item;
}
function list(limit=100) { return rows.slice(-Math.min(Math.max(Number(limit)||100,1),500)).reverse(); }
module.exports = { has, record, list };
