const crypto = require('crypto');

const state = {
  readonlyMode: false,
  minClientVersion: '1.0.0',
  maintenanceMessage: '',
  featureFlags: {
    lucky: true, gifts: true, games: true, payments: true, feed: true, agencies: true,
  },
  health: {
    api: 'ok', database: 'not_configured', cache: 'not_configured', storage: 'not_configured',
    voice: 'not_configured', payments: 'not_configured', push: 'not_configured', games: 'not_configured',
  },
};

const audit = [];
const ledger = [];
const incidents = [];
const fraudSignals = [];
const idempotency = new Map();

function now() { return new Date().toISOString(); }
function id(prefix) { return `${prefix}_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`; }

function appendAudit({ actorId, action, targetType, targetId, before = null, after = null, ip = null }) {
  const row = Object.freeze({ id: id('audit'), actorId, action, targetType, targetId, before, after, ip, at: now() });
  audit.unshift(row); if (audit.length > 5000) audit.pop(); return row;
}

function appendLedger({ userId, type, amount, currency = 'LYMCOIN', refId, metadata = {} }) {
  if (!Number.isFinite(Number(amount))) throw new Error('invalid_amount');
  const row = Object.freeze({ id: id('ledger'), userId: String(userId), type, amount: Number(amount), currency, refId: String(refId || ''), metadata, at: now() });
  ledger.unshift(row); if (ledger.length > 20000) ledger.pop(); return row;
}

function once(key, producer) {
  const k = String(key || '');
  if (!k) return producer();
  if (idempotency.has(k)) return idempotency.get(k);
  const value = producer(); idempotency.set(k, value);
  setTimeout(() => idempotency.delete(k), 24 * 60 * 60 * 1000).unref?.();
  return value;
}

function signalFraud(userId, kind, score, detail = {}) {
  const row = { id: id('risk'), userId: String(userId), kind, score: Math.max(0, Math.min(100, Number(score) || 0)), detail, status: 'review', at: now() };
  fraudSignals.unshift(row); if (fraudSignals.length > 5000) fraudSignals.pop(); return row;
}

function createIncident(title, severity = 'medium', detail = '') {
  const row = { id: id('incident'), title: String(title).slice(0, 140), severity, detail: String(detail).slice(0, 1000), status: 'open', at: now() };
  incidents.unshift(row); return row;
}

function snapshot(extra = {}) {
  const mem = process.memoryUsage();
  return {
    time: now(), uptimeSec: Math.floor(process.uptime()),
    memory: { rssMb: Math.round(mem.rss / 1048576), heapMb: Math.round(mem.heapUsed / 1048576) },
    state, counters: { audit: audit.length, ledger: ledger.length, incidents: incidents.filter(x => x.status === 'open').length, fraudReview: fraudSignals.filter(x => x.status === 'review').length },
    ...extra,
  };
}

module.exports = { state, audit, ledger, incidents, fraudSignals, appendAudit, appendLedger, once, signalFraud, createIncident, snapshot };
