const DEFAULT_RULES = [
  'Saygılı ve seviyeli iletişim kur.',
  'Taciz, tehdit, nefret söylemi ve spam yasaktır.',
  'Mikrofon sırasına ve oda yöneticilerinin uyarılarına uy.',
  'Kişisel bilgi paylaşırken dikkatli ol.',
];

function ensureRoom(room) {
  room.agencyCode ??= '';
  room.agencyId ??= null;
  room.rules ??= [...DEFAULT_RULES];
  room.rulesUpdatedAt ??= new Date().toISOString();
  room.welcomeMode ??= 'owner_and_mods';
  room.welcomeFemaleBroadcastersPriority ??= true;
  room.moderators ??= new Map();
  return room;
}

function publicMeta(room) {
  ensureRoom(room);
  return {
    roomId: room.id,
    agencyId: room.agencyId,
    agencyCode: room.agencyCode,
    rules: room.rules,
    rulesUpdatedAt: room.rulesUpdatedAt,
    welcomeMode: room.welcomeMode,
    welcomeFemaleBroadcastersPriority: room.welcomeFemaleBroadcastersPriority,
  };
}

function updateRules(room, rules) {
  ensureRoom(room);
  const clean = Array.isArray(rules) ? rules.map(x => String(x).trim().slice(0, 180)).filter(Boolean).slice(0, 12) : [];
  if (!clean.length) throw new Error('En az bir oda kuralı olmalı.');
  room.rules = clean; room.rulesUpdatedAt = new Date().toISOString();
  return publicMeta(room);
}

function updateAgency(room, { agencyId, agencyCode }) {
  ensureRoom(room);
  room.agencyId = agencyId ? String(agencyId).slice(0, 64) : null;
  room.agencyCode = agencyCode ? String(agencyCode).toUpperCase().replace(/[^A-Z0-9_-]/g, '').slice(0, 16) : '';
  return publicMeta(room);
}

module.exports = { DEFAULT_RULES, ensureRoom, publicMeta, updateRules, updateAgency };
