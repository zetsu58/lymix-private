'use strict';

/**
 * Production verification gate.
 * This deliberately FAILS CLOSED until real Google/Apple credentials are configured.
 * Never credit Coin based only on a mobile-client purchase callback.
 */
async function verifyStorePurchase({ platform, sku, transactionId, verificationData }) {
  if (!['google_play','app_store'].includes(platform)) throw new Error('unsupported platform');
  if (!sku || !transactionId || !verificationData) throw new Error('missing verification data');

  if (platform === 'google_play') {
    if (!process.env.GOOGLE_PLAY_PACKAGE_NAME || !process.env.GOOGLE_PLAY_SERVICE_ACCOUNT_JSON) {
      const err = new Error('Google Play server verification is not configured'); err.code = 'STORE_NOT_CONFIGURED'; throw err;
    }
    // TODO-PRODUCTION: verify purchaseToken with Google Play Developer API using the service account,
    // check packageName, productId, purchaseState, acknowledgement/consumption and transaction uniqueness.
  }

  if (platform === 'app_store') {
    if (!process.env.APPLE_BUNDLE_ID || !process.env.APPLE_ISSUER_ID || !process.env.APPLE_KEY_ID || !process.env.APPLE_PRIVATE_KEY_P8) {
      const err = new Error('App Store server verification is not configured'); err.code = 'STORE_NOT_CONFIGURED'; throw err;
    }
    // TODO-PRODUCTION: verify signed StoreKit transaction / JWS and bundleId, productId,
    // environment and transaction uniqueness using App Store Server API / signed transaction validation.
  }

  // Fail closed until the official server verification adapters above are completed with real credentials.
  const err = new Error('Server verification adapter requires production credentials');
  err.code = 'STORE_VERIFIER_PENDING';
  throw err;
}

module.exports = { verifyStorePurchase };
