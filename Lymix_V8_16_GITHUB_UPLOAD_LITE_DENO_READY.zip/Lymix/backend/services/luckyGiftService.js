const daily = new Map();
const MULTIPLIERS = [2,5,10,50,100,500,1000];
function dayKey(){return new Date().toISOString().slice(0,10)}
function state(userId){const k=userId+':'+dayKey(); if(!daily.has(k)) daily.set(k,{luck:20,sentCoins:0,streak:0,hits:0}); return daily.get(k)}
function onGift(userId, price){const s=state(userId); s.sentCoins+=price; s.streak++; s.luck=Math.min(100,s.luck + Math.max(1,Math.floor(price/500))); const seed=(s.sentCoins+s.streak*17+userId.length*13)%1000; let multiplier=1; if(seed < s.luck){const idx=Math.min(MULTIPLIERS.length-1,Math.floor((price+s.luck+s.streak)%MULTIPLIERS.length)); multiplier=MULTIPLIERS[idx]; s.hits++; s.luck=Math.max(5,s.luck-12);} return {multiplier,luck:s.luck,daily:s};}
function setLuck(userId, value){state(userId).luck=Math.max(0,Math.min(100,Number(value)||0));return state(userId)}
module.exports={state,onGift,setLuck,MULTIPLIERS};
