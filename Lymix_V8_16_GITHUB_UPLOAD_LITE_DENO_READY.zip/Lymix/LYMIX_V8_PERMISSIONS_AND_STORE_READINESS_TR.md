# Lymix V8 — İzinler, Gizlilik ve Store Hazırlığı

## İzin stratejisi
Lymix izinları topluca ilk açılışta istemek yerine ihtiyaç anında ister. Bu yaklaşım Play Store/App Store incelemesinde daha güvenlidir ve kullanıcı güvenini artırır.

- Mikrofon: Kullanıcı bir sesli odaya girerken istenir.
- Bluetooth: Android 12+ cihazlarda kulaklık/ses cihazı bağlantısı için mikrofon izninden sonra istenir.
- Bildirim: İzin ve Gizlilik Merkezi üzerinden kullanıcı isteğiyle verilir.
- Kamera: Yalnızca yayıncı görüntü teyidi, profil kamerası veya benzeri kamera özelliği başlatıldığında istenir.
- Fotoğraf/medya: Profil, gönderi veya oda arka planı yüklenirken istenir.
- Konum, SMS, rehber ve çağrı kayıtları V8 temel akışında istenmez.

## Android
AndroidManifest.xml içine RECORD_AUDIO, CAMERA, POST_NOTIFICATIONS, BLUETOOTH_CONNECT, READ_MEDIA_IMAGES ve Android 12 ve altı uyumluluğu için sınırlı READ_EXTERNAL_STORAGE tanımları eklendi.

## iOS
Bu arşivde tam iOS Runner projesi bulunmadığı için `ios/Runner/Info.plist.PERMISSION_TEMPLATE.xml` oluşturuldu. macOS + Flutter/Xcode ortamında iOS platformu üretildikten sonra bu anahtarların gerçek Info.plist'e eklenmesi gerekir.

## Store öncesi zorunlu dış adımlar
- Android applicationId ve iOS bundle identifier size ait production kimlikleriyle ayarlanmalı.
- Play App Signing / Apple Distribution ve provisioning profilleri oluşturulmalı.
- Privacy Policy ve Terms URL'leri canlı HTTPS adresinde yayınlanmalı.
- Production API alan adı HTTPS olmalı; `usesCleartextTraffic=true` production build'de kaldırılmalı.
- Firebase/APNs, Agora, oyun sağlayıcısı ve ödeme anahtarları production secret yönetiminden yüklenmeli.
- Data Safety (Play) ve App Privacy (Apple) formları gerçek veri akışına göre doldurulmalı.
- Gerçek Android/iPhone cihazlarda mikrofon, Bluetooth, bildirim, kamera ve medya izinleri test edilmeli.

## V8 QA önerisi
- İlk kurulum / izin reddetme / kalıcı reddetme / ayarlardan tekrar açma testleri
- Odaya mikrofon izni olmadan giriş davranışı
- Bluetooth kulaklık geçişi
- Arka plandan dönüş ve çağrı kesintisi
- Android 13/14/15 ve desteklenen iOS sürümleri
- Ekran okuyucu, font büyütme ve düşük güçlü cihaz testleri
