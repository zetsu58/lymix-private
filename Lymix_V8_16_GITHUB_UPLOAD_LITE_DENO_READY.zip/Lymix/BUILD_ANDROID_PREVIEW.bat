@echo off
powershell -ExecutionPolicy Bypass -File "%~dp0BUILD_ANDROID_PREVIEW.ps1"
pause
