# Store Review Notları — Lymix Coin
- LymCoin dijital sanal para: Play/App Store build'de native store billing.
- ERC20/TRC20 ve ham kredi kartı tahsilatı store build UI'sinde gösterilmez.
- Alternatif ödeme yalnızca ilgili ülke/program uygunluğu doğrulanıp resmi programa kayıt olunursa feature flag ile açılır.
- Lucky/şans ödülü satın alınabilen sanal Coin ile tetikleniyorsa odds disclosure ekranda görünür.
- Coin başka uygulamaya/gerçek paraya çevrilemez; creator payout ayrı kazanç/settlement ledger'ında tutulur.
