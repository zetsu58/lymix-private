# Lymix Oda Efektleri Güncellemesi

Bu sürümde oda içi hediye gönderimi için Lymix'e özgü jenerik tam ekran efekt altyapısı eklendi. Hediye gönderildiğinde hediye adı, gönderen/alıcı ve LymCoin değeri oda üzerinde animasyonlu olarak görünür ve sistem sohbetine kayıt düşer.

## Oda Ayarları
- Oda efektleri: hediye, coin yağmuru ve oda içi görsel efektleri cihaz bazında aç/kapat.
- VIP giriş efektleri: VIP seviyesine özel giriş animasyonlarını cihaz bazında aç/kapat.

## VIP giriş stilleri
- VIP 1: Altın Işık
- VIP 2: Kraliyet İzi
- VIP 3: Lymix Aurora

Efektler başka uygulamadaki görsel varlıklar kopyalanmadan Flutter animasyonları ve Lymix sarı/karanlık marka dili ile oluşturuldu.
