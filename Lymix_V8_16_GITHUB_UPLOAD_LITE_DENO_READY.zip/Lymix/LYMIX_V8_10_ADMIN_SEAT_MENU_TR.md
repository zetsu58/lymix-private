# Lymix V8.10 - Admin Koltuk Menusu

- Normal yayinici/kullanici bos ve acik koltuga dokundugunda dogrudan oturur.
- Oda sahibi veya oda admini bos/kilitli koltuga dokundugunda yonetim menusu acilir.
- Admin koltuk menusu: Otur, Davet et, Sesini kapat, Koltugu kapat/Kilidi ac.
- Kilitli koltuga normal kullanici oturamaz.
- Dolu koltuga dokunuldugunda mevcut kullanici aksiyonlari korunur.
