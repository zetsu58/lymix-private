# Lymix V8.5 — Otomatik Oda Takibi ve Katılım Onayı

Bu sürüm V8.4 ALL-IN-ONE paketinin üzerine hazırlanmıştır.

## Odaya giriş akışı
- Kullanıcı odaya dinleyici olarak girdiğinde oda otomatik olarak takip edilir.
- Oda sahibi ve oda adminleri dışındaki kullanıcılar için otomatik katılım/mikrofona çıkma isteği oluşturulur.
- Katılım isteği oda sahibi ve oda adminlerinin `Katılım İstekleri` paneline düşer.
- Oda sahibi veya oda admini isteği onaylayabilir ya da reddedebilir.
- Onay sırasında sistem ilk açık/boş koltuğu bulur ve kullanıcıyı koltuğa yerleştirir.
- Boş/açık koltuk yoksa istek beklemede kalır ve moderatöre hata gösterilir.
- Kullanıcı onaylanmadan doğrudan boş koltuğa oturamaz.

## Socket.IO olayları
- `room_followed`
- `room_join_request`
- `room_join_request_status`
- `room_join_request_response`
- `room_join_request_resolved`

## Yetki
`room.ownerId` veya `room.adminIds` içinde olan kullanıcılar katılım isteklerini yönetebilir. Aynı yetki V8.4 koltuk kilitleme ve koltuğa davet akışında da kullanılmaktadır.

## Production notu
Takipçi ve katılım istekleri demo belleği yerine production veritabanında kalıcı tutulmalıdır. Socket kimliği doğrulanmış JWT/session üzerinden gelmeli; oda admin rolleri backend RBAC kaynağından yüklenmelidir.
