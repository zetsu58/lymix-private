# Lymix Oda İçi Jenerik Hediye Efekt Sistemi

Bu sürümde oda içinden gönderilen her hediye için Lymix'e özgü, harici telifli görsele bağımlı olmayan jenerik bir efekt katmanı eklendi.

## Davranış
- Hediye gönderildiğinde oda ekranının üzerinde otomatik animasyon oynar.
- Gönderen, alıcı, hediye adı ve LymCoin değeri üst bantta görünür.
- Hediye değeri 3 görsel seviyeden birine otomatik ayrılır:
  - Standard: 0–4.999 LymCoin
  - Premium: 5.000–49.999 LymCoin
  - Legendary / Lymix Efsanesi: 50.000+ LymCoin
- Yüksek değerli hediyelerde efekt daha uzun sürer, daha fazla parçacık ve karartılmış sahne kullanılır.
- Efekt sistemi emoji/ikon tabanlı olduğu için yeni hediyeler eklenirken yeni bir animasyon dosyası zorunlu değildir.
- Aynı yapı daha sonra PNG/WebP, Lottie veya video tabanlı özel Lymix efektleriyle genişletilebilir.

## Realtime yayın
Backend'deki `send_gift` Socket.IO olayı zaten `gift_received` olayını odadaki tüm kullanıcılara yayınlamaktadır. Mobil tarafta production bağlantısında gelen `gift_received` payload'ı `GiftEffectData` modeline dönüştürülerek aynı overlay tetiklenmelidir.

Önerilen eşleme:
```dart
GiftEffectData(
  senderName: data['senderName'],
  receiverName: data['targetName'],
  giftName: data['gift']['name'],
  emoji: data['gift']['emoji'] ?? '🎁',
  coins: data['gift']['price'],
  quantity: data['quantity'] ?? 1,
)
```

Not: Gerçek zamanlı production kullanımında kimlik/bakiye kontrolleri yalnızca backend üzerinde tutulmalıdır.
