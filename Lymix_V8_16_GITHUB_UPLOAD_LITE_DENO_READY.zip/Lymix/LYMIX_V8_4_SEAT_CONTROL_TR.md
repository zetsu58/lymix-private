# Lymix V8.4 – Koltuk Kilidi ve Koltuğa Davet

V8.3 üzerine eklenmiştir.

## Oda koltuk yönetimi
- Oda sahibi/yetkili boş koltuğu kilitleyebilir ve kilidi açabilir.
- Kilitli koltuğa normal kullanıcı doğrudan oturamaz.
- Koltuk üzerinde kilit durumu görsel olarak gösterilir.
- Oda sahibi boş bir koltuk için odadaki kullanıcı listesinden davet gönderebilir.

## Davet akışı
1. Oda sahibi boş koltuğa dokunur.
2. “Kullanıcıyı koltuğa davet et” seçilir.
3. Odadaki kullanıcı seçilir.
4. Davet edilen kullanıcıya koltuk numarası ile Kabul Et / Reddet penceresi gider.
5. Kabul edilirse sunucu koltuğun hâlâ boş ve kilitsiz olduğunu tekrar kontrol eder ve kullanıcıyı yerleştirir.
6. Davet 30 saniye sonra geçersiz olur.

## Güvenlik
- Sunucu tarafı room owner kontrolü vardır.
- Dolu veya kilitli koltuğa davet engellenir.
- Kullanıcı yalnızca kendi davetine cevap verebilir.
- Bir kullanıcının aynı anda iki koltuğa oturması engellenir.
- Client tarafındaki durum güvenilir kabul edilmez; kabul anında koltuk yeniden doğrulanır.

Not: Demo Flutter ekranında akış yerel önizleme ile görülebilir. Production Socket.IO istemci bağlantısında `seat_lock`, `seat_invite`, `seat_invite_response`, `seat_invited`, `seat_updated` ve `seat_invite_result` olayları kullanılmalıdır.
