# Lymix

Lymix is a Flutter social voice-room prototype with a production-oriented backend foundation.

## Added / completed

### Social & discovery
- 5-tab navigation: Home, Discover, Party, Notifications, Profile
- Smart-match style discovery based on interests
- Online indicators, verified profiles and profile actions
- Moments / daily social feed
- Follow, message, block and report entry points

### Live rooms
- 8-seat speaker grid with speaking and microphone states
- Host badge, listener count, follow action and room menu
- Real-time chat composer
- User action sheet: profile, message, gift, block, report
- Gift picker with multiple virtual gifts
- Room rules / report / share / notification entry points
- Backend events for seats, mute, reactions, messages and gifts
- Room lock control for hosts

### Social party features
- Voice party discovery
- PK battle entry point
- Mini-game entry point (Ludo / web-game integration can be attached)
- VIP tiers and badges
- Wallet with Coins and Diamonds

### Safety & moderation
- Block/report UX
- Moderation tables in PostgreSQL schema
- Message length and rate limiting in backend
- Server-side balance validation
- Server-side seat ownership validation
- Room lock and host-only room controls

### Economy
- Gift catalog
- Coin -> Diamond creator revenue calculation
- Wallet transaction tables
- Cashout request tables
- Bank/agency authorization table
- VIP subscriptions and badges

## Important production notes

The included backend still uses in-memory demo users/rooms so the project can be run as a prototype. Before launch:
1. Replace demo identity with JWT/session authentication.
2. Move users, rooms, messages and wallet mutations to PostgreSQL transactions.
3. Use Redis for presence, room state and rate limiting.
4. Verify App Store / Google Play purchase receipts on the server.
5. Never trust client-side coin/diamond balances.
6. Add object storage + signed URLs for user media.
7. Add a real moderation pipeline and audit logs.
8. Put Agora App ID/token issuance behind an authenticated backend endpoint.
9. Restrict CORS and HTTPS/WSS in production.

## Run Flutter

```bash
flutter pub get
flutter run
```

## Run backend

```bash
cd backend
npm install
npm start
```

Android emulator uses `http://10.0.2.2:3000` in `SocketService`. For a physical device, change this to the LAN IP or, preferably, an HTTPS/WSS production endpoint.

## Reference feature direction

The product direction combines patterns visible in SoMatch (smart recommendations, real-time party rooms, voice parties, moments and safety) and Xena (large themed room discovery, PK battles, mini-games, VIP benefits and interactive gifts). These are product patterns, not copied assets or code.

## 2026-08-11 feature package

This build adds UI/data foundations for the requested Lymix expansion:
- 15-seat room layout, room panel chat, emoji reactions, coin rain, room share/report, event carousel, store entry, visitor list and room total gift/throw label.
- VIP 1/2/3 progression entry points, profile age/VIP/level/sent/received tags, personal room, backpack, relationship/ring details and system level-up messages.
- Agency broadcaster quota tracking, agency room quota, received-gift quota multiplier example and Diamond -> Coin conversion endpoint.
- Home Lymix flow bar, feed/event entry points and game-achievement badge foundation.
- Game Center matching the supplied reference list: Greedy Cat, Crash, Fishing, Slot Frenzy, Fruit Crush, Roulette, UEFA, Yummy, Chicken Cross, Lion or Tiger, Teen Patti and Texas Cowboy.

### Game provider connection
The app now contains a provider-agnostic WebView bridge. Licensed game launch URLs are intentionally not hard-coded because a real provider requires account credentials, contracts/rights and server-issued launch tokens. Configure a provider at run/build time:

Backend environment:

```bash
GAME_PROVIDER_BASE_URL=https://YOUR_PROVIDER_LAUNCH_HOST
GAME_PROVIDER_DEMO_TOKEN=YOUR_DEMO_TOKEN
```

Flutter connects to the backend launch endpoint. On Android emulator the default API URL is `http://10.0.2.2:3000`; override it when needed:

```bash
flutter run --dart-define=LYMIX_API_BASE_URL=https://api.yourdomain.com
```

For production, do not ship a permanent provider token in the app. Generate short-lived signed launch URLs/tokens on the backend and return them to authenticated users.
