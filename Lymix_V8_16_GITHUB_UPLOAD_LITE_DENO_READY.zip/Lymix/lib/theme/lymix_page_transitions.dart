import 'package:flutter/material.dart';

class LymixPageTransitionsBuilder extends PageTransitionsBuilder {
  const LymixPageTransitionsBuilder();
  @override Widget buildTransitions<T>(
    PageRoute<T> route,
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
    Widget child,
  ){
    final curved=CurvedAnimation(parent:animation,curve:Curves.easeOutCubic,reverseCurve:Curves.easeInCubic);
    return FadeTransition(
      opacity:Tween<double>(begin:.92,end:1).animate(curved),
      child:SlideTransition(
        position:Tween<Offset>(begin:const Offset(.025,.012),end:Offset.zero).animate(curved),
        child:child,
      ),
    );
  }
}
