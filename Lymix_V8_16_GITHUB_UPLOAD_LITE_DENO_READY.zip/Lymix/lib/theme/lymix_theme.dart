import 'package:flutter/material.dart';
import 'lymix_page_transitions.dart';

class LymixColors {
  static const bg = Color(0xFF08060F);
  static const surface = Color(0xFF120E1A);
  static const surface2 = Color(0xFF191223);
  static const gold = Color(0xFFFFD643);
  static const amber = Color(0xFFFFB000);
  static const pink = Color(0xFFFF4DCC);
  static const purple = Color(0xFF8A2BE2);
  static const text = Color(0xFFF7F3FA);
  static const muted = Color(0xFF9B93A6);
  static const success = Color(0xFF5BE3A5);
  static const danger = Color(0xFFFF667A);

  static const brandGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [gold, amber, pink, purple],
  );
}

class LymixTheme {
  static ThemeData dark() {
    final scheme = ColorScheme.fromSeed(
      seedColor: LymixColors.purple,
      brightness: Brightness.dark,
      surface: LymixColors.surface,
    ).copyWith(
      primary: LymixColors.gold,
      secondary: LymixColors.pink,
      tertiary: LymixColors.purple,
      error: LymixColors.danger,
    );

    return ThemeData(
      brightness: Brightness.dark,
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: LymixColors.bg,
      fontFamily: 'Roboto',
      splashFactory: InkSparkle.splashFactory,
      appBarTheme: const AppBarTheme(
        backgroundColor: LymixColors.bg,
        foregroundColor: LymixColors.text,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        titleTextStyle: TextStyle(
          color: LymixColors.text,
          fontSize: 18,
          fontWeight: FontWeight.w800,
          letterSpacing: -.2,
        ),
      ),
      cardTheme: CardTheme(
        color: LymixColors.surface,
        elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
      ),
      navigationBarTheme: NavigationBarThemeData(
        height: 68,
        backgroundColor: const Color(0xFF0E0A15),
        indicatorColor: LymixColors.gold.withOpacity(.12),
        labelTextStyle: const WidgetStatePropertyAll(
          TextStyle(fontSize: 10, fontWeight: FontWeight.w700),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white.withOpacity(.045),
        hintStyle: const TextStyle(color: Colors.white38),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: Color(0x66FFD643)),
        ),
      ),
      bottomSheetTheme: const BottomSheetThemeData(
        backgroundColor: Color(0xFF120E1A),
        surfaceTintColor: Colors.transparent,
        modalBackgroundColor: Color(0xFF120E1A),
        showDragHandle: true,
        dragHandleColor: Color(0x44FFFFFF),
      ),
      dialogTheme: DialogTheme(
        backgroundColor: LymixColors.surface,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      ),
      pageTransitionsTheme: const PageTransitionsTheme(
        builders: {
          TargetPlatform.android: LymixPageTransitionsBuilder(),
          TargetPlatform.iOS: LymixPageTransitionsBuilder(),
          TargetPlatform.macOS: LymixPageTransitionsBuilder(),
          TargetPlatform.windows: LymixPageTransitionsBuilder(),
          TargetPlatform.linux: LymixPageTransitionsBuilder(),
        },
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: const Color(0xFF21172B),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}

class LymixBrandButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onPressed;
  final bool compact;
  const LymixBrandButton({
    super.key,
    required this.label,
    this.icon,
    this.onPressed,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) => DecoratedBox(
    decoration: BoxDecoration(
      gradient: LymixColors.brandGradient,
      borderRadius: BorderRadius.circular(compact ? 14 : 17),
      boxShadow: const [
        BoxShadow(color: Color(0x338A2BE2), blurRadius: 18, offset: Offset(0, 8)),
      ],
    ),
    child: ElevatedButton.icon(
      onPressed: onPressed,
      icon: icon == null ? const SizedBox.shrink() : Icon(icon, size: compact ? 16 : 18),
      label: Text(label, style: TextStyle(fontSize: compact ? 11 : 13, fontWeight: FontWeight.w800)),
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.transparent,
        disabledBackgroundColor: Colors.transparent,
        shadowColor: Colors.transparent,
        foregroundColor: const Color(0xFF140E18),
        padding: EdgeInsets.symmetric(horizontal: compact ? 13 : 18, vertical: compact ? 10 : 13),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(compact ? 14 : 17)),
      ),
    ),
  );
}
