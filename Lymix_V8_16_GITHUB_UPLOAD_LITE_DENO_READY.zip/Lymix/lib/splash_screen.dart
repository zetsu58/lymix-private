import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'screens/home_screen.dart';
import 'screens/onboarding_screen.dart';
import 'theme/lymix_theme.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 950), () async {
      final prefs = await SharedPreferences.getInstance();
      final done = prefs.getBool('lymix.onboarding.complete') ?? false;
      if (!mounted) return;
      Navigator.of(context).pushReplacement(MaterialPageRoute(
        builder: (_) => done ? const LymixHomeScreen() : const OnboardingScreen(),
      ));
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: const Color(0xFF090611),
    body: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Image.asset('assets/branding/lymix_logo_horizontal.png', width: 260, fit: BoxFit.contain),
      const SizedBox(height: 8),
      Text('Connect • Talk • Play', style: TextStyle(color: Colors.white.withOpacity(.45), letterSpacing: 1.5)),
      const SizedBox(height: 28),
      const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2, color: LymixColors.gold)),
    ])),
  );
}
