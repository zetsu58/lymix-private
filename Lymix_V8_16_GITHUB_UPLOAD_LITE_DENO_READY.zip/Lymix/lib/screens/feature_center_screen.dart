import 'package:flutter/material.dart';
import 'game_center_screen.dart';

class FeatureCenterScreen extends StatelessWidget {
  const FeatureCenterScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: const Color(0xFF090611),
    appBar: AppBar(backgroundColor: const Color(0xFF110B19), title: const Text('Lymix Özellik Merkezi')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      _card(context, Icons.dynamic_feed, 'Akış & Post', 'Post, fotoğraf, etkinlik paylaşımı ve Lymix akış barı', () => _sheet(context, 'Akış & Post', ['Post oluştur', 'Fotoğraf/video ekle', 'Etkinlik paylaş', 'Beğeni / yorum / paylaşım', 'Takip edilenler akışı'])),
      _card(context, Icons.storefront, 'Mağaza & VIP 1–10 + Crown', '30 günlük VIP dönemi, yenileme eşikleri, Crown ve ayrıcalıklar', () => _sheet(context, 'VIP Seviyeleri', ['VIP 1–10 kademeli yükleme sistemi', 'VIP 10 üstü: Lymix Crown', 'Her dönem 30 gün', 'Yükselme eşik geçilince anında', 'Yenileme eşiği karşılanmazsa dönem sonunda düşüş', 'Seviyeye özel çerçeve ve oda giriş efekti'])),
      _card(context, Icons.backpack, 'Sırt Çantası', 'Çerçeveler, yüzükler, giriş efektleri, rozetler ve koleksiyonlar', () => _sheet(context, 'Sırt Çantası', ['Profil çerçeveleri', 'İlişki yüzükleri', 'Giriş efektleri', 'Oyun rozetleri', 'Etkinlik koleksiyonları'])),
      _card(context, Icons.favorite, 'İlişki & Yüzük', 'İlişki tarihi, gün sayacı ve karşılıklı coin atış toplamları', () => _sheet(context, 'İlişki Detayı', ['Başlangıç: 11.08.2026', 'Birlikte: 1 gün', 'Sen → Partner: 82.500 coin', 'Partner → Sen: 74.300 coin', 'Yüzük: Aurora Ring Lv.2'])),
      _card(context, Icons.currency_exchange, 'Kota & Elmas Dönüşümü', 'Alınan atışa bağlı kota çarpanı ve elmas → coin dönüşümü', () => _sheet(context, 'Kota Sistemi', ['0–149.999 atış: 1.0x', '150K atış: 50K kota örneği', '500K atış: 1.5x', '1M atış: 2.0x', 'Dönüşüm oranları sunucudan yönetilir'])),
      _card(context, Icons.groups_3, 'Ajans Paneli', 'Yayıncı kota takibi, ajans odası kotası ve performans özeti', () => _agencySheet(context)),
      _card(context, Icons.home_work_outlined, 'Kendi Odam', 'Her kullanıcıya ait kalıcı kişisel oda', () => _sheet(context, 'Kendi Odam', ['Oda ID: room_101', 'Kalıcı oda bağlantısı', 'Oda teması', 'Yetkili listesi', 'Etkinlik planlama'])),
      _card(context, Icons.sports_esports, 'Oyun Merkezi & Rozetler', 'Oyun başarılarına göre rozet sistemi', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const GameCenterScreen()))),
      _card(context, Icons.campaign, 'Sistem Mesajları', 'Seviye/VIP/kota atlama ve etkinlik duyuruları', () => _sheet(context, 'Sistem Mesajları', ['🎉 Seviye 20 oldun!', '👑 VIP 2 seviyesine yükseldin!', '💎 Dönüşüm tamamlandı', '🏆 Yeni oyun rozeti kazandın'])),
    ]),
  );

  Widget _card(BuildContext context, IconData icon, String title, String subtitle, VoidCallback tap) => Card(
    color: const Color(0xFF15101F), margin: const EdgeInsets.only(bottom: 10),
    child: ListTile(onTap: tap, leading: CircleAvatar(backgroundColor: const Color(0x22FF2D55), child: Icon(icon, color: const Color(0xFFFF6B86))), title: Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)), subtitle: Text(subtitle, style: const TextStyle(color: Colors.white54, fontSize: 11)), trailing: const Icon(Icons.chevron_right, color: Colors.white38)),
  );

  void _sheet(BuildContext context, String title, List<String> items) => showModalBottomSheet(
    context: context, backgroundColor: const Color(0xFF17101F), shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
    builder: (_) => SafeArea(child: Padding(padding: const EdgeInsets.all(20), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)), const SizedBox(height: 12),
      ...items.map((e) => Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Row(children: [const Icon(Icons.check_circle, color: Color(0xFFFF5B78), size: 17), const SizedBox(width: 9), Expanded(child: Text(e, style: const TextStyle(color: Colors.white70)))]))),
    ]))),
  );

  void _agencySheet(BuildContext context) => _sheet(context, 'Ajans Kota Takibi', ['Ajans odası: 8 / 10 kota', 'Yayıncı A: 420K / 500K', 'Yayıncı B: 155K / 250K', 'Yayıncı C: 92K / 150K', 'Toplam ajans atışı: 1.84M']);
}
