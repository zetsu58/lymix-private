import 'package:flutter/material.dart';
import '../theme/lymix_theme.dart';

class RoomEventScreen extends StatefulWidget {
  final String roomId;
  final String roomTitle;
  const RoomEventScreen({super.key, required this.roomId, required this.roomTitle});
  @override State<RoomEventScreen> createState()=>_RoomEventScreenState();
}

class _RoomEventScreenState extends State<RoomEventScreen>{
  bool reminded=false;

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Oda Etkinlikleri')),
    body:ListView(padding:const EdgeInsets.fromLTRB(16,10,16,28),children:[
      _event(
        title:'Gece Sohbeti Özel',
        subtitle:'Konuklarla açık mikrofon ve soru-cevap',
        starts:'Bugün • 22:30',
        attendees:'128 katılımcı',
        featured:true,
      ),
      const SizedBox(height:10),
      _event(
        title:'Haftalık Topluluk Buluşması',
        subtitle:'Haftanın öne çıkan odaları ve yayıncıları',
        starts:'Cumartesi • 20:00',
        attendees:'74 katılımcı',
      ),
      const SizedBox(height:18),
      const Text('Geçmiş etkinlikler',style:TextStyle(fontSize:14,fontWeight:FontWeight.w900)),
      const SizedBox(height:9),
      _past('Müzik Gecesi','2 gün önce • 316 katılım'),
      _past('Yeni Yayıncılar Tanışması','1 hafta önce • 201 katılım'),
    ]),
  );

  Widget _event({required String title,required String subtitle,required String starts,required String attendees,bool featured=false})=>Container(
    padding:const EdgeInsets.all(15),
    decoration:BoxDecoration(
      gradient:featured?const LinearGradient(colors:[Color(0xFF24152B),Color(0xFF17101E),Color(0xFF231B0B)]):null,
      color:featured?null:LymixColors.surface,
      borderRadius:BorderRadius.circular(22),
      border:Border.all(color:featured?const Color(0x44FFD643):Colors.white.withOpacity(.05)),
    ),
    child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(children:[
        Container(width:44,height:44,decoration:BoxDecoration(gradient:featured?LymixColors.brandGradient:null,color:featured?null:const Color(0x16FFD643),borderRadius:BorderRadius.circular(14)),child:Icon(Icons.event_rounded,color:featured?const Color(0xFF150E18):LymixColors.gold)),
        const SizedBox(width:10),
        Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text(title,style:const TextStyle(fontSize:12.5,fontWeight:FontWeight.w900)),
          const SizedBox(height:3),
          Text(subtitle,style:const TextStyle(color:Colors.white42,fontSize:9.2)),
        ])),
      ]),
      const SizedBox(height:12),
      Row(children:[
        const Icon(Icons.schedule_rounded,size:15,color:LymixColors.gold),const SizedBox(width:5),Text(starts,style:const TextStyle(fontSize:9.5,fontWeight:FontWeight.w700)),
        const Spacer(),
        const Icon(Icons.groups_2_outlined,size:15,color:Colors.white38),const SizedBox(width:4),Text(attendees,style:const TextStyle(color:Colors.white45,fontSize:9)),
      ]),
      const SizedBox(height:10),
      SizedBox(width:double.infinity,child:OutlinedButton.icon(
        onPressed:()=>setState(()=>reminded=!reminded),
        icon:Icon(reminded?Icons.notifications_active_rounded:Icons.notifications_none_rounded,size:16),
        label:Text(reminded?'Hatırlatıcı açık':'Hatırlat'),
        style:OutlinedButton.styleFrom(foregroundColor:reminded?LymixColors.gold:Colors.white70,side:BorderSide(color:reminded?const Color(0x66FFD643):Colors.white12)),
      )),
    ]),
  );

  Widget _past(String title,String sub)=>ListTile(
    contentPadding:EdgeInsets.zero,
    leading:const CircleAvatar(backgroundColor:Color(0xFF1D1625),child:Icon(Icons.history_rounded,color:Colors.white38,size:19)),
    title:Text(title,style:const TextStyle(fontSize:11,fontWeight:FontWeight.w700)),
    subtitle:Text(sub,style:const TextStyle(color:Colors.white34,fontSize:8.8)),
  );
}
