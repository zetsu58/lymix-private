import 'package:flutter/material.dart';

class LymixGift {
  final String id;
  final String name;
  final String emoji;
  final int coins;
  final String category;
  final bool featured;
  const LymixGift(this.id, this.name, this.emoji, this.coins, this.category, {this.featured = false});
}

class GiftCatalogScreen extends StatefulWidget {
  const GiftCatalogScreen({super.key});

  @override
  State<GiftCatalogScreen> createState() => _GiftCatalogScreenState();
}

class _GiftCatalogScreenState extends State<GiftCatalogScreen> {
  static const _yellow = Color(0xFFFFC928);
  static const _cyan = Color(0xFF27D7E8);
  String category = 'Hediyeler';
  int selected = 0;

  static const gifts = <LymixGift>[
    LymixGift('spark_rose', 'Işık Gülü', '🌹', 50, 'Hediyeler'),
    LymixGift('star_wand', 'Yıldız Asası', '🪄', 100, 'Hediyeler'),
    LymixGift('sweet_swirl', 'Tatlı Rüya', '🍦', 150, 'Hediyeler'),
    LymixGift('golden_like', 'Altın Alkış', '👍', 500, 'Hediyeler'),
    LymixGift('sky_journey', 'Gökyüzü Yolculuğu', '✈️', 20000, 'Hediyeler', featured: true),
    LymixGift('lucky_bell', 'Şans Çanı', '🔔', 100, 'Şanslı'),
    LymixGift('fortune_drop', 'Şans Damlası', '🍭', 100, 'Şanslı'),
    LymixGift('gold_pouch', 'Altın Kesesi', '💰', 300, 'Şanslı'),
    LymixGift('ruby_promise', 'Yakut Sözü', '💍', 300, 'Şanslı'),
    LymixGift('royal_mark', 'Kraliyet Mührü', '👑', 1000, 'Şanslı', featured: true),
    LymixGift('time_gate', 'Zaman Kapısı', '⌛', 5000, 'Etkinlik'),
    LymixGift('celestial_throne', 'Göksel Taht', '🪽', 30000, 'Etkinlik'),
    LymixGift('dream_palace', 'Rüya Sarayı', '🏰', 150000, 'Etkinlik'),
    LymixGift('sunset_story', 'Gün Batımı Hikâyesi', '🌅', 200000, 'Etkinlik'),
    LymixGift('eternal_gate', 'Ebedi Geçit', '✨', 500000, 'Etkinlik', featured: true),
    LymixGift('bloom_ring', 'Bahar Halkası', '🌼', 10000, 'Yüzük'),
    LymixGift('blue_vow', 'Mavi Yemin', '💎', 26000, 'Yüzük'),
    LymixGift('ruby_vow', 'Yakut Yemin', '❤️‍🔥', 26000, 'Yüzük'),
    LymixGift('moon_bond', 'Ay Bağı', '🌙', 200000, 'Yüzük'),
    LymixGift('phoenix_bond', 'Anka Bağı', '🔥', 750000, 'Yüzük', featured: true),
  ];

  List<LymixGift> get visible => gifts.where((g) => g.category == category).toList();

  @override
  Widget build(BuildContext context) {
    final list = visible;
    if (selected >= list.length) selected = 0;
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF101723), Color(0xFF080B10)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: SafeArea(
        child: Column(
          children: [
            _promo(),
            const SizedBox(height: 12),
            SizedBox(
              height: 42,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                children: ['Hediyeler', 'Şanslı', 'Etkinlik', 'Yüzük'].map(_tab).toList(),
              ),
            ),
            Expanded(
              child: GridView.builder(
                padding: const EdgeInsets.fromLTRB(16, 18, 16, 10),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 4,
                  childAspectRatio: .67,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 14,
                ),
                itemCount: list.length,
                itemBuilder: (_, index) => _giftTile(list[index], index),
              ),
            ),
            _bottomBar(list),
          ],
        ),
      ),
    );
  }

  Widget _promo() => Container(
        margin: const EdgeInsets.fromLTRB(16, 10, 16, 0),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: const LinearGradient(colors: [Color(0xFF3A2E08), Color(0xFF17232A)]),
          border: Border.all(color: _yellow.withOpacity(.55)),
        ),
        child: const Row(children: [
          Text('✨', style: TextStyle(fontSize: 34)),
          SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Lymix Hediye Galaksisi', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800)),
            SizedBox(height: 4),
            Text('Kombolar, oda etkinlikleri ve özel koleksiyonlar', style: TextStyle(color: Colors.white60, fontSize: 12)),
          ])),
        ]),
      );

  Widget _tab(String value) {
    final active = category == value;
    return GestureDetector(
      onTap: () => setState(() { category = value; selected = 0; }),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        margin: const EdgeInsets.only(right: 10),
        padding: const EdgeInsets.symmetric(horizontal: 18),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          color: active ? _yellow : Colors.white.withOpacity(.06),
          border: Border.all(color: active ? _yellow : Colors.white12),
        ),
        child: Text(value, style: TextStyle(color: active ? Colors.black : Colors.white70, fontWeight: FontWeight.w700)),
      ),
    );
  }

  Widget _giftTile(LymixGift gift, int index) {
    final active = selected == index;
    return GestureDetector(
      onTap: () => setState(() => selected = index),
      child: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          color: active ? _yellow.withOpacity(.09) : Colors.transparent,
          border: Border.all(color: active ? _cyan : Colors.transparent, width: 1.6),
        ),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Stack(alignment: Alignment.topRight, children: [
            Container(
              height: 64,
              width: 64,
              alignment: Alignment.center,
              decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(.055)),
              child: Text(gift.emoji, style: const TextStyle(fontSize: 38)),
            ),
            if (gift.featured) const Icon(Icons.auto_awesome, size: 17, color: _yellow),
          ]),
          const SizedBox(height: 8),
          Text(gift.name, maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700)),
          const SizedBox(height: 3),
          Text('${gift.coins} LymCoin', maxLines: 1, style: const TextStyle(color: Colors.white54, fontSize: 10)),
        ]),
      ),
    );
  }

  Widget _bottomBar(List<LymixGift> list) => Container(
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 14),
        decoration: BoxDecoration(color: const Color(0xFF0C1119).withOpacity(.96), border: const Border(top: BorderSide(color: Colors.white10))),
        child: Row(children: [
          const Icon(Icons.monetization_on_rounded, color: _yellow),
          const SizedBox(width: 6),
          const Text('10', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
          const Spacer(),
          FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: _yellow, foregroundColor: Colors.black, padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 13)),
            onPressed: list.isEmpty ? null : () {},
            icon: const Icon(Icons.send_rounded, size: 18),
            label: const Text('Gönder', style: TextStyle(fontWeight: FontWeight.w800)),
          ),
        ]),
      );
}
