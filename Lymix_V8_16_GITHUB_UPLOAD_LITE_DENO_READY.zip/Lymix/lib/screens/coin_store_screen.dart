import 'dart:async';
import 'package:flutter/material.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import '../services/coin_purchase_service.dart';

class CoinStoreScreen extends StatefulWidget {
  const CoinStoreScreen({super.key});
  @override State<CoinStoreScreen> createState() => _CoinStoreScreenState();
}

class _CoinStoreScreenState extends State<CoinStoreScreen> {
  bool loading = true;
  bool available = false;
  List<ProductDetails> products = const [];
  StreamSubscription<PurchaseDetails>? sub;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    available = await CoinPurchaseService.instance.init();
    if (available) products = await CoinPurchaseService.instance.loadProducts();
    sub = CoinPurchaseService.instance.purchaseEvents.listen(_onPurchase);
    if (mounted) setState(() => loading = false);
  }

  void _onPurchase(PurchaseDetails p) {
    if (!mounted) return;
    final text = switch (p.status) {
      PurchaseStatus.pending => 'Ödeme bekleniyor…',
      PurchaseStatus.purchased || PurchaseStatus.restored => 'Ödeme alındı. Sunucu doğrulaması tamamlandığında Coin bakiyen güncellenecek.',
      PurchaseStatus.error => 'Ödeme tamamlanamadı: ${p.error?.message ?? 'Bilinmeyen hata'}',
      PurchaseStatus.canceled => 'Ödeme iptal edildi.',
    };
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  void dispose() {
    sub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const bg = Color(0xFF090611), panel = Color(0xFF171224), gold = Color(0xFFFFC928), purple = Color(0xFF7B3FF2);
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(backgroundColor: bg, title: const Text('LymCoin Yükle', style: TextStyle(fontWeight: FontWeight.w800))),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : !available
              ? const Center(child: Padding(padding: EdgeInsets.all(24), child: Text('Bu cihazda mağaza ödeme servisine erişilemiyor.', textAlign: TextAlign.center)))
              : ListView(padding: const EdgeInsets.all(18), children: [
                  Container(
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(22),
                      gradient: const LinearGradient(colors: [Color(0xFFFFB300), Color(0xFF7B3FF2)]),
                    ),
                    child: const Row(children: [
                      Text('🪙', style: TextStyle(fontSize: 42)), SizedBox(width: 12),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('Coin yükleme', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                        Text('Paket büyüdükçe daha yüksek Coin bonusu', style: TextStyle(color: Colors.white70)),
                      ])),
                    ]),
                  ),
                  const SizedBox(height: 18),
                  const Text('Güvenli mağaza ödemesi', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 5),
                  const Text('Android’de Google Play, iPhone’da App Store ödeme ekranı kullanılır. Kart bilgilerin Lymix sunucularına gelmez.', style: TextStyle(color: Colors.white54, fontSize: 12)),
                  const SizedBox(height: 16),
                  if (products.isEmpty)
                    Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(18)), child: const Text('Coin ürünleri mağaza panelinde henüz oluşturulmamış. SKU listesi PAYMENT_SETUP_TR.md dosyasında.', style: TextStyle(color: Colors.white70)))
                  else
                    GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: products.length,
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: 1.35, crossAxisSpacing: 12, mainAxisSpacing: 12),
                      itemBuilder: (_, i) {
                        final p = products[i]; final pack = CoinPurchaseService.instance.packFor(p.id);
                        return InkWell(
                          onTap: () => CoinPurchaseService.instance.buy(p),
                          borderRadius: BorderRadius.circular(18),
                          child: Container(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(18), border: Border.all(color: i == products.length - 1 ? gold.withOpacity(.65) : Colors.white10)),
                            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                              const Icon(Icons.monetization_on_rounded, color: gold, size: 29),
                              const SizedBox(height: 5),
                              Text('${pack?.coins ?? 0}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                              Text(p.price, style: const TextStyle(color: Colors.white60, fontWeight: FontWeight.w700)),
                              if (pack != null) Text(pack.label, style: const TextStyle(color: purple, fontSize: 10, fontWeight: FontWeight.w800)),
                            ]),
                          ),
                        );
                      },
                    ),
                  const SizedBox(height: 20),
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16)),
                    child: const Text('Not: LymCoin yalnızca Lymix içinde kullanılabilen sanal para birimidir. Lucky/şans mekaniklerinin olasılıkları işlem öncesinde gösterilir. Satın alınan Coin’in nakit değeri yoktur.', style: TextStyle(color: Colors.white54, fontSize: 11)),
                  ),
                ]),
    );
  }
}
