import 'package:flutter/material.dart';

class FeedScreen extends StatefulWidget {
  const FeedScreen({super.key});
  @override State<FeedScreen> createState() => _FeedScreenState();
}

class _FeedScreenState extends State<FeedScreen> {
  final controller = TextEditingController();
  final posts = <Map<String, dynamic>>[
    {'user':'Ece','text':'Bu gece 22:00’de odamızda oyun etkinliği var 🎮','likes':128,'comments':24},
    {'user':'Tugay','text':'VIP sezon görevlerini tamamladım 👑✨','likes':86,'comments':11},
  ];

  @override void dispose(){controller.dispose();super.dispose();}

  @override Widget build(BuildContext context)=>Scaffold(
    backgroundColor:const Color(0xFF090611),
    appBar:AppBar(backgroundColor:const Color(0xFF110B19),title:const Text('Lymix Akış')),
    body:ListView(padding:const EdgeInsets.all(14),children:[
      Container(padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:const Color(0xFF15101F),borderRadius:BorderRadius.circular(18)),child:Column(children:[
        Row(children:[const CircleAvatar(radius:20,backgroundImage:NetworkImage('https://i.pravatar.cc/100?img=11')),const SizedBox(width:10),Expanded(child:TextField(controller:controller,maxLines:3,minLines:1,decoration:const InputDecoration(hintText='Bir şey paylaş...',border:InputBorder.none)))]),
        Row(children:[TextButton.icon(onPressed:(){},icon:const Icon(Icons.image_outlined),label:const Text('Medya')),TextButton.icon(onPressed:(){},icon:const Icon(Icons.event_outlined),label:const Text('Etkinlik')),const Spacer(),FilledButton(onPressed:_post,child:const Text('Paylaş'))])
      ])),
      const SizedBox(height:14),
      ...posts.map((p)=>Container(margin:const EdgeInsets.only(bottom:12),padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:const Color(0xFF15101F),borderRadius:BorderRadius.circular(18)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Row(children:[const CircleAvatar(radius:18,backgroundImage:NetworkImage('https://i.pravatar.cc/100?img=31')),const SizedBox(width:9),Text(p['user'],style:const TextStyle(fontWeight:FontWeight.bold)),const Spacer(),const Text('şimdi',style:TextStyle(color:Colors.white38,fontSize:10))]),
        const SizedBox(height:10),Text(p['text'],style:const TextStyle(color:Colors.white70)),const SizedBox(height:12),
        Row(children:[IconButton(onPressed:()=>setState(()=>p['likes']=(p['likes'] as int)+1),icon:const Icon(Icons.favorite_border,size:20)),Text('${p['likes']}',style:const TextStyle(fontSize:11,color:Colors.white54)),IconButton(onPressed:(){},icon:const Icon(Icons.chat_bubble_outline,size:19)),Text('${p['comments']}',style:const TextStyle(fontSize:11,color:Colors.white54)),const Spacer(),IconButton(onPressed:(){},icon:const Icon(Icons.share_outlined,size:19))])
      ])))
    ])
  );

  void _post(){final text=controller.text.trim();if(text.isEmpty)return;setState((){posts.insert(0,{'user':'Siz','text':text,'likes':0,'comments':0});controller.clear();});}
}
