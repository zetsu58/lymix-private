import 'package:flutter/material.dart';
import '../theme/lymix_theme.dart';
import 'my_reports_screen.dart';

class PrivacyCenterScreen extends StatefulWidget {
  const PrivacyCenterScreen({super.key});
  @override State<PrivacyCenterScreen> createState()=>_PrivacyCenterScreenState();
}

class _PrivacyCenterScreenState extends State<PrivacyCenterScreen>{
  bool profileVisible=true;
  bool allowDm=true;
  bool showOnline=true;
  bool roomInvites=true;
  bool personalized=true;

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Gizlilik Merkezi')),
    body:ListView(padding:const EdgeInsets.fromLTRB(16,8,16,28),children:[
      _hero(),
      const SizedBox(height:14),
      _group('Profil ve görünürlük',[
        _switch('Profilimi herkese göster','Arama ve önerilerde profilin görünebilir.',profileVisible,(v)=>setState(()=>profileVisible=v)),
        _switch('Çevrimiçi durumumu göster','Takipçilerin aktif olduğunu görebilir.',showOnline,(v)=>setState(()=>showOnline=v)),
      ]),
      const SizedBox(height:12),
      _group('İletişim',[
        _switch('Özel mesajlara izin ver','Takip ettiğin veya izin verdiğin kişiler mesaj gönderebilir.',allowDm,(v)=>setState(()=>allowDm=v)),
        _switch('Oda davetlerine izin ver','Oda yöneticileri sana koltuk/oda daveti gönderebilir.',roomInvites,(v)=>setState(()=>roomInvites=v)),
      ]),
      const SizedBox(height:12),
      _group('Kişiselleştirme',[
        _switch('Kişiselleştirilmiş öneriler','Oda ve içerik önerileri kullanım tercihlerine göre şekillenir.',personalized,(v)=>setState(()=>personalized=v)),
      ]),
      const SizedBox(height:14),
      ListTile(
        onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const MyReportsScreen())),
        tileColor:LymixColors.surface,
        shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(18)),
        leading:const Icon(Icons.flag_outlined,color:LymixColors.gold),
        title:const Text('Şikayetlerim',style:TextStyle(fontWeight:FontWeight.w800)),
        subtitle:const Text('Gönderdiğin şikayetlerin inceleme durumunu takip et.',style:TextStyle(color:Colors.white38,fontSize:9.5)),
        trailing:const Icon(Icons.chevron_right_rounded,color:Colors.white30),
      ),
      const SizedBox(height:9),
      ListTile(
        tileColor:LymixColors.surface,
        shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(18)),
        leading:const Icon(Icons.block_rounded,color:LymixColors.gold),
        title:const Text('Engellenen hesaplar',style:TextStyle(fontWeight:FontWeight.w800)),
        subtitle:const Text('Engellediğin kullanıcıları gözden geçir.',style:TextStyle(color:Colors.white38,fontSize:9.5)),
        trailing:const Icon(Icons.chevron_right_rounded,color:Colors.white30),
      ),
      const SizedBox(height:9),
      ListTile(
        tileColor:LymixColors.surface,
        shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(18)),
        leading:const Icon(Icons.download_for_offline_outlined,color:LymixColors.gold),
        title:const Text('Verilerimi indir',style:TextStyle(fontWeight:FontWeight.w800)),
        subtitle:const Text('Hesabına ait dışa aktarılabilir veriler için talep oluştur.',style:TextStyle(color:Colors.white38,fontSize:9.5)),
        trailing:const Icon(Icons.chevron_right_rounded,color:Colors.white30),
      ),
    ]),
  );

  Widget _hero()=>Container(
    padding:const EdgeInsets.all(16),
    decoration:BoxDecoration(gradient:const LinearGradient(colors:[Color(0xFF1F1428),Color(0xFF100C16)]),borderRadius:BorderRadius.circular(22),border:Border.all(color:const Color(0x33FFD643))),
    child:const Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Icon(Icons.shield_outlined,color:LymixColors.gold,size:26),
      SizedBox(width:11),
      Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('Kontrol sende',style:TextStyle(fontSize:15,fontWeight:FontWeight.w900)),
        SizedBox(height:4),
        Text('Profil görünürlüğünü, iletişim izinlerini ve kişiselleştirme seçeneklerini tek yerden yönet.',style:TextStyle(color:Colors.white50,fontSize:10,height:1.4)),
      ])),
    ]),
  );

  Widget _group(String title,List<Widget> children)=>Container(
    padding:const EdgeInsets.fromLTRB(12,12,12,4),
    decoration:BoxDecoration(color:LymixColors.surface,borderRadius:BorderRadius.circular(20),border:Border.all(color:Colors.white.withOpacity(.05))),
    child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Padding(padding:const EdgeInsets.fromLTRB(5,2,5,4),child:Text(title,style:const TextStyle(color:Colors.white54,fontSize:9.5,fontWeight:FontWeight.w800,letterSpacing:.4))),
      ...children,
    ]),
  );

  Widget _switch(String title,String sub,bool value,ValueChanged<bool> onChanged)=>SwitchListTile.adaptive(
    value:value,onChanged:onChanged,activeColor:LymixColors.gold,
    title:Text(title,style:const TextStyle(fontWeight:FontWeight.w700,fontSize:12)),
    subtitle:Text(sub,style:const TextStyle(color:Colors.white38,fontSize:9.2)),
    contentPadding:const EdgeInsets.symmetric(horizontal:4),
  );
}
