import 'package:flutter/material.dart';
import '../theme/lymix_theme.dart';

class ModerationSafetyScreen extends StatelessWidget {
  const ModerationSafetyScreen({super.key});

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Moderasyon ve Güvenlik')),
    body:ListView(padding:const EdgeInsets.fromLTRB(16,8,16,28),children:[
      _hero(),
      const SizedBox(height:14),
      _card(Icons.chat_bubble_outline_rounded,'Mesaj filtresi','Küfür, ağır hakaret ve bazı uygunsuz ifadeler mesaj gönderilmeden önce kontrol edilir. Engellenen mesaj karşı tarafa ulaşmaz.'),
      _card(Icons.graphic_eq_rounded,'Mikrofon moderasyonu','Oda konuşmaları, etkinleştirilen konuşmadan metne dönüştürme hizmetinden gelen kısa transkript parçalarıyla denetlenir. Düşük güven skorları ceza üretmez.'),
      _card(Icons.warning_amber_rounded,'Kademeli yaptırım','Tekrarlanan ses ihlallerinde önce uyarı, ardından 5 dakikalık mikrofon kapatma ve daha ileri tekrar halinde 30 dakikalık oda uzaklaştırması uygulanabilir.'),
      _card(Icons.flag_outlined,'Şikayet hakkı','Kullanıcı, mesaj veya oda menüsünden şikayet kaydı oluşturabilirsin. Kullanıcı şikayeti tek başına otomatik ceza sebebi değildir; moderasyon kayıtlarıyla birlikte incelenir.'),
      _card(Icons.privacy_tip_outlined,'Gizlilik yaklaşımı','Ham ses kaydını şikayet kanıtı olarak saklamak yerine, mümkün olduğunda kısa transkript kesiti, zaman, oda ve işlem kaydı tutulur.'),
    ]),
  );

  Widget _hero()=>Container(
    padding:const EdgeInsets.all(16),
    decoration:BoxDecoration(gradient:const LinearGradient(colors:[Color(0xFF20142B),Color(0xFF100C16)]),borderRadius:BorderRadius.circular(22),border:Border.all(color:const Color(0x33FFD643))),
    child:const Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Icon(Icons.health_and_safety_outlined,color:LymixColors.gold,size:28),
      SizedBox(width:11),
      Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('Daha güvenli oda deneyimi',style:TextStyle(fontSize:15,fontWeight:FontWeight.w900)),
        SizedBox(height:4),
        Text('Lymix, mesaj ve ses moderasyonunu kullanıcı şikayetleriyle birlikte değerlendirir; hatalı pozitifleri azaltmak için kademeli yaptırım uygular.',style:TextStyle(color:Colors.white50,fontSize:10,height:1.4)),
      ])),
    ]),
  );

  Widget _card(IconData icon,String title,String text)=>Container(
    margin:const EdgeInsets.only(bottom:10),
    padding:const EdgeInsets.all(14),
    decoration:BoxDecoration(color:LymixColors.surface,borderRadius:BorderRadius.circular(18),border:Border.all(color:Colors.white.withOpacity(.05))),
    child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Container(width:40,height:40,decoration:BoxDecoration(color:const Color(0x15FFD643),borderRadius:BorderRadius.circular(12)),child:Icon(icon,color:LymixColors.gold,size:19)),
      const SizedBox(width:10),
      Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text(title,style:const TextStyle(fontSize:11.5,fontWeight:FontWeight.w800)),
        const SizedBox(height:3),
        Text(text,style:const TextStyle(color:Colors.white45,fontSize:9.5,height:1.4)),
      ])),
    ]),
  );
}
