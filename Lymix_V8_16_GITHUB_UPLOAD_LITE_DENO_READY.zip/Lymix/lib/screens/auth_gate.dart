import 'package:flutter/material.dart';
import '../core/api_client.dart';
import '../services/auth_service.dart';
import '../services/session_service.dart';
import '../lymix_pro_showcase.dart';
import 'login_screen.dart';

class AuthGate extends StatefulWidget {
  const AuthGate({super.key});

  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  bool _loading = true;
  bool _authenticated = false;

  @override
  void initState() {
    super.initState();
    _restore();
  }

  Future<void> _restore() async {
    final has = await SessionService.hasSession();
    if (!has) {
      if (mounted) setState(() {
        _loading = false;
        _authenticated = false;
      });
      return;
    }

    // Refresh first so a stale 15-minute access token does not block the app.
    final ok = await AuthService(
      ApiClient(tokenProvider: SessionService.token),
    ).refresh();

    if (!mounted) return;
    setState(() {
      _loading = false;
      _authenticated = ok;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        backgroundColor: Color(0xFF0D0B14),
        body: Center(
          child: CircularProgressIndicator(color: Color(0xFFFFD200)),
        ),
      );
    }

    if (!_authenticated) {
      return LoginScreen(
        onAuthenticated: () => setState(() => _authenticated = true),
      );
    }

    return const LymixProShowcase();
  }
}
