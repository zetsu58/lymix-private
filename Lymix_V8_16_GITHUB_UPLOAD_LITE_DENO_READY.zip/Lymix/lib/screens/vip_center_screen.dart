import 'package:flutter/material.dart';

class VipTier {
  final String code;
  final String title;
  final int entryCoins;
  final int renewCoins;
  final IconData icon;
  final List<String> perks;
  const VipTier(this.code, this.title, this.entryCoins, this.renewCoins, this.icon, this.perks);
}

const vipTiers = <VipTier>[
  VipTier('VIP 1', 'Kıvılcım', 50000, 30000, Icons.auto_awesome, ['VIP rozeti', 'Profil vurgusu']),
  VipTier('VIP 2', 'Parıltı', 100000, 60000, Icons.palette_outlined, ['Özel isim tonu', 'Mini kart teması']),
  VipTier('VIP 3', 'Işık', 250000, 150000, Icons.bolt_rounded, ['Oda giriş izi', 'Profil çerçevesi']),
  VipTier('VIP 4', 'Aura', 500000, 300000, Icons.flare_rounded, ['Gelişmiş giriş efekti', 'Sohbet vurgusu']),
  VipTier('VIP 5', 'Nova', 1000000, 600000, Icons.diamond_outlined, ['Hediye vitrini', 'Hareketli profil detayı']),
  VipTier('VIP 6', 'Orbit', 2000000, 1200000, Icons.public_rounded, ['Öncelikli görünürlük', 'Özel oda kartı']),
  VipTier('VIP 7', 'Zenith', 4000000, 2400000, Icons.workspace_premium_outlined, ['Premium giriş sahnesi', 'Sezon rozeti']),
  VipTier('VIP 8', 'Royal', 7500000, 4500000, Icons.shield_outlined, ['Özel oda teması', 'Gelişmiş avatar halkası']),
  VipTier('VIP 9', 'Legend', 12000000, 7200000, Icons.local_fire_department_outlined, ['Legend profil izi', 'Sınırlı koleksiyon']),
  VipTier('VIP 10', 'Mythic', 20000000, 12000000, Icons.stars_rounded, ['Mythic giriş sahnesi', 'Özel kimlik efekti']),
  VipTier('CROWN', 'Lymix Crown', 35000000, 21000000, Icons.emoji_events_rounded, ['Crown jeneriği', 'En üst profil vitrini']),
];

class VipCenterScreen extends StatefulWidget {
  const VipCenterScreen({super.key});
  @override State<VipCenterScreen> createState() => _VipCenterScreenState();
}

class _VipCenterScreenState extends State<VipCenterScreen> {
  int selected = 2;

  String _n(int value) {
    if (value >= 1000000) return '${(value / 1000000).toStringAsFixed(value % 1000000 == 0 ? 0 : 1)}M';
    if (value >= 1000) return '${(value / 1000).toStringAsFixed(value % 1000 == 0 ? 0 : 1)}K';
    return '$value';
  }

  @override
  Widget build(BuildContext context) {
    const cycleLoad = 188000, renewTarget = 150000, nextTarget = 500000, daysLeft = 19;
    final tier = vipTiers[selected];
    return Scaffold(
      backgroundColor: const Color(0xFF080610),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0E0A17),
        title: const Text('VIP Yolculuğu', style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [TextButton.icon(onPressed: () {}, icon: const Icon(Icons.history_rounded, size: 17, color: Color(0xFFFFD45A)), label: const Text('Geçmiş', style: TextStyle(color: Colors.white70, fontSize: 11)))],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 26),
        children: [
          _statusCard(cycleLoad, renewTarget, nextTarget, daysLeft),
          const SizedBox(height: 18),
          const Text('Seviyeni keşfet', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900)),
          const SizedBox(height: 5),
          const Text('Her kademe yeni görsel kimlik ve sosyal ayrıcalıklar açar. Düzen Lymix için özgün olarak tasarlandı.', style: TextStyle(color: Colors.white54, fontSize: 11, height: 1.35)),
          const SizedBox(height: 12),
          SizedBox(height: 132, child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: vipTiers.length,
            separatorBuilder: (_, __) => const SizedBox(width: 9),
            itemBuilder: (_, i) => _tierSelector(i),
          )),
          const SizedBox(height: 16),
          _benefitPanel(tier),
          const SizedBox(height: 14),
          _ruleCard(),
        ],
      ),
    );
  }

  Widget _statusCard(int load, int renew, int next, int days) => Container(
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(24),
      gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF281231), Color(0xFF151022), Color(0xFF241B0B)]),
      border: Border.all(color: const Color(0x55FFD45A)),
      boxShadow: const [BoxShadow(color: Color(0x33000000), blurRadius: 24, offset: Offset(0, 10))],
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Container(width: 54, height: 54, decoration: const BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [Color(0xFFFFD84A), Color(0xFFB945F5)])), child: const Icon(Icons.bolt_rounded, color: Color(0xFF171019), size: 31)),
        const SizedBox(width: 12),
        const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('VIP 3 • Işık', style: TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w900)),
          SizedBox(height: 3), Text('Mevcut seviyen aktif', style: TextStyle(color: Color(0xFF8FE7B2), fontSize: 10, fontWeight: FontWeight.w700)),
        ])),
        Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7), decoration: BoxDecoration(color: Colors.white.withOpacity(.06), borderRadius: BorderRadius.circular(14)), child: Text('$days gün', style: const TextStyle(color: Color(0xFFFFD45A), fontWeight: FontWeight.w800))),
      ]),
      const SizedBox(height: 17),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text('Bu dönem ${_n(load)}', style: const TextStyle(color: Colors.white70, fontSize: 11)),
        Text('VIP 4 için ${_n(next-load)} kaldı', style: const TextStyle(color: Color(0xFFFFD45A), fontSize: 10)),
      ]),
      const SizedBox(height: 8),
      ClipRRect(borderRadius: BorderRadius.circular(20), child: LinearProgressIndicator(value: (load/next).clamp(0.0,1.0), minHeight: 10, backgroundColor: Colors.white10, valueColor: const AlwaysStoppedAnimation(Color(0xFFFFD45A)))),
      const SizedBox(height: 11),
      Row(children: [const Icon(Icons.verified_rounded, color: Color(0xFF8FE7B2), size: 17), const SizedBox(width: 6), Text('Yenileme hedefi ${_n(renew)} tamamlandı', style: const TextStyle(color: Colors.white60, fontSize: 10))]),
    ]),
  );

  Widget _tierSelector(int i) {
    final tier = vipTiers[i], active = i == selected, current = i == 2;
    return InkWell(
      onTap: () => setState(() => selected = i),
      borderRadius: BorderRadius.circular(20),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        width: 104,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: active ? const Color(0xFF20142C) : Colors.white.withOpacity(.035), borderRadius: BorderRadius.circular(20), border: Border.all(color: active ? const Color(0xFFFFD45A) : Colors.white10, width: active ? 1.4 : 1)),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Container(width: 48, height: 48, decoration: BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: active ? const [Color(0xFFFFD84A), Color(0xFFB843EF)] : const [Color(0xFF302B38), Color(0xFF1A1721)])), child: Icon(tier.icon, color: active ? const Color(0xFF171019) : Colors.white54, size: 25)),
          const SizedBox(height: 8),
          Text(tier.code, style: TextStyle(color: active ? Colors.white : Colors.white60, fontSize: 11, fontWeight: FontWeight.w900)),
          Text(tier.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white38, fontSize: 8)),
          if (current) const Padding(padding: EdgeInsets.only(top: 3), child: Text('AKTİF', style: TextStyle(color: Color(0xFF8FE7B2), fontSize: 7, fontWeight: FontWeight.w900))),
        ]),
      ),
    );
  }

  Widget _benefitPanel(VipTier tier) {
    final benefits = _expandedBenefits(tier);
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(color: const Color(0xFF12101B), borderRadius: BorderRadius.circular(22), border: Border.all(color: Colors.white10)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${tier.code == 'CROWN' ? tier.title : '${tier.code} • ${tier.title}'} avantajları', style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w900)),
            const SizedBox(height: 3), Text('Giriş ${_n(tier.entryCoins)} • Yenileme ${_n(tier.renewCoins)}', style: const TextStyle(color: Color(0xFFFFD45A), fontSize: 10)),
          ])),
          const Icon(Icons.auto_awesome_rounded, color: Color(0xFFFFD45A)),
        ]),
        const SizedBox(height: 13),
        GridView.builder(
          shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: benefits.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, mainAxisSpacing: 9, crossAxisSpacing: 9, childAspectRatio: .92),
          itemBuilder: (_, i) => _benefitTile(benefits[i].$1, benefits[i].$2),
        ),
      ]),
    );
  }

  List<(IconData, String)> _expandedBenefits(VipTier tier) {
    final level = tier.code == 'CROWN' ? 11 : int.tryParse(tier.code.split(' ').last) ?? 1;
    final all = <(IconData, String)>[
      (Icons.badge_outlined, 'Seviye rozeti'), (Icons.account_circle_outlined, 'Avatar halkası'),
      (Icons.palette_outlined, 'İsim stili'), (Icons.login_rounded, 'Giriş efekti'),
      (Icons.credit_card_rounded, 'Mini kart teması'), (Icons.campaign_outlined, 'Oda bildirimi'),
      (Icons.card_giftcard_rounded, 'Hediye vitrini'), (Icons.visibility_outlined, 'Öncelikli görünürlük'),
      (Icons.chat_bubble_outline_rounded, 'Mesaj vurgusu'), (Icons.room_preferences_outlined, 'Oda kimliği'),
      (Icons.collections_outlined, 'Profil vitrini'), (Icons.workspace_premium_outlined, 'Sezon ayrıcalığı'),
    ];
    final count = (4 + (level * .8).floor()).clamp(4, 12);
    return all.take(count).toList();
  }

  Widget _benefitTile(IconData icon, String label) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
    decoration: BoxDecoration(color: Colors.white.withOpacity(.035), borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white.withOpacity(.06))),
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Container(width: 38, height: 38, decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0x18FFD45A)), child: Icon(icon, color: const Color(0xFFFFD982), size: 20)),
      const SizedBox(height: 8), Text(label, textAlign: TextAlign.center, maxLines: 2, style: const TextStyle(color: Colors.white70, fontSize: 9.5, height: 1.2)),
    ]),
  );

  Widget _ruleCard() => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(color: const Color(0xFF0F0D16), borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.white.withOpacity(.06))),
    child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(Icons.info_outline_rounded, color: Colors.white38, size: 19), SizedBox(width: 9),
      Expanded(child: Text('VIP dönemi 30 gündür. Eşik geçildiğinde yükselme anında uygulanır. Yenileme hedefi karşılanmazsa dönem sonunda son 30 günlük yüklemeye göre uygun seviyeye geçilir.', style: TextStyle(color: Colors.white46, fontSize: 10, height: 1.4))),
    ]),
  );
}
