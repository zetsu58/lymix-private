import 'package:flutter/material.dart';
class LymixCommandCenterScreen extends StatelessWidget {
  const LymixCommandCenterScreen({super.key});
  @override Widget build(BuildContext context)=>Scaffold(backgroundColor:const Color(0xFF07050C),appBar:AppBar(title:const Text('LYMIX COMMAND CENTER')),body:ListView(padding:const EdgeInsets.all(16),children:const[
    _Health('API','Healthy'),_Health('Voice / RTC','Healthy'),_Health('Database','Healthy'),_Health('Payments','Healthy'),_Health('Push','Healthy'),_Health('Games Provider','Healthy'),
    SizedBox(height:12),Text('OWNER ONLY • MFA + audit log + allowlist production policy',style:TextStyle(color:Colors.amber,fontSize:11)),
  ]));
}
class _Health extends StatelessWidget{final String a,b;const _Health(this.a,this.b);@override Widget build(BuildContext c)=>Card(child:ListTile(leading:const Icon(Icons.circle,color:Colors.green,size:12),title:Text(a),trailing:Text(b)));}
