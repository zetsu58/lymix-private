import 'package:flutter/material.dart';
import '../services/app_permission_service.dart';

class PermissionCenterScreen extends StatefulWidget {
  final bool firstRun;
  const PermissionCenterScreen({super.key, this.firstRun = false});

  @override
  State<PermissionCenterScreen> createState() => _PermissionCenterScreenState();
}

class _PermissionCenterScreenState extends State<PermissionCenterScreen> {
  bool busy = false;
  String? info;

  Future<void> _run(Future<bool> Function() action, String ok, String no) async {
    setState(() { busy = true; info = null; });
    final granted = await action();
    if (!mounted) return;
    setState(() { busy = false; info = granted ? ok : no; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF090611),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: const Text('İzin ve Gizlilik Merkezi'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF24152E), Color(0xFF111827)]),
              borderRadius: BorderRadius.circular(22),
            ),
            child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Kontrol sende', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
              SizedBox(height: 7),
              Text('Lymix yalnızca ihtiyaç duyduğu anda izin ister. Mikrofon oda girişinde; kamera doğrulamada; fotoğraflar yükleme sırasında kullanılır.', style: TextStyle(color: Colors.white70, height: 1.35)),
            ]),
          ),
          const SizedBox(height: 16),
          _permissionTile(Icons.notifications_active_outlined, 'Bildirimler', 'Mesaj, oda daveti, destek yanıtı ve güvenlik bildirimleri.', () => _run(AppPermissionService.requestNotifications, 'Bildirim izni verildi.', 'Bildirim izni verilmedi.')),
          _permissionTile(Icons.mic_none, 'Mikrofon', 'Sesli odaya katılırken istenir. Bu ekrandan da önceden verebilirsin.', () => _run(AppPermissionService.requestMicrophoneForRoom, 'Mikrofon izni verildi.', 'Mikrofon izni verilmedi.')),
          _permissionTile(Icons.camera_alt_outlined, 'Kamera', 'Yayıncı görüntü teyidi veya profil kamerasını kullandığında istenir.', () => _run(AppPermissionService.requestCameraForVerification, 'Kamera izni verildi.', 'Kamera izni verilmedi.')),
          _permissionTile(Icons.photo_library_outlined, 'Fotoğraf ve medya', 'Profil, oda arka planı veya gönderi yüklerken istenir.', () => _run(AppPermissionService.requestMediaForUpload, 'Medya izni verildi.', 'Medya izni verilmedi.')),
          const SizedBox(height: 12),
          if (info != null) Text(info!, style: const TextStyle(color: Color(0xFFFFD23F), fontWeight: FontWeight.w600)),
          if (busy) const Padding(padding: EdgeInsets.only(top: 14), child: LinearProgressIndicator()),
          const SizedBox(height: 18),
          OutlinedButton.icon(
            onPressed: AppPermissionService.openSettings,
            icon: const Icon(Icons.settings_outlined),
            label: const Text('Telefon ayarlarını aç'),
          ),
          if (widget.firstRun) ...[
            const SizedBox(height: 10),
            FilledButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Devam et'),
            ),
          ],
          const SizedBox(height: 18),
          const Text('Not: Konum, kişiler, arama geçmişi veya SMS gibi uygulamanın temel işlevi için gerekli olmayan izinleri istemiyoruz.', style: TextStyle(color: Colors.white38, fontSize: 12, height: 1.35)),
        ],
      ),
    );
  }

  Widget _permissionTile(IconData icon, String title, String subtitle, VoidCallback onTap) {
    return Card(
      color: const Color(0xFF15101F),
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        leading: CircleAvatar(backgroundColor: const Color(0x22FFD23F), child: Icon(icon, color: const Color(0xFFFFD23F))),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(subtitle, style: const TextStyle(color: Colors.white54, fontSize: 12)),
        trailing: const Icon(Icons.chevron_right),
        onTap: busy ? null : onTap,
      ),
    );
  }
}
