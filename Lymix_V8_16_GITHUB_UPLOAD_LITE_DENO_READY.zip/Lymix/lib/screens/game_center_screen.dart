import 'package:flutter/material.dart';
import '../game_overlay_widget.dart';
import '../services/game_provider_service.dart';

class GameDefinition {
  final String id;
  final String name;
  final String emoji;
  final String category;
  final bool achievementEnabled;
  const GameDefinition(this.id, this.name, this.emoji, this.category, {this.achievementEnabled = true});
}

class GameProviderConfig {
  static const String directBaseUrl = String.fromEnvironment('LYMIX_GAME_BASE_URL', defaultValue: '');
}

class GameCenterScreen extends StatelessWidget {
  final String roomId;
  const GameCenterScreen({super.key, this.roomId = 'global'});

  static const games = <GameDefinition>[
    GameDefinition('neon-cat', 'Neon Cat', '🐱', 'Arcade'),
    GameDefinition('sky-rocket', 'Sky Rocket', '🚀', 'Arcade'),
    GameDefinition('deep-sea', 'Deep Sea', '🦈', 'Arcade'),
    GameDefinition('lucky-reels', 'Lucky Reels', '🎰', 'Casual'),
    GameDefinition('fruit-pop', 'Fruit Pop', '🍒', 'Arcade'),
    GameDefinition('wheel-arena', 'Wheel Arena', '🎡', 'Party'),
    GameDefinition('goal-master', 'Goal Master', '⚽', 'Sports'),
    GameDefinition('tasty-rush', 'Tasty Rush', '🍱', 'Arcade'),
    GameDefinition('chicken-dash', 'Chicken Dash', '🐔', 'Arcade'),
    GameDefinition('beast-duel', 'Beast Duel', '🦁', 'Quick'),
    GameDefinition('triple-cards', 'Triple Cards', '🃏', 'Cards'),
    GameDefinition('western-poker', 'Western Poker', '🤠', 'Cards'),
  ];

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: const Color(0xFF090611),
        appBar: AppBar(
          backgroundColor: const Color(0xFF160B28),
          title: const Text('Oyun Merkezi', style: TextStyle(fontWeight: FontWeight.w800)),
          actions: const [Padding(padding: EdgeInsets.only(right: 16), child: Center(child: Text('🏆 Rozetler', style: TextStyle(color: Colors.amber))) )],
        ),
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(colors: [Color(0xFF2B0C50), Color(0xFF10051F)], begin: Alignment.topCenter, end: Alignment.bottomCenter),
          ),
          child: GridView.builder(
            padding: const EdgeInsets.fromLTRB(18, 22, 18, 28),
            itemCount: games.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4, childAspectRatio: .72, crossAxisSpacing: 12, mainAxisSpacing: 18),
            itemBuilder: (_, i) => _GameTile(game: games[i], roomId: roomId),
          ),
        ),
      );
}

class _GameTile extends StatelessWidget {
  final GameDefinition game;
  final String roomId;
  const _GameTile({required this.game, required this.roomId});

  @override
  Widget build(BuildContext context) => InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => _open(context),
        child: Column(children: [
          Container(
            height: 68,
            width: 68,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              gradient: const LinearGradient(colors: [Color(0xFF594079), Color(0xFF24143E)]),
              boxShadow: const [BoxShadow(color: Color(0x55000000), blurRadius: 8, offset: Offset(0, 4))],
            ),
            child: Text(game.emoji, style: const TextStyle(fontSize: 36)),
          ),
          const SizedBox(height: 8),
          Text(game.name, textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.w600)),
        ]),
      );

  Future<void> _open(BuildContext context) async {
    try {
      final String url;
      if (GameProviderConfig.directBaseUrl.isNotEmpty) {
        final root = GameProviderConfig.directBaseUrl.endsWith('/') ? GameProviderConfig.directBaseUrl.substring(0, GameProviderConfig.directBaseUrl.length - 1) : GameProviderConfig.directBaseUrl;
        url = Uri.parse('$root/${game.id}').replace(queryParameters: {'roomId': roomId, 'userId': '101', 'bridge': 'LymixGameBridge'}).toString();
      } else {
        url = await GameProviderService().getLaunchUrl(gameId: game.id, roomId: roomId, userId: '101');
      }
      if (!context.mounted) return;
      showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        builder: (sheetContext) => LymixLiveGameOverlay(gameUrl: url, onClose: () => Navigator.pop(sheetContext)),
      );
    } catch (e) {
      if (!context.mounted) return;
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          backgroundColor: const Color(0xFF1A1027),
          title: Text('${game.emoji} ${game.name}'),
          content: const Text('Oyun merkezi ve WebView köprüsü hazır. Gerçek oyunu açmak için lisanslı sağlayıcının launch API/secret bilgilerini backend .env dosyasına eklemek gerekiyor.'),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Tamam'))],
        ),
      );
    }
  }
}
