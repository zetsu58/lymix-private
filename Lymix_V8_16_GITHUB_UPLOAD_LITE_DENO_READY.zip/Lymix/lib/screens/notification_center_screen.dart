import 'package:flutter/material.dart';
import '../theme/lymix_theme.dart';
import '../widgets/lymix_states.dart';

enum NoticeFilter { all, social, rooms, rewards, system }

class NotificationCenterScreen extends StatefulWidget {
  const NotificationCenterScreen({super.key});
  @override State<NotificationCenterScreen> createState()=>_NotificationCenterScreenState();
}

class _NotificationCenterScreenState extends State<NotificationCenterScreen>{
  NoticeFilter filter=NoticeFilter.all;
  final notices=<Map<String,dynamic>>[
    {'type':NoticeFilter.social,'icon':Icons.favorite_rounded,'title':'Selin seni takip etti','body':'Profilini görüntüledi ve seni takip etmeye başladı.','time':'2 dk önce','read':false},
    {'type':NoticeFilter.rewards,'icon':Icons.card_giftcard_rounded,'title':'Yeni hediye aldın','body':'Mert odada sana bir hediye gönderdi.','time':'18 dk önce','read':false},
    {'type':NoticeFilter.rooms,'icon':Icons.mic_rounded,'title':'Gece Muhabbeti yeniden başladı','body':'Takip ettiğin oda tekrar yayında.','time':'1 saat önce','read':true},
    {'type':NoticeFilter.rewards,'icon':Icons.emoji_events_rounded,'title':'Haftalık sıralamada ilk 10','body':'Oda katkı sıralamasında yükseldin.','time':'3 saat önce','read':true},
    {'type':NoticeFilter.system,'icon':Icons.shield_rounded,'title':'Güvenlik kontrolü tamamlandı','body':'Hesabında yeni bir güvenlik sorunu tespit edilmedi.','time':'Dün','read':true},
  ];

  @override Widget build(BuildContext context){
    final visible=filter==NoticeFilter.all?notices:notices.where((n)=>n['type']==filter).toList();
    final unread=notices.where((n)=>n['read']!=true).length;
    return Scaffold(
      appBar:AppBar(
        title:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          const Text('Bildirim Merkezi'),
          Text(unread==0?'Tüm bildirimler okundu':'$unread okunmamış bildirim',style:const TextStyle(color:Colors.white38,fontSize:9,fontWeight:FontWeight.w500)),
        ]),
        actions:[TextButton(onPressed:(){setState(()=>notices.forEach((n)=>n['read']=true));},child:const Text('Tümünü oku'))],
      ),
      body:ListView(
        padding:const EdgeInsets.fromLTRB(16,8,16,28),
        children:[
          SizedBox(height:42,child:ListView(scrollDirection:Axis.horizontal,children:[
            _chip(NoticeFilter.all,'Tümü'),_chip(NoticeFilter.social,'Sosyal'),_chip(NoticeFilter.rooms,'Odalar'),_chip(NoticeFilter.rewards,'Ödüller'),_chip(NoticeFilter.system,'Sistem'),
          ])),
          const SizedBox(height:14),
          if(visible.isEmpty) const LymixStateCard(icon:Icons.notifications_off_outlined,title:'Burada bir şey yok',message:'Bu kategoride yeni bildirimin olduğunda burada görünecek.')
          else ...visible.map(_notice),
        ],
      ),
    );
  }

  Widget _chip(NoticeFilter v,String label)=>Padding(
    padding:const EdgeInsets.only(right:8),
    child:ChoiceChip(
      label:Text(label),
      selected:filter==v,
      onSelected:(_)=>setState(()=>filter=v),
      selectedColor:LymixColors.gold.withOpacity(.16),
      side:BorderSide(color:filter==v?const Color(0x66FFD643):Colors.white10),
    ),
  );

  Widget _notice(Map<String,dynamic> n)=>Dismissible(
    key:ValueKey('${n['title']}-${n['time']}'),
    direction:DismissDirection.endToStart,
    background:Container(
      margin:const EdgeInsets.only(bottom:9),
      padding:const EdgeInsets.only(right:18),
      alignment:Alignment.centerRight,
      decoration:BoxDecoration(color:const Color(0xFF3A1520),borderRadius:BorderRadius.circular(18)),
      child:const Icon(Icons.delete_outline_rounded,color:Color(0xFFFFA8B6)),
    ),
    onDismissed:(_)=>setState(()=>notices.remove(n)),
    child:InkWell(
      onTap:()=>setState(()=>n['read']=true),
      borderRadius:BorderRadius.circular(18),
      child:Container(
        margin:const EdgeInsets.only(bottom:9),
        padding:const EdgeInsets.all(12),
        decoration:BoxDecoration(
          color:n['read']==true?Colors.white.withOpacity(.025):const Color(0xFF18111F),
          borderRadius:BorderRadius.circular(18),
          border:Border.all(color:n['read']==true?Colors.white.withOpacity(.04):const Color(0x33FFD643)),
        ),
        child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Container(width:42,height:42,decoration:BoxDecoration(color:const Color(0x14FFD643),borderRadius:BorderRadius.circular(13)),child:Icon(n['icon'] as IconData,color:LymixColors.gold,size:20)),
          const SizedBox(width:10),
          Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Row(children:[
              Expanded(child:Text(n['title'].toString(),style:const TextStyle(fontSize:11.5,fontWeight:FontWeight.w800))),
              if(n['read']!=true) Container(width:7,height:7,decoration:const BoxDecoration(color:LymixColors.gold,shape:BoxShape.circle)),
            ]),
            const SizedBox(height:3),
            Text(n['body'].toString(),style:const TextStyle(color:Colors.white46,fontSize:9.5,height:1.35)),
            const SizedBox(height:5),
            Text(n['time'].toString(),style:const TextStyle(color:Colors.white30,fontSize:8.5)),
          ])),
        ]),
      ),
    ),
  );
}
