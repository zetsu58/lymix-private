import 'package:flutter/material.dart';
import '../theme/lymix_theme.dart';

class NotificationPreferencesScreen extends StatefulWidget {
  const NotificationPreferencesScreen({super.key});
  @override State<NotificationPreferencesScreen> createState()=>_NotificationPreferencesScreenState();
}

class _NotificationPreferencesScreenState extends State<NotificationPreferencesScreen>{
  bool dm=true, rooms=true, gifts=true, vip=true, agency=true, system=true, quiet=false;
  TimeOfDay start=const TimeOfDay(hour:23,minute:0), end=const TimeOfDay(hour:8,minute:0);

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Bildirim Tercihleri')),
    body:ListView(padding:const EdgeInsets.fromLTRB(16,10,16,28),children:[
      _group('Bildirim türleri',[
        _sw('Özel mesajlar','Mesaj ve mesaj isteği bildirimleri',dm,(v)=>setState(()=>dm=v)),
        _sw('Takip edilen odalar','Takip ettiğin oda yayına başladığında',rooms,(v)=>setState(()=>rooms=v)),
        _sw('Hediyeler','Hediye, coin ve katkı hareketleri',gifts,(v)=>setState(()=>gifts=v)),
        _sw('VIP','VIP yükselme, yenileme ve avantajlar',vip,(v)=>setState(()=>vip=v)),
        _sw('Ajans / aile','Ajans davetleri ve yönetim bildirimleri',agency,(v)=>setState(()=>agency=v)),
        _sw('Sistem ve güvenlik','Oturum, şikayet ve güvenlik uyarıları',system,(v)=>setState(()=>system=v)),
      ]),
      const SizedBox(height:12),
      _group('Sessiz saatler',[
        _sw('Sessiz saatleri kullan','Bu aralıkta acil olmayan bildirimler sessiz gelir.',quiet,(v)=>setState(()=>quiet=v)),
        if(quiet) ListTile(
          contentPadding:const EdgeInsets.symmetric(horizontal:4),
          leading:const Icon(Icons.bedtime_outlined,color:LymixColors.gold),
          title:const Text('Saat aralığı',style:TextStyle(fontSize:11.5,fontWeight:FontWeight.w800)),
          subtitle:Text('${start.format(context)} – ${end.format(context)}',style:const TextStyle(color:Colors.white38,fontSize:9.2)),
          trailing:const Icon(Icons.chevron_right_rounded,color:Colors.white30),
          onTap:()async{
            final s=await showTimePicker(context:context,initialTime:start);
            if(!mounted||s==null)return;
            final e=await showTimePicker(context:context,initialTime:end);
            if(!mounted||e==null)return;
            setState((){start=s;end=e;});
          },
        ),
      ]),
      const SizedBox(height:12),
      const Text('Güvenlik, hesap doğrulama ve kritik moderasyon bildirimleri bazı durumlarda sessiz saatlerden bağımsız gösterilebilir.',style:TextStyle(color:Colors.white34,fontSize:9.2,height:1.4)),
    ]),
  );

  Widget _group(String title,List<Widget> children)=>Container(
    padding:const EdgeInsets.fromLTRB(12,12,12,4),
    decoration:BoxDecoration(color:LymixColors.surface,borderRadius:BorderRadius.circular(20),border:Border.all(color:Colors.white.withOpacity(.05))),
    child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Padding(padding:const EdgeInsets.fromLTRB(5,2,5,4),child:Text(title,style:const TextStyle(color:Colors.white54,fontSize:9.5,fontWeight:FontWeight.w800,letterSpacing:.4))),
      ...children,
    ]),
  );
  Widget _sw(String t,String s,bool v,ValueChanged<bool> c)=>SwitchListTile.adaptive(value:v,onChanged:c,activeColor:LymixColors.gold,title:Text(t,style:const TextStyle(fontSize:11.5,fontWeight:FontWeight.w800)),subtitle:Text(s,style:const TextStyle(color:Colors.white38,fontSize:9.2)),contentPadding:const EdgeInsets.symmetric(horizontal:4));
}
