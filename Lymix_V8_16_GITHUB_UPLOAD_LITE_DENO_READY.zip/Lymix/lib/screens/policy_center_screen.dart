import 'package:flutter/material.dart';
class PolicyCenterScreen extends StatelessWidget { const PolicyCenterScreen({super.key});
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Lymix Politika Merkezi')),body:ListView(padding:const EdgeInsets.all(16),children:const[
  _P('Ajans Transfer Politikası','Bir yayıncı ajansa katıldıktan sonra ilk 90 gün başka ajansa transfer olamaz. Süre ve istisnalar baş admin tarafından uzaktan yapılandırılabilir.'),
  _P('Yayıncı Kota Politikası','Yayıncılar aylık minimum yayın süresi, aktif gün ve hediye/coin hedeflerini panelden madde madde görür. Kota karşılanmadığında uyarı ve ajans incelemesi oluşur.'),
  _P('Ajans Sorumluluğu','Ajans sahibi yayıncı doğrulama, kota takibi, oda düzeni ve ihlal bildirimlerinden sorumludur.'),
  _P('Ceza & İtiraz','Uyarı → geçici kısıtlama → oda/yayın kısıtlaması → hesap incelemesi şeklinde kademeli politika uygulanır; kullanıcı itiraz kaydı açabilir.'),
  _P('Gizlilik & Cihaz Güvenliği','Telefon, cihaz ve güvenlik sinyalleri yalnızca sahte hesap/ihlâl önleme amacıyla sınırlı erişimli admin sisteminde tutulur.'),
 ]));}
class _P extends StatelessWidget{final String a,b;const _P(this.a,this.b);@override Widget build(BuildContext c)=>Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(a,style:const TextStyle(fontWeight:FontWeight.bold)),const SizedBox(height:6),Text(b,style:const TextStyle(color:Colors.white60,height:1.35))])));}
