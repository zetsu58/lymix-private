import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class LinkSafetyService {
  static bool isHttpUrl(String value) {
    final uri = Uri.tryParse(value.trim());
    return uri != null && (uri.scheme == 'https' || uri.scheme == 'http') && uri.host.isNotEmpty;
  }

  static bool looksSuspicious(Uri uri) {
    final host = uri.host.toLowerCase();
    if (uri.scheme != 'https') return true;
    if (host.contains('xn--')) return true;
    if (host.split('.').length < 2) return true;
    if (uri.userInfo.isNotEmpty) return true;
    return false;
  }

  static Future<void> openWithWarning(BuildContext context, String value) async {
    final uri = Uri.tryParse(value.trim());
    if (uri == null || !isHttpUrl(value)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Geçerli bir bağlantı değil.')));
      return;
    }
    final suspicious = looksSuspicious(uri);
    final allow = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(suspicious ? 'Bağlantıya dikkat' : 'Harici bağlantı'),
        content: Text(
          suspicious
            ? 'Bu bağlantı güvenli görünmeyebilir:\n\n${uri.host}\n\nDevam etmeden önce adresi kontrol et.'
            : 'Lymix dışındaki bir siteye gideceksin:\n\n${uri.host}',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Devam Et')),
        ],
      ),
    ) ?? false;
    if (!allow) return;
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }
}
