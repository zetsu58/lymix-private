import '../core/api_client.dart';
import 'session_service.dart';

class TextModerationResult {
  final bool allowed;
  final int strikes;
  final String? message;
  const TextModerationResult({required this.allowed, this.strikes = 0, this.message});
}

class ModerationService {
  ApiClient get _api => ApiClient(tokenProvider: SessionService.token);

  // Fast device-side guard for UX. Server remains authoritative.
  static final _localRoots = <String>[
    'amk','aq','orospu','siktir','sikik','siker','sikeyim','piç','pic','pezevenk',
    'ibne','kaltak','kahpe','yavşak','yavsak','gerizekalı','gerizekali','salak','aptal',
    'fuck','fucking','motherfucker','bitch','asshole','dickhead','shithead',
    'arschloch','hurensohn','fotze','wichser',
    'blyat','suka','нахуй','блять','сука','пизд',
    'sikdir','gicdillaq','qehbe','qəhbə',
  ];

  static String _normalize(String input) => input
      .toLowerCase()
      .replaceAll(RegExp(r'[4@]'), 'a')
      .replaceAll(RegExp(r'[1!|]'), 'i')
      .replaceAll('0', 'o')
      .replaceAll('3', 'e')
      .replaceAll(RegExp(r'[5$]'), 's')
      .replaceAll(RegExp(r'[^\p{L}\p{N}\s]', unicode: true), ' ')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();

  static bool localContainsBlockedLanguage(String input) {
    final n = _normalize(input);
    final compact = n.replaceAll(' ', '');
    return _localRoots.any((root) => n.contains(root) || compact.contains(root));
  }

  Future<TextModerationResult> checkText(String text) async {
    if (localContainsBlockedLanguage(text)) {
      return const TextModerationResult(
        allowed: false,
        message: 'Mesaj gönderilemedi. Uygunsuz veya küfürlü ifade algılandı.',
      );
    }
    try {
      final data = await _api.postJson('/api/moderation/text/check', {'text': text});
      final map = Map<String, dynamic>.from(data as Map);
      return TextModerationResult(
        allowed: map['allowed'] == true,
        strikes: (map['strikes'] as num?)?.toInt() ?? 0,
        message: map['allowed'] == true ? null : 'Mesaj gönderilemedi. Uygunsuz veya küfürlü ifade algılandı.',
      );
    } catch (_) {
      // Do not block clean-looking messages solely because moderation API is temporarily unavailable.
      // Server/socket filter still remains authoritative when actually sent.
      return const TextModerationResult(allowed: true);
    }
  }

  Future<void> report({
    String? targetUserId,
    String? roomId,
    required String category,
    required String description,
    List<Map<String, dynamic>> evidence = const [],
  }) async {
    await _api.postJson('/api/moderation/reports', {
      'targetUserId': targetUserId,
      'roomId': roomId,
      'category': category,
      'description': description,
      'evidence': evidence,
    });
  }
}
