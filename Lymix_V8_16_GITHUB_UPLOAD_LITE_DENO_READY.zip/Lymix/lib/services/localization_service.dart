import 'package:flutter/material.dart';

class LymixLocaleController extends ChangeNotifier {
  Locale _locale = const Locale('tr');
  Locale get locale => _locale;
  static const supported = <Locale>[
    Locale('tr'), Locale('en'), Locale('de'), Locale('it'), Locale('ru'), Locale('hi'), Locale('az')
  ];
  void setLocale(Locale value) { if (supported.contains(value)) { _locale=value; notifyListeners(); } }
}

const lymixLanguageNames = <String,String>{
  'tr':'Türkçe','en':'English','de':'Deutsch','it':'Italiano','ru':'Русский','hi':'हिन्दी','az':'Azərbaycan türkcəsi'
};

class LymixStrings {
  static const Map<String, Map<String,String>> _v = {
    'tr': {'app':'Lymix','language':'Dil','ownerOps':'Baş Yönetici Müdahale Paneli','support':'Canlı Destek','policy':'Politikalar','lucky':'Şanslı Hediye'},
    'en': {'app':'Lymix','language':'Language','ownerOps':'Owner Operations','support':'Live Support','policy':'Policies','lucky':'Lucky Gift'},
    'de': {'app':'Lymix','language':'Sprache','ownerOps':'Hauptadmin-Kontrolle','support':'Live-Support','policy':'Richtlinien','lucky':'Glücksgeschenk'},
    'it': {'app':'Lymix','language':'Lingua','ownerOps':'Pannello Admin Principale','support':'Supporto Live','policy':'Politiche','lucky':'Regalo Fortuna'},
    'ru': {'app':'Lymix','language':'Язык','ownerOps':'Панель главного администратора','support':'Поддержка','policy':'Правила','lucky':'Счастливый подарок'},
    'hi': {'app':'Lymix','language':'भाषा','ownerOps':'मुख्य एडमिन पैनल','support':'लाइव सहायता','policy':'नीतियाँ','lucky':'लकी उपहार'},
    'az': {'app':'Lymix','language':'Dil','ownerOps':'Baş Admin Müdaxilə Paneli','support':'Canlı Dəstək','policy':'Qaydalar','lucky':'Şanslı Hədiyyə'},
  };
  static String t(Locale l, String key) => _v[l.languageCode]?[key] ?? _v['tr']![key] ?? key;
}
