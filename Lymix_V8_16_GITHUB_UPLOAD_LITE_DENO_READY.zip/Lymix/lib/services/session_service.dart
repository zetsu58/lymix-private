import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class SessionUser {
  final String id;
  final String login;
  final String displayName;
  final String role;
  final int level;
  final List<String> badges;

  const SessionUser({
    required this.id,
    required this.login,
    required this.displayName,
    required this.role,
    required this.level,
    required this.badges,
  });

  factory SessionUser.fromJson(Map<String, dynamic> json) => SessionUser(
    id: '${json['id'] ?? ''}',
    login: '${json['login'] ?? ''}',
    displayName: '${json['displayName'] ?? json['name'] ?? ''}',
    role: '${json['role'] ?? 'user'}',
    level: (json['level'] as num?)?.toInt() ?? 1,
    badges: (json['badges'] as List? ?? const []).map((e) => '$e').toList(),
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'login': login,
    'displayName': displayName,
    'role': role,
    'level': level,
    'badges': badges,
  };
}

class SessionService {
  static const _storage = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  static const _tokenKey = 'lymix.auth.accessToken';
  static const _refreshKey = 'lymix.auth.refreshToken';
  static const _userKey = 'lymix.auth.user';

  static Future<void> save({
    required String accessToken,
    required String refreshToken,
    required SessionUser user,
  }) async {
    await Future.wait([
      _storage.write(key: _tokenKey, value: accessToken),
      _storage.write(key: _refreshKey, value: refreshToken),
      _storage.write(key: _userKey, value: jsonEncode(user.toJson())),
    ]);
  }

  static Future<void> updateAccessToken(String accessToken) =>
      _storage.write(key: _tokenKey, value: accessToken);

  static Future<String?> token() => _storage.read(key: _tokenKey);
  static Future<String?> refreshToken() => _storage.read(key: _refreshKey);

  static Future<SessionUser?> user() async {
    final raw = await _storage.read(key: _userKey);
    if (raw == null || raw.isEmpty) return null;
    try {
      return SessionUser.fromJson(
        Map<String, dynamic>.from(jsonDecode(raw) as Map),
      );
    } catch (_) {
      return null;
    }
  }

  static Future<bool> hasSession() async {
    final access = await token();
    final refresh = await refreshToken();
    return (access?.isNotEmpty ?? false) || (refresh?.isNotEmpty ?? false);
  }

  static Future<void> clear() async {
    await Future.wait([
      _storage.delete(key: _tokenKey),
      _storage.delete(key: _refreshKey),
      _storage.delete(key: _userKey),
    ]);
  }
}
