import '../core/api_client.dart';

class RemoteConfigService {
  RemoteConfigService._();
  static final instance = RemoteConfigService._();

  Map<String, dynamic> _data = const {};
  Map<String, dynamic> get data => _data;

  Future<void> refresh() async {
    try {
      final raw = await const ApiClient().getJson('/api/config/public');
      _data = Map<String, dynamic>.from(raw as Map);
    } catch (_) {
      _data = const {
        'features': {
          'roomContribution': true,
          'customIdentity': true,
          'moderationAppeal': true,
          'messageReactions': true,
          'messageReply': true,
          'typingIndicator': true,
        },
        'ux': {
          'enableSkeletons': true,
          'enableHaptics': true,
          'reduceMotionDefault': false,
          'dataSaverDefault': false,
        }
      };
    }
  }

  bool feature(String name, {bool fallback = false}) {
    final f = _data['features'];
    return f is Map ? (f[name] == true) : fallback;
  }

  T value<T>(List<String> path, T fallback) {
    dynamic current = _data;
    for (final key in path) {
      if (current is! Map || !current.containsKey(key)) return fallback;
      current = current[key];
    }
    return current is T ? current : fallback;
  }
}
