import 'package:shared_preferences/shared_preferences.dart';

class AudioExperienceSettings {
  final bool noiseSuppression;
  final bool echoCancellation;
  final bool autoGain;
  final bool lowDataMode;
  final String preferredRoute;

  const AudioExperienceSettings({
    this.noiseSuppression = true,
    this.echoCancellation = true,
    this.autoGain = true,
    this.lowDataMode = false,
    this.preferredRoute = 'auto',
  });
}

class AudioExperienceService {
  static const _prefix = 'lymix.audio.';

  static Future<AudioExperienceSettings> load() async {
    final p = await SharedPreferences.getInstance();
    return AudioExperienceSettings(
      noiseSuppression: p.getBool('${_prefix}noiseSuppression') ?? true,
      echoCancellation: p.getBool('${_prefix}echoCancellation') ?? true,
      autoGain: p.getBool('${_prefix}autoGain') ?? true,
      lowDataMode: p.getBool('${_prefix}lowDataMode') ?? false,
      preferredRoute: p.getString('${_prefix}preferredRoute') ?? 'auto',
    );
  }

  static Future<void> save(AudioExperienceSettings s) async {
    final p = await SharedPreferences.getInstance();
    await p.setBool('${_prefix}noiseSuppression', s.noiseSuppression);
    await p.setBool('${_prefix}echoCancellation', s.echoCancellation);
    await p.setBool('${_prefix}autoGain', s.autoGain);
    await p.setBool('${_prefix}lowDataMode', s.lowDataMode);
    await p.setString('${_prefix}preferredRoute', s.preferredRoute);
  }
}
