import 'package:shared_preferences/shared_preferences.dart';

class ComfortPreferences {
  final bool calmMode;
  final bool reduceGlow;
  final bool compactCards;
  final bool autoHideBars;
  final bool oneHandedActions;
  const ComfortPreferences({
    this.calmMode=false,
    this.reduceGlow=false,
    this.compactCards=false,
    this.autoHideBars=true,
    this.oneHandedActions=true,
  });
}

class ComfortPreferencesService {
  static Future<ComfortPreferences> load() async{
    final p=await SharedPreferences.getInstance();
    return ComfortPreferences(
      calmMode:p.getBool('lymix.comfort.calmMode')??false,
      reduceGlow:p.getBool('lymix.comfort.reduceGlow')??false,
      compactCards:p.getBool('lymix.comfort.compactCards')??false,
      autoHideBars:p.getBool('lymix.comfort.autoHideBars')??true,
      oneHandedActions:p.getBool('lymix.comfort.oneHandedActions')??true,
    );
  }

  static Future<void> save(ComfortPreferences s) async{
    final p=await SharedPreferences.getInstance();
    await p.setBool('lymix.comfort.calmMode',s.calmMode);
    await p.setBool('lymix.comfort.reduceGlow',s.reduceGlow);
    await p.setBool('lymix.comfort.compactCards',s.compactCards);
    await p.setBool('lymix.comfort.autoHideBars',s.autoHideBars);
    await p.setBool('lymix.comfort.oneHandedActions',s.oneHandedActions);
  }
}
