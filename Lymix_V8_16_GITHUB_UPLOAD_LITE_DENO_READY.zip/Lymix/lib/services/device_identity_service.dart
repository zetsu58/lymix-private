import 'dart:math';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class DeviceIdentityService {
  static const _storage = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );
  static const _key = 'lymix.device.installationId';

  static Future<String> getOrCreate() async {
    final current = await _storage.read(key: _key);
    if (current != null && current.isNotEmpty) return current;

    final r = Random.secure();
    final bytes = List<int>.generate(24, (_) => r.nextInt(256));
    final id = bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
    await _storage.write(key: _key, value: id);
    return id;
  }
}
