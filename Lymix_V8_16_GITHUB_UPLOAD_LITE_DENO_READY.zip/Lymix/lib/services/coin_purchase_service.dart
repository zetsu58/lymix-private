import 'dart:async';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:in_app_purchase/in_app_purchase.dart';

class CoinPack {
  final String sku;
  final int coins;
  final String label;
  const CoinPack(this.sku, this.coins, this.label);
}

/// Store-safe coin catalogue. Prices are NEVER trusted from the app;
/// Google Play / App Store remain the price source of truth.
const coinPacks = <CoinPack>[
  CoinPack('lymix_coins_1700', 1700, 'Mini'),
  CoinPack('lymix_coins_5800', 5800, 'Başlangıç'),
  CoinPack('lymix_coins_23500', 23500, 'Sosyal'),
  CoinPack('lymix_coins_64000', 64000, 'Plus'),
  CoinPack('lymix_coins_131000', 131000, 'Pro'),
  CoinPack('lymix_coins_340000', 340000, 'Elite'),
  CoinPack('lymix_coins_690000', 690000, 'Crown'),
];

class CoinPurchaseService {
  CoinPurchaseService._();
  static final instance = CoinPurchaseService._();
  final InAppPurchase _iap = InAppPurchase.instance;
  StreamSubscription<List<PurchaseDetails>>? _sub;

  final _purchaseEvents = StreamController<PurchaseDetails>.broadcast();
  Stream<PurchaseDetails> get purchaseEvents => _purchaseEvents.stream;

  Future<bool> init() async {
    if (!(Platform.isAndroid || Platform.isIOS)) return false;
    final available = await _iap.isAvailable();
    if (!available) return false;
    _sub ??= _iap.purchaseStream.listen((items) async {
      for (final p in items) {
        _purchaseEvents.add(p);
        // IMPORTANT: coin crediting must happen only after backend verification.
        if (p.pendingCompletePurchase) await _iap.completePurchase(p);
      }
    });
    return true;
  }

  Future<List<ProductDetails>> loadProducts() async {
    final ids = coinPacks.map((e) => e.sku).toSet();
    final response = await _iap.queryProductDetails(ids);
    if (response.error != null) {
      debugPrint('IAP product error: ${response.error}');
    }
    final list = [...response.productDetails];
    list.sort((a, b) => coinPacks.indexWhere((x) => x.sku == a.id)
        .compareTo(coinPacks.indexWhere((x) => x.sku == b.id)));
    return list;
  }

  Future<void> buy(ProductDetails product) async {
    final param = PurchaseParam(productDetails: product);
    await _iap.buyConsumable(purchaseParam: param, autoConsume: Platform.isAndroid);
  }

  CoinPack? packFor(String sku) {
    for (final p in coinPacks) {
      if (p.sku == sku) return p;
    }
    return null;
  }

  void dispose() {
    _sub?.cancel();
    _purchaseEvents.close();
  }
}
