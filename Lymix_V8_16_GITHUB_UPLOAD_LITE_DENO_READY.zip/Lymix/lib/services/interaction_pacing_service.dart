class InteractionPacingService {
  final List<DateTime> _actions=[];
  bool registerAction(){
    final now=DateTime.now();
    _actions.removeWhere((x)=>now.difference(x)>const Duration(seconds:20));
    _actions.add(now);
    return _actions.length>18;
  }
}
