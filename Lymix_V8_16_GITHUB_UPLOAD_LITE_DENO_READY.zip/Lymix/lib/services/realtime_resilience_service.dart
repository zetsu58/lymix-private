import 'dart:async';

enum RealtimeState { disconnected, connecting, connected, reconnecting }

class RealtimeResilienceService {
  RealtimeState state = RealtimeState.disconnected;
  int attempt = 0;
  Timer? _timer;
  String? lastRoomId;
  String? lastSeatId;
  DateTime? disconnectedAt;

  Duration backoffForAttempt(int value) {
    final seconds = [1, 2, 4, 7, 10, 15][value.clamp(0, 5)];
    return Duration(seconds: seconds);
  }

  void rememberRoom({required String roomId, String? seatId}) {
    lastRoomId = roomId;
    lastSeatId = seatId;
  }

  void onDisconnected() {
    disconnectedAt = DateTime.now();
    state = RealtimeState.reconnecting;
  }

  bool get mayRestoreSeat {
    final at = disconnectedAt;
    if (at == null) return false;
    return DateTime.now().difference(at) <= const Duration(seconds: 25);
  }

  void scheduleReconnect(Future<bool> Function() reconnect, {void Function()? onGiveUp}) {
    _timer?.cancel();
    final delay = backoffForAttempt(attempt);
    _timer = Timer(delay, () async {
      final ok = await reconnect();
      if (ok) {
        attempt = 0;
        state = RealtimeState.connected;
        disconnectedAt = null;
      } else {
        attempt++;
        if (attempt >= 8) {
          state = RealtimeState.disconnected;
          onGiveUp?.call();
        } else {
          scheduleReconnect(reconnect, onGiveUp: onGiveUp);
        }
      }
    });
  }

  void dispose() => _timer?.cancel();
}
