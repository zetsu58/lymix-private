import 'dart:convert';
import 'package:http/http.dart' as http;

class GameProviderService {
  static const String apiBaseUrl = String.fromEnvironment('LYMIX_API_BASE_URL', defaultValue: 'http://10.0.2.2:3000');

  Future<String> getLaunchUrl({required String gameId, required String roomId, required String userId}) async {
    final uri = Uri.parse('$apiBaseUrl/api/games/$gameId/launch').replace(queryParameters: {'roomId': roomId, 'userId': userId});
    final response = await http.get(uri).timeout(const Duration(seconds: 8));
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    if (response.statusCode != 200 || data['launchUrl'] == null) {
      throw Exception(data['error'] ?? 'Oyun sağlayıcısı başlatılamadı');
    }
    return data['launchUrl'] as String;
  }
}
