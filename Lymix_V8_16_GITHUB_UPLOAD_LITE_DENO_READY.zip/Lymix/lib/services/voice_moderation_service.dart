import '../core/api_client.dart';
import 'session_service.dart';

class VoiceModerationService {
  ApiClient get _api => ApiClient(tokenProvider: SessionService.token);

  /// Use this only when the speech provider produces a FINAL transcript.
  /// Raw microphone audio should stay in the RTC/ASR pipeline; the Lymix API receives short text segments.
  Future<Map<String, dynamic>> submitFinalTranscript({
    required String roomId,
    required String transcript,
    double confidence = 1,
  }) async {
    final data = await _api.postJson('/api/moderation/voice/transcript', {
      'roomId': roomId,
      'transcript': transcript,
      'confidence': confidence,
      'isFinal': true,
    });
    return Map<String, dynamic>.from(data as Map);
  }
}
