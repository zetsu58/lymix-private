import '../core/api_client.dart';
import 'session_service.dart';

class AuthService {
  final ApiClient api;
  const AuthService(this.api);

  Future<SessionUser> login({
    required String login,
    required String password,
    required String deviceId,
    String platform = 'android',
    String appVersion = '8.16.0',
  }) async {
    final data = await api.postJson('/api/auth/login', {
      'login': login.trim(),
      'password': password,
      'deviceId': deviceId,
      'deviceName': 'LYMIX Android',
      'platform': platform,
      'appVersion': appVersion,
    });

    final map = Map<String, dynamic>.from(data as Map);
    final user = SessionUser.fromJson(
      Map<String, dynamic>.from(map['user'] as Map),
    );

    await SessionService.save(
      accessToken: '${map['accessToken']}',
      refreshToken: '${map['refreshToken']}',
      user: user,
    );
    return user;
  }

  Future<bool> refresh() async {
    final refreshToken = await SessionService.refreshToken();
    if (refreshToken == null || refreshToken.isEmpty) return false;

    try {
      final data = await api.postJson('/api/auth/refresh', {
        'refreshToken': refreshToken,
      });
      final map = Map<String, dynamic>.from(data as Map);
      final token = '${map['accessToken']}';
      if (token.isEmpty) return false;
      await SessionService.updateAccessToken(token);
      return true;
    } catch (_) {
      await SessionService.clear();
      return false;
    }
  }

  Future<void> logout() async {
    final refreshToken = await SessionService.refreshToken();
    try {
      if (refreshToken != null && refreshToken.isNotEmpty) {
        await api.postJson('/api/auth/logout', {'refreshToken': refreshToken});
      }
    } catch (_) {
      // Local logout must still work if the server is unreachable.
    } finally {
      await SessionService.clear();
    }
  }
}
