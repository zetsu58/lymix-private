import 'dart:io';
import 'package:permission_handler/permission_handler.dart';

/// Merkezi izin yöneticisi. Mağaza politikalarına uygun olarak izinleri
/// mümkün olduğunca "tam ihtiyaç anında" ister.
class AppPermissionService {
  static Future<bool> requestMicrophoneForRoom() async {
    final mic = await Permission.microphone.request();
    if (!mic.isGranted) return false;

    // Android 12+ Bluetooth kulaklıklar için. Desteklenmeyen platformlarda
    // permission_handler güvenli biçimde durumu döndürür.
    if (Platform.isAndroid) {
      await Permission.bluetoothConnect.request();
    }
    return true;
  }

  static Future<bool> requestNotifications() async {
    final status = await Permission.notification.request();
    return status.isGranted || status.isLimited;
  }

  static Future<bool> requestCameraForVerification() async {
    final status = await Permission.camera.request();
    return status.isGranted;
  }

  static Future<bool> requestMediaForUpload() async {
    if (Platform.isIOS) {
      final status = await Permission.photos.request();
      return status.isGranted || status.isLimited;
    }

    // Android sürümüne göre permission_handler uygun izin durumunu yönetir.
    final photos = await Permission.photos.request();
    if (photos.isGranted || photos.isLimited) return true;
    final storage = await Permission.storage.request();
    return storage.isGranted;
  }

  static Future<void> openSettings() => openAppSettings();
}
