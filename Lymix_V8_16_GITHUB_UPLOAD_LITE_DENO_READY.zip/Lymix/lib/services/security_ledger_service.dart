class LedgerEntry {
  final String id, userId, type, referenceId;
  final int amount;
  final DateTime createdAt;
  const LedgerEntry(this.id,this.userId,this.type,this.referenceId,this.amount,this.createdAt);
}
class SecurityLedgerService {
  final Set<String> processedTransactions = {};
  bool claimIdempotencyKey(String key) => processedTransactions.add(key);
  int riskScore({required int accountAgeDays,required int devices,required int failedPayments,required int rapidGifts}) {
    return ((devices-1)*12 + failedPayments*8 + rapidGifts*3 + (accountAgeDays<2?20:0)).clamp(0,100);
  }
}
