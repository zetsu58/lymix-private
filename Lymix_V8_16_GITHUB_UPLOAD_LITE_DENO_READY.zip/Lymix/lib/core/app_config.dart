class AppConfig {
  // Physical phones cannot use 10.0.2.2 (Android emulator loopback).
  // Build production/test APK with:
  // --dart-define=LYMIX_API_BASE=https://YOUR-SERVER
  static const apiBase = String.fromEnvironment(
    'LYMIX_API_BASE',
    defaultValue: 'https://lymix-privates-y9rb8ydya1x6.zetsu58.deno.net',
  );

  static const requireAuth = bool.fromEnvironment(
    'LYMIX_REQUIRE_AUTH',
    defaultValue: true,
  );

  static const appName = 'Lymix';
  static const supportEmail = String.fromEnvironment(
    'LYMIX_SUPPORT_EMAIL',
    defaultValue: 'support@lymix.app',
  );
}
