// lib/widgets/game_overlay_widget.dart
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class LymixLiveGameOverlay extends StatefulWidget {
  final String gameUrl; // Örn: https://games.lymix.app/fishing?token=XYZ&roomId=999
  final VoidCallback onClose;

  const LymixLiveGameOverlay({
    Key? key,
    required this.gameUrl,
    required this.onClose,
  }) : super(key: key);

  @override
  State<LymixLiveGameOverlay> createState() => _LymixLiveGameOverlayState();
}

class _LymixLiveGameOverlayState extends State<LymixLiveGameOverlay> {
  late final WebViewController _controller;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..addJavaScriptChannel(
        'LymixGameBridge',
        onMessageReceived: (JavaScriptMessage message) {
          // Oyun içi coin harcama veya kazanma olayları (Game -> Flutter)
          print("Oyun İçi Tetikleyici: ${message.message}");
        },
      )
      ..loadRequest(Uri.parse(widget.gameUrl));
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.5, // Ekranın alt yarısında açılan oyun penceresi
      decoration: const BoxDecoration(
        color: Color(0xFF100826),
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(
        children: [
          // Oyun Başlık BARI
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text("🎮 Lymix Mini Games", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                IconButton(
                  icon: const Icon(Icons.close, color: Colors.white),
                  onPressed: widget.onClose,
                ),
              ],
            ),
          ),
          Expanded(
            child: ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
              child: WebViewWidget(controller: _controller),
            ),
          ),
        ],
      ),
    );
  }
}