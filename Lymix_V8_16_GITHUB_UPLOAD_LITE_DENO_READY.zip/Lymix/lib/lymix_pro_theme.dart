
import 'package:flutter/material.dart';

class LymixPro {
  static const bg = Color(0xFF0D0B14);
  static const panel = Color(0xFF17131F);
  static const panel2 = Color(0xFF21172E);
  static const yellow = Color(0xFFFFD200);
  static const purple = Color(0xFF7B3FF2);
  static const deepPurple = Color(0xFF2C0F4D);
  static const text = Color(0xFFF7F4FF);
  static const muted = Color(0xFFAAA2B5);

  static const brandGradient = LinearGradient(
    colors: [yellow, Color(0xFFFFA800), purple],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const premiumGradient = LinearGradient(
    colors: [Color(0xFF32134E), Color(0xFF7B3FF2), Color(0xFFFFD200)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static ThemeData theme() => ThemeData(
    brightness: Brightness.dark,
    scaffoldBackgroundColor: bg,
    colorScheme: const ColorScheme.dark(primary: yellow, secondary: purple, surface: panel),
    cardTheme: const CardThemeData(color: panel, elevation: 0),
    useMaterial3: true,
  );
}
