
import 'dart:async';
import 'package:flutter/material.dart';
import 'lymix_pro_theme.dart';

class LymixLivePulse extends StatefulWidget {
  final Widget child;
  const LymixLivePulse({super.key, required this.child});
  @override State<LymixLivePulse> createState()=>_LymixLivePulseState();
}
class _LymixLivePulseState extends State<LymixLivePulse> {
  Timer? t; bool on=false;
  @override void initState(){super.initState();t=Timer.periodic(const Duration(milliseconds:850),(_){if(mounted)setState(()=>on=!on);});}
  @override void dispose(){t?.cancel();super.dispose();}
  @override Widget build(BuildContext c)=>AnimatedContainer(
    duration:const Duration(milliseconds:500),
    decoration:BoxDecoration(boxShadow:[BoxShadow(color:LymixPro.yellow.withOpacity(on ? .18 : .06),blurRadius:on?22:8)]),
    child:widget.child);
}
class LiveBadge extends StatelessWidget {
 const LiveBadge({super.key});
 @override Widget build(BuildContext c)=>Container(
  padding:const EdgeInsets.symmetric(horizontal:9,vertical:5),
  decoration:BoxDecoration(gradient:LymixPro.brandGradient,borderRadius:BorderRadius.circular(20)),
  child:const Row(mainAxisSize:MainAxisSize.min,children:[Icon(Icons.graphic_eq,size:14,color:LymixPro.bg),SizedBox(width:4),Text('CANLI',style:TextStyle(color:LymixPro.bg,fontWeight:FontWeight.w900,fontSize:11))]));
}
class VoiceRing extends StatefulWidget {
 final Widget child; const VoiceRing({super.key,required this.child});
 @override State<VoiceRing> createState()=>_VoiceRingState();
}
class _VoiceRingState extends State<VoiceRing> with SingleTickerProviderStateMixin {
 late final AnimationController c;
 @override void initState(){super.initState();c=AnimationController(vsync:this,duration:const Duration(milliseconds:1300))..repeat(reverse:true);}
 @override void dispose(){c.dispose();super.dispose();}
 @override Widget build(BuildContext x)=>AnimatedBuilder(animation:c,builder:(_,__)=>Container(
   padding:EdgeInsets.all(2+2*c.value),
   decoration:BoxDecoration(shape:BoxShape.circle,border:Border.all(color:LymixPro.yellow.withOpacity(.45+.5*c.value),width:2)),
   child:widget.child));
}
