import 'dart:async';
import 'package:flutter/material.dart';
import '../../config/v816_product_config.dart';

class LymixLaunchScreen extends StatefulWidget {
  final Widget next;
  const LymixLaunchScreen({super.key, required this.next});

  @override
  State<LymixLaunchScreen> createState() => _LymixLaunchScreenState();
}

class _LymixLaunchScreenState extends State<LymixLaunchScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: LymixV816.splashSeconds),
    )..forward();

    _timer = Timer(
      const Duration(seconds: LymixV816.splashSeconds),
      _finish,
    );
  }

  void _finish() {
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 240),
        pageBuilder: (_, animation, __) => FadeTransition(
          opacity: animation,
          child: widget.next,
        ),
      ),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0F14),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 28),
          child: Column(
            children: [
              const Spacer(),
              TweenAnimationBuilder<double>(
                tween: Tween(begin: .92, end: 1),
                duration: const Duration(milliseconds: 900),
                curve: Curves.easeOutBack,
                builder: (_, scale, child) =>
                    Transform.scale(scale: scale, child: child),
                child: const Text(
                  'LYMIX',
                  style: TextStyle(
                    fontSize: 48,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 4,
                    color: Color(0xFFFFC928),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              const Text(
                LymixV816.slogan,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFFE7E9EE),
                  fontSize: 15,
                  letterSpacing: .2,
                ),
              ),
              const Spacer(),
              AnimatedBuilder(
                animation: _controller,
                builder: (_, __) => Column(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(99),
                      child: LinearProgressIndicator(
                        value: _controller.value,
                        minHeight: 5,
                        backgroundColor: const Color(0xFF252933),
                        valueColor: const AlwaysStoppedAnimation(
                          Color(0xFFFFC928),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      '${(_controller.value * 100).round()}%',
                      style: const TextStyle(
                        color: Color(0xFF9DA3B0),
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 26),
            ],
          ),
        ),
      ),
    );
  }
}
