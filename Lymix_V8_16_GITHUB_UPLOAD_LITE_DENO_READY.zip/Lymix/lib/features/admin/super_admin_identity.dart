import 'package:flutter/material.dart';
import '../../config/v816_product_config.dart';

class SuperAdminIdentity extends StatelessWidget {
  const SuperAdminIdentity({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        const Icon(Icons.workspace_premium_rounded,
            color: Color(0xFFFFC928), size: 18),
        const SizedBox(width: 6),
        const Text(
          LymixV816.devAdminDisplayName,
          style: TextStyle(fontWeight: FontWeight.w800),
        ),
        const SizedBox(width: 7),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
          decoration: BoxDecoration(
            color: const Color(0xFFFFC928).withOpacity(.14),
            borderRadius: BorderRadius.circular(999),
            border: Border.all(color: const Color(0xFFFFC928).withOpacity(.55)),
          ),
          child: const Text(
            'SUPER ADMIN',
            style: TextStyle(
              color: Color(0xFFFFC928),
              fontSize: 9,
              fontWeight: FontWeight.w900,
              letterSpacing: .7,
            ),
          ),
        ),
      ],
    );
  }
}
