import 'package:flutter/material.dart';

class LymixBreakpoints {
  static const compact = 360.0;
  static const tablet = 700.0;
}

class LymixResponsive extends StatelessWidget {
  final Widget Function(BuildContext context, bool compact, bool tablet) builder;
  const LymixResponsive({super.key, required this.builder});

  @override Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, constraints) {
      final w = constraints.maxWidth;
      return builder(context, w < LymixBreakpoints.compact, w >= LymixBreakpoints.tablet);
    },
  );
}

class LymixSemanticButton extends StatelessWidget {
  final String label;
  final String? hint;
  final Widget child;
  const LymixSemanticButton({super.key, required this.label, this.hint, required this.child});

  @override Widget build(BuildContext context) => Semantics(
    button: true,
    label: label,
    hint: hint,
    child: child,
  );
}
