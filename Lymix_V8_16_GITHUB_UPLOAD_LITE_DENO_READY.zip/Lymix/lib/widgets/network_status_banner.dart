import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';

class NetworkStatusBanner extends StatefulWidget {
  final Widget child;
  const NetworkStatusBanner({super.key, required this.child});
  @override State<NetworkStatusBanner> createState()=>_NetworkStatusBannerState();
}

class _NetworkStatusBannerState extends State<NetworkStatusBanner> {
  StreamSubscription<List<ConnectivityResult>>? sub;
  bool offline=false;

  @override void initState(){
    super.initState();
    sub=Connectivity().onConnectivityChanged.listen((results){
      final value=results.isEmpty || results.every((r)=>r==ConnectivityResult.none);
      if(mounted && value!=offline)setState(()=>offline=value);
    });
  }

  @override void dispose(){sub?.cancel();super.dispose();}

  @override Widget build(BuildContext context)=>Column(children:[
    AnimatedSize(
      duration:const Duration(milliseconds:180),
      child:offline
          ? Container(
              width:double.infinity,
              padding:const EdgeInsets.symmetric(horizontal:12,vertical:7),
              color:const Color(0xFF3B1720),
              child:const SafeArea(bottom:false,child:Row(mainAxisAlignment:MainAxisAlignment.center,children:[
                Icon(Icons.cloud_off_rounded,size:15,color:Color(0xFFFFB7C1)),
                SizedBox(width:7),
                Flexible(child:Text('Çevrimdışısın • bazı özellikler bağlantı gelene kadar güncellenmeyebilir.',textAlign:TextAlign.center,style:TextStyle(color:Color(0xFFFFD9DE),fontSize:9.5,fontWeight:FontWeight.w600))),
              ])),
            )
          : const SizedBox.shrink(),
    ),
    Expanded(child:widget.child),
  ]);
}
