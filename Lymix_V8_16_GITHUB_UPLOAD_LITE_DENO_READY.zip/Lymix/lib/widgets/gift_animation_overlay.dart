import 'dart:math';
import 'package:flutter/material.dart';

class GiftOverlayData {
  final String senderName;
  final String receiverName;
  final String giftName;
  final String giftEmoji;
  final int coinValue;
  const GiftOverlayData({required this.senderName, required this.receiverName, required this.giftName, required this.giftEmoji, required this.coinValue});
}

class VipEntranceData {
  final String userName;
  final int vipLevel;
  const VipEntranceData({required this.userName, required this.vipLevel});
}

class GiftAnimationOverlay extends StatefulWidget {
  final GiftOverlayData data;
  final VoidCallback onFinished;
  const GiftAnimationOverlay({super.key, required this.data, required this.onFinished});
  @override State<GiftAnimationOverlay> createState()=>_GiftAnimationOverlayState();
}

class _GiftAnimationOverlayState extends State<GiftAnimationOverlay> with SingleTickerProviderStateMixin {
  late final AnimationController c;
  @override void initState(){super.initState();c=AnimationController(vsync:this,duration:const Duration(milliseconds:2800))..forward().whenComplete(widget.onFinished);}
  @override void dispose(){c.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>IgnorePointer(child:AnimatedBuilder(animation:c,builder:(_,__) {
    final t=c.value;
    final fade=t<.12?t/.12:(t>.78?(1-t)/.22:1.0);
    final scale=.72+min(t/.32,1)*.34;
    return Opacity(opacity:fade.clamp(0,1),child:Stack(children:[
      Positioned.fill(child:CustomPaint(painter:_ParticlePainter(t,widget.data.coinValue))),
      Align(alignment:const Alignment(0,-.08),child:Transform.scale(scale:scale,child:Container(
        width:310,padding:const EdgeInsets.fromLTRB(18,18,18,15),
        decoration:BoxDecoration(
          gradient:const LinearGradient(begin:Alignment.topLeft,end:Alignment.bottomRight,colors:[Color(0xF0211A10),Color(0xF0443000),Color(0xF014111D)]),
          borderRadius:BorderRadius.circular(26),border:Border.all(color:const Color(0xFFFFC928),width:1.5),
          boxShadow:const [BoxShadow(color:Color(0x88FFC928),blurRadius:28,spreadRadius:2)],
        ),
        child:Column(mainAxisSize:MainAxisSize.min,children:[
          Text(widget.data.giftEmoji,style:const TextStyle(fontSize:76)),
          const SizedBox(height:5),
          Text(widget.data.giftName,style:const TextStyle(color:Color(0xFFFFD85B),fontSize:20,fontWeight:FontWeight.w900)),
          const SizedBox(height:5),
          Text('${widget.data.senderName} → ${widget.data.receiverName}',style:const TextStyle(color:Colors.white,fontSize:13,fontWeight:FontWeight.w700)),
          const SizedBox(height:3),
          Text('${widget.data.coinValue} LymCoin',style:const TextStyle(color:Colors.white60,fontSize:11)),
          const SizedBox(height:10),
          Container(padding:const EdgeInsets.symmetric(horizontal:12,vertical:6),decoration:BoxDecoration(color:Colors.black26,borderRadius:BorderRadius.circular(999)),child:const Text('LYMIX HEDİYE ANI',style:TextStyle(color:Color(0xFFFFC928),fontSize:9,fontWeight:FontWeight.bold,letterSpacing:1.2))),
        ]),
      ))),
      Positioned(top:110,left:18,right:18,child:Transform.translate(offset:Offset((1-min(t/.22,1))*-30,0),child:Container(
        padding:const EdgeInsets.symmetric(horizontal:14,vertical:10),
        decoration:BoxDecoration(color:const Color(0xE5171320),borderRadius:BorderRadius.circular(18),border:Border.all(color:const Color(0x55FFC928))),
        child:Text('🎁 ${widget.data.senderName}, ${widget.data.receiverName} için ${widget.data.giftName} gönderdi!',textAlign:TextAlign.center,style:const TextStyle(color:Colors.white,fontSize:12,fontWeight:FontWeight.w600)),
      ))),
    ]));
  }));
}

class VipEntranceOverlay extends StatefulWidget {
  final VipEntranceData data; final VoidCallback onFinished;
  const VipEntranceOverlay({super.key,required this.data,required this.onFinished});
  @override State<VipEntranceOverlay> createState()=>_VipEntranceOverlayState();
}
class _VipEntranceOverlayState extends State<VipEntranceOverlay> with SingleTickerProviderStateMixin {
  late final AnimationController c;
  @override void initState(){super.initState();c=AnimationController(vsync:this,duration:const Duration(milliseconds:2200))..forward().whenComplete(widget.onFinished);}
  @override void dispose(){c.dispose();super.dispose();}
  @override Widget build(BuildContext context){
    final names={1:'ALTIN IŞIK',2:'KRALİYET İZİ',3:'LYMIX AURORA'};
    final symbols={1:'✦',2:'♛',3:'✧'};
    return IgnorePointer(child:AnimatedBuilder(animation:c,builder:(_,__) {
      final t=c.value; final y=(1-min(t/.30,1))*55; final opacity=t<.15?t/.15:(t>.8?(1-t)/.2:1.0);
      return Opacity(opacity:opacity.clamp(0,1),child:Stack(children:[
        Positioned.fill(child:CustomPaint(painter:_VipPainter(t,widget.data.vipLevel))),
        Align(alignment:const Alignment(0,-.28),child:Transform.translate(offset:Offset(0,y),child:Container(
          margin:const EdgeInsets.symmetric(horizontal:28),padding:const EdgeInsets.symmetric(horizontal:18,vertical:15),
          decoration:BoxDecoration(gradient:const LinearGradient(colors:[Color(0xF014111D),Color(0xF0433200),Color(0xF014111D)]),borderRadius:BorderRadius.circular(22),border:Border.all(color:const Color(0xFFFFC928)),boxShadow:const [BoxShadow(color:Color(0x66FFC928),blurRadius:22)]),
          child:Row(children:[
            Text(symbols[widget.data.vipLevel]??'✦',style:const TextStyle(fontSize:38,color:Color(0xFFFFD85B))),
            const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,mainAxisSize:MainAxisSize.min,children:[
              Text('${widget.data.userName} odaya katıldı',style:const TextStyle(color:Colors.white,fontSize:15,fontWeight:FontWeight.w800)),
              Text('VIP ${widget.data.vipLevel} • ${names[widget.data.vipLevel]??'ÖZEL GİRİŞ'}',style:const TextStyle(color:Color(0xFFFFC928),fontSize:10,fontWeight:FontWeight.bold,letterSpacing:.7)),
            ])),
          ]),
        ))),
      ]));
    }));
  }
}

class _ParticlePainter extends CustomPainter {
  final double t; final int value; _ParticlePainter(this.t,this.value);
  @override void paint(Canvas canvas,Size size){final p=Paint()..color=const Color(0xFFFFD85B);for(var i=0;i<28;i++){final x=(i*83.0)%size.width;final y=((i*37.0)+(t*size.height*1.15))%size.height;final r=2.0+(i%4);canvas.drawCircle(Offset(x,y),r,p..color=Color.fromARGB((170*(1-t*.45)).toInt().clamp(0,255),255,200+(i%55),40));}}
  @override bool shouldRepaint(covariant _ParticlePainter old)=>old.t!=t;
}
class _VipPainter extends CustomPainter {
  final double t; final int level; _VipPainter(this.t,this.level);
  @override void paint(Canvas canvas,Size size){final p=Paint()..style=PaintingStyle.stroke..strokeWidth=1.2;for(var i=0;i<18;i++){final a=(i/18)*pi*2+t*pi;final rad=80+(i%5)*22+t*45;final c=Offset(size.width/2+cos(a)*rad,size.height*.35+sin(a)*rad*.45);p.color=Color.fromARGB((150*(1-t*.35)).toInt().clamp(0,255),255,196+(i%45),40);canvas.drawCircle(c,3+(i%3).toDouble(),p);}}
  @override bool shouldRepaint(covariant _VipPainter old)=>old.t!=t||old.level!=level;
}
