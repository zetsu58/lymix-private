import 'package:flutter/material.dart';
import '../theme/lymix_theme.dart';

class LymixSectionHeader extends StatelessWidget {
  final String title;
  final String? subtitle;
  final String? actionLabel;
  final VoidCallback? onAction;
  const LymixSectionHeader({super.key,required this.title,this.subtitle,this.actionLabel,this.onAction});

  @override Widget build(BuildContext context)=>Row(crossAxisAlignment:CrossAxisAlignment.end,children:[
    Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(title,style:const TextStyle(fontSize:15,fontWeight:FontWeight.w900,letterSpacing:-.15)),
      if(subtitle!=null)...[
        const SizedBox(height:3),
        Text(subtitle!,style:const TextStyle(color:Colors.white38,fontSize:9.4,height:1.3)),
      ],
    ])),
    if(actionLabel!=null&&onAction!=null)
      TextButton(onPressed:onAction,child:Text(actionLabel!,style:const TextStyle(color:LymixColors.gold,fontSize:10,fontWeight:FontWeight.w800))),
  ]);
}
