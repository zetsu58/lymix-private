import 'package:flutter/material.dart';

class LymixFeedback {
  static void success(BuildContext context,String message)=>_show(context,message,Icons.check_circle_rounded,const Color(0xFF5BE3A5));
  static void warning(BuildContext context,String message)=>_show(context,message,Icons.warning_amber_rounded,const Color(0xFFFFD36E));
  static void error(BuildContext context,String message)=>_show(context,message,Icons.error_outline_rounded,const Color(0xFFFF91A2));
  static void info(BuildContext context,String message)=>_show(context,message,Icons.info_outline_rounded,const Color(0xFF73D5FF));

  static void _show(BuildContext context,String message,IconData icon,Color color){
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        duration:const Duration(seconds:3),
        content:Row(children:[Icon(icon,color:color,size:18),const SizedBox(width:8),Expanded(child:Text(message))]),
      ));
  }
}
