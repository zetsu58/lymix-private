import 'package:flutter/material.dart';
import '../theme/lymix_theme.dart';

class LymixRefresh extends StatelessWidget {
  final Future<void> Function() onRefresh;
  final Widget child;
  const LymixRefresh({super.key, required this.onRefresh, required this.child});

  @override Widget build(BuildContext context)=>RefreshIndicator(
    color:LymixColors.gold,
    backgroundColor:LymixColors.surface,
    strokeWidth:2.2,
    displacement:32,
    onRefresh:onRefresh,
    child:child,
  );
}
