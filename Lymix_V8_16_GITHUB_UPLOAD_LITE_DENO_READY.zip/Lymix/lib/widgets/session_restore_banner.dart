import 'package:flutter/material.dart';
import '../theme/lymix_theme.dart';

class SessionRestoreBanner extends StatelessWidget {
  final String roomTitle;
  final VoidCallback onRestore;
  final VoidCallback onDismiss;
  const SessionRestoreBanner({super.key,required this.roomTitle,required this.onRestore,required this.onDismiss});

  @override Widget build(BuildContext context)=>Container(
    margin:const EdgeInsets.fromLTRB(16,8,16,0),
    padding:const EdgeInsets.all(12),
    decoration:BoxDecoration(color:const Color(0xFF17121F),borderRadius:BorderRadius.circular(17),border:Border.all(color:const Color(0x22FFD643))),
    child:Row(children:[
      const Icon(Icons.history_toggle_off_rounded,color:LymixColors.gold,size:21),
      const SizedBox(width:9),
      Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('Kaldığın yerden devam et',style:TextStyle(fontWeight:FontWeight.w800,fontSize:10.5)),
        Text(roomTitle,maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(color:Colors.white38,fontSize:8.8)),
      ])),
      TextButton(onPressed:onRestore,child:const Text('Dön')),
      IconButton(onPressed:onDismiss,icon:const Icon(Icons.close_rounded,size:17,color:Colors.white30)),
    ]),
  );
}
