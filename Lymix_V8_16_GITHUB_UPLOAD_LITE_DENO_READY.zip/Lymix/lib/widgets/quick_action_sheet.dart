import 'package:flutter/material.dart';
import '../theme/lymix_theme.dart';

class QuickActionItem {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final bool destructive;
  const QuickActionItem(this.icon,this.title,this.subtitle,this.onTap,{this.destructive=false});
}

Future<void> showLymixQuickActions(BuildContext context,{
  required String title,
  required List<QuickActionItem> items,
})=>showModalBottomSheet(
  context:context,
  isScrollControlled:true,
  backgroundColor:LymixColors.surface,
  shape:const RoundedRectangleBorder(borderRadius:BorderRadius.vertical(top:Radius.circular(28))),
  builder:(ctx)=>SafeArea(
    child:Padding(
      padding:const EdgeInsets.fromLTRB(16,8,16,20),
      child:Column(mainAxisSize:MainAxisSize.min,children:[
        Row(children:[
          Expanded(child:Text(title,style:const TextStyle(fontSize:15,fontWeight:FontWeight.w900))),
          IconButton(onPressed:()=>Navigator.pop(ctx),icon:const Icon(Icons.close_rounded,color:Colors.white38)),
        ]),
        ...items.map((i)=>ListTile(
          shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(15)),
          leading:Container(
            width:40,height:40,
            decoration:BoxDecoration(
              color:i.destructive?const Color(0x16FF667A):const Color(0x14FFD643),
              borderRadius:BorderRadius.circular(12),
            ),
            child:Icon(i.icon,color:i.destructive?const Color(0xFFFF8A9C):LymixColors.gold,size:19),
          ),
          title:Text(i.title,style:TextStyle(fontSize:11.5,fontWeight:FontWeight.w800,color:i.destructive?const Color(0xFFFFA8B6):Colors.white)),
          subtitle:Text(i.subtitle,style:const TextStyle(color:Colors.white38,fontSize:9)),
          onTap:(){Navigator.pop(ctx);i.onTap();},
        )),
      ]),
    ),
  ),
);
