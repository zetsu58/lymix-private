import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../theme/lymix_theme.dart';

class LymixNetworkImage extends StatelessWidget {
  final String? url;
  final double? width;
  final double? height;
  final BoxFit fit;
  final BorderRadius borderRadius;
  final IconData fallbackIcon;

  const LymixNetworkImage({
    super.key,
    required this.url,
    this.width,
    this.height,
    this.fit = BoxFit.cover,
    this.borderRadius = BorderRadius.zero,
    this.fallbackIcon = Icons.person_rounded,
  });

  @override Widget build(BuildContext context) {
    final value = url?.trim() ?? '';
    final fallback = Container(
      width: width, height: height,
      alignment: Alignment.center,
      color: const Color(0xFF21172B),
      child: Icon(fallbackIcon, color: LymixColors.gold.withOpacity(.65)),
    );
    if (value.isEmpty) return ClipRRect(borderRadius: borderRadius, child: fallback);
    return ClipRRect(
      borderRadius: borderRadius,
      child: CachedNetworkImage(
        imageUrl: value,
        width: width, height: height, fit: fit,
        placeholder: (_, __) => Container(
          width: width, height: height,
          color: const Color(0xFF17111F),
        ),
        errorWidget: (_, __, ___) => fallback,
      ),
    );
  }
}
