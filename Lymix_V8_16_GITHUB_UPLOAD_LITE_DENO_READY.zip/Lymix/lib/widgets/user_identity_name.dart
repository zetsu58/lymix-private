import 'package:flutter/material.dart';
import '../services/identity_asset_service.dart';

class UserIdentityName extends StatefulWidget {
  final String userId;
  final String name;
  final TextStyle style;
  const UserIdentityName({super.key, required this.userId, required this.name, required this.style});

  @override State<UserIdentityName> createState()=>_UserIdentityNameState();
}

class _UserIdentityNameState extends State<UserIdentityName>{
  String? family;
  String? iconUrl;
  bool loaded=false;

  @override void initState(){super.initState();_load();}

  Future<void> _load() async {
    try{
      final identity=await IdentityAssetService.fetchIdentity(widget.userId);
      final f=identity?['fontFamily'] as String?;
      final u=identity?['fontUrl'] as String?;
      final icon=identity?['iconUrl'] as String?;
      String? resolved;
      if(f!=null&&u!=null&&f.isNotEmpty&&u.isNotEmpty){
        try{resolved=await IdentityAssetService.loadRemoteFont(url:IdentityAssetService.assetUri(u),stableFamilyName:f);}catch(_){resolved=null;}
      }
      if(mounted)setState((){family=resolved;iconUrl=icon;loaded=true;});
    }catch(_){
      if(mounted)setState(()=>loaded=true);
    }
  }

  @override Widget build(BuildContext context)=>Row(mainAxisSize:MainAxisSize.min,children:[
    Flexible(child:Text(widget.name,overflow:TextOverflow.ellipsis,style:widget.style.copyWith(fontFamily:family))),
    if(iconUrl!=null&&iconUrl!.isNotEmpty)...[
      const SizedBox(width:5),
      ClipRRect(
        borderRadius:BorderRadius.circular(5),
        child:Image.network(
          IdentityAssetService.assetUri(iconUrl!).toString(),
          width:18,height:18,fit:BoxFit.contain,
          errorBuilder:(_,__,___)=>const SizedBox.shrink(),
        ),
      ),
    ],
  ]);
}
