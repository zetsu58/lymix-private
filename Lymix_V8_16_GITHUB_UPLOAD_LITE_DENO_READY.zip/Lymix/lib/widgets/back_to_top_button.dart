import 'package:flutter/material.dart';
import '../theme/lymix_theme.dart';

class BackToTopButton extends StatelessWidget {
  final ScrollController controller;
  final bool visible;
  const BackToTopButton({super.key,required this.controller,required this.visible});
  @override Widget build(BuildContext context)=>AnimatedScale(
    duration:const Duration(milliseconds:180),
    scale:visible?1:0,
    child:FloatingActionButton.small(
      heroTag:null,
      backgroundColor:LymixColors.surface2,
      foregroundColor:LymixColors.gold,
      onPressed:()=>controller.animateTo(0,duration:const Duration(milliseconds:280),curve:Curves.easeOutCubic),
      child:const Icon(Icons.keyboard_arrow_up_rounded),
    ),
  );
}
