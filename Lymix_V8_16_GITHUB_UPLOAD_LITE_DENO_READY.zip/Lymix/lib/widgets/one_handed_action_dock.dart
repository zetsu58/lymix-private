import 'package:flutter/material.dart';
import '../theme/lymix_theme.dart';

class OneHandedAction {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const OneHandedAction(this.icon,this.label,this.onTap);
}

class OneHandedActionDock extends StatelessWidget {
  final List<OneHandedAction> actions;
  const OneHandedActionDock({super.key,required this.actions});

  @override Widget build(BuildContext context)=>SafeArea(
    top:false,
    child:Container(
      margin:const EdgeInsets.fromLTRB(12,0,12,8),
      padding:const EdgeInsets.symmetric(horizontal:7,vertical:7),
      decoration:BoxDecoration(
        color:const Color(0xF20F0C15),
        borderRadius:BorderRadius.circular(22),
        border:Border.all(color:Colors.white.withOpacity(.06)),
        boxShadow:const[BoxShadow(color:Color(0x33000000),blurRadius:22,offset:Offset(0,8))],
      ),
      child:Row(children:actions.map((a)=>Expanded(child:InkWell(
        onTap:a.onTap,
        borderRadius:BorderRadius.circular(14),
        child:Padding(
          padding:const EdgeInsets.symmetric(vertical:8),
          child:Column(mainAxisSize:MainAxisSize.min,children:[
            Icon(a.icon,color:LymixColors.gold,size:19),
            const SizedBox(height:3),
            Text(a.label,maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(color:Colors.white54,fontSize:8.5,fontWeight:FontWeight.w700)),
          ]),
        ),
      ))).toList()),
    ),
  );
}
