import 'package:flutter/material.dart';

class LymixSkeleton extends StatefulWidget {
  final double height;
  final double? width;
  final BorderRadius borderRadius;
  const LymixSkeleton({super.key, required this.height, this.width, this.borderRadius = const BorderRadius.all(Radius.circular(14))});
  @override State<LymixSkeleton> createState()=>_LymixSkeletonState();
}

class _LymixSkeletonState extends State<LymixSkeleton> with SingleTickerProviderStateMixin {
  late final AnimationController c=AnimationController(vsync:this,duration:const Duration(milliseconds:1100))..repeat(reverse:true);
  @override void dispose(){c.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>AnimatedBuilder(
    animation:c,
    builder:(_,__)=>Container(
      width:widget.width,height:widget.height,
      decoration:BoxDecoration(
        borderRadius:widget.borderRadius,
        color:Color.lerp(const Color(0xFF15101D),const Color(0xFF211829),c.value),
      ),
    ),
  );
}
