import 'package:flutter/material.dart';
import '../theme/lymix_theme.dart';

class FeatureHint extends StatelessWidget {
  final String title;
  final String message;
  final Widget child;
  const FeatureHint({super.key,required this.title,required this.message,required this.child});

  @override Widget build(BuildContext context)=>Tooltip(
    richMessage:TextSpan(children:[
      TextSpan(text:'$title\n',style:const TextStyle(fontWeight:FontWeight.w900,color:LymixColors.gold)),
      TextSpan(text:message),
    ]),
    waitDuration:const Duration(milliseconds:550),
    showDuration:const Duration(seconds:4),
    child:child,
  );
}
