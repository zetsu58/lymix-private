$ErrorActionPreference = "Stop"

Write-Host "LYMIX Android Phone Preview Hazirlaniyor..." -ForegroundColor Yellow

if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) {
  Write-Host ""
  Write-Host "Flutter bulunamadi." -ForegroundColor Red
  Write-Host "Once Flutter SDK kurup PATH'e ekleyin, sonra bu dosyayi tekrar calistirin."
  exit 1
}

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root

Write-Host "1/4 Eksik Android platform dosyalari tamamlaniyor..." -ForegroundColor Cyan
flutter create --platforms=android --org com.lymix --project-name lymix .

Write-Host "2/4 Paketler indiriliyor..." -ForegroundColor Cyan
flutter pub get

Write-Host "3/4 Kod kontrolu yapiliyor..." -ForegroundColor Cyan
flutter analyze

Write-Host "4/4 Debug APK olusturuluyor..." -ForegroundColor Cyan
flutter build apk --debug

$apk = Join-Path $root "build\app\outputs\flutter-apk\app-debug.apk"
if (Test-Path $apk) {
  Write-Host ""
  Write-Host "HAZIR!" -ForegroundColor Green
  Write-Host "APK: $apk"
  Write-Host ""
  Write-Host "Telefon USB ile bagliysa su komutla da kurabilirsiniz:"
  Write-Host "flutter install"
} else {
  Write-Host "APK beklenen konumda bulunamadi." -ForegroundColor Red
  exit 1
}
