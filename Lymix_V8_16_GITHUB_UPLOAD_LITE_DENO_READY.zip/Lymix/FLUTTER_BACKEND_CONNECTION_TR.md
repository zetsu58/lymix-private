# LYMIX V8.16 — Flutter ↔ Backend Bağlantısı

Bağlandı:
- `POST /api/auth/login`
- Access JWT saklama
- Refresh token saklama
- Uygulama yeniden açıldığında refresh ile oturum geri yükleme
- Logout altyapısı
- Güvenli cihaz/installation ID gönderimi
- 5 saniyelik splash → AuthGate → Login → LYMIX uygulaması akışı
- `Lymix Emre` Super Admin profili backend'in environment bootstrap hesabından gelir

## Sunucu adresi
Fiziksel Android telefonda `10.0.2.2` çalışmaz; bu Android emulator adresidir.
APK build edilirken gerçek HTTPS backend adresi verilmelidir:

flutter build apk --debug --dart-define=LYMIX_API_BASE=https://api.example.com

## Backend Super Admin environment
JWT_SECRET=<uzun-rastgele-secret>
LYMIX_REQUIRE_AUTH=true
LYMIX_ADMIN_LOGIN=<admin-login>
LYMIX_ADMIN_PASSWORD=<güçlü-parola>
LYMIX_ADMIN_DISPLAY_NAME=Lymix Emre
LYMIX_ADMIN_USER_ID=owner_emre

Admin parolası Flutter/APK kaynak koduna yazılmamalıdır.
