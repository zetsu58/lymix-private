# LYMIX V8.16 Backend Kimlik Doğrulama

## Eklenen gerçek çekirdek
- `/api/auth/login`: kullanıcı adı + parola ile giriş
- 15 dakikalık JWT access token
- Refresh token ile oturum yenileme
- `/api/auth/logout`: refresh token iptali
- `Lymix Emre` OWNER/SUPER_ADMIN hesabını yalnızca sunucu ortam değişkenlerinden oluşturma
- Super Admin seviye 999 + `SUPER_ADMIN` ve `FOUNDER` rozetleri
- Giriş sırasında güvenilir cihaz kaydı için cihaz verisi kabul etme
- Admin şifresini Flutter/APK/GitHub kaynak koduna gömmeme

## Sunucuda ayarlanacak gizli değerler
`JWT_SECRET`: en az 32+ rastgele byte
`LYMIX_ADMIN_LOGIN=lymix.emre`
`LYMIX_ADMIN_PASSWORD=<çok güçlü parola>`
`LYMIX_REQUIRE_AUTH=true`

## Güvenlik
Bu sürüm ilk backend prototipidir. Üretime çıkmadan önce kullanıcı ve refresh-token verileri PostgreSQL/Redis gibi kalıcı depolara taşınmalı; MFA, rate-limit, parola sıfırlama, e-posta/telefon doğrulama ve audit logları canlı altyapıya bağlanmalıdır.
