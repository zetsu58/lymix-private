# Lymix v7 – Global, Lucky, Room Roles, Policies & Support

- Diller: Türkçe, İngilizce, Almanca, İtalyanca, Rusça, Hintçe, Azerbaycan Türkçesi.
- Baş Admin formülü: OWNER_ROOT rolü + tek kullanımlık bootstrap kodu + MFA + IP/VPN allowlist + audit log. İlk kurulumdan sonra bootstrap kodu döndürülmelidir.
- Lucky Hediye: günlük şans puanı, atış miktarı ve seri davranışına göre sanal ödül çarpanları; 2x–1000x. Admin günlük şansı 0–100 arası düzenleyebilir. Gerçek para/nakit karşılığına bağlanmamalıdır.
- Oda Yetkileri: oda seviyesi arttıkça admin slotu artar; mikrofon, susturma, koltuk, odadan çıkarma, etkinlik ve düzen yetkileri rol bazlı verilir.
- VIP 1–10: her kademeye artan avantaj; yüksek VIP için düşük/eşdeğer moderatör işlemlerine karşı kademeli koruma. Oda sahibi ve baş admin nihai yetkiye sahiptir.
- Ajans Politikası: örnek varsayılan transfer kilidi 90 gün; yayıncı kota zorunluluğu; madde madde politika ekranı.
- Canlı Destek: kullanıcı/admin mesajlaşması, çevrimiçi bilgisi, gönderildi/görüldü kayıtları ve Socket.IO olayları.
