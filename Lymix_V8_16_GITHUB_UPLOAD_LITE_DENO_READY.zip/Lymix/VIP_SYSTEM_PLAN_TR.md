# Lymix VIP 1–10 + Lymix Crown

## Yapı
- Standart seri: VIP 1, 2, 3, 4, 5, 6, 7, 8, 9, 10.
- VIP 10 üzerindeki özel sınıfın adı: **Lymix Crown**.
- Her VIP dönemi yüklemenin/aktivasyonun başladığı tarihten itibaren **30 gün**.
- Kullanıcı dönem içinde bir üst giriş eşiğini geçerse yükseltme **anında** yapılır.
- Kazanılmış seviye 30 günlük mevcut dönem bitene kadar korunur.
- Dönem sonunda yenileme eşiği karşılanmazsa son 30 günlük yüklemeye göre hak edilen en yüksek seviyeye otomatik düşürülür.
- Eşikler backend config olarak tutulmalı; mağaza fiyatları/değerleri değiştiğinde uygulama güncellemesi gerektirmeden admin panelinden düzenlenebilir.

## Önerilen eşikler
| Kademe | Giriş eşiği | 30 günlük yenileme eşiği |
|---|---:|---:|
| VIP 1 | 50K | 30K |
| VIP 2 | 100K | 60K |
| VIP 3 | 250K | 150K |
| VIP 4 | 500K | 300K |
| VIP 5 | 1M | 600K |
| VIP 6 | 2M | 1.2M |
| VIP 7 | 4M | 2.4M |
| VIP 8 | 7.5M | 4.5M |
| VIP 9 | 12M | 7.2M |
| VIP 10 | 20M | 12M |
| Lymix Crown | 35M | 21M |

Yenileme eşikleri başlangıçta giriş eşiğinin yaklaşık %60'ı olarak ayarlandı. Bunlar ticari dengeye göre admin panelinden değiştirilmeli.

## Kullanıcı ekranında gösterilecekler
- Mevcut VIP / Crown seviyesi
- Kalan gün sayısı
- Bu dönem toplam yükleme
- Yenileme eşiği ve tamamlanma çubuğu
- Bir sonraki seviyeye kalan miktar
- Seviye ayrıcalıkları
- Dönem sonunda düşme riski uyarısı

## Backend
- `GET /api/vip/config`
- `GET /api/vip/:userId/status`
- `POST /api/vip/:userId/recharge` body: `{ "amount": 50000 }`

Üretimde yükleme endpoint'i doğrudan istemciden çağrılmamalı. Sadece App Store / Google Play / ödeme sağlayıcısı tarafından doğrulanmış satın alma sonrasında sunucu tarafından VIP motoruna işlenmeli.
