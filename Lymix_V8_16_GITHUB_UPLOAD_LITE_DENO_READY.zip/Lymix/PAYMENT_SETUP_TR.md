# Lymix V8.1 — Ödeme ve LymCoin Kurulum Planı

## 1) Mağaza sürümleri için doğru ödeme modeli
LymCoin, uygulama içinde tüketilen dijital/sanal para olduğundan Android Google Play sürümünde varsayılan ödeme kanalı Google Play Billing; iOS App Store sürümünde Apple In‑App Purchase / StoreKit olmalıdır. Harici kart/kripto seçenekleri mağaza sürümünde varsayılan olarak `DIRECT_BILLING_ENABLED=false` ile kapalıdır.

## 2) Ürün SKU listesi
- `lymix_coins_1700` → 1.700 Coin
- `lymix_coins_5800` → 5.800 Coin
- `lymix_coins_23500` → 23.500 Coin
- `lymix_coins_64000` → 64.000 Coin
- `lymix_coins_131000` → 131.000 Coin
- `lymix_coins_340000` → 340.000 Coin
- `lymix_coins_690000` → 690.000 Coin

Fiyatı kod içine sabitleme. Play Console ve App Store Connect'te yerel fiyatları tanımla; uygulama ekranda mağazanın döndürdüğü gerçek fiyatı gösterir.

### Referans TRY planı (başlangıç önerisi)
Bu sadece ticari başlangıç planıdır; mağazadaki vergi/komisyon ve yayıncı ödeme oranlarına göre Owner panelinden yeniden hesaplanmalıdır.
- yaklaşık ₺47,50 → 7.000 Coin (direct/web referans)
- ₺190 → 29.000 Coin
- ₺475 → 74.000 Coin
- ₺950 → 154.000 Coin
- ₺2.375 → 400.000 Coin
- ₺4.750 → 820.000 Coin
- ₺14.250 → 2.550.000 Coin

## 3) Para sana nasıl gelir?
### Google Play
Play Console ödeme profilinde şirket/şahıs işletmesi adına doğrulanmış banka hesabını tanımlarsın. Google tahsilatı yapar ve ödeme takvimine göre banka hesabına settlement gönderir. Kart numarasını Lymix sunucusuna almazsın.

### Apple
App Store Connect'te Agreements/Tax/Banking bölümünden banka ve vergi bilgilerini tanımlarsın. Apple tahsilatı yapar ve uygun bakiyeyi kayıtlı banka hesabına öder.

### Web / doğrudan satış (Türkiye)
iyzico gibi lisanslı ödeme kuruluşunda üye işyeri hesabı açılır; işletme/KYC ve banka hesabı tanımlanır. Lymix backend ödeme oturumunu oluşturur; tercihen Checkout Form + 3D Secure kullanılır. Ham kart verisi Flutter/backend loglarına yazılmaz. Settlement üye işyeri sözleşmendeki banka hesabına gider.

## 4) Kritik güvenlik
- Coin yalnızca SERVER-SIDE doğrulanmış işlemden sonra yüklenir.
- `transactionId/orderId` UNIQUE tutulur; aynı makbuz iki kez kullanılamaz.
- Google purchase token ve Apple signed transaction sunucuda doğrulanır.
- Refund/chargeback geldiğinde ledger işaretlenir; gerekirse kullanılmamış Coin geri alınır veya hesap incelemeye düşer.
- Admin manuel bakiye işlemleri değiştirilemez audit log'a yazılır.
- LymCoin'in nakit karşılığı olmadığı kullanıcıya açık gösterilir.
- Lucky/random ödüllerde olasılıklar satın alma/harcama noktasına yakın gösterilir.

## 5) Zarar etmeme koruması
Tek başına “kaç Coin satılıyor” kârlılığı garanti etmez. Şu formül Owner Economy panelinde izlenmelidir:

`Net Gelir = Brüt Satış - mağaza/ödeme komisyonu - vergi - iade/chargeback - yayıncı/ajans ödemesi - promosyon/Lucky maliyeti - altyapı maliyeti`

`MIN_GROSS_MARGIN` ve `MAX_CREATOR_PAYOUT_RATIO` gibi uzaktan konfigürasyon değerleri kullanılmalıdır. Paket bonusu artırıldığında yayıncıya nakde dönüşebilen elmas oranı otomatik artırılmamalıdır.

## 6) Bu pakette tamamlananlar
- Flutter `in_app_purchase` katalog ve satın alma ekranı.
- Google Play/App Store SKU eşlemesi.
- Server-side verification için fail-closed adapter katmanı.
- Ödeme ledger / idempotency altyapısı.
- Direct billing'i mağaza sürümünden ayıran feature flag.
- iyzico entegrasyon noktası (merchant anahtarları olmadan kart tahsilatı aktif edilmez).
- Refund/settlement veri modeli.

## 7) Production öncesi gerekli gerçek bilgiler
Google Play service account, package name; Apple Issuer ID / Key ID / .p8 / bundle ID; iyzico kullanılacaksa merchant API key/secret; şirket vergi ve banka hesabı. Bu bilgiler olmadan gerçek para tahsilatı açılmamalıdır.
