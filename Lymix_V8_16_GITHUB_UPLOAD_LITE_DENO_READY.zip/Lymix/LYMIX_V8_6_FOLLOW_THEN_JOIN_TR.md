# Lymix V8.6 — Takip Et → Katılma İsteği

- Odaya giren kullanıcı artık otomatik olarak odayı takip etmez.
- Oda başlığının yanında **Takip Et** butonu görünür.
- Kullanıcı kendi isteğiyle Takip Et'e bastıktan sonra **Katılma İsteği** butonu görünür.
- Katılma isteği yalnızca takipçi durumundaki kullanıcı tarafından gönderilebilir.
- İsteği oda sahibi veya oda adminlerinden biri onaylar/reddeder.
- Takipten çıkılırsa bekleyen katılma isteği iptal edilir.
- Backend de `room_join_request` öncesinde takip durumunu doğrular; sadece istemci arayüzüne güvenmez.
