# Lymix V8 ALL-IN-ONE

V8, önceki ALL-IN-ONE sürümlerindeki sosyal oda, hediye, Lucky, VIP 1-10 + Crown, ajans, politika, canlı destek, admin/owner ops, çoklu dil, oyun sağlayıcı adaptörü ve ekonomi altyapısını korur.

Bu revizyonda cihaz izinleri merkezi hale getirildi. Sesli oda girişinde mikrofon izni istenir; Bluetooth ses cihazı izni Android'de ihtiyaç anında devreye girer. Kamera, fotoğraf/medya ve bildirim izinleri ayrı ve açıklamalı akışlara taşındı. İzin reddedildiğinde kullanıcı uygulama ayarlarına yönlendirilebilir.

Önemli: Bu paket Store hazırlığı için kod ve checklist içerir; gerçek App Store/Play Store kabulü ancak production sertifikaları, sunucu uçları, gizlilik beyanları ve fiziksel cihaz testleri tamamlandıktan sonra doğrulanabilir.
