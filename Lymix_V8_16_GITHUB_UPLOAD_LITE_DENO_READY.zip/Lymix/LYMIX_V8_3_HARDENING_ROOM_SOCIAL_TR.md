# Lymix V8.3 – Sağlamlık + Oda Sosyal Katmanı

Bu sürüm V8.2 üzerine eklenmiştir.

## Sağlamlık
- Command Center servis sağlık kontratı
- Remote Config / Feature Flags / Kill Switch altyapısı
- Coin ledger ve idempotency yardımcı katmanı
- Fraud risk puanı kontratı
- Reconnect/backoff altyapısı
- Audit log, staging, backup/restore, forced update, rate-limit ve alerting için production checklist
- Düşük cihazlarda efekt kalitesi ve CDN/cache yaklaşımı

## Oda
- Katılan kullanıcı için chat içinde “Selam ver” hızlı butonu
- Kadın yayıncı / doğrulanmış yayıncı giriş mesajı için destek
- Oda sahibinin düzenleyebildiği oda kuralları (12 maddeye kadar)
- Kalıcı Oda ID + Ajans Kodu görünümü
- Her kullanıcı için kendi mikrofonunu aç/kapat butonu
- Her kullanıcı için oda sesini aç/kapat (speaker mute) butonu
- Oda tarih/saat/versiyon etiketi korunur

## Production notu
Gerçek RTC ses kapatma, sunucu metricleri, fraud sinyalleri ve ödeme ledger kayıtları sağlayıcı SDK/backend bağlantısı yapıldığında bu kontratlara bağlanmalıdır. Client tarafındaki butonlar tek başına güvenlik otoritesi değildir.
