# Lymix Control Center v2

Bu sürüm ALL-IN-ONE projenin üzerine admin/yönetim ve güvenlik modüllerini ekler.

## Eklenen yönetim alanları
- Kullanıcı arama, özel Lymix ID atama/değiştirme
- Coin/elmas ekleme, düşme veya kesin bakiyeye düzeltme
- Kullanıcı ban / unban ve süreli ban
- Cihaz banı ve IP banı (hash/fingerprint yaklaşımı)
- Yayıncı, ajans sahibi, moderatör, destek/finans rolleri
- Odayı ajansa bağlama, ajans sahibi ve yayıncı atama
- Oda kilitleme, askıya alma, başlık düzeltme ve sistem mesajı
- VIP/seviye ve yönetici notları
- Telefon doğrulama durumu, cihaz/IP fingerprint kayıtları
- Kadın yayıncılar için manuel görüntü/liveness doğrulama kuyruğu
- Onaylanan yayıncıya "Gerçek Kullanıcı" doğrulama tiki
- Aynı telefon/cihaz/IP sinyalleriyle çoklu hesap risk kontrolü
- Uygulama feature flag ve ekonomi oranı yönetimi
- Her yönetici işlemi için audit log

## Önemli güvenlik notu
Otomatik yüz tanıma veya bir kişinin yüzünü başka hesaplarda arayıp kimlik eşleştirme özelliği eklenmemiştir. Bunun yerine doğrulama görüntüsü/video kanıtı insan moderatör tarafından incelenir; tekrarlı hesap riski telefon, cihaz fingerprint'i ve IP gibi hesap güvenliği sinyalleriyle gösterilir. Doğrulama medya dosyaları üretimde şifreli saklanmalı, erişimleri loglanmalı ve saklama süresi sonunda silinmelidir.

## Backend
Yeni router: `backend/routes/adminRoutes.js`
Mount: `/api/admin/*`

Üretime geçmeden önce `x-admin-id` demo yaklaşımını gerçek admin JWT + RBAC ile değiştirin.
