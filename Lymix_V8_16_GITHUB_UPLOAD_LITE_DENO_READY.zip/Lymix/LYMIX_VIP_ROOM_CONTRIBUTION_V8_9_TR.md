# Lymix VIP + Oda Atışları V8.9
- VIP merkezi referanslardan yalnızca fikir alınarak özgün Lymix düzeniyle yenilendi.
- VIP 1–10 + Crown, 30 günlük ilerleme ve seviye bazlı avantaj ızgarası eklendi.
- Oda Atışları, hediye/coin katkı sıralaması olarak tasarlandı.
- Günlük / Haftalık / Aylık sekmeler ve özgün ilk-3 podyumu eklendi.
- Oda hızlı menüsüne Atışlar kısayolu ve istatistikten sıralamaya geçiş eklendi.
