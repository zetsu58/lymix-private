LYMIX V8.15
- V8.14 profesyonel arayüz korunmuştur.
- Canlı konuşmacı pulse/ring bileşeni eklendi.
- CANLI durum rozeti eklendi.
- Reklam ve mağaza ekranları için 8 sahnelik gerçek-UI çekim standardı eklendi.
- Reklam sloganı: “Sesinle Bağlan, Dünyanı Paylaş.”
- Canlı kullanıcı/oda/hediye verileri mevcut backend/API katmanına bağlandığında aynı UI bileşenleri dinamik veriyle çalışacak şekilde ayrıştırılabilir.
- Referans uygulamanın marka varlıkları veya ekranları birebir kopyalanmamıştır.
