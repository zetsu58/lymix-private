# Lymix v6 — Growth + Owner Ops
Bu sürüm v5 ALL-IN-ONE üzerine eklenmiştir.

## Ürün sistemleri
- Lymix Seasons: 30 günlük sezon, ücretsiz/premium ödül yolu, XP ve sezon kozmetikleri.
- Prestige: VIP'den bağımsız kalıcı sadakat/statü seviyesi.
- VIP koruma hakkı ve Lymix Club davet statüsü.
- Hediye koleksiyonları, combo x10/x50/x100/x999, Mega Gift duyuruları.
- Oda hedefi, oda ligi, yayıncı görevleri, ajans ligi ve Ajans Akademisi.
- Lymix Duo ortak görev/yıldönümü/yüzük evrimi; Friendship bağı.
- Oyun sezonları, başarı rozetleri ve turnuva odaları.
- Günlük seri, geri dönüş görevleri, kişiselleştirilmiş Keşfet ve onboarding.
- Oda mini etkinlikleri; canlı altyazı/çeviri için provider-ready katman.
- Moderasyon kademeleri, itiraz, Fraud Center risk kuyruğu.
- Ekonomi/analytics paneli, Feature Flags, Remote Config ve Kill Switch.
- Lymix World: oda + akış + oyun + arkadaşlık + hediye + etkinlik ortak ilerleme seviyesi.

## Owner Ops (sadece uygulama sahibi)
Backend: /api/owner-ops/status, /maintenance, /emergency, /feature/:key, /broadcast, /disconnect-user, /incident.
OWNER_OPS_TOKEN zorunludur. Production'da owner rolü, MFA, VPN/IP allowlist, secret rotation ve değiştirilemez audit log eklenmelidir.
Canlı metrikler: uptime, process RAM/heap, host memory/load, Socket.IO bağlantıları, oda/kullanıcı sayısı, incident ve action geçmişi.
Müdahale: bakım modu, read-only emergency, özellik bazlı kill switch, global duyuru, kullanıcı bağlantısını kesme, olay kaydı.

## Önemli
Sunucuyu uygulama içinden doğrudan shell/SSH komutlarıyla yönetmek yerine sınırlı ve audit edilen operasyon endpointleri kullanılır. Restart/scale/failover işlemleri production hosting sağlayıcısının API'sine ayrı adapter ile bağlanmalıdır.
