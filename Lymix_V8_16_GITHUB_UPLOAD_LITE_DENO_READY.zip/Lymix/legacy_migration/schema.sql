-- 1. Var olan tabloları temizle (Yeniden kurulumlarda çakışmayı önler)
DROP TABLE IF EXISTS messages CASCADE;
DROP TABLE IF EXISTS users CASCADE;

-- 2. Kullanıcılar Tablosu
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 3. Mesajlar / Oturum Tablosu (Örnek ilişki)
CREATE TABLE messages (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    sent_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 4. Performans için İndeksler (İsteğe Bağlı)
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_messages_user_id ON messages(user_id);
-- Lymix extended social/game/economy modules
CREATE TABLE IF NOT EXISTS user_profiles (
  user_id INT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  age INT, vip_level INT DEFAULT 0, level INT DEFAULT 1,
  sent_coins BIGINT DEFAULT 0, received_coins BIGINT DEFAULT 0,
  personal_room_id VARCHAR(80), updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS room_events (id BIGSERIAL PRIMARY KEY, room_id VARCHAR(80) NOT NULL, title VARCHAR(160) NOT NULL, starts_at TIMESTAMPTZ, ends_at TIMESTAMPTZ, payload JSONB DEFAULT '{}'::jsonb);
CREATE TABLE IF NOT EXISTS room_reports (id BIGSERIAL PRIMARY KEY, reporter_user_id INT, room_id VARCHAR(80), target_user_id INT, reason VARCHAR(80), details TEXT, status VARCHAR(30) DEFAULT 'open', created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS system_messages (id BIGSERIAL PRIMARY KEY, user_id INT, room_id VARCHAR(80), message_type VARCHAR(50), content TEXT NOT NULL, created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS vip_progress (user_id INT PRIMARY KEY, vip_level INT DEFAULT 0, load_total BIGINT DEFAULT 0, threshold_next BIGINT DEFAULT 50000, updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS inventory_items (id BIGSERIAL PRIMARY KEY, code VARCHAR(80) UNIQUE NOT NULL, item_type VARCHAR(40) NOT NULL, name VARCHAR(120) NOT NULL, metadata JSONB DEFAULT '{}'::jsonb);
CREATE TABLE IF NOT EXISTS user_inventory (user_id INT, item_id BIGINT REFERENCES inventory_items(id), quantity INT DEFAULT 1, equipped BOOLEAN DEFAULT FALSE, acquired_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(user_id,item_id));
CREATE TABLE IF NOT EXISTS relationships (id BIGSERIAL PRIMARY KEY, user_a INT NOT NULL, user_b INT NOT NULL, ring_item_id BIGINT, started_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP, ended_at TIMESTAMPTZ, sent_a_to_b BIGINT DEFAULT 0, sent_b_to_a BIGINT DEFAULT 0);
CREATE TABLE IF NOT EXISTS agency_quotas (agency_id BIGINT, user_id INT, period_start DATE, period_end DATE, received_coins BIGINT DEFAULT 0, quota_target BIGINT DEFAULT 0, multiplier NUMERIC(6,2) DEFAULT 1, PRIMARY KEY(agency_id,user_id,period_start));
CREATE TABLE IF NOT EXISTS agency_room_quotas (agency_id BIGINT PRIMARY KEY, used_count INT DEFAULT 0, limit_count INT DEFAULT 0, updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS diamond_conversions (id BIGSERIAL PRIMARY KEY, user_id INT, diamonds BIGINT NOT NULL, coin_amount BIGINT NOT NULL, rate NUMERIC(12,4) NOT NULL, created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS game_catalog (id VARCHAR(80) PRIMARY KEY, name VARCHAR(120) NOT NULL, provider_code VARCHAR(80), enabled BOOLEAN DEFAULT FALSE, launch_path TEXT, metadata JSONB DEFAULT '{}'::jsonb);
CREATE TABLE IF NOT EXISTS game_achievements (id BIGSERIAL PRIMARY KEY, user_id INT, game_id VARCHAR(80), achievement_id VARCHAR(100), score BIGINT DEFAULT 0, badge_code VARCHAR(80), earned_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS feed_posts (id BIGSERIAL PRIMARY KEY, user_id INT, body TEXT, media_url TEXT, post_type VARCHAR(30) DEFAULT 'post', created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS room_coin_rains (id BIGSERIAL PRIMARY KEY, room_id VARCHAR(80), sender_user_id INT, amount BIGINT NOT NULL, created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS idx_game_achievements_user ON game_achievements(user_id);
CREATE INDEX IF NOT EXISTS idx_feed_posts_created ON feed_posts(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_room_reports_status ON room_reports(status);

-- =========================================================
-- Lymix Control Center / Admin & Trust-Safety schema
-- =========================================================
CREATE TABLE IF NOT EXISTS admin_roles (
  code VARCHAR(40) PRIMARY KEY,
  description VARCHAR(200) NOT NULL
);
CREATE TABLE IF NOT EXISTS admin_users (
  user_id INT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  role_code VARCHAR(40) REFERENCES admin_roles(code),
  enabled BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS admin_audit_log (
  id BIGSERIAL PRIMARY KEY,
  admin_user_id INT,
  action VARCHAR(80) NOT NULL,
  target_type VARCHAR(40),
  target_id VARCHAR(120),
  reason TEXT,
  before_json JSONB,
  after_json JSONB,
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_admin_audit_created ON admin_audit_log(created_at DESC);

CREATE TABLE IF NOT EXISTS user_admin_profile (
  user_id INT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  custom_public_id VARCHAR(32) UNIQUE,
  gender VARCHAR(20),
  is_broadcaster BOOLEAN DEFAULT FALSE,
  is_agency_owner BOOLEAN DEFAULT FALSE,
  is_moderator BOOLEAN DEFAULT FALSE,
  real_user_verified BOOLEAN DEFAULT FALSE,
  phone_e164 VARCHAR(24),
  phone_verified BOOLEAN DEFAULT FALSE,
  vip_level INT DEFAULT 0,
  level INT DEFAULT 1,
  admin_notes TEXT,
  updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS account_bans (
  id BIGSERIAL PRIMARY KEY,
  user_id INT REFERENCES users(id) ON DELETE CASCADE,
  reason TEXT NOT NULL,
  scope VARCHAR(40) DEFAULT 'account',
  expires_at TIMESTAMPTZ,
  created_by INT,
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  revoked_at TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS device_fingerprints (
  id BIGSERIAL PRIMARY KEY,
  user_id INT REFERENCES users(id) ON DELETE CASCADE,
  device_hash CHAR(64) NOT NULL,
  first_seen_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  last_seen_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_device_fp_hash ON device_fingerprints(device_hash);
CREATE TABLE IF NOT EXISTS ip_fingerprints (
  id BIGSERIAL PRIMARY KEY,
  user_id INT REFERENCES users(id) ON DELETE CASCADE,
  ip_hash CHAR(64) NOT NULL,
  first_seen_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  last_seen_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_ip_fp_hash ON ip_fingerprints(ip_hash);
CREATE TABLE IF NOT EXISTS device_bans (
  device_hash CHAR(64) PRIMARY KEY,
  reason TEXT NOT NULL,
  expires_at TIMESTAMPTZ,
  created_by INT,
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS ip_bans (
  ip_hash CHAR(64) PRIMARY KEY,
  reason TEXT NOT NULL,
  expires_at TIMESTAMPTZ,
  created_by INT,
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS agencies (
  id BIGSERIAL PRIMARY KEY,
  code VARCHAR(50) UNIQUE,
  name VARCHAR(120) NOT NULL,
  owner_user_id INT REFERENCES users(id),
  active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS agency_members (
  agency_id BIGINT REFERENCES agencies(id) ON DELETE CASCADE,
  user_id INT REFERENCES users(id) ON DELETE CASCADE,
  member_role VARCHAR(30) DEFAULT 'broadcaster',
  joined_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (agency_id, user_id)
);
CREATE TABLE IF NOT EXISTS agency_rooms (
  agency_id BIGINT REFERENCES agencies(id) ON DELETE CASCADE,
  room_id VARCHAR(80) NOT NULL,
  assigned_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (agency_id, room_id)
);

-- Manual identity/liveness review for broadcaster verification.
-- No automated face-recognition template or cross-account biometric matching is stored here.
CREATE TABLE IF NOT EXISTS verification_cases (
  id BIGSERIAL PRIMARY KEY,
  user_id INT REFERENCES users(id) ON DELETE CASCADE,
  verification_type VARCHAR(60) DEFAULT 'broadcaster_manual',
  status VARCHAR(30) DEFAULT 'PENDING',
  evidence_refs JSONB DEFAULT '[]'::jsonb,
  reviewer_user_id INT,
  reviewer_note TEXT,
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_verification_status ON verification_cases(status);

CREATE TABLE IF NOT EXISTS app_feature_flags (
  key VARCHAR(80) PRIMARY KEY,
  enabled BOOLEAN DEFAULT TRUE,
  config JSONB DEFAULT '{}'::jsonb,
  updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- VIP 1-10 + Lymix Crown 30-day membership cycle
ALTER TABLE users ADD COLUMN IF NOT EXISTS vip_cycle_start TIMESTAMPTZ;
ALTER TABLE users ADD COLUMN IF NOT EXISTS vip_cycle_end TIMESTAMPTZ;
ALTER TABLE users ADD COLUMN IF NOT EXISTS vip_cycle_load BIGINT DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS vip_lifetime_load BIGINT DEFAULT 0;
CREATE TABLE IF NOT EXISTS vip_cycle_history (
  id BIGSERIAL PRIMARY KEY,
  user_id INT NOT NULL,
  old_tier INT DEFAULT 0,
  new_tier INT DEFAULT 0,
  cycle_load BIGINT DEFAULT 0,
  action VARCHAR(40) NOT NULL,
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- V8.1 PAYMENT LEDGER / STORE PURCHASES
CREATE TABLE IF NOT EXISTS payment_transactions (
  id BIGSERIAL PRIMARY KEY,
  tx_id VARCHAR(255) UNIQUE NOT NULL,
  user_id BIGINT NOT NULL,
  platform VARCHAR(32) NOT NULL,
  sku VARCHAR(120) NOT NULL,
  gross_amount NUMERIC(18,4),
  currency VARCHAR(8),
  coins_granted BIGINT NOT NULL DEFAULT 0,
  status VARCHAR(32) NOT NULL DEFAULT 'pending',
  verified_at TIMESTAMPTZ,
  refunded_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_payment_transactions_user ON payment_transactions(user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS payout_reconciliation (
  id BIGSERIAL PRIMARY KEY,
  provider VARCHAR(32) NOT NULL,
  settlement_ref VARCHAR(255) UNIQUE,
  amount NUMERIC(18,4) NOT NULL,
  currency VARCHAR(8) NOT NULL,
  settlement_date DATE,
  status VARCHAR(32) NOT NULL DEFAULT 'pending',
  created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);
