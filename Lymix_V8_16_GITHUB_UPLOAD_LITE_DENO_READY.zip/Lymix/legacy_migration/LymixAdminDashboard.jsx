import React, { useMemo, useState } from 'react';
import {
  Activity, BadgeCheck, Ban, Building2, Coins, Fingerprint, Gauge,
  History, IdCard, Megaphone, Radio, Search, Settings, ShieldAlert,
  Smartphone, UserCog, Users, WalletCards
} from 'lucide-react';

const menu = [
  ['overview','Genel Bakış',Gauge], ['users','Kullanıcı Yönetimi',Users],
  ['security','Ban & Güvenlik',ShieldAlert], ['verification','Yayıncı Teyit',BadgeCheck],
  ['agencies','Ajans Yönetimi',Building2], ['rooms','Oda Moderasyonu',Radio],
  ['economy','Coin & Ekonomi',Coins], ['system','Sistem & Duyuru',Megaphone],
  ['settings','Uygulama Ayarları',Settings], ['audit','İşlem Geçmişi',History]
];

const demoUsers = [
  { id:'101', customId:'LYMIX101', name:'Oda Sahibi', role:'Ajans Sahibi', vip:3, coins:5000, diamonds:0, verified:true },
  { id:'102', customId:'LYMIX102', name:'Ahmet', role:'Yayıncı', vip:1, coins:1200, diamonds:0, verified:false },
  { id:'103', customId:'LYMIX103', name:'Ece', role:'Yayıncı', vip:2, coins:2500, diamonds:0, verified:true }
];

export default function LymixAdminDashboard() {
  const [tab, setTab] = useState('overview');
  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState(demoUsers[0]);
  const filtered = useMemo(() => demoUsers.filter(u => `${u.id} ${u.customId} ${u.name}`.toLowerCase().includes(query.toLowerCase())), [query]);

  const Card = ({title, value, hint}) => <div className="rounded-2xl border border-amber-400/15 bg-slate-900/70 p-5"><p className="text-xs text-slate-400">{title}</p><div className="mt-1 text-2xl font-black text-white">{value}</div>{hint && <p className="mt-1 text-xs text-amber-300">{hint}</p>}</div>;
  const Btn = ({children, danger=false}) => <button className={`rounded-xl px-3 py-2 text-xs font-bold ${danger ? 'bg-red-500/15 text-red-300 hover:bg-red-500/25' : 'bg-amber-400 text-slate-950 hover:bg-amber-300'}`}>{children}</button>;
  const Field = ({label, placeholder}) => <label className="block"><span className="mb-1 block text-xs text-slate-400">{label}</span><input placeholder={placeholder} className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-sm text-white outline-none focus:border-amber-400" /></label>;

  return <div className="min-h-screen bg-[#090d15] text-slate-100">
    <div className="flex min-h-screen">
      <aside className="w-72 border-r border-slate-800 bg-[#070a10] p-5">
        <div className="mb-7 flex items-center gap-3"><div className="grid h-11 w-11 place-items-center rounded-2xl bg-amber-400 text-xl font-black text-slate-950">L</div><div><div className="font-black">Lymix Control</div><div className="text-xs text-slate-500">Admin Center v2</div></div></div>
        <nav className="space-y-1">{menu.map(([id,label,Icon]) => <button key={id} onClick={()=>setTab(id)} className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-sm ${tab===id?'bg-amber-400 text-slate-950 font-bold':'text-slate-400 hover:bg-slate-900 hover:text-white'}`}><Icon size={18}/>{label}</button>)}</nav>
        <div className="mt-8 rounded-xl border border-slate-800 bg-slate-900/50 p-3 text-xs text-slate-500">Tüm kritik işlemler audit log'a yazılır. Üretimde JWT + rol bazlı yetki zorunludur.</div>
      </aside>

      <main className="flex-1 p-7">
        <div className="mb-6 flex items-center justify-between"><div><h1 className="text-2xl font-black">Lymix Yönetim Merkezi</h1><p className="text-sm text-slate-500">Kullanıcı, oda, ajans, ekonomi ve güvenlik kontrolü</p></div><div className="rounded-full border border-emerald-500/20 bg-emerald-500/10 px-4 py-2 text-xs font-bold text-emerald-300">● Sistem aktif</div></div>

        {tab==='overview' && <><div className="grid grid-cols-4 gap-4"><Card title="Toplam Kullanıcı" value="14.250"/><Card title="Aktif Odalar" value="38"/><Card title="Bekleyen Teyit" value="12" hint="Manuel inceleme"/><Card title="Bugünkü Admin İşlemi" value="86"/></div><div className="mt-5 grid grid-cols-3 gap-4"><Card title="Aktif Ajans" value="47"/><Card title="Cihaz Banı" value="31"/><Card title="Açık Şikayet" value="19"/></div></>}

        {tab==='users' && <div className="grid grid-cols-[1fr_1.1fr] gap-5">
          <section className="rounded-2xl border border-slate-800 bg-slate-900/50 p-5"><div className="mb-4 flex items-center gap-2"><Search size={18} className="text-amber-400"/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="ID, Lymix ID veya kullanıcı adı" className="w-full bg-transparent text-sm outline-none"/></div><div className="space-y-2">{filtered.map(u=><button key={u.id} onClick={()=>setSelected(u)} className={`w-full rounded-xl border p-3 text-left ${selected.id===u.id?'border-amber-400/60 bg-amber-400/5':'border-slate-800 bg-slate-950/40'}`}><div className="flex items-center justify-between"><span className="font-bold">{u.name}</span>{u.verified&&<BadgeCheck size={17} className="text-sky-400"/>}</div><div className="mt-1 text-xs text-slate-500">{u.customId} · {u.role} · VIP {u.vip}</div></button>)}</div></section>
          <section className="rounded-2xl border border-slate-800 bg-slate-900/50 p-5"><div className="mb-4 flex items-center gap-2"><UserCog className="text-amber-400"/><h2 className="font-black">{selected.name}</h2></div><div className="grid grid-cols-2 gap-3"><Field label="Özel Lymix ID" placeholder={selected.customId}/><Field label="Telefon" placeholder="+90..."/><Field label="VIP Seviye" placeholder={String(selected.vip)}/><Field label="Kullanıcı Seviye" placeholder="26"/></div><div className="mt-4 flex flex-wrap gap-2"><Btn>ID Değiştir</Btn><Btn>Yayıncı Yap</Btn><Btn>Ajans Sahibi Yap</Btn><Btn>Gerçek Kullanıcı Tiki</Btn><Btn danger>Hesabı Banla</Btn></div><div className="mt-5 border-t border-slate-800 pt-4"><div className="mb-2 text-xs font-bold text-slate-400">Bakiye düzeltme</div><div className="grid grid-cols-3 gap-2"><Field label="Coin" placeholder="5000"/><Field label="Elmas" placeholder="0"/><Field label="Sebep" placeholder="Admin düzeltmesi"/></div><div className="mt-3"><Btn>Bakiyeyi Güncelle</Btn></div></div></section>
        </div>}

        {tab==='security' && <div className="grid grid-cols-3 gap-4"><section className="rounded-2xl border border-slate-800 bg-slate-900/50 p-5"><Fingerprint className="mb-3 text-amber-400"/><h2 className="font-black">Cihaz Banı</h2><p className="mt-1 text-xs text-slate-500">Cihaz fingerprint'i hashlenerek engellenir.</p><div className="mt-4 space-y-3"><Field label="Device ID" placeholder="Cihaz kimliği"/><Field label="Sebep" placeholder="Çoklu hesap / ihlal"/><Btn>Cihazı Banla</Btn></div></section><section className="rounded-2xl border border-slate-800 bg-slate-900/50 p-5"><Smartphone className="mb-3 text-amber-400"/><h2 className="font-black">IP / Oturum Güvenliği</h2><div className="mt-4 space-y-3"><Field label="IP" placeholder="1.2.3.4"/><Field label="Süre" placeholder="7 gün / kalıcı"/><Btn>IP Banı Uygula</Btn></div></section><section className="rounded-2xl border border-slate-800 bg-slate-900/50 p-5"><Ban className="mb-3 text-red-400"/><h2 className="font-black">Hesap Banı</h2><div className="mt-4 space-y-3"><Field label="Kullanıcı ID" placeholder="101"/><Field label="Sebep" placeholder="İhlal nedeni"/><Btn danger>Banla & Oturumu Kapat</Btn></div></section></div>}

        {tab==='verification' && <div className="rounded-2xl border border-slate-800 bg-slate-900/50 p-5"><div className="flex items-center gap-3"><BadgeCheck className="text-sky-400"/><div><h2 className="font-black">Kadın Yayıncı Görüntü Teyit Kuyruğu</h2><p className="text-xs text-slate-500">Selfie/video kanıtı manuel incelenir. Onaylanan hesaba Gerçek Kullanıcı tiki verilir.</p></div></div><div className="mt-5 overflow-hidden rounded-xl border border-slate-800"><table className="w-full text-sm"><thead className="bg-slate-950 text-slate-500"><tr><th className="p-3 text-left">Kullanıcı</th><th className="p-3 text-left">Kanıt</th><th className="p-3 text-left">Çoklu Hesap Riski</th><th className="p-3 text-right">İşlem</th></tr></thead><tbody><tr className="border-t border-slate-800"><td className="p-3">Ece · LYMIX103</td><td className="p-3">Video + selfie</td><td className="p-3 text-amber-300">Aynı cihaz: yok</td><td className="p-3 text-right"><div className="flex justify-end gap-2"><Btn>Onayla + Tik</Btn><Btn danger>Reddet</Btn></div></td></tr></tbody></table></div><div className="mt-4 rounded-xl border border-amber-400/20 bg-amber-400/5 p-3 text-xs text-amber-200">Yüzü başka hesaplarda otomatik arayan biyometrik eşleştirme yerine telefon, cihaz fingerprint'i, IP ve manuel moderasyon sinyalleri kullanılır.</div></div>}

        {tab==='agencies' && <div className="grid grid-cols-2 gap-4"><section className="rounded-2xl border border-slate-800 bg-slate-900/50 p-5"><Building2 className="mb-3 text-amber-400"/><h2 className="font-black">Ajans Oluştur / Sahip Ata</h2><div className="mt-4 space-y-3"><Field label="Ajans adı" placeholder="Lymix Stars"/><Field label="Sahip kullanıcı ID" placeholder="101"/><Btn>Ajans Oluştur</Btn></div></section><section className="rounded-2xl border border-slate-800 bg-slate-900/50 p-5"><Users className="mb-3 text-amber-400"/><h2 className="font-black">Yayıncı & Oda Ata</h2><div className="mt-4 space-y-3"><Field label="Ajans ID" placeholder="agency_1"/><Field label="Yayıncı ID" placeholder="103"/><Field label="Oda ID" placeholder="room_999"/><div className="flex gap-2"><Btn>Yayıncı Ekle</Btn><Btn>Odayı Ajans Yap</Btn></div></div></section></div>}

        {tab==='rooms' && <div className="rounded-2xl border border-slate-800 bg-slate-900/50 p-5"><h2 className="font-black">Canlı Oda Moderasyonu</h2><div className="mt-4 grid grid-cols-4 gap-3"><Field label="Oda ID" placeholder="room_999"/><Field label="Yeni başlık" placeholder="Oda adı"/><Field label="Sebep" placeholder="Moderasyon nedeni"/><div className="flex items-end gap-2"><Btn>Kilitle</Btn><Btn danger>Askıya Al</Btn></div></div></div>}

        {tab==='economy' && <div className="grid grid-cols-2 gap-4"><section className="rounded-2xl border border-slate-800 bg-slate-900/50 p-5"><WalletCards className="mb-3 text-amber-400"/><h2 className="font-black">Coin / Elmas Oranları</h2><div className="mt-4 space-y-3"><Field label="Elmas → Coin oranı" placeholder="1.00"/><Field label="Hediye yayıncı payı" placeholder="0.70"/><Field label="Minimum çekim elması" placeholder="10000"/><Btn>Oranları Kaydet</Btn></div></section><section className="rounded-2xl border border-slate-800 bg-slate-900/50 p-5"><Coins className="mb-3 text-amber-400"/><h2 className="font-black">Manuel Bakiye İşlemi</h2><div className="mt-4 space-y-3"><Field label="Kullanıcı ID" placeholder="101"/><Field label="Miktar" placeholder="50000"/><Field label="İşlem nedeni" placeholder="Kampanya / düzeltme"/><Btn>İşlemi Uygula</Btn></div></section></div>}

        {tab==='system' && <div className="rounded-2xl border border-slate-800 bg-slate-900/50 p-5"><Megaphone className="mb-3 text-amber-400"/><h2 className="font-black">Sistem Mesajı / Duyuru</h2><div className="mt-4 grid grid-cols-2 gap-3"><Field label="Hedef kullanıcı/oda (boş=herkes)" placeholder="room_999"/><Field label="Başlık" placeholder="Lymix Duyuru"/><div className="col-span-2"><Field label="Mesaj" placeholder="Duyuru metni"/></div></div><div className="mt-3"><Btn>Gönder</Btn></div></div>}

        {tab==='settings' && <div className="grid grid-cols-3 gap-4">{['Oda hediye efektleri','VIP giriş efektleri','Coin yağmuru','Oyun merkezi','Lymix Akış','Ajans sistemi'].map(x=><div key={x} className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-900/50 p-4"><span className="text-sm font-bold">{x}</span><span className="rounded-full bg-emerald-500/15 px-3 py-1 text-xs font-bold text-emerald-300">AÇIK</span></div>)}</div>}

        {tab==='audit' && <div className="rounded-2xl border border-slate-800 bg-slate-900/50 p-5"><div className="mb-4 flex items-center gap-2"><Activity className="text-amber-400"/><h2 className="font-black">Admin Audit Log</h2></div><div className="space-y-2">{['Coin bakiyesi düzeltildi · kullanıcı 101','Ajans sahibi atandı · kullanıcı 101','Gerçek kullanıcı tiki onaylandı · kullanıcı 103','Oda başlığı güncellendi · room_999'].map((x,i)=><div key={i} className="rounded-xl border border-slate-800 bg-slate-950/50 p-3 text-sm"><span className="font-bold">{x}</span><span className="float-right text-xs text-slate-500">admin · az önce</span></div>)}</div></div>}
      </main>
    </div>
  </div>;
}
