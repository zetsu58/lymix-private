-- 1. Var olan tabloları temizle (Yeniden kurulumlarda çakışmayı önler)
DROP TABLE IF EXISTS messages CASCADE;
DROP TABLE IF EXISTS users CASCADE;

-- 2. Kullanıcılar Tablosu
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 3. Mesajlar / Oturum Tablosu (Örnek ilişki)
CREATE TABLE messages (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    sent_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 4. Performans için İndeksler (İsteğe Bağlı)
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_messages_user_id ON messages(user_id);
-- Lymix extended social/game/economy modules
CREATE TABLE IF NOT EXISTS user_profiles (
  user_id INT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  age INT, vip_level INT DEFAULT 0, level INT DEFAULT 1,
  sent_coins BIGINT DEFAULT 0, received_coins BIGINT DEFAULT 0,
  personal_room_id VARCHAR(80), updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS room_events (id BIGSERIAL PRIMARY KEY, room_id VARCHAR(80) NOT NULL, title VARCHAR(160) NOT NULL, starts_at TIMESTAMPTZ, ends_at TIMESTAMPTZ, payload JSONB DEFAULT '{}'::jsonb);
CREATE TABLE IF NOT EXISTS room_reports (id BIGSERIAL PRIMARY KEY, reporter_user_id INT, room_id VARCHAR(80), target_user_id INT, reason VARCHAR(80), details TEXT, status VARCHAR(30) DEFAULT 'open', created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS system_messages (id BIGSERIAL PRIMARY KEY, user_id INT, room_id VARCHAR(80), message_type VARCHAR(50), content TEXT NOT NULL, created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS vip_progress (user_id INT PRIMARY KEY, vip_level INT DEFAULT 0, load_total BIGINT DEFAULT 0, threshold_next BIGINT DEFAULT 50000, updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS inventory_items (id BIGSERIAL PRIMARY KEY, code VARCHAR(80) UNIQUE NOT NULL, item_type VARCHAR(40) NOT NULL, name VARCHAR(120) NOT NULL, metadata JSONB DEFAULT '{}'::jsonb);
CREATE TABLE IF NOT EXISTS user_inventory (user_id INT, item_id BIGINT REFERENCES inventory_items(id), quantity INT DEFAULT 1, equipped BOOLEAN DEFAULT FALSE, acquired_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(user_id,item_id));
CREATE TABLE IF NOT EXISTS relationships (id BIGSERIAL PRIMARY KEY, user_a INT NOT NULL, user_b INT NOT NULL, ring_item_id BIGINT, started_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP, ended_at TIMESTAMPTZ, sent_a_to_b BIGINT DEFAULT 0, sent_b_to_a BIGINT DEFAULT 0);
CREATE TABLE IF NOT EXISTS agency_quotas (agency_id BIGINT, user_id INT, period_start DATE, period_end DATE, received_coins BIGINT DEFAULT 0, quota_target BIGINT DEFAULT 0, multiplier NUMERIC(6,2) DEFAULT 1, PRIMARY KEY(agency_id,user_id,period_start));
CREATE TABLE IF NOT EXISTS agency_room_quotas (agency_id BIGINT PRIMARY KEY, used_count INT DEFAULT 0, limit_count INT DEFAULT 0, updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS diamond_conversions (id BIGSERIAL PRIMARY KEY, user_id INT, diamonds BIGINT NOT NULL, coin_amount BIGINT NOT NULL, rate NUMERIC(12,4) NOT NULL, created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS game_catalog (id VARCHAR(80) PRIMARY KEY, name VARCHAR(120) NOT NULL, provider_code VARCHAR(80), enabled BOOLEAN DEFAULT FALSE, launch_path TEXT, metadata JSONB DEFAULT '{}'::jsonb);
CREATE TABLE IF NOT EXISTS game_achievements (id BIGSERIAL PRIMARY KEY, user_id INT, game_id VARCHAR(80), achievement_id VARCHAR(100), score BIGINT DEFAULT 0, badge_code VARCHAR(80), earned_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS feed_posts (id BIGSERIAL PRIMARY KEY, user_id INT, body TEXT, media_url TEXT, post_type VARCHAR(30) DEFAULT 'post', created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS room_coin_rains (id BIGSERIAL PRIMARY KEY, room_id VARCHAR(80), sender_user_id INT, amount BIGINT NOT NULL, created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS idx_game_achievements_user ON game_achievements(user_id);
CREATE INDEX IF NOT EXISTS idx_feed_posts_created ON feed_posts(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_room_reports_status ON room_reports(status);

-- V8.7 Ajans ailesi / özel ajans sohbeti
CREATE TABLE IF NOT EXISTS agency_family_members (
  agency_id BIGINT NOT NULL,
  user_id BIGINT NOT NULL,
  role VARCHAR(30) NOT NULL DEFAULT 'MEMBER',
  approved_by BIGINT,
  approved_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (agency_id, user_id)
);
CREATE TABLE IF NOT EXISTS agency_family_join_requests (
  id BIGSERIAL PRIMARY KEY,
  agency_id BIGINT NOT NULL,
  user_id BIGINT NOT NULL,
  note VARCHAR(300),
  status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
  reviewed_by BIGINT,
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (agency_id, user_id, status)
);
CREATE TABLE IF NOT EXISTS agency_family_messages (
  id BIGSERIAL PRIMARY KEY,
  agency_id BIGINT NOT NULL,
  sender_user_id BIGINT NOT NULL,
  content VARCHAR(500) NOT NULL,
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_agency_family_messages_agency_created ON agency_family_messages(agency_id, created_at DESC);
