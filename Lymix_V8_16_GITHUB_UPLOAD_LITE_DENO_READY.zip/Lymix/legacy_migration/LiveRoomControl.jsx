// admin/components/LiveRoomControl.jsx
import React, { useState, useEffect } from 'react';
import axios from 'axios';

export default function LiveRoomControl({ roomId, channelName }) {
  const [roomStats, setRoomStats] = useState(null);
  const [isMuted, setIsMuted] = useState(false);

  useEffect(() => {
    const fetchStats = async () => {
      const res = await axios.get(`/api/admin/rooms/${roomId}/stats`);
      setRoomStats(res.data);
    };
    fetchStats();
    const interval = setInterval(fetchStats, 3000); // 3 sn'de bir canlı metrik güncelleme
    return () => clearInterval(interval);
  }, [roomId]);

  // Agora Kanalındaki Yayıncıyı Susturma (Mute Host)
  const toggleMuteHost = async () => {
    await axios.post('/api/admin/agora/mute-user', {
      channelName,
      uid: roomStats?.hostUid,
      mute: !isMuted,
    });
    setIsMuted(!isMuted);
  };

  // Odayı Kapatma ve Kanalı Düşürme (Force Terminate)
  const terminateRoom = async () => {
    if (confirm("Bu canlı odayı kapatmak ve tüm kullanıcıları çıkarmak istediğinize emin misiniz?")) {
      await axios.post('/api/admin/rooms/terminate', { roomId, channelName });
      alert("Oda başarıyla kapatıldı.");
    }
  };

  return (
    <div className="p-6 bg-slate-900 text-white rounded-xl shadow-lg border border-slate-800">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-xl font-bold">Oda Kontrolü: #{channelName}</h3>
        <span className="px-3 py-1 bg-green-500/20 text-green-400 rounded-full text-sm">
          🟢 CANLI ({roomStats?.listenerCount || 0} Dinleyici)
        </span>
      </div>

      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="bg-slate-800 p-4 rounded-lg">
          <p className="text-gray-400 text-sm">Ses Gecikmesi (RTT)</p>
          <p className="text-2xl font-bold">{roomStats?.audioDelay || 0} ms</p>
        </div>
        <div className="bg-slate-800 p-4 rounded-lg">
          <p className="text-gray-400 text-sm">Toplam Harcanan Coin</p>
          <p className="text-2xl font-bold text-amber-400">{roomStats?.coinsSpent || 0} 🪙</p>
        </div>
        <div className="bg-slate-800 p-4 rounded-lg">
          <p className="text-gray-400 text-sm">Paket Kaybı (Loss)</p>
          <p className="text-2xl font-bold text-blue-400">%{roomStats?.packetLoss || 0}</p>
        </div>
      </div>

      <div className="flex space-x-4">
        <button 
          onClick={toggleMuteHost}
          className={`px-4 py-2 rounded-lg font-semibold ${isMuted ? 'bg-amber-600' : 'bg-slate-700'}`}
        >
          {isMuted ? "Yayıncı Sesi Aç" : "Yayıncıyı Sustur (Mute)"}
        </button>
        <button 
          onClick={terminateRoom}
          className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-semibold"
        >
          Odayı Kapat ve Yayıncıyı Banla
        </button>
      </div>
    </div>
  );
}