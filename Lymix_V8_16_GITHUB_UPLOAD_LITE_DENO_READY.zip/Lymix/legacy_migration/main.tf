# main.tf - Alibaba Cloud Infrastructure Automation
terraform {
  required_providers {
    alicloud = {
      source  = "aliyun/alicloud"
      version = "~> 1.200.0"
    }
  }
}

provider "alicloud" {
  region = "eu-central-1" # Frankfurt / Almanya Lokasyonu
}

# 1. VPC & Subnet Oluşturma
resource "alicloud_vpc" "lymix_vpc" {
  vpc_name   = "lymix-vpc"
  cidr_block = "172.16.0.0/16"
}

resource "alicloud_vswitch" "lymix_vswitch" {
  vpc_id       = alicloud_vpc.lymix_vpc.id
  cidr_block   = "172.16.1.0/24"
  zone_id      = "eu-central-1a"
}

# 2. Object Storage (OSS) Bucket - Hediyeler ve Avatarlar için
resource "alicloud_oss_bucket" "lymix_bucket" {
  bucket = "lymix-media-assets-prod"
  acl    = "public-read"
}

# 3. ApsaraDB for RDS (PostgreSQL Instance)
resource "alicloud_db_instance" "lymix_rds" {
  engine           = "PostgreSQL"
  engine_version   = "15.0"
  instance_type    = "pg.n2.medium.1" # 2 vCPU, 4GB RAM
  instance_storage = 50
  vswitch_id       = alicloud_vswitch.lymix_vswitch.id
  security_ips     = ["0.0.0.0/0"]
}