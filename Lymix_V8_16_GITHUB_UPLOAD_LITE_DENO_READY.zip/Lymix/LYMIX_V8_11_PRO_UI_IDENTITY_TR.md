# LYMIX V8.11 — Professional UI + Cross-Platform Identity

Bu sürümde yapılan ana iyileştirmeler:

- LYMIX marka paleti uygulama genelinde standartlaştırıldı:
  - #FFD643 altın
  - #FFB000 amber
  - #FF4DCC magenta
  - #8A2BE2 mor
  - koyu premium arka planlar
- Ana ekran, profil, ayarlar, dil ekranı ve oda kontrolleri daha profesyonel ve tutarlı hale getirildi.
- Admin koltuk menüsü küçük ekranlarda daha rahat kullanılacak 2x2 yönetim kartı düzenine geçirildi.
- Normal kullanıcı boş/açık koltuğa doğrudan oturur; admin/oda sahibi yönetim menüsü görür.
- Kullanıcıların kendi TTF/OTF yazı tiplerini yükleyebilmesi için istemci + backend altyapısı eklendi.
- Kullanıcıların kendi profil simgesini PNG/JPG/WebP olarak yükleyebilmesi eklendi.
- Simge backend tarafında 512x512 WebP formatına normalize edilir; EXIF yönü ve alfa kanalı düzeltilir.
- Font için kalıcı family adı ve SHA-256 checksum üretilir.
- Özel font yüklenemezse otomatik Lymix Sans/varsayılan font fallback'i kullanılır.
- Profil ve oda koltuk isimleri uzak kullanıcı kimliği font/simgesini güvenli şekilde gösterebilir.
- Dil ekranı yeniden düzenlendi; belirgin Türkçe kısaltma/imla sorunları düzeltildi.
- Profil Kimliği ve Ayarlar ekranları eklendi.
- Backend'e /api/profile-identity/:userId uçları eklendi.
- Backend bağımlılıkları: multer + sharp.

Üretim notu:
Flutter uygulaması backend adresini `--dart-define=LYMIX_API_BASE=https://api.senin-domainin.com`
ile almalıdır. HTTPS zorunlu kullanılmalıdır. Font/simge dosyaları üretimde yerel disk yerine CDN/object storage'a taşınmalıdır.
