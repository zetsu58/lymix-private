# LYMIX Reklam / Gerçek Uygulama Ekranı Çekim Planı

Ana slogan: **LYMIX — Sesinle Bağlan, Dünyanı Paylaş.**

Reklam görselleri uygulamanın gerçek UI tasarım sistemini göstermelidir. Kullanıcı adları, mesajlar,
oda adları ve sayılar yalnızca demo veridir.

8 çekim:
1. Keşfet — dolu oda kartları + canlı göstergeler.
2. Sesli oda — aktif konuşmacı halkası, 9 koltuk, sohbet ve hediye CTA.
3. Hediye anı — LYMIX altın/mor hediye animasyonu ve gönderici bildirimi.
4. Plaza — canlı sosyal akış + odaya katıl CTA.
5. Oyun Merkezi — oyun kartları + odada birlikte oynama.
6. Mesaj — aktivite, bildirim, ziyaretçiler ve gerçekçi konuşmalar.
7. Profil/VIP — rozetler, seviye, başarı ve premium kimlik.
8. Creator/Agency — yayıncı merkezi, performans ve topluluk yönetimi.

Görsel dil: koyu premium zemin; LYMIX sarısı/altını birincil; mor ikincil; büyük boşluklar,
yüksek kontrastlı tipografi, 20–28px yuvarlatılmış kartlar; kontrollü glow; kalabalık fakat okunabilir UI.
