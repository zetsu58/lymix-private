import 'package:flutter/material.dart';
import '../services/localization_service.dart';
import '../theme/lymix_theme.dart';

class LanguageScreen extends StatelessWidget {
  final LymixLocaleController controller;
  const LanguageScreen({super.key, required this.controller});

  static const notes = <String,String>{
    'tr':'Türkçe',
    'en':'English',
    'de':'Deutsch',
    'it':'Italiano',
    'ru':'Русский',
    'hi':'हिन्दी',
    'az':'Azərbaycan türkcəsi',
  };

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Dil')),
    body:ListView(
      padding:const EdgeInsets.fromLTRB(16,8,16,24),
      children:[
        Container(
          padding:const EdgeInsets.all(15),
          decoration:BoxDecoration(
            gradient:const LinearGradient(colors:[Color(0xFF20142B),Color(0xFF110D18)]),
            borderRadius:BorderRadius.circular(20),
            border:Border.all(color:Color(0x33FFD643)),
          ),
          child:const Row(children:[
            Icon(Icons.translate_rounded,color:LymixColors.gold),
            SizedBox(width:10),
            Expanded(child:Text('Uygulama dilini seç. Metinler seçilen dile göre tutarlı ve okunaklı gösterilir.',style:TextStyle(color:Colors.white60,fontSize:11,height:1.35))),
          ]),
        ),
        const SizedBox(height:14),
        ...LymixLocaleController.supported.map((l){
          final selected=controller.locale==l;
          return Container(
            margin:const EdgeInsets.only(bottom:8),
            decoration:BoxDecoration(
              color:selected?const Color(0xFF1E1526):const Color(0xFF120E1A),
              borderRadius:BorderRadius.circular(17),
              border:Border.all(color:selected?const Color(0x66FFD643):Colors.white.withValues(alpha: .05)),
            ),
            child:RadioListTile<Locale>(
              value:l,
              groupValue:controller.locale,
              activeColor:LymixColors.gold,
              title:Text(notes[l.languageCode]??l.languageCode,style:TextStyle(fontWeight:selected?FontWeight.w800:FontWeight.w600)),
              secondary:Icon(selected?Icons.check_circle_rounded:Icons.language_rounded,color:selected?LymixColors.gold:Colors.white38),
              onChanged:(v){if(v!=null)controller.setLocale(v);},
            ),
          );
        }),
      ],
    ),
  );
}
