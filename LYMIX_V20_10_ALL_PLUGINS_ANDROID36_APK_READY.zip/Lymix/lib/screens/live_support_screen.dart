import 'package:flutter/material.dart';

class LiveSupportScreen extends StatefulWidget {
  const LiveSupportScreen({super.key});

  @override
  State<LiveSupportScreen> createState() => _LiveSupportScreenState();
}

class _LiveSupportScreenState extends State<LiveSupportScreen> {
  final List<Map<String, dynamic>> _messages = <Map<String, dynamic>>[
    <String, dynamic>{
      'me': false,
      'text': 'Merhaba, nasıl yardımcı olabiliriz?',
      'seen': true,
    },
  ];

  final TextEditingController _controller = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _sendMessage() {
    final String text = _controller.text.trim();
    if (text.isEmpty) return;

    setState(() {
      _messages.add(<String, dynamic>{
        'me': true,
        'text': text,
        'seen': false,
      });
    });
    _controller.clear();

    Future<void>.delayed(const Duration(seconds: 1), () {
      if (!mounted || _messages.isEmpty) return;
      setState(() {
        _messages.last['seen'] = true;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Canlı Destek • Çevrimiçi'),
      ),
      body: Column(
        children: <Widget>[
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: _messages.length,
              itemBuilder: (BuildContext context, int index) {
                final Map<String, dynamic> message = _messages[index];
                final bool isMe = message['me'] == true;
                final bool seen = message['seen'] == true;

                return Align(
                  alignment: isMe
                      ? Alignment.centerRight
                      : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 10,
                    ),
                    decoration: BoxDecoration(
                      color: isMe
                          ? const Color(0x33FFC928)
                          : Colors.white.withValues(alpha: 0.06),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: <Widget>[
                        Text(message['text'] as String? ?? ''),
                        if (isMe)
                          Padding(
                            padding: const EdgeInsets.only(top: 4),
                            child: Text(
                              seen ? 'Görüldü ✓✓' : 'Gönderildi ✓',
                              style: TextStyle(
                                fontSize: 9,
                                color: Colors.white.withValues(alpha: 0.38),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      textInputAction: TextInputAction.send,
                      onSubmitted: (_) => _sendMessage(),
                      decoration: const InputDecoration(
                        hintText: 'Mesajınızı yazın...',
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: _sendMessage,
                    icon: const Icon(
                      Icons.send_rounded,
                      color: Color(0xFFFFC928),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
