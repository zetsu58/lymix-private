import 'package:flutter/material.dart';
import '../design/lymix_design_system.dart';
import '../economy/quota_economy.dart';

class AgencyCoinBankScreen extends StatelessWidget {
  final String agencyName;
  final int bankCoins;
  final int pendingCredits;
  final int settledCredits;

  const AgencyCoinBankScreen({
    super.key,
    this.agencyName = 'Ajans',
    this.bankCoins = 0,
    this.pendingCredits = 0,
    this.settledCredits = 0,
  });

  @override
  Widget build(BuildContext context) {
    const policy = QuotaEconomyPolicy.defaults;

    return Scaffold(
      appBar: AppBar(title: const Text('Ajans Coin Bankası')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          LymixGlassSurface(
            elevated: true,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const LymixPremiumBadge(
                  'AGENCY BANK',
                  icon: Icons.account_balance_rounded,
                ),
                const SizedBox(height: 12),
                Text(
                  agencyName,
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 6),
                const Text(
                  'Yayıncıların geri dönüş coinleri ve ajans settlement hareketleri burada izlenir.',
                  style: TextStyle(
                    color: LymixPalette.text2,
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(child: _metric('Bank Coin', bankCoins, Icons.toll_rounded)),
              const SizedBox(width: 10),
              Expanded(child: _metric('Bekleyen', pendingCredits, Icons.schedule_rounded)),
            ],
          ),
          const SizedBox(height: 10),
          _metric('Settled Kazanç Kredisi', settledCredits, Icons.verified_rounded),
          const SizedBox(height: 18),
          const Text(
            'Kota Politikası',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 8),
          ...policy.tiers.map((p) => Card(
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: giftColor(p.tier).withValues(alpha: .12),
                    child: Icon(Icons.auto_awesome_rounded, color: giftColor(p.tier)),
                  ),
                  title: Text(p.tier.name.toUpperCase()),
                  subtitle: Text(
                    'Kota %${(p.quotaWeightBps / 100).toStringAsFixed(0)} • '
                    'Geri coin %${(p.recyclableCoinBps / 100).toStringAsFixed(1)} • '
                    'Host %${(p.hostEarningBps / 100).toStringAsFixed(0)} • '
                    'Ajans %${(p.agencyCommissionBps / 100).toStringAsFixed(1)}',
                  ),
                ),
              )),
          const SizedBox(height: 14),
          const Text(
            'Gerçek para ödemesi uygulama içinden yapılmaz. KYC, ülke uygunluğu, chargeback süresi ve ödeme sağlayıcısı doğrulaması sonrası backend settlement üretir.',
            style: TextStyle(color: LymixPalette.text3, fontSize: 10),
          ),
        ],
      ),
    );
  }

  Widget _metric(String label, int value, IconData icon) => LymixGlassSurface(
        child: Row(children: [
          Icon(icon, color: LymixPalette.gold),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: const TextStyle(
                      color: LymixPalette.text3,
                      fontSize: 9,
                    )),
                const SizedBox(height: 3),
                Text(
                  '$value',
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
          ),
        ]),
      );

  Color giftColor(GiftTier tier) => switch (tier) {
        GiftTier.spark => LymixPalette.gold,
        GiftTier.social => LymixPalette.violet,
        GiftTier.premium => LymixPalette.purple,
        GiftTier.epic => LymixPalette.cyan,
        GiftTier.legend => LymixPalette.amber,
      };
}
