import '../models/gift_model.dart';

enum SettlementStatus { pending, locked, settled, reversed }

class QuotaTierPolicy {
  final GiftTier tier;
  final int quotaWeightBps;
  final int recyclableCoinBps;
  final int hostEarningBps;
  final int agencyCommissionBps;

  const QuotaTierPolicy({
    required this.tier,
    required this.quotaWeightBps,
    required this.recyclableCoinBps,
    required this.hostEarningBps,
    required this.agencyCommissionBps,
  });
}

class QuotaEconomyPolicy {
  final int dailyQuotaTarget;
  final int monthlyQuotaTarget;
  final int settlementLockHours;
  final List<QuotaTierPolicy> tiers;

  const QuotaEconomyPolicy({
    required this.dailyQuotaTarget,
    required this.monthlyQuotaTarget,
    required this.settlementLockHours,
    required this.tiers,
  });

  static const defaults = QuotaEconomyPolicy(
    dailyQuotaTarget: 25_000,
    monthlyQuotaTarget: 750_000,
    settlementLockHours: 72,
    tiers: [
      QuotaTierPolicy(
        tier: GiftTier.spark,
        quotaWeightBps: 1200,
        recyclableCoinBps: 300,
        hostEarningBps: 2500,
        agencyCommissionBps: 300,
      ),
      QuotaTierPolicy(
        tier: GiftTier.social,
        quotaWeightBps: 1800,
        recyclableCoinBps: 400,
        hostEarningBps: 3000,
        agencyCommissionBps: 400,
      ),
      QuotaTierPolicy(
        tier: GiftTier.premium,
        quotaWeightBps: 2400,
        recyclableCoinBps: 500,
        hostEarningBps: 3500,
        agencyCommissionBps: 500,
      ),
      QuotaTierPolicy(
        tier: GiftTier.epic,
        quotaWeightBps: 3000,
        recyclableCoinBps: 650,
        hostEarningBps: 4000,
        agencyCommissionBps: 600,
      ),
      QuotaTierPolicy(
        tier: GiftTier.legend,
        quotaWeightBps: 3800,
        recyclableCoinBps: 800,
        hostEarningBps: 4500,
        agencyCommissionBps: 700,
      ),
    ],
  );

  QuotaTierPolicy forTier(GiftTier tier) =>
      tiers.firstWhere((e) => e.tier == tier);
}

class GiftSettlementPreview {
  final int grossGiftCoins;
  final int quotaPoints;
  final int recyclableCoins;
  final int hostEarnedCredits;
  final int agencyEarnedCredits;
  final int platformRemainderCredits;
  final SettlementStatus status;

  const GiftSettlementPreview({
    required this.grossGiftCoins,
    required this.quotaPoints,
    required this.recyclableCoins,
    required this.hostEarnedCredits,
    required this.agencyEarnedCredits,
    required this.platformRemainderCredits,
    this.status = SettlementStatus.pending,
  });
}

class QuotaEconomyEngine {
  final QuotaEconomyPolicy policy;
  const QuotaEconomyEngine([this.policy = QuotaEconomyPolicy.defaults]);

  int _bps(int value, int bps) => (value * bps / 10000).floor();

  GiftSettlementPreview preview({
    required LymixGiftItem gift,
    int quantity = 1,
    required bool receiverHasAgency,
  }) {
    final gross = gift.coins * quantity;
    final tier = policy.forTier(gift.tier);

    final quota = _bps(gross, tier.quotaWeightBps);
    final recyclable = _bps(gross, tier.recyclableCoinBps);
    final host = _bps(gross, tier.hostEarningBps);
    final agency =
        receiverHasAgency ? _bps(gross, tier.agencyCommissionBps) : 0;

    final remainder = (gross - recyclable - host - agency).clamp(0, gross);

    return GiftSettlementPreview(
      grossGiftCoins: gross,
      quotaPoints: quota,
      recyclableCoins: recyclable,
      hostEarnedCredits: host,
      agencyEarnedCredits: agency,
      platformRemainderCredits: remainder,
    );
  }
}

class QuotaProgress {
  final int current;
  final int target;
  const QuotaProgress({required this.current, required this.target});

  double get ratio => target <= 0 ? 0 : (current / target).clamp(0, 1);
  bool get completed => current >= target;
}
