
import 'package:flutter/material.dart';
import 'lymix_pro_theme.dart';

class LymixProShowcase extends StatefulWidget {
  const LymixProShowcase({super.key});
  @override State<LymixProShowcase> createState()=>_LymixProShowcaseState();
}
class _LymixProShowcaseState extends State<LymixProShowcase> {
  int index=0;
  final List<Widget> pages = const <Widget>[
    DiscoverPage(),
    SocialPage(),
    GameCenterPage(),
    InboxPage(),
    ProfilePage(),
  ];
  @override Widget build(BuildContext context)=>Scaffold(
    body: SafeArea(child: pages[index]),
    bottomNavigationBar: NavigationBar(
      selectedIndex:index,
      onDestinationSelected:(v)=>setState(()=>index=v),
      destinations: const [
        NavigationDestination(icon:Icon(Icons.home_rounded),label:'Keşfet'),
        NavigationDestination(icon:Icon(Icons.public_rounded),label:'Plaza'),
        NavigationDestination(icon:Icon(Icons.sports_esports_rounded),label:'Oyun'),
        NavigationDestination(icon:Icon(Icons.chat_bubble_rounded),label:'Mesaj'),
        NavigationDestination(icon:Icon(Icons.person_rounded),label:'Profil'),
      ],
    ),
  );
}
class Head extends StatelessWidget {
 final String title; const Head(this.title,{super.key});
 @override Widget build(BuildContext c)=>Padding(padding:const EdgeInsets.fromLTRB(20,18,20,12),
 child:Row(children:[ShaderMask(shaderCallback:(r)=>LymixPro.brandGradient.createShader(r),
 child:const Text('LYMIX',style:TextStyle(fontSize:27,fontWeight:FontWeight.w900,color:Colors.white,letterSpacing:1.5))),
 const Spacer(),Text(title,style:const TextStyle(fontWeight:FontWeight.w700)),const SizedBox(width:12),
 const CircleAvatar(backgroundColor:LymixPro.panel2,child:Icon(Icons.search_rounded))]));
}
class DiscoverPage extends StatelessWidget {
 const DiscoverPage({super.key});
 @override Widget build(BuildContext c)=>ListView(children:[
 const Head('Parti'),
 Container(margin:const EdgeInsets.all(16),height:145,decoration:BoxDecoration(gradient:LymixPro.premiumGradient,borderRadius:BorderRadius.circular(28)),
 child:const Padding(padding:EdgeInsets.all(22),child:Column(crossAxisAlignment:CrossAxisAlignment.start,mainAxisAlignment:MainAxisAlignment.end,children:[
 Text('SESİNİ GÖSTER',style:TextStyle(fontSize:25,fontWeight:FontWeight.w900)),Text('Sohbet • Topluluk • Eğlence',style:TextStyle(color:Colors.white70))]))),
 const _Tabs(), const _Room(name:'Gece Sohbeti',sub:'Müzik • Muhabbet',people:'53',icon:Icons.mic_rounded),
 const _Room(name:'Yeni İnsanlar, Yeni Sesler',sub:'LYMIX Topluluğu',people:'46',icon:Icons.auto_awesome),
 const _Room(name:'VIP Lounge',sub:'Premium oda',people:'28',icon:Icons.workspace_premium_rounded),
 ]);
}
class _Tabs extends StatelessWidget { const _Tabs();
 @override Widget build(BuildContext c)=>const Padding(padding:EdgeInsets.symmetric(horizontal:16,vertical:6),
 child:Wrap(spacing:8,children:[Chip(label:Text('⭐ Önerilen')),Chip(label:Text('🇹🇷 Türkiye')),Chip(label:Text('🌍 Global')),Chip(label:Text('🎵 Müzik'))]));}
class _Room extends StatelessWidget {
 final String name,sub,people; final IconData icon; const _Room({required this.name,required this.sub,required this.people,required this.icon});
 @override Widget build(BuildContext c)=>Container(margin:const EdgeInsets.fromLTRB(16,8,16,8),padding:const EdgeInsets.all(14),
 decoration:BoxDecoration(color:LymixPro.panel,borderRadius:BorderRadius.circular(24)),
 child:Row(children:[Container(width:76,height:76,decoration:BoxDecoration(gradient:LymixPro.brandGradient,borderRadius:BorderRadius.circular(20)),child:Icon(icon,size:34,color:LymixPro.bg)),
 const SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(name,style:const TextStyle(fontSize:17,fontWeight:FontWeight.w800)),const SizedBox(height:7),Text(sub,style:const TextStyle(color:LymixPro.muted)),const SizedBox(height:8),
 const Row(children:[CircleAvatar(radius:10,backgroundColor:LymixPro.purple),SizedBox(width:4),CircleAvatar(radius:10,backgroundColor:LymixPro.yellow),SizedBox(width:4),CircleAvatar(radius:10,backgroundColor:Colors.blueGrey)])])),
 Text('▮▮ $people',style:const TextStyle(color:LymixPro.yellow,fontWeight:FontWeight.bold))]));
}
class SocialPage extends StatelessWidget {
 const SocialPage({super.key});

 @override
 Widget build(BuildContext c) => ListView(
   children: [
     const Head('Plaza'),
     ...List.generate(
       4,
       (i) => Container(
         margin: const EdgeInsets.all(16),
         padding: const EdgeInsets.all(18),
         decoration: BoxDecoration(
           color: LymixPro.panel,
           borderRadius: BorderRadius.circular(24),
         ),
         child: Column(
           crossAxisAlignment: CrossAxisAlignment.start,
           children: [
             Row(
               children: [
                 const CircleAvatar(
                   backgroundColor: LymixPro.purple,
                   child: Icon(Icons.person),
                 ),
                 const SizedBox(width: 10),
                 Text(
                   'LYMIX Creator ${i + 1}',
                   style: const TextStyle(fontWeight: FontWeight.bold),
                 ),
                 const Spacer(),
                 const Icon(Icons.add_circle_outline),
               ],
             ),
             const SizedBox(height: 14),
             const Text('Senin gibi bir sesi bekliyoruz. Koltuğunu kap, sohbete katıl! 🎙️'),
             const SizedBox(height: 14),
             Container(
               padding: const EdgeInsets.all(16),
               decoration: BoxDecoration(
                 gradient: LymixPro.premiumGradient,
                 borderRadius: BorderRadius.circular(18),
               ),
               child: const Row(
                 children: [
                   Icon(Icons.graphic_eq),
                   SizedBox(width: 10),
                   Text(
                     'Parti Odasına Katıl',
                     style: TextStyle(fontWeight: FontWeight.w800),
                   ),
                 ],
               ),
             ),
             const SizedBox(height: 12),
             const Row(
               mainAxisAlignment: MainAxisAlignment.end,
               children: [
                 Icon(Icons.favorite_border),
                 SizedBox(width: 18),
                 Icon(Icons.chat_bubble_outline),
                 SizedBox(width: 18),
                 Icon(Icons.more_horiz),
               ],
             ),
           ],
         ),
       ),
     ),
   ],
 );
}
class GameCenterPage extends StatelessWidget { const GameCenterPage({super.key});
 @override Widget build(BuildContext c)=>ListView(children:[const Head('Oyun Merkezi'),Container(margin:const EdgeInsets.all(16),padding:const EdgeInsets.all(20),decoration:BoxDecoration(gradient:LymixPro.premiumGradient,borderRadius:BorderRadius.circular(28)),child:const Row(children:[Icon(Icons.bolt,size:36),SizedBox(width:12),Text('Seviye 22',style:TextStyle(fontSize:22,fontWeight:FontWeight.w900)),Spacer(),Icon(Icons.emoji_events,size:40)])),
 Padding(padding:const EdgeInsets.all(16),child:GridView.count(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:3,mainAxisSpacing:14,crossAxisSpacing:14,children:
 [Icons.rocket_launch,Icons.pets,Icons.phishing,Icons.sports_soccer,Icons.casino,Icons.sports_esports].map((e)=>Container(decoration:BoxDecoration(color:LymixPro.panel,borderRadius:BorderRadius.circular(22)),child:Icon(e,size:44,color:LymixPro.yellow))).toList()))]);}
class InboxPage extends StatelessWidget { const InboxPage({super.key});
 @override Widget build(BuildContext c)=>ListView(children:[const Head('Mesaj'),const Padding(padding:EdgeInsets.all(16),child:Row(mainAxisAlignment:MainAxisAlignment.spaceAround,children:[_Quick(Icons.person_add,'Uygula'),_Quick(Icons.campaign,'Aktivite'),_Quick(Icons.notifications,'Bildirim'),_Quick(Icons.visibility,'Ziyaretçiler')])),
 ...List.generate(7,(i)=>ListTile(leading:CircleAvatar(backgroundColor:i.isEven?LymixPro.purple:LymixPro.yellow,child:const Icon(Icons.person)),title:Text('LYMIX Kullanıcı ${i+1}',style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:const Text('Yeni mesaj ve oda daveti'),trailing:Text(i==0?'13 sn':'Dün')))]);}
class _Quick extends StatelessWidget {final IconData i;final String t;const _Quick(this.i,this.t);@override Widget build(BuildContext c)=>Column(children:[CircleAvatar(radius:28,backgroundColor:LymixPro.panel2,child:Icon(i,color:LymixPro.yellow)),const SizedBox(height:7),Text(t)]);}
class ProfilePage extends StatelessWidget { const ProfilePage({super.key});
 @override Widget build(BuildContext c)=>ListView(children:[const Head('Profil'),const SizedBox(height:15),const CircleAvatar(radius:52,backgroundColor:LymixPro.purple,child:Icon(Icons.person,size:56)),const SizedBox(height:12),const Center(child:Text('LYMIX CREATOR',style:TextStyle(fontSize:23,fontWeight:FontWeight.w900))),const Center(child:Text('ID: 31059515',style:TextStyle(color:LymixPro.muted))),const SizedBox(height:22),
 const Padding(padding:EdgeInsets.symmetric(horizontal:24),child:Row(mainAxisAlignment:MainAxisAlignment.spaceAround,children:[_Stat('4','Arkadaşlar'),_Stat('5','Takip'),_Stat('6','Fan')])),
 Container(margin:const EdgeInsets.all(18),padding:const EdgeInsets.all(18),decoration:BoxDecoration(gradient:LymixPro.premiumGradient,borderRadius:BorderRadius.circular(24)),child:const Row(children:[Icon(Icons.workspace_premium,size:36),SizedBox(width:14),Text('VIP Merkezi',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),Spacer(),Icon(Icons.chevron_right)])),
 Padding(padding:const EdgeInsets.all(18),child:GridView.count(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:4,children:[Icons.workspace_premium,Icons.military_tech,Icons.favorite,Icons.shopping_bag,Icons.backpack,Icons.sports_esports,Icons.groups,Icons.settings].map((e)=>Icon(e,color:LymixPro.yellow,size:34)).toList()))]);}
class _Stat extends StatelessWidget {final String n,t;const _Stat(this.n,this.t);@override Widget build(BuildContext c)=>Column(children:[Text(n,style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold)),Text(t,style:const TextStyle(color:LymixPro.muted))]);}
